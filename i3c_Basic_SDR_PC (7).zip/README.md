# I3C Basic v1.2 SDR Primary Controller IP — RTL Implementation

SystemVerilog implementation of a **MIPI I3C Basic v1.2 SDR Primary Controller**,
built up to a full-featured **Controller + Target** design.

The controller is **ASIC-synthesizable**: no `timescale` directives, no
simulation-only constructs, no FPGA-specific attributes in the synthesizable RTL.

## Highlights

- **AXI4-Lite slave** (32-bit data, 32-bit address) for register access
- **4 FIFOs**: Command, Write, Read, Response — all software-accessible
- **SDR up to 12.5 MHz** in push-pull mode
- **Open-drain / I2C fallback** via per-command flag (separate I2C FSM)
- **CCC engine**: broadcast + direct
- **DAA engine**: ENTDAA + SETDASA
- **IBI handler** (5-state FSM, single-slot latch)
- **Hot-Join handler** (4-state FSM, auto-ENTDAA trigger)
- **Group Addressing** (8-entry table, 7-bit group addr + 16-bit target bitmap)
- **PEC (CRC-8, polynomial 0x07)** — generation + checking
- **Digital Noise Filter** (programmable 0–15 cycle depth)
- **Wake-Up Detector** in PD_AON (async START + SCL edge detection)
- **Target Engine** (8-state FSM clocked by external SCL)
- **Power Domain Controller** (PD_AON ↔ PD_CORE handshake)
- **Configurable timing**: SCL high/low, SDA hold, bus free, TSU/THD start/stop
- **Static address** support for I2C fallback / SETDASA
- **Software Reset + Status** (status register survives all resets)
- **Comprehensive Interrupt System** (15-bit INTERRUPT_STATUS, W1C + mask)
- **No `timescale` directives** in synthesizable RTL (ASIC-friendly)
- **No `initial` blocks, no `$display`, no `#delays`, no FPGA attributes**

## NOT IMPLEMENTED

- HDR-DDR / HDR-BT
- Multi-Lane
- DMA descriptor rings (not present; pure register/FIFO interface)
- Arbitration (this is a primary-only controller — all ARB logic removed)
- GETACCR controller-role transfer sequencer (opcode reserved)

## BUS TOPOLOGY (DEFAULT: MIXED FAST BUS)

This IP targets a **Mixed Fast Bus** topology by default — both I3C devices
and legacy I2C devices (with 50 ns spike filters) coexist on the same
SDA/SCL pair, per MIPI I3C Basic v1.2 §4.3.2.4 Table 11.

- `BUS_CONFIG` register reset value = `0x1` (BUS_TYPE_MIXED_FAST)
- All Open-Drain / START / STOP / I2C-fallback timing defaults are Fm+
  compliant (260 ns setup/hold, 260 ns tHIGH_OD, 500 ns tLOW_OD)
- Push-pull I3C defaults: SCL_HIGH = SCL_LOW = 4 cycles = 40 ns
  (within MIPI tDIG_H_MIXED 32-45 ns range)
- SCL_HIGH_TIME_MIXED = 4 cycles = 40 ns (within 32-45 ns range)

If NO I2C devices are present on the bus, software may write `0x0` to
BUS_CONFIG to switch to Pure I3C Bus mode (removes the tDIG_H_MIXED ≤ 45 ns
cap, tiny perf gain). For Mixed Slow Bus (I2C devices without spike
filters), software must reprogram timing registers to I2C-speed values
before writing `0x2` to BUS_CONFIG.

## Why no `timescale` in synthesizable RTL?

`` `timescale 1ns / 1ps `` is a **simulator directive** that sets the time
unit and precision for `#delays`, `$time`, `$display`, etc. It has no
hardware meaning — synthesis tools silently ignore it. For pure ASIC RTL:

1. `#delays` must not exist in synthesizable code (they don't synthesize).
2. Without `#delays`, `timescale` has no effect on synthesis.
3. Keeping `timescale` in synthesizable RTL implies simulation constructs
   may be present, which is misleading and a lint red-flag.
4. Best practice: keep `timescale` only in testbenches, never in RTL.

This RTL keeps `timescale` only in `tb/tb_i3c_primary_controller_sdr.sv` (testbench);
all synthesizable modules have it removed.

## Directory Layout

```
i3c_controller_rtl/
├── i3c_controller_top.f           # filelist
├── README.md                      # this file
├── rtl/
│   ├── include/
│   │   ├── i3c_pkg.sv             # package: register offsets (*_ADDR), typedefs, enums, helpers
│   │   └── i3c_defines.svh        # compile-time macros (currently empty)
│   ├── axi/
│   │   └── axi4_lite_slave.sv     # AXI4-Lite protocol handler
│   ├── register_map/
│   │   └── i3c_register_file.sv   # all 48 config / status registers (storage flops: *_q)
│   ├── fifo/
│   │   ├── i3c_fifo.sv            # generic parametrizable FIFO
│   │   ├── i3c_cmd_fifo.sv        # command queue wrapper
│   │   ├── i3c_wr_fifo.sv         # write-data queue wrapper
│   │   ├── i3c_rd_fifo.sv         # read-data queue wrapper
│   │   └── i3c_resp_fifo.sv       # response queue wrapper
│   ├── io_pad/                    # analog frontend (OUTSIDE digital_phy)
│   │   └── i3c_iobuf.sv           # tri-state I/O buffer (ASIC pad cell wrapper)
│   ├── digital_phy/               # Digital PHY (all synthesizable PHY logic)
│   │   ├── i3c_timing_control.sv  # SCL/SDA bit-time engine (configurable via AXI4-Lite)
│   │   ├── i3c_dnf.sv             # digital noise filter
│   │   ├── i3c_byte_serdes.sv     # 32b FIFO <-> 8b bus serializer
│   │   ├── i3c_pec.sv             # PEC (CRC-8) generator/checker
│   │   ├── i3c_start_stop_gen.sv  # START/STOP condition generator
│   │   ├── i3c_phy_fsm.sv         # Digital PHY FSM coordinator
│   │   └── i3c_phy_mux.sv         # 3:1 mux: Digital PHY / Target Engine / Autonomous Bootstrap (TBD) -> iobuf
│   ├── ccc/
│   │   └── i3c_ccc_handler.sv     # CCC engine (broadcast + direct)
│   ├── daa/
│   │   └── i3c_daa.sv             # DAA sequencer (ENTDAA / SETDASA)
│   ├── ibi/
│   │   └── i3c_ibi_handler.sv     # In-Band Interrupt handler (5-state FSM)
│   ├── hj/
│   │   └── i3c_hotjoin_handler.sv # Hot-Join handler (4-state FSM)
│   ├── group/
│   │   └── i3c_group_addr.sv      # Group addressing (8-entry table)
│   ├── wake/
│   │   └── i3c_wake_detector.sv   # Async wake detector in PD_AON
│   ├── target/
│   │   └── i3c_target_engine.sv   # Target engine (8-state FSM)
│   ├── clock/
│   │   ├── i3c_clock_gate.sv      # Hierarchical clock gating cell
│   │   └── i3c_async_fifo.sv      # Dual-clock CDC FIFO (Gray-code pointers)
│   ├── power/
│   │   └── i3c_power_controller.sv# PD_AON <-> PD_CORE power handshake
│   ├── role/
│   │   └── i3c_role_manager.sv    # Role manager (Figure 186 reclaim FSM)
│   └── controller/
│       ├── i3c_primary_controller_sdr.sv  # top-level integration + I3C FSM
│       └── i2c_controller_fsm.sv          # I2C legacy controller FSM
└── tb/
    └── tb_i3c_primary_controller_sdr.sv   # smoke testbench (sim-only)
```

### Key Architecture Decisions

1. **Dual controller FSM architecture.** The controller container holds TWO FSMs:
   - `i3c_primary_controller_sdr.sv` — I3C Basic v1.2 SDR controller (active when cmd_word_t.i2c_fallback=0)
   - `i2c_controller_fsm.sv` — I2C legacy controller (active when cmd_word_t.i2c_fallback=1)
   The per-command `i2c_fallback` bit (cmd_word_t[24]) is latched into `i2c_fallback_q`
   when the FSM pops a command from the CMD FIFO. `i2c_fallback_q` selects which FSM
   drives the shared Digital PHY. The I2C FSM uses open-drain timing
   (SCL_OD_HIGH/LOW_TIME_CFG) and a prescaler-based SCL frequency
   (I2C_SPD_MODE_CFG.SPEED_PRESCALER).

2. **Separate I2C register map.** The I2C controller has its own register file
   (`rtl/register_map/i2c_register_file.sv`) at offsets 0xC0..0xF8, containing 15
   registers: I2C_TRANS_CFG, I2C_TRANS_EN_CTRL, I2C_TRANS_STATUS,
   I2C_SW_RST_CTRL, I2C_SW_RST_STATUS, I2C_SPD_MODE_CFG, I2C_TARGET_ADDR_CFG,
   I2C_TIMEOUT_CFG, I2C_ACK_STATUS, I2C_FIFO_CTRL, I2C_FIFO_STATUS,
   I2C_WDATA_TXFIFO, I2C_RDATA_RXFIFO, I2C_INT_EN_CTRL, I2C_INT_STATUS.

3. **Per-transaction config in cmd_word_t.** Repeated START, PEC enable, PEC
   append, and PEC check are all per-command bits in `cmd_word_t` (bits 24–27).
   The I3C register file does not have a TRANSACTION_CFG register; the offset
   0x04 is `I3C_SPEED_MODE_CFG` with a 3-bit SPEED_MODE field
   (0=SDR, 1=HDR-DDR, 2=HDR-BT; only SDR is implemented).

4. **Repeated START is pure FSM logic.** The I3C FSM tracks `bus_is_held_q` —
   set when a transaction completes without STOP, cleared when STOP is issued.
   In `CTRL_SEND_START`, the FSM issues REPEATED_START if `bus_is_held_q=1`,
   else START. The I2C FSM uses an analogous `rep_start_q` flag latched at
   TRANS_EN time when the bus is already held.

5. **Digital PHY contains all synthesizable PHY logic.** The `rtl/digital_phy/`
   folder holds timing_control, dnf, byte_serdes, pec, start_stop_gen, phy_fsm,
   and phy_mux. The only PHY-related block OUTSIDE this folder is the I/O pad
   buffer (`rtl/io_pad/i3c_iobuf.sv`), which is the analog frontend.

6. **PHY MUX between Digital PHY and iobuf.** The Digital PHY does NOT connect
   directly to `i3c_iobuf`. An `i3c_phy_mux` is inserted between them:
   ```
   Digital PHY (dphy_*)        ──┐
   Target Engine (tgt_*)       ──┤── PHY MUX ── iobuf (SDA/SCL pads)
   Autonomous Bootstrap (boot_*)──┘         ↑
                                phy_mux_sel (driven by i3c_role_manager)
   ```
   The mux select (`phy_mux_sel`) is driven internally by `i3c_role_manager`
   — it is NOT a top-level port and is NEVER written by software directly.
   Software influences the select indirectly via handoff commands and the
   role FSM. Three drivers share the pads: Digital PHY (active controller),
   Target Engine (target mode), and Autonomous Bootstrap (TBD).

7. **Timing Control is configurable via AXI4-Lite.** The `i3c_timing_control`
   module receives 9 `cfg_*` inputs from the register file, which is accessed
   through the AXI4-Lite slave. The configuration path:
   ```
   Host CPU → AXI4-Lite slave → Register File → cfg_* → i3c_timing_control
   ```

8. **No separate PHY register block.** All PHY configuration (timing, DNF
   threshold, PEC enable) lives in the main register file. A separate PHY
   register block is unnecessary for this single-clock design.

## Module Hierarchy

```
i3c_primary_controller_sdr               (top-level; 12-state FSM + reset synchronizer)
├── axi4_lite_slave                  (AXI4-Lite register access; SLVERR on decerr)
├── i3c_register_file                (48 I3C registers; FIFO pop/push decode; IRQ agg)
├── i2c_register_file                (15 I2C registers at 0xC0..0xF8; FIFO interface)
├── i3c_cmd_fifo                     (command queue, depth 16)
├── i3c_wr_fifo                      (write-data queue, depth 32)
├── i3c_rd_fifo                      (read-data queue, depth 32)
├── i3c_resp_fifo                    (response queue, depth 16)
├── i3c_fifo (x2)                    (I2C TX/RX FIFOs, 8-bit, depth 16)
│   └── i3c_fifo                     (generic parameterized FIFO template, used by all 6 above)
├── i3c_ccc_handler                  (CCC engine; broadcast + direct)
├── i3c_daa                          (DAA sequencer; ENTDAA / SETDASA)
├── i3c_ibi_handler                  (IBI handler; 5-state FSM)
├── i3c_hotjoin_handler              (Hot-Join handler; 4-state FSM)
├── i3c_group_addr                   (Group addressing; 8-entry table)
├── i3c_wake_detector                (Wake detector; async, in PD_AON)
├── i3c_target_engine                (Target engine; 8-state FSM, ext SCL)
├── i3c_role_manager                 (Role manager; Figure 186 reclaim FSM)
├── i3c_async_fifo                   (Dual-clock CDC FIFO; available for SoC use)
├── i3c_power_controller             (Power domain handshake; 8-state FSM)
│
├── Digital PHY (rtl/digital_phy/)   ← does NOT include iobuf
│   ├── i3c_byte_serdes              (32b FIFO <-> 8b bus serializer)
│   ├── i3c_pec                      (PEC CRC-8 generator/checker)
│   ├── i3c_start_stop_gen           (START/STOP condition generator)
│   ├── i3c_phy_fsm                  (PHY FSM coordinator; 5-state FSM)
│   │   └── i3c_timing_control       (bit-time engine; 12-state FSM; configurable via AXI4-Lite)
│   └── i3c_phy_mux                  (3:1 MUX: dphy_* / tgt_* / boot_* -> pad_*)
│
├── i3c_dnf                          (Digital noise filter; 0–15 cycles)
├── i2c_controller_fsm               (I2C legacy controller FSM; 10-state FSM)
│
└── i3c_iobuf (x2)                   (SDA + SCL tri-state pads; rtl/io_pad/)
    ↑
    └── Connected to Digital PHY through i3c_phy_mux (NOT directly)
```

## Register Map (I3C: 48 registers 0x00–0xBC, I2C: 15 registers 0xC0–0xF8)

### I3C Extension Register File

| Offset  | Register                  | Access | Description                              |
|---------|---------------------------|--------|------------------------------------------|
| 0x00    | VERSION                   | RO     | IP version (0x0001_0002 = MAJOR=1, MINOR=2) |
| 0x04    | I3C_SPEED_MODE_CFG        | RW     | [2:0] SPEED_MODE (0=SDR, 1=HDR-DDR, 2=HDR-BT) |
| 0x08    | TRANSACTION_CTRL          | RW     | [1]IBI_EN, [0]EN                         |
| 0x0C    | TRANSACTION_STATUS        | RO     | Bus active + xfer done + bytes           |
| 0x10    | INTERRUPT_ENABLE_CTRL     | RW     | Interrupt enable mask (15 bits)          |
| 0x14    | INTERRUPT_STATUS          | W1C    | Interrupt status flags (15 bits)         |
| 0x18    | IBI_ENABLE_CTRL           | RW     | [7:0]target_mask, [8]payload_en          |
| 0x1C    | IBI_STATUS                | W1C    | IBI detection (sticky)                   |
| 0x20    | IBI_QUEUE_STATUS          | RO     | Captured IBI address + payload           |
| 0x24    | HJ_ENABLE_CTRL            | RW     | Hot-Join enable + auto-DAA               |
| 0x28    | HJ_STATUS                 | W1C    | Hot-Join detected (sticky)               |
| 0x2C    | CMD_FIFO_CTRL             | WO     | Push command word                        |
| 0x30    | WR_FIFO_CTRL              | WO     | Push write-data word                     |
| 0x34    | RD_FIFO_STATUS            | RO     | Pop read-data word                       |
| 0x38    | RESP_STATUS_FIFO          | RO     | Pop response word                        |
| 0x3C    | FIFO_LVL_STATUS           | RO     | CMD/WR free space                        |
| 0x40    | FIFO_LVL_STATUS_1         | RO     | RESP/RD available words                  |
| 0x44    | TX_FIFO_STATUS            | RO     | CMD/WR detailed flags                    |
| 0x48    | RX_FIFO_STATUS            | RO     | RESP/RD detailed flags                   |
| 0x4C    | ACK_STATUS                | RO     | ACK/NACK from last transfer              |
| 0x50    | SW_RESET_CTRL             | RWSC   | Software reset (self-clearing)           |
| 0x54    | SW_RESET_STATUS           | W1C    | Reset status (survives all resets)       |
| 0x58    | FIFO_FLUSH_CTRL           | RWSC   | Per-FIFO flush (self-clearing)           |
| 0x5C    | ABORT_CTRL                | RWSC   | Abort + resume (self-clearing)           |
| 0x60    | CONTROLLER_ROLE_REQ_CFG   | RW     | Role handoff config (addr, force)        |
| 0x64    | CONTROLLER_ROLE_REQ_CTRL  | RWSC   | Role handoff trigger (self-clearing)     |
| 0x68    | SCL_HIGH_TIME_CFG         | RW     | SCL high period (PCLK cycles)            |
| 0x6C    | SCL_LOW_TIME_CFG          | RW     | SCL low period (PCLK cycles)             |
| 0x70    | SDA_HOLD_TIME_CFG         | RW     | SDA hold time                            |
| 0x74    | BUS_FREE_TIME_CFG         | RW     | Bus idle between STOP/START              |
| 0x78    | TSU_START_CFG             | RW     | START setup time                         |
| 0x7C    | THD_START_CFG             | RW     | START hold time                          |
| 0x80    | TSU_STOP_CFG              | RW     | STOP setup time                          |
| 0x84    | SCL_OD_HIGH_TIME_CFG      | RW     | SCL high (open-drain / I2C)              |
| 0x88    | SCL_OD_LOW_TIME_CFG       | RW     | SCL low (open-drain / I2C)               |
| 0x8C    | DNF_CTRL                  | RW     | Noise filter enable + threshold          |
| 0x90    | WAKE_CTRL                 | RW     | Wake enable + START/SCL detect           |
| 0x94    | WAKE_STATUS               | W1C    | Wake source (survives resets)            |
| 0x98    | CLK_GATE_CTRL             | RW     | Clock gating (global + sub-module)       |
| 0x9C    | POWER_CTRL                | RW     | Power domain request + acknowledge       |
| 0xA0    | TARGET_CTRL               | RW     | Target enable + addr + IBI               |
| 0xA4    | TARGET_STATUS             | RO     | Target addressed + NACK                  |
| 0xA8    | GROUP_ADDR_CFG            | RW     | Group enable + count                     |
| 0xAC    | GROUP_ADDR_TBL_CFG        | RW     | Group table (8 entries, indexed)         |
| 0xB0    | STATIC_ADDR_CFG           | RW     | Static address for SETDASA               |
| 0xB4    | PID0_STATUS               | RO     | Provisioned ID lower 32 bits             |
| 0xB8    | PID1_BCR_DCR_STATUS       | RO     | PID upper + BCR + DCR                    |
| 0xBC    | MWL_MRL_CTRL              | RW     | Max Write/Read Length                    |

### I2C Controller Register File (0xC0–0xF8, 15 registers)

| Offset  | Register                  | Access | Field description                        |
|---------|---------------------------|--------|------------------------------------------|
| 0xC0    | I2C_TRANS_CFG             | R/W    | [7:0]XFER_LENGTH (default=0x01)          |
| 0xC4    | I2C_TRANS_EN_CTRL         | RWSC   | [0]TRANS_EN                              |
| 0xC8    | I2C_TRANS_STATUS          | RO     | [11:4]BYTES_XFERD, [3]DATA_LOST, [2]CMD_ABORTED, [1]BUSY, [0]XFER_DONE |
| 0xCC    | I2C_SW_RST_CTRL           | RWSC   | [0]SW_RESET                              |
| 0xD0    | I2C_SW_RST_STATUS         | W1C    | [0]SW_RST_OCCURRED                       |
| 0xD4    | I2C_SPD_MODE_CFG          | R/W    | [19:0]SPEED_PRESCALER                   |
| 0xD8    | I2C_TARGET_ADDR_CFG       | R/W    | [7:1]TARGET_ADDR, [0]RnW                 |
| 0xDC    | I2C_TIMEOUT_CFG           | R/W    | [15:0]TIMEOUT                            |
| 0xE0    | I2C_ACK_STATUS            | RWSC   | [1]DATA_NACK, [0]SLV_ADDR_ACK            |
| 0xE4    | I2C_FIFO_CTRL             | RWSC   | [1]RX_FIFO_FLUSH, [0]TX_FIFO_FLUSH       |
| 0xE8    | I2C_FIFO_STATUS           | RO     | [5:0]RX/TX clear/full/empty flags        |
| 0xEC    | I2C_WDATA_TXFIFO          | WO     | [7:0]TXDATA (push to TX FIFO)            |
| 0xF0    | I2C_RDATA_RXFIFO          | RO     | [7:0]RXDATA (pop from RX FIFO)           |
| 0xF4    | I2C_INT_EN_CTRL           | R/W    | [4:0]enable bits                         |
| 0xF8    | I2C_INT_STATUS            | W1C    | [4:0]status bits                         |

Naming convention:
- `_CTRL` = control register (real-time actions)
- `_CFG`  = configuration register (static setup)
- `_STATUS` = status register (read-only or W1C sticky)

Access modes: **RO** = read-only, **RW** = read/write, **WO** = write-only,
**W1C** = write-1-to-clear sticky, **RWSC** = read/write self-clearing.

## Command FIFO Format (32-bit)

```
 bits 31..28 : reserved
 bit      27 : pec_append     (1 = append PEC byte on write)
 bit      26 : pec_check      (1 = check PEC byte on read)
 bit      25 : pec_en         (1 = enable PEC for this transaction)
 bit      24 : i2c_fallback   (1 = use I2C mode & open-drain timing)
 bits 23..16 : byte_cnt_m1    (0..255 → 1..256 bytes) = XFER_LENGTH-1
 bits 15..9  : dev_addr       (7-bit I3C dynamic address)
 bit       8 : rnw            (1 = read, 0 = write)
 bits  7..0  : opcode         (see cmd_opcode_e in i3c_pkg)
```

Note: REPEATED_START is NOT a command bit — it is pure FSM logic.
The I3C FSM tracks `bus_is_held_q` and issues REPEATED_START automatically
when a new transaction starts and the bus is held.

Opcodes:
- 0x00 NOP
- 0x01 START
- 0x02 STOP
- 0x03 PRIVATE_XFER (direction selected by rnw bit)
- 0x05 CCC_BROADCAST
- 0x06 CCC_DIRECT
- 0x07 ENTDAA
- 0x08 SETDASA
- 0x09 RST_PATTERN (sends RSTACT CCC)
- 0x0A GETACCR (controller role transfer)

## Response FIFO Format (32-bit)

```
 bits 31..19 : reserved
 bit      18 : timeout
 bit      17 : nack
 bit      16 : reserved (was pec_err; PEC errors now in INTERRUPT_STATUS)
 bits 15..8  : xfer_len  (bytes actually transferred)
 bits  7..0  : code      (resp_code_e in i3c_pkg)
```

Response codes: 0x00 SUCCESS, 0x01 NACK_ADDR, 0x02 NACK_DATA,
0x04 TIMEOUT, 0x06 FIFO_UNDERFLOW, 0x07 FIFO_OVERFLOW,
0x08 INVALID_CMD, 0x09 BUSY.

## Software Usage Flow

1. **Reset & program timing registers** based on `C_AXI_CLK_FREQ / C_SCL_CLK_FREQ`.
2. **(Optional)** Program `STATIC_ADDR_CFG` for I2C fallback / SETDASA use.
3. **For a private write** to target at 0x42 of 4 bytes `[A B C D]`:
   - Push 4 bytes to WR_FIFO_CTRL: `{D, C, B, A}` (LSB byte first within word)
   - Push to CMD_FIFO_CTRL: `opcode=PRIVATE_WR(0x03)`, `dev_addr=0x42`, `rnw=0`,
     `byte_cnt_m1=3`.
4. **For a private read** of 4 bytes from 0x42:
   - Push to CMD_FIFO_CTRL: `opcode=PRIVATE_RD(0x04)`, `dev_addr=0x42`, `rnw=1`,
     `byte_cnt_m1=3`.
   - Poll RESP_STATUS_FIFO until non-empty, pop the response, then read 1 word
     from RD_FIFO_STATUS.
5. **For a CCC broadcast** `DISEC` (0x01):
   - Push 1 byte `0x01` to WR_FIFO_CTRL: `0x0000_0001`
   - Push to CMD_FIFO_CTRL: `opcode=CCC_BROADCAST(0x05)`, `dev_addr=0x7E`, `rnw=0`,
     `byte_cnt_m1=0`.
6. **For DAA**:
   - Push to CMD_FIFO_CTRL: `opcode=ENTDAA(0x07)`.
   - Poll RESP_STATUS_FIFO; for each target found, one 32-bit word will appear in
     RD_FIFO_STATUS containing the assigned dynamic address + BCR + DCR + PID[7:0].
7. **Poll RESP_STATUS_FIFO** for completion / error code. Poll `FIFO_LVL_STATUS` /
   `FIFO_LVL_STATUS_1` for FIFO occupancy. Poll the `controller_busy` /
   `controller_idle` top-level status pins for bus state.
8. **Enable interrupts** by writing `INTERRUPT_ENABLE_CTRL`, then either poll
   `INTERRUPT_STATUS` (W1C) or wire the `irq` top-level output to your GIC.

## ASIC-Synthesizable Notes

- **No `timescale`** directives in synthesizable RTL (testbench keeps one).
- **No `initial` blocks** for register init — all registers use async active-low
  `rst_n` for reset.
- **No `$display` / `$error` / `$finish`** in synthesizable RTL.
- **No `#delays`** in synthesizable RTL.
- **No FPGA-specific attributes** (e.g. `(* PULLUP = "YES" *)`) — replaced with
  a comment describing how to instantiate the pad cell at the floorplan.
- **Tri-state inference**: `assign pad = pad_oe ? pad_o : 1'bz;` is left as
  portable RTL; ASIC synthesis will map to a pad library cell, FPGA synthesis
  to an IOBUF primitive.
- **Reset polarity**: active-low (`rst_n`), async-assert / sync-deassert via
  2-stage synchronizer in `i3c_primary_controller_sdr.sv`.
- **Single clock domain**: `s_axi_aclk` only. `clk` inside the controller is
  an alias: `assign clk = s_axi_aclk`.

## Build / Simulate

```bash
# Using Icarus Verilog (smoke test)
iverilog -g2012 -timescale=1ns/1ps -f i3c_controller_top.f \
    tb/tb_i3c_primary_controller_sdr.sv -o tb.vvp
vvp tb.vvp

# Using Verilator
verilator --binary --top-module tb_i3c_primary_controller_sdr \
    -f i3c_controller_top.f tb/tb_i3c_primary_controller_sdr.sv

# ASIC synthesis (example with Design Compiler)
dc_shell -f synth.tcl  # user-provided; reads i3c_controller_top.f
```

## License

MIT.
