// =============================================================================
// i3c_role_manager.sv
// -----------------------------------------------------------------------------
// Role Management FSM for the I3C Primary Controller.
// Reset declaration order, role_return sync, parameterized clock
// =============================================================================


module i3c_role_manager #(
    parameter int unsigned CLK_FREQ_MHZ = 100  // Parameterized for different SoC clocks
) (
    input  logic        clk_sys,
    input  logic        rst_sys_n,

    // --- Configuration (from register file) ---
    input  logic        reclaim_en,
    input  logic [15:0] reclaim_timeout_us,

    // --- Handoff control (from controller FSM) ---
    input  logic        handoff_trigger,
    input  logic        getacccr_done,
    input  logic        getacccr_ack,
    input  logic        getacccr_addr_nack,
    input  logic        getacccr_data_nack,

    // --- Bus activity detection (from DNF / io_buf) ---
    input  logic        scl_falling,
    input  logic        sda_falling,

    // Filtered SCL/SDA line levels (kept as TB-only observation hooks;
    // not used internally — the FSM only acts on falling edges above).
    input  logic        scl_filt,
    input  logic        sda_filt,

    // --- Bootstrap control (from Autonomous Bootstrap (TBD)) ---
    input  logic        bootstrap_active,

    // --- Outputs to controller FSM ---
    output logic        role_is_controller,
    output logic        role_is_target,
    output logic        reclaim_in_progress,
    output logic        handoff_done_pulse,
    output logic        handoff_failed_pulse,
    output logic [1:0]  handoff_fail_reason,
    output logic [1:0]  handoff_status,

    // --- Outputs to phy_mux ---
    output logic [1:0]  phy_mux_sel,

    // --- Outputs to target_engine ---
    output logic        target_engine_en,

    // Voluntary return input (from target engine)
    // Now synchronized internally
    input  logic        role_return,

    // --- Outputs to register file (status readback) ---
    output logic [2:0]  role_state_out
);

  // -------------------------------------------------------------------------
  // Reset synchronizer — DECLARED BEFORE USE
  // -------------------------------------------------------------------------
  logic rst_sync1, rst_sync2;
  always_ff @(posedge clk_sys or negedge rst_sys_n) begin
    if (!rst_sys_n) begin
      rst_sync1 <= 1'b0;
      rst_sync2 <= 1'b0;
    end else begin
      rst_sync1 <= 1'b1;
      rst_sync2 <= rst_sync1;
    end
  end
  wire rst_sys_n_sync = rst_sync2;

  // -------------------------------------------------------------------------
  // role_return: synchronized externally by the parent controller
  // (i3c_primary_controller_sdr.sv feeds role_return_synced through a 3-flop
  // synchronizer from the scl_filt domain). Use it directly — no additional
  // synchronizer needed here. If a future integration feeds raw role_return
  // (unsynchronized), add a 2-flop synchronizer here.
  // -------------------------------------------------------------------------
  wire role_return_eff = role_return;

  // -------------------------------------------------------------------------
  // State register (3-bit encoded)
  // -------------------------------------------------------------------------
  logic [2:0] state_q, state_d;

  // -------------------------------------------------------------------------
  // 100 µs bus-idle timer (the "Reclaim Time Monitor")
  // Counts clk_sys cycles since last SCL/SDA falling edge.
  // Parameterized CLK_FREQ_MHZ ensures correct timing at any frequency.
  // -------------------------------------------------------------------------
  localparam int unsigned TIMER_WIDTH   = 24;
  logic [TIMER_WIDTH-1:0] idle_cnt_q, idle_cnt_d;
  logic [TIMER_WIDTH-1:0] idle_threshold;
  logic                   idle_timer_rst;
  logic                   idle_timer_expired;

  // Use parameterized clock frequency
  always_comb begin
    idle_threshold = (reclaim_timeout_us == 0)        ? 24'd100 * CLK_FREQ_MHZ :
                     (reclaim_timeout_us > 16'd1000)  ? 24'd1000 * CLK_FREQ_MHZ :
                                                        reclaim_timeout_us * CLK_FREQ_MHZ;
  end

  assign idle_timer_rst = scl_falling | sda_falling | handoff_trigger |
                          ((state_q == 3'd2) && reclaim_en && idle_timer_expired);

  always_ff @(posedge clk_sys or negedge rst_sys_n_sync) begin
    if (!rst_sys_n_sync)
      idle_cnt_q <= '0;
    else if (idle_timer_rst)
      idle_cnt_q <= '0;
    else if (idle_cnt_q < idle_threshold)
      idle_cnt_q <= idle_cnt_q + 1'b1;
  end

  assign idle_timer_expired = (idle_cnt_q >= idle_threshold);

  // -------------------------------------------------------------------------
  // Handoff status encoding
  // 0 = idle (no handoff in progress)
  // 1 = ok (handoff succeeded)
  // 2 = fail_no_tgt (addr NACK)
  // 3 = fail_not_capable (data NACK)
  // -------------------------------------------------------------------------
  logic [1:0] handoff_status_q;

  always_ff @(posedge clk_sys or negedge rst_sys_n_sync) begin
    if (!rst_sys_n_sync)
      handoff_status_q <= 2'd0;  // idle
    else if (handoff_trigger)
      handoff_status_q <= 2'd0;  // clear on new handoff
    else if ((state_q == 3'd1) && getacccr_done) begin
      if (getacccr_ack)
        handoff_status_q <= 2'd1;  // ok
      else if (getacccr_addr_nack)
        handoff_status_q <= 2'd2;  // fail_no_tgt
      else if (getacccr_data_nack)
        handoff_status_q <= 2'd3;  // fail_not_capable
    end
  end

  // -------------------------------------------------------------------------
  // Pulse outputs (1-cycle) — edge-detected on getacccr_done rising edge
  // -------------------------------------------------------------------------
  logic getacccr_done_q;
  logic handoff_done_q, handoff_failed_q;

  always_ff @(posedge clk_sys or negedge rst_sys_n_sync) begin
    if (!rst_sys_n_sync) begin
      getacccr_done_q   <= 1'b0;
      handoff_done_q    <= 1'b0;
      handoff_failed_q  <= 1'b0;
    end else begin
      getacccr_done_q  <= getacccr_done;
      handoff_done_q   <= (state_q == 3'd1) && getacccr_done && !getacccr_done_q && getacccr_ack;
      handoff_failed_q <= (state_q == 3'd1) && getacccr_done && !getacccr_done_q &&
                          (getacccr_addr_nack | getacccr_data_nack);
    end
  end

  assign handoff_done_pulse   = handoff_done_q;
  assign handoff_failed_pulse = handoff_failed_q;
  assign handoff_status       = handoff_status_q;
  assign handoff_fail_reason  = (handoff_status_q == 2'd2) ? 2'd1 :
                                  (handoff_status_q == 2'd3) ? 2'd2 : 2'd0;

  // -------------------------------------------------------------------------
  // Reclaim phase counter
  // -------------------------------------------------------------------------
  logic [15:0] reclaim_cnt_q;
  localparam logic [15:0] RECLAIM_DURATION = 16'd10000;  // 100µs at 100 MHz

  always_ff @(posedge clk_sys or negedge rst_sys_n_sync) begin
    if (!rst_sys_n_sync)
      reclaim_cnt_q <= '0;
    else if (state_q == 3'd4)  // ROLE_RECLAIMING
      reclaim_cnt_q <= reclaim_cnt_q + 1'b1;
    else
      reclaim_cnt_q <= '0;
  end

  // -------------------------------------------------------------------------
  // Next-state logic (Figure 186 simplified)
  // Uses role_return_sync (not raw role_return)
  // -------------------------------------------------------------------------
  always_comb begin
    state_d = state_q;
    unique case (state_q)
      3'd0: begin  // ROLE_ACTIVE_CONTROLLER
        if (bootstrap_active)
          state_d = 3'd7;
        else if (handoff_trigger)
          state_d = 3'd1;
      end
      3'd1: begin  // ROLE_PREPARING_HANDOFF
        if (getacccr_done) begin
          if (getacccr_ack)
            state_d = 3'd2;
          else
            state_d = 3'd6;
        end
      end
      3'd2: begin  // ROLE_MONITORING_NEW
        if (role_return_eff)
          state_d = 3'd0;  // Return to active controller
        else if (scl_falling || sda_falling)
          state_d = 3'd5;  // bus activity → TARGET directly
        else if (idle_timer_expired)
          state_d = 3'd3;  // idle timeout → TESTING_NEW (not RECLAIMING)
      end
      3'd3: begin  // ROLE_TESTING_NEW
        if (role_return_eff)
          state_d = 3'd0;
        else if (scl_falling || sda_falling)
          state_d = 3'd5;  // New controller is active, become target
        else if (reclaim_en && idle_timer_expired)
          state_d = 3'd4;  // Reclaim bus after second idle timeout
      end
      3'd4: begin  // ROLE_RECLAIMING
        if (reclaim_cnt_q >= RECLAIM_DURATION)
          state_d = 3'd0;  // Back to active controller
      end
      3'd5: begin  // ROLE_TARGET
        if (role_return_eff)
          state_d = 3'd0;
        else if (reclaim_en && idle_timer_expired)
          state_d = 3'd4;
      end
      3'd6: begin  // ROLE_HANDOFF_FAILED
        if (handoff_trigger)
          state_d = 3'd1;  // Retry handoff
        else
          state_d = 3'd0;  // auto-recover to ACTIVE immediately
      end
      3'd7: begin  // ROLE_BOOTSTRAP
        if (!bootstrap_active)
          state_d = 3'd0;
      end
      default: state_d = 3'd0;
    endcase
  end

  always_ff @(posedge clk_sys or negedge rst_sys_n_sync) begin
    if (!rst_sys_n_sync)
      state_q <= 3'd0;
    else
      state_q <= state_d;
  end

  // -------------------------------------------------------------------------
  // Output assignments
  // -------------------------------------------------------------------------
  assign role_is_controller = (state_q == 3'd0) || (state_q == 3'd1) || (state_q == 3'd6);
  assign role_is_target     = (state_q == 3'd2) || (state_q == 3'd3) || (state_q == 3'd5);
  assign reclaim_in_progress = (state_q == 3'd4);
  // target_engine_en: asserted in MONITORING_NEW (state 2), TESTING_NEW (state 3),
  // and TARGET (state 5). During MONITORING/TESTING, the controller has handed
  // off and must listen as a target — the target engine must be enabled to
  // detect its address. The PHY mux also switches to TARGET mode.
  // (Reverted from state_q==3'd5 only — that broke tb_i3c_role_manager which
  // correctly expects target_engine_en=1 during MONITORING.)
  assign target_engine_en    = (state_q == 3'd2) || (state_q == 3'd3) || (state_q == 3'd5);

  assign phy_mux_sel = ((state_q == 3'd2) || (state_q == 3'd3) || (state_q == 3'd5)) ? 2'd1 :  // PHY_MUX_TARGET
                       (state_q == 3'd7) ? 2'd2 :  // PHY_MUX_BOOT
                                           2'd0;   // PHY_MUX_DPHY

  assign role_state_out = state_q;

endmodule : i3c_role_manager

