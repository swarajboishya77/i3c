// =============================================================================
// i3c_ibi_handler.sv
// Rewritten to match controller's bus-level interface
// Monitors SDA/SCL directly, requests bus control, drives bus transactions
// Uses i3c_target_table for MRL lookup
// =============================================================================

import i3c_pkg::*;

module i3c_ibi_handler (
    input  logic        clk,
    input  logic        rst_n,

    // -------------------------------------------------------------------------
    // IBI enable (from register file / ENEC-DISEC CCC decode)
    // -------------------------------------------------------------------------
    input  logic        ibi_enable,       // 1 = IBI processing enabled

    // -------------------------------------------------------------------------
    // Bus monitoring (direct from pads, synchronized by caller or internally)
    // -------------------------------------------------------------------------
    input  logic        bus_idle,         // Bus is idle (no transaction)
    input  logic        controller_idle,  // Main FSM is idle
    input  logic        sda_i,            // SDA input (async, sampled internally)
    input  logic        scl_i,            // SCL input (async, sampled internally)

    // -------------------------------------------------------------------------
    // Bus control request (to controller FSM arbiter)
    // -------------------------------------------------------------------------
    output logic        ibi_req_bus,      // Request bus control
    output logic        ibi_req_start,    // Request START condition
    output logic        ibi_req_recv_byte,// Request byte receive
    output logic        ibi_req_nack,     // NACK (last byte indicator)
    output logic        ibi_req_stop,     // Request STOP condition

    // -------------------------------------------------------------------------
    // Bus status (from controller bus interface)
    // -------------------------------------------------------------------------
    input  logic        bus_done,         // Bus operation complete
    input  logic        bus_ack_recv,     // ACK received for byte
    input  logic [7:0]  bus_byte_rx,      // last received byte from bus (TB hook; not used internally)

    // -------------------------------------------------------------------------
    // FIFO output (IBI data to software)
    // -------------------------------------------------------------------------
    output logic        ibi_fifo_push,
    output logic [31:0] ibi_fifo_push_data, // {MDB[7:0], Payload_len[7:0], DA[6:0], RSVD[8:0]}

    // -------------------------------------------------------------------------
    // Status outputs
    // -------------------------------------------------------------------------
    output logic        ibi_irq,          // IBI interrupt to host
    output logic        ibi_active,       // IBI processing active

    // -------------------------------------------------------------------------
    // CRR (Controller Role Request) detection
    // -------------------------------------------------------------------------
    output logic        crr_received,     // Secondary controller wants bus
    output logic [6:0]  crr_dev_addr,     // Address of requesting device
    output logic [6:0]  ibi_detected_addr,  // Detected IBI target address for MRL lookup

    // -------------------------------------------------------------------------
    // HJ (Hot-Join) detection — IBI from address 0x02/W per spec §4.3.5
    // -------------------------------------------------------------------------
    output logic        hj_received,      // Hot-Join request detected on bus

    // -------------------------------------------------------------------------
    // Target table interface (for MRL lookup)
    // -------------------------------------------------------------------------
    output logic [6:0]  ibi_lookup_da,
    input  logic [3:0]  ibi_lookup_idx,
    input  logic        ibi_lookup_valid,
    input  logic [15:0] ibi_lookup_mrl,
    input  logic [7:0]  ibi_lookup_ibi_max,
    input  logic [7:0]  ibi_lookup_bcr
);

  // Forward declaration (Vivado VRFC requires declaration before use)
  logic [7:0]  ibi_da;               // DA of IBI-issuing device

  // ibi_detected_addr driven from captured IBI DA
  assign ibi_detected_addr = ibi_da[6:0];

  // -------------------------------------------------------------------------
  // SDA/SCL synchronizers (2-flop, prevent metastability)
  // -------------------------------------------------------------------------
  logic sda_meta, sda_sync, sda_dly;
  logic scl_meta, scl_sync, scl_dly;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sda_meta <= 1'b1; sda_sync <= 1'b1; sda_dly <= 1'b1;
      scl_meta <= 1'b1; scl_sync <= 1'b1; scl_dly <= 1'b1;
    end else begin
      sda_meta <= sda_i;  sda_sync <= sda_meta; sda_dly <= sda_sync;
      scl_meta <= scl_i;  scl_sync <= scl_meta; scl_dly <= scl_sync;
    end
  end

  // Edge detection
  logic scl_rise, scl_fall, sda_rise, sda_fall;
  assign scl_rise = scl_sync && !scl_dly;
  assign scl_fall = !scl_sync && scl_dly;
  assign sda_rise = sda_sync && !sda_dly;
  assign sda_fall = !sda_sync && sda_dly;

  // START/STOP detection (I3C spec)
  logic start_detected, stop_detected;
  assign start_detected = sda_fall && scl_sync;  // SDA falls while SCL high
  assign stop_detected  = sda_rise && scl_sync;   // SDA rises while SCL high

  // -------------------------------------------------------------------------
  // Bit counter and shift register for address/data capture
  // -------------------------------------------------------------------------
  logic [3:0] bit_cnt;
  logic [7:0] shift_reg;
  logic [7:0] addr_byte;      // 7-bit address + R/W
  logic [6:0] rx_addr;        // Extracted 7-bit address
  logic       rx_rnw;         // R/W bit
  logic       addr_match;     // Address matches a known target
  logic [3:0] matched_idx;    // Index of matched target

  assign addr_byte = shift_reg;
  assign rx_addr   = addr_byte[7:1];
  assign rx_rnw    = addr_byte[0];

  // At the 8th SCL rising edge (bit_cnt==7), shift_reg has
  // only 7 bits shifted in (bits [6:0] = addr[6:0]). The 8th bit (R/W) is in
  // sda_sync, about to be shifted in via NBA. The old code used shift_reg[7:1]
  // and shift_reg[0], which read stale/wrong bits. Use the "next" byte instead.
  logic [7:0] addr_byte_next;
  logic [6:0] rx_addr_next;
  logic       rx_rnw_next;

  assign addr_byte_next = {shift_reg[6:0], sda_sync};
  assign rx_addr_next   = addr_byte_next[7:1];
  assign rx_rnw_next    = addr_byte_next[0];

  // IBI State Machine Enum
  // -------------------------------------------------------------------------
  typedef enum logic [3:0] {
    IBI_IDLE,
    IBI_WAIT_BUS,       // Waiting for bus to be idle
    IBI_MONITOR_ADDR,   // Monitoring address phase after START
    IBI_CHECK_IBI,      // Check if this is an IBI (7E/R + NACK)
    IBI_REQ_BUS,        // Request bus control from controller
    IBI_RECV_MDB,       // Receive MDB byte
    IBI_RECV_PAYLOAD, // Receive payload bytes
    IBI_COMPLETE,       // Push to FIFO, generate IRQ
    IBI_REJECT,         // Not an IBI or rejected
    IBI_CRR_DETECT      // Controller Role Request detected
  } ibi_state_e;

  ibi_state_e state, next_state;

  // During MONITOR_ADDR, use the look-ahead address. Afterwards, rx_addr is stable 
  // until the MDB starts shifting in.
  assign ibi_lookup_da = (state == IBI_MONITOR_ADDR) ? rx_addr_next : rx_addr;

  always_comb begin
    addr_match = ibi_lookup_valid;
    matched_idx = ibi_lookup_idx;
  end

  logic [7:0] latched_bcr;

  // -------------------------------------------------------------------------
  // IBI State Machine (moved up for declare-before-use)
  // -------------------------------------------------------------------------

  // Payload tracking
  logic [7:0]  mdb_byte;
  logic [2:0]  mdb_priority;
  logic [15:0] payload_cnt;
  logic [15:0] max_payload;

  // CRR detection
  logic crr_pending;
  logic [6:0] crr_addr;

  // HJ detection (per spec §4.3.5: IBI from address 0x02/W)
  logic hj_pending;

  // IBI type latches — registered, set when IBI_MONITOR_ADDR detects the type,
  // cleared on entry to IBI_MONITOR_ADDR.
  logic ibi_type_is_hj;   // 1 = Hot-Join request (addr 0x02/W per spec §4.3.5)
  logic ibi_type_is_crr;  // 1 = Controller Role Request (target DA/W per spec §4.3.6.3)

  // IBI enable (from register file - could be input)
  // ibi_enable now connected via port from primary controller register

  // -------------------------------------------------------------------------
  // State register and sequential logic
  // -------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state        <= IBI_IDLE;
      bit_cnt      <= '0;
      shift_reg    <= '0;
      mdb_byte     <= '0;
      payload_cnt  <= '0;
      ibi_da       <= '0;
      crr_pending  <= 1'b0;
      crr_addr     <= '0;
      hj_pending   <= 1'b0;
      ibi_type_is_hj  <= 1'b0;
      ibi_type_is_crr <= 1'b0;
      max_payload  <= '0;
    end else begin
      state <= next_state;

      // Clear IBI type latches on entry to IBI_MONITOR_ADDR (fresh START)
      if (next_state == IBI_MONITOR_ADDR) begin
        ibi_type_is_hj  <= 1'b0;
        ibi_type_is_crr <= 1'b0;
      end

      if (state == IBI_CHECK_IBI && next_state == IBI_REQ_BUS) begin
        ibi_da <= {1'b0, rx_addr};
        max_payload <= (ibi_lookup_ibi_max != 8'h00) ?
                       ibi_lookup_ibi_max :
                       (ibi_lookup_mrl != 16'hFFFF) ?
                       ibi_lookup_mrl : 16'd256;
      end

      // Bit shifting on SCL rise
      if (scl_rise) begin
        shift_reg <= {shift_reg[6:0], sda_sync};
        if (bit_cnt == 4'd8)
          bit_cnt <= 4'd0;
        else
          bit_cnt <= bit_cnt + 1'b1;
          
        if (state == IBI_MONITOR_ADDR && bit_cnt == 4'd7) begin
            latched_bcr <= ibi_lookup_bcr;
        end
      end

      // Byte complete — capture at the 8th SCL rise (bit_cnt==7)
      // At this point, 7 bits are in shift_reg[6:0] and the 8th bit (sda_sync)
      // is about to be shifted in. Capture the full byte {shift_reg[6:0], sda_sync}.
      if (scl_rise && bit_cnt == 4'd7) begin
        if (state == IBI_RECV_MDB) begin
          mdb_byte <= {shift_reg[6:0], sda_sync};
          // $display("[%0t] Captured MDB: %h, shift_reg: %h, sda_sync: %b", $time, {shift_reg[6:0], sda_sync}, shift_reg, sda_sync);
        end else if (state == IBI_RECV_PAYLOAD)
          payload_cnt <= payload_cnt + 1'b1;
      end

      // Reset bit counter on START/STOP
      if (start_detected || stop_detected)
        bit_cnt <= '0;

      // CRR detection: Controller Role Request via target DA/W
      // Per spec §4.3.6.3, CRR is detected when a controller-capable target
      // (BCR[7:6]=2'b01) sends its DA + RnW=0 (Write).
      if (state == IBI_MONITOR_ADDR && bit_cnt == 4'd7 && scl_rise) begin
        if (addr_match && rx_rnw_next == 1'b0 && ibi_lookup_bcr[6]) begin
          crr_pending <= 1'b1;
          crr_addr    <= rx_addr_next;
          ibi_type_is_crr <= 1'b1;  // registered latch for CRR type
        end
        // HJ detection: address 0x02/W per spec §4.3.5
        if (rx_addr_next == 7'h02 && rx_rnw_next == 1'b0)
          ibi_type_is_hj <= 1'b1;  // registered latch for HJ type
      end

      // HJ detection: IBI from address 0x02/W per spec §4.3.5.
      // Set hj_pending when the IBI handler successfully ACKs the HJ request.
      if (state == IBI_CHECK_IBI && next_state == IBI_REQ_BUS && ibi_type_is_hj)
        hj_pending <= 1'b1;
      // Auto-clear hj_pending when controller starts DAA (handled externally
      // by hj_clear input if needed — for now it stays sticky until reset).
    end
  end

  // -------------------------------------------------------------------------
  // Next-state logic
  // -------------------------------------------------------------------------
  always_comb begin
    next_state = state;

    // Default outputs
    ibi_req_bus       = 1'b0;
    ibi_req_start     = 1'b0;
    ibi_req_recv_byte = 1'b0;
    ibi_req_nack      = 1'b0;
    ibi_req_stop      = 1'b0;
    ibi_fifo_push     = 1'b0;
    ibi_fifo_push_data = '0;
    ibi_irq           = 1'b0;
    ibi_active        = 1'b0;
    crr_received      = crr_pending;
    crr_dev_addr      = crr_addr;
    hj_received       = hj_pending;
    mdb_priority      = 3'd0;  // default to prevent latch

    unique case (state)
      IBI_IDLE: begin
        if (ibi_enable && start_detected)
          next_state = IBI_WAIT_BUS;
      end

      IBI_WAIT_BUS: begin
        if (bus_idle && controller_idle)
          next_state = IBI_MONITOR_ADDR;
        else if (stop_detected)
          next_state = IBI_IDLE;
      end

      IBI_MONITOR_ADDR: begin
        ibi_active = 1'b1;
        if (bit_cnt == 4'd7 && scl_rise) begin
          // Use rx_addr_next/rx_rnw_next which include the 8th bit being sampled.
          // Per MIPI I3C Basic v1.2:
          //   - IBI: target DA + RnW=1 (Read) from a target with BCR[1]=1
          //   - Hot-Join: reserved address 0x02 + RnW=0 (Write)  [spec §4.3.5]
          //   - Controller Role Request: target DA + RnW=0 (Write) from a target
          //     with BCR[7:6]=2'b01 (Controller-capable)  [spec §4.3.6.3]
          // The actual ibi_type_is_hj/crr latches are set in the always_ff
          // block below (registered, no latch inference).
          if (rx_addr_next == 7'h7E && rx_rnw_next == 1'b1)
            next_state = IBI_CHECK_IBI;  // 7E/R during DAA — not an IBI but a DAA pattern
          else if (rx_addr_next == 7'h02 && rx_rnw_next == 1'b0) begin
            // Hot-Join Request: address 0x02 / Write
            next_state = IBI_CHECK_IBI;
          end else if (addr_match && rx_rnw_next == 1'b1 && ibi_lookup_bcr[1])
            next_state = IBI_CHECK_IBI;  // Target with IBI capability
          else if (addr_match && rx_rnw_next == 1'b0 && ibi_lookup_bcr[6]) begin
            // Controller Role Request from controller-capable target
            next_state = IBI_CHECK_IBI;
          end
          else
            next_state = IBI_REJECT;
        end
        if (stop_detected)
          next_state = IBI_IDLE;
      end

      IBI_CHECK_IBI: begin
        ibi_active = 1'b1;
        // Wait for ACK/NACK phase (9th bit)
        if (scl_rise && bit_cnt == 4'd8) begin  // ACK bit position
          if (sda_sync == 1'b0) begin
            // ACKed - this is an IBI from a known target
            next_state = IBI_REQ_BUS;
          end else begin
            // NACKed - could be IBI arbitration
            next_state = IBI_REJECT;
          end
        end
        if (stop_detected)
          next_state = IBI_IDLE;
      end

      IBI_REQ_BUS: begin
        ibi_active = 1'b1;
        ibi_req_bus = 1'b1;
        if (bus_done) begin  // Controller grants bus
          if (ibi_type_is_crr) begin
            // Controller Role Request: no MDB, complete immediately
            next_state = IBI_COMPLETE;
          end else if (ibi_type_is_hj) begin
            // Hot-Join: no MDB, complete immediately
            next_state = IBI_COMPLETE;
          end else begin
            // Normal IBI: receive Mandatory Data Byte
            ibi_req_recv_byte = 1'b1;
            next_state = IBI_RECV_MDB;
          end
        end
      end

      IBI_RECV_MDB: begin
        ibi_active = 1'b1;
        ibi_req_recv_byte = 1'b1;
        if (bus_done) begin
          // mdb_byte captured in always_ff
          mdb_priority = mdb_byte[2:0];
          // Check if target wants to send payload (BCR[2] = IBI payload)
          if (latched_bcr[2])
            next_state = IBI_RECV_PAYLOAD;
          else
            next_state = IBI_COMPLETE;
        end
      end

      IBI_RECV_PAYLOAD: begin
        ibi_active = 1'b1;
        ibi_req_recv_byte = 1'b1;
        if (bus_done) begin
          // payload_buf captured in always_ff
          // payload_cnt incremented in always_ff
          // Check termination conditions
          if (payload_cnt >= max_payload - 1) begin
            ibi_req_nack = 1'b1;  // NACK to terminate
            next_state = IBI_COMPLETE;
          end else if (bus_ack_recv == 1'b0) begin  // Target NACKed (last byte)
            next_state = IBI_COMPLETE;
          end
        end
      end

      IBI_COMPLETE: begin
        ibi_active = 1'b1;
        ibi_req_stop = 1'b1;
        if (bus_done) begin
          // Push IBI info to FIFO
          // old concatenation was 33 bits (9+8+8+8), truncated MSB.
          // Layout: {RSVD[8:0] (9), DA[6:0] (7), Payload_len[7:0] (8), MDB[7:0] (8)} = 32 bits.
          ibi_fifo_push = 1'b1;
          ibi_fifo_push_data = {
            9'h000,            // Reserved [31:23]
            ibi_da[6:0],       // Device Address [22:16]
            payload_cnt[7:0],  // Payload length [15:8]
            mdb_byte           // MDB [7:0]
          };
          ibi_irq = 1'b1;
          next_state = IBI_IDLE;
        end
      end

      IBI_REJECT: begin
        ibi_active = 1'b0;  // IBI rejected — not active
        if (stop_detected || start_detected)
          next_state = IBI_IDLE;
        else if (bus_idle && controller_idle)
          next_state = IBI_IDLE;  // return to idle if bus is idle
      end

      IBI_CRR_DETECT: begin
        crr_received = 1'b1;
        crr_dev_addr = crr_addr;
        if (stop_detected)
          next_state = IBI_IDLE;
      end

      default: next_state = IBI_IDLE;
    endcase
  end

endmodule : i3c_ibi_handler

