// =============================================================================
// byte_serdes_i2c.sv — I2C Byte Serializer/Deserializer
// -----------------------------------------------------------------------------
// Handles 8-bit byte shifting (MSB first) and 9th-bit ACK/NACK for I2C mode.
// 9th Bit Behavior:
// Write: Controller releases SDA (High-Z). Target drives ACK (0) or NACK (1).
// Read: Controller drives ACK (0) or NACK (1, last byte). Target releases.
// Drive Mode: Always Open-Drain (I2C never uses Push-Pull).
// Location: controller/ — this is protocol logic (ACK/NACK), not PHY logic.
// Reusability: Self-contained — can be reused in standalone I2C controller.
// =============================================================================

module byte_serdes_i2c (
    input  logic        clk,
    input  logic        rst_n,

    // ------------------------------------------------------------------
    // Command interface (from I2C FSM)
    // ------------------------------------------------------------------
    input  logic        req_send_byte,      // send 8 data bits + 9th bit (ACK)
    input  logic        req_recv_byte,      // receive 8 data bits + 9th bit (ACK)
    input  logic [7:0]  byte_tx,            // byte to transmit (MSB first)
    output logic [7:0]  byte_rx,            // byte received
    input  logic        is_last_byte,       // 1 = NACK on last read byte

    // ------------------------------------------------------------------
    // PHY interface (to timing_control via phy_fsm)
    // ------------------------------------------------------------------
    output logic        cmd_bit_xfer,       // request 1 SCL cycle
    output logic        cmd_bit_xfer_od,    // always 1 (Open-Drain)
    output logic        sda_drive_val,      // SDA value to drive (when driving)
    output logic        mode_pushpull,      // always 0 (Open-Drain)
    input  logic        phy_done,           // 1 = bit transfer complete
    input  logic        sda_sampled,        // SDA value sampled at SCL high

    // ------------------------------------------------------------------
    // Status
    // ------------------------------------------------------------------
    output logic        byte_done,          // pulse: 8 bits + 9th bit complete
    output logic        ack_received,       // 0 = ACK (target accepted), 1 = NACK
    output logic        busy                // 1 = SerDes is active
);

    // ------------------------------------------------------------------
    // FSM States
    // ------------------------------------------------------------------
    typedef enum logic [2:0] {
        BS_IDLE,
        BS_SHIFT,       // shift 8 bits MSB first
        BS_NINTH_BIT,   // ACK/NACK phase
        BS_DONE
    } bs_state_e;

    bs_state_e  state_q, state_d;
    logic [7:0] shift_reg_q, shift_reg_d;
    logic [3:0] bit_cnt_q, bit_cnt_d;
    logic       is_recv_q, is_recv_d;
    logic       is_last_q, is_last_d;
    // (always_ff reset/default + always_comb state set). _d signals hold
    // next-state values; _r flops are driven ONLY in always_ff via <=.
    logic       byte_done_r;
    logic       ack_nack_r;
    logic       byte_done_d;
    logic       ack_nack_d;

    // ------------------------------------------------------------------
    // Sequential
    // ------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q     <= BS_IDLE;
            shift_reg_q <= 8'h00;
            bit_cnt_q   <= 4'd0;
            is_recv_q   <= 1'b0;
            is_last_q   <= 1'b0;
            byte_done_r <= 1'b0;
            ack_nack_r  <= 1'b0;
        end else begin
            state_q     <= state_d;
            shift_reg_q <= shift_reg_d;
            bit_cnt_q   <= bit_cnt_d;
            is_recv_q   <= is_recv_d;
            is_last_q   <= is_last_d;
            byte_done_r <= byte_done_d;
            ack_nack_r  <= ack_nack_d;
        end
    end

    // ------------------------------------------------------------------
    // Combinational logic
    // ------------------------------------------------------------------
    always_comb begin
        // Defaults
        state_d         = state_q;
        shift_reg_d     = shift_reg_q;
        bit_cnt_d       = bit_cnt_q;
        is_recv_d       = is_recv_q;
        is_last_d       = is_last_q;
        cmd_bit_xfer    = 1'b0;
        cmd_bit_xfer_od = 1'b1;   // I2C: always Open-Drain
        sda_drive_val   = 1'b1;   // default: release SDA (High-Z)
        mode_pushpull   = 1'b0;   // I2C: always Open-Drain
        byte_done_d     = 1'b0;
        ack_nack_d      = ack_nack_r;

        unique case (state_q)
            // ----------------------------------------------------------
            // IDLE: Wait for send/recv command
            // ----------------------------------------------------------
            BS_IDLE: begin
                if (req_send_byte) begin
                    shift_reg_d = byte_tx;
                    is_recv_d   = 1'b0;
                    is_last_d   = is_last_byte;
                    bit_cnt_d   = 4'd8;
                    state_d     = BS_SHIFT;
                end else if (req_recv_byte) begin
                    shift_reg_d = 8'h00;
                    is_recv_d   = 1'b1;
                    is_last_d   = is_last_byte;
                    bit_cnt_d   = 4'd8;
                    state_d     = BS_SHIFT;
                end
            end

            // ----------------------------------------------------------
            // SHIFT: 8 bits MSB first
            // ----------------------------------------------------------
            BS_SHIFT: begin
                cmd_bit_xfer = 1'b1;

                if (is_recv_q) begin
                    // Receive: release SDA, sample on phy_done
                    sda_drive_val = 1'b1;  // High-Z
                    if (phy_done) begin
                        shift_reg_d = {shift_reg_q[6:0], sda_sampled};
                        bit_cnt_d   = bit_cnt_q - 1'b1;
                        if (bit_cnt_q == 4'd1)
                            state_d = BS_NINTH_BIT;
                    end
                end else begin
                    // Transmit: drive SDA with MSB
                    sda_drive_val = shift_reg_q[7];
                    if (phy_done) begin
                        shift_reg_d = {shift_reg_q[6:0], 1'b0};
                        bit_cnt_d   = bit_cnt_q - 1'b1;
                        if (bit_cnt_q == 4'd1)
                            state_d = BS_NINTH_BIT;
                    end
                end
            end

            // ----------------------------------------------------------
            // NINTH_BIT: ACK/NACK (always Open-Drain)
            // ----------------------------------------------------------
            BS_NINTH_BIT: begin
                cmd_bit_xfer    = 1'b1;
                cmd_bit_xfer_od = 1'b1;
                mode_pushpull   = 1'b0;

                if (is_recv_q) begin
                    // Read: Controller drives ACK (0) or NACK (1, last byte)
                    sda_drive_val = is_last_q ? 1'b1 : 1'b0;
                end else begin
                    // Write: Controller releases SDA, target drives ACK/NACK
                    sda_drive_val = 1'b1;  // High-Z
                end

                if (phy_done) begin
                    // Sample ACK/NACK from target (write mode)
                    if (!is_recv_q) begin
                        ack_nack_d = sda_sampled;
                    end
                    byte_done_d = 1'b1;
                    state_d     = BS_DONE;
                end
            end

            // ----------------------------------------------------------
            // DONE: Return to IDLE
            // ----------------------------------------------------------
            BS_DONE: begin
                state_d = BS_IDLE;
            end

            default: state_d = BS_IDLE;
        endcase
    end

    // ------------------------------------------------------------------
    // Output assignments
    // ------------------------------------------------------------------
    assign byte_rx       = shift_reg_q;
    assign byte_done     = byte_done_r;
    assign ack_received  = ~ack_nack_r;  // 1 = ACK, 0 = NACK
    assign busy          = (state_q != BS_IDLE);

endmodule : byte_serdes_i2c

