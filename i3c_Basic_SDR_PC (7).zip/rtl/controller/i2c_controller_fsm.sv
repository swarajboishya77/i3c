// =============================================================================
// i2c_controller_fsm.sv — I2C Legacy Controller FSM
// -----------------------------------------------------------------------------
// Manages I2C bus transactions (START, address, data, STOP).
// Byte-level shifting (8 data bits + 9th ACK/NACK bit) is delegated to a
// separate byte_serdes_i2c module, instantiated inside this FSM. This
// mirrors the I3C side's architecture (byte_serdes_i3c inside the I3C
// controller), making the two protocol engines symmetric.
// The FSM retains:
// - Transaction-level state machine (IDLE → START → ADDR → DATA → STOP)
// - START/STOP/RELEASE condition generation (phy_req_start, phy_req_stop)
// - Byte count / transfer length management
// - Timeout detection
// The SerDes handles:
// - 8-bit MSB-first shift register
// - 9th bit ACK/NACK (drive on write, sample on read)
// - Bit-level PHY interface (cmd_bit_xfer, sda_drive_val)
// =============================================================================


module i2c_controller_fsm (
    input  logic        clk,
    input  logic        rst_n,

    // ------------------------------------------------------------------
    // Reset
    // ------------------------------------------------------------------
    input  logic        i2c_sw_reset,      // SW_RESET pulse (RWSC) from I2C_SW_RST_CTRL

    // ------------------------------------------------------------------
    // Configuration (from I2C register file)
    // ------------------------------------------------------------------
    input  logic [7:0]  i2c_target_addr,   // [7:1]=addr, [0]=RnW
    input  logic [7:0]  i2c_xfer_length,   // [7:0]=XFER_LENGTH
    input  logic [7:0]  i2c_tx_data,       // TX data byte (from I2C TX FIFO)
    output logic [7:0]  i2c_rx_data,       // RX data byte (to I2C RX FIFO)
    input  logic [15:0] i2c_timeout,       // Timeout

    // ------------------------------------------------------------------
    // Control (from I2C register file)
    // ------------------------------------------------------------------
    input  logic        i2c_enable,        // TRANS_EN_CTRL[0]: write 1 to start transaction

    // ------------------------------------------------------------------
    // Status outputs (to I2C register file)
    // ------------------------------------------------------------------
    output logic        i2c_xfer_done,
    output logic        i2c_busy,
    output logic [7:0]  i2c_bytes_xferd,
    output logic        i2c_trans_aborted,
    output logic        i2c_slv_addr_ack,
    output logic        i2c_data_nack,

    // ------------------------------------------------------------------
    // FIFO interface outputs
    // ------------------------------------------------------------------
    output logic        i2c_is_read,
    output logic        i2c_tx_byte_req,
    output logic        i2c_rx_byte_valid,
    output logic        i2c_fsm_idle,

    // ------------------------------------------------------------------
    // PHY interface (to timing_control / phy_fsm via i2c_mode mux)
    // ------------------------------------------------------------------
    output logic        phy_req_start,
    output logic        phy_req_repeat_start,
    output logic        phy_req_stop,
    output logic        phy_req_bit_xfer,
    output logic        phy_req_release,
    output logic        phy_sda_drive,
    input  logic        phy_done,
    input  logic        phy_sda_sampled,
    input  logic        i2c_tx_fifo_empty,  //TX FIFO empty flag (for write wait)
    input  logic        bus_idle
);

    // ------------------------------------------------------------------
    // FSM States (6 states)
    // ------------------------------------------------------------------
    // The byte_serdes_i2c module handles the 9th ACK/NACK bit internally as
    // part of each byte transfer.
    // ------------------------------------------------------------------
    typedef enum logic [2:0] {
        I2C_IDLE,          // Wait for TRANS_EN
        I2C_START,         // Issue START or Repeated START
        I2C_ADDR,          // Send address byte via serdes (8 bits + ACK)
        I2C_DATA,          // Send/receive data bytes via serdes (8 bits + ACK)
        I2C_CHECK_NEXT,    // Check if next transaction is pending (auto Repeated START)
        I2C_STOP,          // Issue STOP
        I2C_DONE           // Transaction complete
    } i2c_state_e;

    // ------------------------------------------------------------------
    // Registered signals
    // ------------------------------------------------------------------
    i2c_state_e  state_q, state_d;
    logic        rnw_q, rnw_d;             // Read/Write flag
    logic        addr_ack_q, addr_ack_d;   // Address ACK received
    logic        data_nack_q, data_nack_d; // Data NACK received
    logic [15:0] timeout_cnt_q, timeout_cnt_d;
    logic        timeout_expired_q, timeout_expired_d;
    logic        trans_aborted_sticky_q, trans_aborted_sticky_d;  // sticky abort flag
    logic [7:0]  byte_cnt_q, byte_cnt_d;   // Byte counter (0 to 255)
    logic [7:0]  xfer_length_q, xfer_length_d;
    logic [7:0]  bytes_xferd_q, bytes_xferd_d;
    logic        bus_is_held_q, bus_is_held_d;  // 1=bus held, next START = Repeated START
    logic [3:0]  repstart_wait_q, repstart_wait_d;  // wait counter for pending TRANS_EN
    logic [7:0]  rx_data_q, rx_data_d;     // Registered RX data
    logic        tx_byte_req_r;            // Pulse: loading new TX byte
    logic        rx_byte_valid_r;          // Pulse: full RX byte valid
    // (always_ff reset/default + always_comb state set). _d signals hold
    // next-state values; _r flops are driven ONLY in always_ff via <=.
    logic        tx_byte_req_d;
    logic        rx_byte_valid_d;

    // ------------------------------------------------------------------
    // SerDes interface signals
    // ------------------------------------------------------------------
    logic        serdes_req_send;    // FSM → serdes: send a byte
    logic        serdes_req_recv;    // FSM → serdes: receive a byte
    logic [7:0]  serdes_byte_tx;     // FSM → serdes: byte to transmit
    logic [7:0]  serdes_byte_rx;     // serdes → FSM: byte received
    logic        serdes_byte_done;   // serdes → FSM: byte transfer complete
    logic        serdes_ack_recv;    // serdes → FSM: 1=ACK, 0=NACK
    logic        serdes_busy;        // serdes → FSM: serdes is active
    logic        serdes_is_last;     // FSM → serdes: NACK on last read byte

    // SerDes drives bit-level PHY signals
    logic        serdes_cmd_bit_xfer;
    logic        serdes_sda_drive;

    // ------------------------------------------------------------------
    // XFER_LENGTH decode (0 means 256)
    // ------------------------------------------------------------------
    logic [7:0]  xfer_length_decoded;  // 0=256 bytes (sentinel), 1-255 = N bytes
    always_comb begin
        xfer_length_decoded = i2c_xfer_length;  // 0=256 bytes (sentinel)
    end

    // ------------------------------------------------------------------
    // Byte SerDes instantiation
    // ------------------------------------------------------------------
    byte_serdes_i2c u_byte_serdes (
        .clk              (clk),
        .rst_n            (rst_n),
        .req_send_byte    (serdes_req_send),
        .req_recv_byte    (serdes_req_recv),
        .byte_tx          (serdes_byte_tx),
        .byte_rx          (serdes_byte_rx),
        .is_last_byte     (serdes_is_last),
        .cmd_bit_xfer     (serdes_cmd_bit_xfer),
        .cmd_bit_xfer_od  (),               // unused — parent mux forces OD
        .sda_drive_val    (serdes_sda_drive),
        .mode_pushpull    (),               // unused — parent mux forces 0
        .phy_done         (phy_done),
        .sda_sampled      (phy_sda_sampled),
        .byte_done        (serdes_byte_done),
        .ack_received     (serdes_ack_recv),
        .busy             (serdes_busy)
    );

    // ------------------------------------------------------------------
    // Sequential
    // ------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n || i2c_sw_reset) begin
            state_q            <= I2C_IDLE;
            rnw_q              <= 1'b0;
            addr_ack_q         <= 1'b0;
            data_nack_q        <= 1'b0;
            timeout_cnt_q      <= 16'h0;
            timeout_expired_q  <= 1'b0;
            trans_aborted_sticky_q <= 1'b0;
            byte_cnt_q         <= 8'd0;
            xfer_length_q      <= 8'd0;
            bytes_xferd_q      <= 8'd0;
            bus_is_held_q      <= 1'b0;
            repstart_wait_q    <= 4'd0;
            rx_data_q          <= 8'h0;
            tx_byte_req_r      <= 1'b0;
            rx_byte_valid_r    <= 1'b0;
        end else begin
            state_q            <= state_d;
            rnw_q              <= rnw_d;
            addr_ack_q         <= addr_ack_d;
            data_nack_q        <= data_nack_d;
            timeout_cnt_q      <= timeout_cnt_d;
            timeout_expired_q  <= timeout_expired_d;
            trans_aborted_sticky_q <= trans_aborted_sticky_d;
            byte_cnt_q         <= byte_cnt_d;
            xfer_length_q      <= xfer_length_d;
            bytes_xferd_q      <= bytes_xferd_d;
            bus_is_held_q      <= bus_is_held_d;
            repstart_wait_q    <= repstart_wait_d;
            rx_data_q          <= rx_data_d;
            tx_byte_req_r      <= tx_byte_req_d;
            rx_byte_valid_r    <= rx_byte_valid_d;
        end
    end

    // ------------------------------------------------------------------
    // Next-state + output logic
    // ------------------------------------------------------------------
    always_comb begin
        // Defaults: hold current values
        state_d            = state_q;
        rnw_d              = rnw_q;
        addr_ack_d         = addr_ack_q;
        data_nack_d        = data_nack_q;
        timeout_cnt_d      = timeout_cnt_q;
        timeout_expired_d  = timeout_expired_q;
        trans_aborted_sticky_d = trans_aborted_sticky_q;  // default: hold
        byte_cnt_d         = byte_cnt_q;
        xfer_length_d      = xfer_length_q;
        bytes_xferd_d      = bytes_xferd_q;
        bus_is_held_d      = bus_is_held_q;
        repstart_wait_d    = repstart_wait_q;
        rx_data_d          = rx_data_q;

        // PHY condition outputs (driven by FSM, not serdes)
        phy_req_start    = 1'b0;
        phy_req_repeat_start = 1'b0;
        phy_req_stop     = 1'b0;
        phy_req_release  = 1'b0;

        // SerDes request signals (default: idle)
        serdes_req_send  = 1'b0;
        serdes_req_recv  = 1'b0;
        serdes_byte_tx   = 8'h00;
        serdes_is_last   = 1'b0;

        tx_byte_req_d    = 1'b0;
        rx_byte_valid_d  = 1'b0;

        // Timeout counter logic
        // suspend timeout when waiting for TX FIFO data
        if (state_q == I2C_IDLE) begin
            timeout_cnt_d     = 16'h0;
            timeout_expired_d = 1'b0;
            // Don't clear sticky here — clear it when a NEW transaction starts
            // (in the I2C_IDLE case below when i2c_enable fires)
        end else if (state_q == I2C_DATA && !rnw_q && i2c_tx_fifo_empty) begin
            // Write mode + TX FIFO empty: suspend timeout while waiting for host
            timeout_cnt_d     = timeout_cnt_q;
            timeout_expired_d = 1'b0;
        end else if (i2c_timeout != 16'h0) begin
            if (timeout_cnt_q >= i2c_timeout) begin
                timeout_expired_d = 1'b1;
                trans_aborted_sticky_d = 1'b1;  // set sticky on timeout
            end else begin
                timeout_cnt_d = timeout_cnt_q + 1'b1;
            end
        end

        unique case (state_q)
            // ----------------------------------------------------------
            // IDLE: Wait for TRANS_EN pulse
            // ----------------------------------------------------------
            I2C_IDLE: begin
                // Allow start when bus is idle, OR when bus is held
                // (previous transaction skipped STOP via auto-Repeated-START)
                if (i2c_enable && (bus_idle || bus_is_held_q)) begin
                    rnw_d         = i2c_target_addr[0];
                    xfer_length_d = xfer_length_decoded;
                    byte_cnt_d    = 8'd0;
                    bytes_xferd_d = 8'd0;
                    data_nack_d   = 1'b0;
                    addr_ack_d    = 1'b0;
                    trans_aborted_sticky_d = 1'b0;  // clear sticky on new transaction
                    state_d       = I2C_START;
                end
            end

            // ----------------------------------------------------------
            // START: Issue START (or Repeated START if bus_is_held_q)
            // ----------------------------------------------------------
            I2C_START: begin
                if (bus_is_held_q)
                    phy_req_repeat_start = 1'b1;  // Repeated START
                else
                    phy_req_start = 1'b1;          // Full START
                if (phy_done) begin
                    state_d = I2C_ADDR;
                end
                if (timeout_expired_q) state_d = I2C_STOP;
            end

            // ----------------------------------------------------------
            // ADDR: Send address byte via serdes (8 bits + 9th ACK/NACK)
            // ----------------------------------------------------------
            I2C_ADDR: begin
                serdes_req_send = 1'b1;
                serdes_byte_tx  = i2c_target_addr;
                if (serdes_byte_done) begin
                    addr_ack_d = serdes_ack_recv;  // 1=ACK, 0=NACK
                    if (!serdes_ack_recv) begin
                        // NACK — no device at this address
                        state_d = I2C_STOP;
                    end else begin
                        // ACK — proceed to data phase
                        byte_cnt_d = 8'd0;
                        state_d    = I2C_DATA;
                    end
                end
                if (timeout_expired_q) state_d = I2C_STOP;
            end

            // ----------------------------------------------------------
            // DATA: Send/receive data bytes via serdes
            // ----------------------------------------------------------
            I2C_DATA: begin
                if (rnw_q) begin
                    // Read mode: receive byte
                    serdes_req_recv = 1'b1;
                    serdes_is_last  = (xfer_length_q == 8'h0) ? (byte_cnt_q == 8'hFF) : (byte_cnt_q + 1 >= xfer_length_q);
                    if (serdes_byte_done) begin
                        rx_data_d       = serdes_byte_rx;
                        rx_byte_valid_d = 1'b1;
                        byte_cnt_d      = byte_cnt_q + 1'b1;
                        bytes_xferd_d   = bytes_xferd_q + 1'b1;
                        if ((xfer_length_q == 8'h0 && byte_cnt_q == 8'hFF) ||
                            (xfer_length_q != 8'h0 && byte_cnt_q + 1 >= xfer_length_q)) begin
                            // All bytes received — check for pending Repeated START
                            repstart_wait_d = 4'd8;
                            state_d = I2C_CHECK_NEXT;
                        end
                        // Otherwise stay in I2C_DATA for next byte
                    end
                end else begin
                    // Write mode: send byte
                    //Wait if TX FIFO is empty. Controller holds SCL low
                    // (by not requesting bit transfer) until host fills TX FIFO.
                    if (!i2c_tx_fifo_empty) begin
                        // TX FIFO has data — proceed with sending
                        serdes_req_send = 1'b1;
                        serdes_byte_tx  = i2c_tx_data;
                        if (serdes_byte_done) begin
                            tx_byte_req_d   = 1'b1;
                            data_nack_d     = ~serdes_ack_recv;  // 1=NACK from target
                            byte_cnt_d      = byte_cnt_q + 1'b1;
                            bytes_xferd_d   = bytes_xferd_q + 1'b1;
                            if (!serdes_ack_recv) begin
                                // NACK — target can't accept more data
                                state_d = I2C_STOP;
                            end else if ((xfer_length_q == 8'h0 && byte_cnt_q == 8'hFF) ||
                                         (xfer_length_q != 8'h0 && byte_cnt_q + 1 >= xfer_length_q)) begin
                                // All bytes transferred — check for pending Repeated START
                                repstart_wait_d = 4'd8;
                                state_d = I2C_CHECK_NEXT;
                            end
                            // Otherwise stay in I2C_DATA for next byte
                        end
                    end
                    // else: TX FIFO empty — do nothing, hold SCL low, wait for host
                end
                if (timeout_expired_q) state_d = I2C_STOP;
            end

            // ----------------------------------------------------------
            // STOP: Issue STOP (or skip if no_stop=1 to hold bus for Repeated START)
            // ----------------------------------------------------------
            // ----------------------------------------------------------
            // CHECK_NEXT: Data transfer done. Check if next TRANS_EN is
            // already pending. If yes, skip STOP → Repeated START.
            // If no new TRANS_EN within 8 cycles, issue STOP.
            // This is fully automatic — no software bit needed.
            // ----------------------------------------------------------
            I2C_CHECK_NEXT: begin
                // BUGFIX: Always issue STOP after data transfer completes.
                // The previous code checked i2c_enable (trans_en_ctrl_q) to
                // detect a new transfer for Repeated START optimization. But
                // i2c_xfer_done fires in I2C_DONE and clears trans_en_ctrl_q
                // via NBA, so i2c_enable is still 1 in this cycle — causing
                // the FSM to loop back to I2C_START indefinitely without ever
                // issuing STOP or reaching I2C_DONE. Repeated START is an
                // optimization, not a requirement — STOP + START is functionally
                // equivalent for I2C.
                state_d = I2C_STOP;
            end

            // ----------------------------------------------------------
            // STOP: Issue STOP and wait for completion
            // ----------------------------------------------------------
            I2C_STOP: begin
                phy_req_stop = 1'b1;
                // On timeout, force completion without waiting for phy_done
                // (the PHY may be unresponsive if that's what caused the timeout)
                if (timeout_expired_q) begin
                    bus_is_held_d = 1'b0;  // bus released
                    state_d       = I2C_DONE;
                end else if (phy_done) begin
                    bus_is_held_d = 1'b0;  // bus released
                    state_d       = I2C_DONE;
                end
            end

            // ----------------------------------------------------------
            // DONE: Transaction complete
            // ----------------------------------------------------------
            I2C_DONE: begin
                state_d = I2C_IDLE;
            end

            default: state_d = I2C_IDLE;
        endcase
    end

    // ------------------------------------------------------------------
    // PHY output muxing: FSM drives conditions, serdes drives bits
    // ------------------------------------------------------------------
    // During START/STOP: FSM drives phy_req_start/stop, serdes is idle
    // → phy_req_bit_xfer = 0 (from serdes), phy_sda_drive = 1 (release)
    // During byte transfer: serdes drives phy_req_bit_xfer + phy_sda_drive
    // → phy_req_start/stop = 0 (from FSM)
    // Both are 0 when in their respective idle states, so no conflict.
    assign phy_req_bit_xfer = serdes_cmd_bit_xfer;
    assign phy_sda_drive    = serdes_sda_drive;

    // ------------------------------------------------------------------
    // Output assignments
    // ------------------------------------------------------------------
    assign i2c_rx_data      = rx_data_q;
    assign i2c_busy         = (state_q != I2C_IDLE);
    assign i2c_bytes_xferd  = bytes_xferd_q[7:0];  // truncate MSB (0x00=256)
    assign i2c_xfer_done    = (state_q == I2C_DONE) || (state_q == I2C_CHECK_NEXT);
    assign i2c_slv_addr_ack = addr_ack_q;
    assign i2c_data_nack    = data_nack_q;
    // i2c_trans_aborted is sticky — once set by timeout or sw_reset, it stays
    // asserted until the next transaction starts (cleared in I2C_IDLE when
    // i2c_enable fires a new transaction).
    assign i2c_trans_aborted  = timeout_expired_q || i2c_sw_reset ||
                                trans_aborted_sticky_q;

    assign i2c_is_read      = rnw_q;
    assign i2c_tx_byte_req  = tx_byte_req_r;
    assign i2c_rx_byte_valid = rx_byte_valid_r;
    assign i2c_fsm_idle     = (state_q == I2C_IDLE) || (state_q == I2C_CHECK_NEXT);

endmodule : i2c_controller_fsm

