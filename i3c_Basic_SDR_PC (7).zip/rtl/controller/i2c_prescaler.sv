// =============================================================================
// i2c_prescaler.sv
// -----------------------------------------------------------------------------
// I2C SCL Timing Prescaler
// Converts the SPEED_PRESCALER value from I2C_SPD_MODE_CFG into SCL high/low
// time in PCLK cycles for the timing control module.
// SCL frequency = f_PCLK / (SPEED_PRESCALER × 2)
// - SCL High = SPEED_PRESCALER PCLK cycles
// - SCL Low = SPEED_PRESCALER PCLK cycles
// At 100 MHz PCLK:
// 0x1F3 (499) → 499 cycles high + 499 low = 998 cycle period → ~100 kHz (Std)
// 0x07D (125) → 125 cycles high + 125 low = 250 cycle period → 400 kHz (Fm)
// 0x032 (50) → 50 cycles high + 50 low = 100 cycle period → 1 MHz (Fm+)
// =============================================================================

module i2c_prescaler (
    // Clock and reset (module is purely combinational; clk/rst_n are kept as
    // no-op testbench hooks so unit-level TBs can use RisingEdge(dut.clk) for
    // test pacing. They are intentionally unused inside this module.)
    input  logic        clk,
    input  logic        rst_n,

    // Configuration from I2C_SPD_MODE_CFG (0xC0)
    input  logic [19:0] speed_prescaler,   // 0 = disabled, else prescaler value

    // Output to timing mux: SCL high/low in PCLK cycles
    output logic [17:0] i2c_scl_high_time,
    output logic [17:0] i2c_scl_low_time,

    // Status
    output logic        prescaler_active   // 1 = prescaler programmed (non-zero)
);

    // The prescaler value directly gives SCL high and low times in PCLK cycles
    // SCL High = prescaler cycles, SCL Low = prescaler cycles
    // This gives 50% duty cycle, which is standard for I2C

    always_comb begin
        if (speed_prescaler == 20'd0) begin
            // Not programmed — output safe default (Fm+ speed)
            i2c_scl_high_time = 18'd50;   // 50 cycles = 500ns @ 100MHz = 1 MHz
            i2c_scl_low_time  = 18'd50;
            prescaler_active  = 1'b0;
        end else if (speed_prescaler >= 20'd262143) begin
            // Cap at 18-bit max (262143 cycles = 2.6ms @ 100MHz, very slow)
            i2c_scl_high_time = 18'h3FFFF;
            i2c_scl_low_time  = 18'h3FFFF;
            prescaler_active  = 1'b1;
        end else begin
            // Normal: SCL high = prescaler, SCL low = prescaler
            i2c_scl_high_time = 18'(speed_prescaler);
            i2c_scl_low_time  = 18'(speed_prescaler);
            prescaler_active  = 1'b1;
        end
    end

endmodule : i2c_prescaler

