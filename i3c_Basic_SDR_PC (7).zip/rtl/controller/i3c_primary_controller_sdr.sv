// =============================================================================
// primary_controller_sdr.sv
// -----------------------------------------------------------------------------
// THE I3C Basic SDR Primary Controller — single controller module.
// This module contains BOTH:
// - The main controller FSM logic (command dispatch, TX/RX loops, DAA staging)
// - The top-level integration (instantiates serdes, timing, CCC, DAA, iobufs)
// There is NO separate i3c_controller_fsm file. The FSM logic is inlined
// into this module so there is only ONE controller: primary_controller_sdr.
// Sub-modules instantiated here (in separate files):
// - rtl/io_pad/io_buf.sv — tri-state I/O pad wrapper (SDA/SCL, analog frontend)
// - rtl/digital_phy/i3c_timing_control.sv — SCL/SDA bit-time engine (configurable via AXI4-Lite)
// - rtl/digital_phy/i3c_dnf.sv — Digital Noise Filter
// - rtl/controller/byte_serdes_i3c.sv — I3C bus controller (byte shift + START/STOP + PEC)
// - rtl/digital_phy/i3c_pec.sv — PEC (CRC-8) generator/checker (instantiated inside byte_serdes_i3c)
// - rtl/digital_phy/i3c_start_stop_gen.sv — START/STOP condition generator
// - rtl/digital_phy/i3c_phy_fsm.sv — Digital PHY FSM coordinator
// - rtl/digital_phy/i3c_phy_mux.sv — 3:1 mux: Digital PHY / Target Engine / Autonomous Bootstrap (TBD) -> iobuf
// - rtl/clock/i3c_clock_gate.sv — Clock gating cell (2 instances: ctrl + FIFO)
// - rtl/ccc/i3c_ccc_handler.sv — CCC broadcast/direct sequencer
// - rtl/daa/i3c_daa.sv — DAA sequencer (ENTDAA / SETDASA)
// The Digital PHY (i3c_phy_fsm) does NOT connect directly to io_buf.
// An i3c_phy_mux is inserted between them so that three SDA/SCL drivers —
// Digital PHY, Target Engine, and Autonomous Bootstrap (TBD) — can share
// the same pads under control of i3c_role_manager.
// ASIC-synthesizable: no `timescale, no simulation-only constructs.
// =============================================================================

import i3c_pkg::*;

module i3c_primary_controller_sdr #(
  parameter int unsigned AXI_CLK_FREQ_HZ = 100_000_000,
  parameter int unsigned SCL_CLK_FREQ_HZ = 12_500_000,
  parameter int unsigned CMD_FIFO_DEPTH  = 16,
  parameter int unsigned WR_FIFO_DEPTH   = 32,
  parameter int unsigned RD_FIFO_DEPTH   = 32,
  parameter int unsigned RESP_FIFO_DEPTH = 16,
  parameter logic [47:0] CTRL_PID        = 48'h0000_0000_0001,
  parameter logic [7:0]  CTRL_BCR        = 8'h00,
  parameter logic [7:0]  CTRL_DCR        = 8'h00,
  parameter bit          INST_PULLUP     = 1'b0
) (

  // ---------------- Clock / Reset ----------------
  input  logic        s_axi_aclk,
  input  logic        s_axi_aresetn,

  // ---------------- AXI4-Lite slave ----------------
  input  logic             s_axi_awvalid,
  output logic             s_axi_awready,
  input  logic [31:0]      s_axi_awaddr,
  input  logic [2:0]       s_axi_awprot,    // AMBA AXI4-Lite required (Table B1-1)
  input  logic             s_axi_wvalid,
  output logic             s_axi_wready,
  input  logic [31:0]      s_axi_wdata,
  input  logic [3:0]       s_axi_wstrb,
  output logic             s_axi_bvalid,
  input  logic             s_axi_bready,
  output logic [1:0]       s_axi_bresp,
  input  logic             s_axi_arvalid,
  output logic             s_axi_arready,
  input  logic [31:0]      s_axi_araddr,
  input  logic [2:0]       s_axi_arprot,    // AMBA AXI4-Lite required (Table B1-1)
  output logic             s_axi_rvalid,
  input  logic             s_axi_rready,
  output logic [31:0]      s_axi_rdata,
  output logic [1:0]       s_axi_rresp,

  // ---------------- I3C bus pads ----------------
  inout  wire logic        sda,
  inout  wire logic        scl,
  output logic        sda_pullup_en,
  output logic        scl_pullup_en,

  // ---------------- Always-on domain (PD_AON) ----------------
  // Wake detector and power controller live in PD_AON and use clk_aon
  // (typically 32 kHz RTC). These clocks/resets are NOT the same as
  // s_axi_aclk / s_axi_aresetn. The SoC must provide clk_aon and
  // rst_aon_n from the always-on power domain.
  input  logic        clk_aon,
  input  logic        rst_aon_n,

  // ---------------- Wake detector interface ----------------
  output logic        wake_irq,           // sticky wake interrupt (clk_aon)
  output logic        wake_src_start,     // 1 = woken by START condition
  output logic        wake_src_scl,       // 1 = woken by SCL edge

  // ---------------- Power domain handshake (PD_AON <-> PD_CORE) ----------------
  input  logic        pd_core_req,        // host requests PD_CORE power-down
  output logic        pd_core_off,        // 1 = PD_CORE currently powered off
  input  logic        pd_core_ack,        // host acks power-up
  output logic        pd_core_sw_en,      // to PMU power-switch cell
  output logic        pd_core_iso_en,     // to isolation cells
  output logic        pd_core_rst,        // reset PD_CORE during power-up
  output logic        wake_to_host,       // wake interrupt to host (clk_aon)

  // ---------------- Target engine interface ----------------
  // Target engine responds to commands from another controller on the bus.
  // It uses the filtered external SCL as its clock (CDC from s_axi_aclk).
  output logic        target_addressed,   // 1 = target addressed by external master
  output logic        target_busy,        // 1 = target engine active
  output logic        target_rx_done,     // pulse: RX byte received
  output logic [7:0]  target_rx_byte,     // received byte value
  output logic        target_tx_req,      // pulse: target requests TX byte
  input  logic [7:0]  target_tx_byte,     // TX byte from host
  input  logic        target_tx_valid,    // host provides TX byte
  output logic        target_ibi_req,     // target IBI request to bus
  output logic        target_nack_sent,   // target sent NACK

  // ---------------- Mode select (I3C vs I2C) ----------------
  // Per-transaction mode selection is driven by cmd_word_t.i2c_mode
  // (bit 24 of the command descriptor). The FSM latches it into i2c_mode_q
  // when popping a command from the CMD FIFO. When i2c_mode_q=1, the I2C
  // controller FSM is active and the I3C FSM is idle.
  // When i2c_mode_q=0 (default), the I3C controller FSM is active.
  output logic        i2c_irq,            // I2C interrupt request
  output logic        i3c_irq,            // I3C interrupt request (aggregated from INT_STATUS & INT_EN_CTRL)
  output logic        irq,                // Combined interrupt = i3c_irq OR i2c_irq

  // ---------------- Status (polled) ----------------
  output logic        controller_busy,
  output logic        controller_idle,

  // ---------------- FIFO Host-Side Interface ----------------
  // These ports connect to a TCRI/HCI wrapper (outside this module).
  // In standalone mode (no TCRI/HCI), these can be driven directly by a
  // testbench or a simple PIO address decoder.
  // CMD FIFO (host pushes commands, controller FSM pops)
  input  logic        cmd_fifo_push,
  input  logic [31:0] cmd_fifo_push_data,
  output logic        cmd_fifo_full,
  output logic        cmd_fifo_empty,
  // WR FIFO (host pushes TX data, controller FSM pops)
  input  logic        wr_fifo_push,
  input  logic [31:0] wr_fifo_push_data,
  output logic        wr_fifo_full,
  output logic        wr_fifo_empty,
  // RD FIFO (controller FSM pushes RX data, host pops)
  output logic [31:0] rd_fifo_pop_data,
  input  logic        rd_fifo_pop,
  output logic        rd_fifo_full,
  output logic        rd_fifo_empty,
  // RESP FIFO (controller FSM pushes responses, host pops)
  output logic [31:0] resp_fifo_pop_data,
  input  logic        resp_fifo_pop,
  output logic        resp_fifo_full,
  output logic        resp_fifo_empty
);

  // -------------------------------------------------------------------------
  // FSM internal signals
  // -------------------------------------------------------------------------
  logic clk;
  logic rst_n;

  //Role manager + phy_mux select
  logic [1:0]  phy_mux_sel;       // driven by i3c_role_manager
  logic        role_is_controller;
  logic        role_is_target;
  logic        reclaim_in_progress;
  logic        reclaim_test_active;
  logic        handoff_done_pulse;
  logic        handoff_failed_pulse;
  logic        reclaim_done_pulse;
  logic [1:0]  handoff_fail_reason;
  logic [1:0]  handoff_status;
  logic [2:0]  role_state_out;
  logic        handoff_trigger_internal;
  logic        getacccr_done_internal;
  logic        getacccr_ack_internal;
  logic        getacccr_addr_nack_internal;
  logic        getacccr_data_nack_internal;
  logic        scl_falling_det, sda_falling_det;
  logic        bootstrap_active = 1'b0;  // Autonomous Bootstrap (TBD) not implemented
  logic        role_return_pulse;  //from target engine (voluntary return)
  logic        role_target_en;     //from role_manager (target engine enable)

  // CDC synchronizers for signals crossing between s_axi_aclk and scl_filt domains
  // Target engine runs on scl_filt (external SCL); role_manager runs on s_axi_aclk.
  // role_return: SCL domain → AXI domain (1-cycle pulse, needs edge detect)
  // role_is_target: AXI domain → SCL domain (level signal, needs 2-flop sync)
  logic        role_return_sync1, role_return_sync2, role_return_sync2_d;
  logic        role_is_target_sync1, role_is_target_sync2;
  wire         role_is_target_synced = role_is_target_sync2;

  // logic declaration in the original code (iverilog doesn't support forward refs)
  // --- Forward Declarations (signal ordering for synthesis) ---
  logic        ctrl_en, ctrl_ibi_en;
  logic        wake_irq_meta, wake_irq_sync1, wake_irq_sync2;
  logic        pec_append_req_r;
  logic        pec_rx_check_r;
  logic        pec_tx_byte_valid_bus;
  logic [7:0]  pec_tx_byte_value_bus;
  logic        pec_phase;
  logic        abort_req;
  logic        hj_pending_wire;
  logic        group_match_w;
  logic        scl_filt_rst_n_sync_meta, scl_filt_rst_n_sync;
  logic        i2c_tx_fifo_wr;
  logic        i2c_rx_fifo_rd;
  logic        i2c_tx_fifo_rd;
  logic        i2c_rx_fifo_wr;
  logic        resp_overflow, resp_underflow;
  logic        hj_detected_w, hj_pending_w, hj_trigger_daa_w;
  logic        hj_detected_via_ibi_w;  // HJ detected by IBI handler (0x02/W)
  logic        i2c_xfer_done, i2c_busy;
  logic        i2c_trans_en;
  // ----------------------------------------------------
  logic        pec_en_bus;
  logic        axi_wr_ack_final, axi_rd_ack_final;
  logic [31:0] axi_rd_data_final;
  logic [1:0]  bus_type;
  logic        reclaim_en;
  logic [15:0] reclaim_timeout_us;
  logic [17:0] scl_high_time_mixed;
  logic [17:0] cfg_scl_high_time_mixed;
  logic        ccc_getacccr_addr_nack, ccc_getacccr_data_nack, ccc_getacccr_ack;
  logic        ccc_error;  // general CCC NACK flag from CCC handler

  // Register file handoff signals
  logic        mux_cmd_start, mux_cmd_repeat_start, mux_cmd_stop;
  logic        mux_cmd_drive_scl_low, mux_cmd_release_bus;
  logic        mux_cmd_bit_xfer, mux_cmd_bit_xfer_od;
  logic        mux_sda_drive_val, mux_mode_pushpull;

  // Reset synchronizer (CDC-safe async-assert / sync-deassert)
  logic rst_sync_meta, rst_sync_n;
  always_ff @(posedge s_axi_aclk or negedge s_axi_aresetn) begin
    if (!s_axi_aresetn) begin
      rst_sync_meta <= 1'b0;
      rst_sync_n    <= 1'b0;
    end else begin
      rst_sync_meta <= 1'b1;
      rst_sync_n    <= rst_sync_meta;
    end
  end
  assign rst_n = rst_sync_n;
  assign clk   = s_axi_aclk;

  logic cmd_fifo_pop;
  logic [31:0]cmd_fifo_data;
  logic cmd_fifo_valid;
  logic wr_fifo_pop;
  logic [31:0]wr_fifo_data;
  logic wr_fifo_valid;
  logic rd_fifo_push;
  logic [31:0]rd_fifo_push_data;
  logic resp_fifo_push;
  logic [31:0]resp_fifo_push_data;
  logic bus_req_start;
  logic bus_req_repeat_start;
  logic bus_req_stop;
  logic bus_req_send_addr_w;
  logic bus_req_send_addr_r;
  logic [6:0]bus_addr_val;
  logic bus_req_send_byte;
  logic [7:0]bus_byte_tx;
  logic bus_req_recv_byte;
  logic bus_recv_last_byte;
  logic bus_done;
  logic bus_ack_recv;
  logic [7:0]bus_byte_rx;
  logic bus_busy;
  logic bus_idle;
  // separate I3C SerDes idle from the combined bus_idle.
  // bus_idle_i3c = I3C SerDes (u_bus_ctrl) idle output
  // bus_idle = bus_idle_i3c & i2c_fsm_idle (true only when BOTH FSMs are idle)
  // The I2C FSM sees bus_idle_i3c (so it can start when I3C side is idle).
  // All other consumers (IBI, HJ, controller_idle, CDC to clk_aon) see the
  // combined bus_idle, so they know the bus is truly free.
  logic bus_idle_i3c;
  logic ccc_req;
  logic ccc_is_direct;
  logic [7:0]ccc_opcode;
  logic [6:0]ccc_target_addr;
  logic [15:0]ccc_defining_byte;
  logic ccc_has_defining_byte;
  logic ccc_done;
  logic ccc_resp_valid;
  logic [7:0]ccc_resp_byte;
  logic ccc_start;
  logic ccc_repeat_start;
  logic ccc_stop;
  logic ccc_send_addr_w;
  logic ccc_send_addr_r;
  logic [6:0]ccc_addr_val;
  logic ccc_send_byte;
  logic [7:0]ccc_byte_val;
  logic ccc_recv_byte;
  logic ccc_expect_response;
  logic daa_start_entdaa;
  logic daa_start_setdasa;
  logic [6:0]daa_setdasa_static;
  logic daa_done;
  logic daa_target_found;
  logic [47:0]daa_pid;
  logic [7:0]daa_bcr;
  logic [7:0]daa_dcr;
  logic [6:0]daa_dyn_addr_assigned;
  logic [1:0] daa_rd_push_phase;  // multi-word DAA result push
  logic daa_recv_last_byte;
  // -------------------------------------------------------------------------
  // Target Table signals (NEW )
  // -------------------------------------------------------------------------
  // Forward declarations (must be before wire assigns below)
  logic [6:0]  tgt_table_da    [0:15];
  logic        tgt_table_valid [0:15];
  logic [3:0]  tgt_table_count;
  logic        tgt_table_full;  // all 16 slots valid

  wire        tgt_table_daa_wr = daa_target_found;
  wire [3:0]  tgt_table_daa_idx = tgt_table_count;
  wire [6:0]  tgt_table_daa_da = daa_dyn_addr_assigned;
  wire [7:0]  tgt_table_daa_bcr = daa_bcr;
  wire [7:0]  tgt_table_daa_dcr = daa_dcr;
  wire [47:0] tgt_table_daa_pid = daa_pid;

  logic        tgt_table_ccc_wr;
  logic [3:0]  tgt_table_ccc_idx;
  logic        tgt_table_ccc_wr_mrl;
  logic        tgt_table_ccc_wr_mwl;
  logic        tgt_table_ccc_wr_ibi;
  logic [15:0] tgt_table_ccc_mrl_val;
  logic [15:0] tgt_table_ccc_mwl_val;
  logic [7:0]  tgt_table_ccc_ibi_val;

  // Target table lookup interface
  logic [6:0]  ibi_lookup_da;
  logic [3:0]  ibi_lookup_idx;
  logic        ibi_lookup_valid;
  logic [15:0] ibi_lookup_mrl;
  logic [7:0]  ibi_lookup_ibi_max;
  logic [7:0]  ibi_lookup_bcr;

  logic [6:0]  ccc_tgt_da;
  // capture outgoing CCC payload bytes (MRL/MWL) for target table update
  logic [15:0] ccc_mrl_captured;
  logic [15:0] ccc_mwl_captured;
  logic [7:0]  ccc_ibi_max_captured;
  logic [3:0]  ccc_tgt_idx;

  logic daa_req_start;
  logic daa_req_repeat_start;
  logic daa_req_stop;
  logic daa_req_send_byte;
  logic [7:0]daa_req_send_byte_val;
  logic daa_req_recv_byte;
  // daa_req_send_ack/nack: driven by i3c_daa FSM to indicate per-byte ACK/NACK
  // control during DAA PID/BCR/DCR reads. Currently not wired into byte_serdes
  // (the DAA handler uses state-machine-driven termination via recv_last_byte
  // instead). Kept as outputs for future integration when byte_serdes_i3c
  // adds I3C ACK/NACK control on the 9th bit during DAA reads.
  logic daa_req_send_ack;
  logic daa_req_send_nack;
  logic daa_req_send_addr_w;
  logic daa_req_send_addr_r;
  logic [6:0]daa_req_addr_val;

  // -------------------------------------------------------------------------
  // FSM-internal primitive requests (driven by the main always_ff).
  // The comb mux at the bottom selects between FSM / CCC / DAA sources
  // to drive the bus_req_* outputs to the bus controller.
  // -------------------------------------------------------------------------
  logic             fsm_req_start;
  logic             fsm_req_repeat_start;
  logic             fsm_req_stop;
  logic             fsm_req_send_addr_w;
  logic             fsm_req_send_addr_r;
  logic [6:0]       fsm_addr_val;
  logic             fsm_req_send_byte;
  logic [7:0]       fsm_byte_tx;
  logic             fsm_req_recv_byte;
  logic             fsm_recv_last_byte;

  // -------------------------------------------------------------------------
  // Decoded command (combinational view of cmd_fifo_data)
  // -------------------------------------------------------------------------
  cmd_word_t  cmd_dec;
  assign cmd_dec = cmd_word_t'(cmd_fifo_data);

  // -------------------------------------------------------------------------
  // State + working registers
  // -------------------------------------------------------------------------
  ctrl_state_e state;

  wire        ibi_req_ack_w = 1'b0;
  wire        ibi_req_nack_w = 1'b0;

  logic [8:0]  bytes_remaining;  // 9-bit internal (count down from byte_cnt_m1+1)
  logic [2:0]  word_bytes_used;
  logic [31:0] wr_word_buf;
  logic [2:0]  rx_byte_idx;
  logic [31:0] rx_word_buf;
  logic        cmd_was_read;
  logic [6:0]  cmd_dev_addr;
  logic        cmd_cp;           // Command Present (1=CCC, 0=private xfer)
  logic [7:0]  cmd_ccc_opcode;   // CCC opcode (spec-compliant)
  logic        cmd_toc;          // Terminate on Completion (1=STOP, 0=Sr)

  //CRR (Controller Role Request) receive detection
  // When a secondary controller pulls SDA low and sends its dyn addr with RnW=0,
  // the IBI handler detects this as a CRR (vs IBI which has RnW=1).
  // The controller FSM then automatically issues GETACCR to that device.
  logic        crr_received;       // 1 = CRR detected from secondary controller
  logic [6:0]  crr_dev_addr;      // dynamic address of the CRR requester
  logic [7:0]  resp_code_r;
  logic [8:0]  resp_xfer_len_r;  // 9-bit internal, [7:0] output (0x00=256 bytes)
  logic        resp_nack_r;
  logic        resp_timeout_r;

  // --- Per-command latched config (from cmd_word_t at pop time) ---
  logic        i2c_mode_q;   // latched cmd_dec.i2c_mode
  logic        cmd_pec_en_q;     // latched cmd_dec.pec_en
  logic        cmd_pec_append_q; // latched cmd_dec.pec_append
  logic        cmd_pec_check_q;  // latched cmd_dec.pec_check

  // --- Bus-held flag (pure FSM logic for Repeated START) ---
  // Set when a transaction completes WITHOUT issuing STOP.
  // Cleared when STOP is issued.
  // Used in CTRL_SEND_START to decide START vs REPEATED_START.
  logic        bus_is_held_q;

  // Config bus nets — declared early because the Main FSM uses cfg_bus_free_time
  // in CTRL_WAIT_BUS_FREE state (Vivado VRFC requires declaration before use).
  logic [17:0] cfg_scl_high_time, cfg_scl_low_time, cfg_sda_hold_time;
  logic [17:0] cfg_bus_free_time, cfg_tsu_start, cfg_thd_start, cfg_tsu_stop;
  logic [17:0] cfg_scl_od_high_time, cfg_scl_od_low_time;

  // -------------------------------------------------------------------------
  // Main FSM
  // -------------------------------------------------------------------------
  logic        abort_pending_q;  // tracks abort in progress (forces STOP regardless of TOC)
  logic [17:0] bus_free_cnt_q;   // tBUF wait counter for CTRL_WAIT_BUS_FREE
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state             <= CTRL_IDLE;
      bytes_remaining   <= '0;
      word_bytes_used   <= '0;
      wr_word_buf       <= '0;
      rx_byte_idx       <= '0;
      rx_word_buf       <= '0;
      cmd_was_read      <= 1'b0;
      cmd_dev_addr      <= '0;
      cmd_cp            <= 1'b0;
      cmd_ccc_opcode    <= '0;
      cmd_toc           <= 1'b0;
      abort_pending_q   <= 1'b0;
      bus_free_cnt_q    <= '0;
      resp_code_r       <= 8'h00;
      resp_xfer_len_r   <= '0;
      resp_nack_r       <= 1'b0;
      resp_timeout_r    <= 1'b0;

      // Output defaults at reset
      cmd_fifo_pop       <= 1'b0;
      wr_fifo_pop        <= 1'b0;
      rd_fifo_push       <= 1'b0;
      rd_fifo_push_data  <= '0;
      daa_rd_push_phase  <= '0;  // reset multi-word push phase
      resp_fifo_push     <= 1'b0;
      resp_fifo_push_data<= '0;
      fsm_req_start       <= 1'b0;
      fsm_req_repeat_start<= 1'b0;
      fsm_req_stop        <= 1'b0;
      fsm_req_send_addr_w <= 1'b0;
      fsm_req_send_addr_r <= 1'b0;
      fsm_addr_val        <= '0;
      fsm_req_send_byte   <= 1'b0;
      fsm_byte_tx         <= '0;
      fsm_req_recv_byte   <= 1'b0;
      fsm_recv_last_byte  <= 1'b0;
      ccc_req             <= 1'b0;
      ccc_is_direct       <= 1'b0;
      ccc_opcode          <= '0;
      ccc_target_addr     <= '0;
      ccc_defining_byte   <= '0;
      ccc_has_defining_byte<=1'b0;
      daa_start_entdaa    <= 1'b0;
      daa_start_setdasa   <= 1'b0;
      daa_setdasa_static  <= '0;
      pec_append_req_r    <= 1'b0;
      pec_rx_check_r      <= 1'b0;
      pec_phase           <= 1'b0;
      // Per-command latched config reset
      i2c_mode_q      <= 1'b0;
      cmd_pec_en_q        <= 1'b0;
      cmd_pec_append_q    <= 1'b0;
      cmd_pec_check_q     <= 1'b0;
      // Bus-held flag reset (no transaction in progress)
      bus_is_held_q       <= 1'b0;
    end else begin
      // ----- Default deassertion of pulsed outputs -----
      cmd_fifo_pop       <= 1'b0;
      wr_fifo_pop        <= 1'b0;
      rd_fifo_push       <= 1'b0;
      resp_fifo_push     <= 1'b0;
      // multi-word DAA result push (phase 1=PID[47:32]+BCR+DCR+DA, phase 2=done)
      // Consolidated into single next-state assignment (was 3 overlapping NBAs).
      if (daa_rd_push_phase != 2'd0) begin
        rd_fifo_push <= 1'b1;
        case (daa_rd_push_phase)
          2'd1: begin
            rd_fifo_push_data <= {daa_pid[47:32], daa_bcr, daa_dcr, {daa_dyn_addr_assigned, 1'b0}};
            daa_rd_push_phase <= 2'd2;  // advance to phase 2
          end
          2'd2: begin
            rd_fifo_push_data <= '0;  // 3rd word not needed (only 9 bytes = 2.25 words)
            daa_rd_push_phase <= 2'd0;  // done — return to idle
          end
          default: begin
            rd_fifo_push_data <= '0;
            daa_rd_push_phase <= 2'd0;  // safety: unknown phase → idle
          end
        endcase
      end
      fsm_req_start       <= 1'b0;
      fsm_req_repeat_start<= 1'b0;
      fsm_req_stop        <= 1'b0;
      fsm_req_send_addr_w <= 1'b0;
      // was only set when popping a command from the CMD FIFO (cmd_dec.i2c_mode),
      // but I2C register-initiated transfers don't use the CMD FIFO. Without
      // this , the PHY mux stays in I3C mode and the I2C FSM's phy_req_*
      // signals never reach the PHY, causing the I2C FSM to hang in I2C_START
      // forever waiting for phy_done.
      if (i2c_trans_en && !i2c_xfer_done)
        i2c_mode_q <= 1'b1;  // I2C register transfer active
      else if (i2c_xfer_done || (!i2c_trans_en && state == CTRL_IDLE))
        i2c_mode_q <= 1'b0;  // I2C transfer done or idle: back to I3C mode
      fsm_req_send_addr_r <= 1'b0;
      fsm_req_send_byte   <= 1'b0;
      fsm_req_recv_byte   <= 1'b0;
      ccc_req             <= 1'b0;
      // NOTE: ccc_has_defining_byte is also defaulted here so it does not
      // persist from one CCC to the next (e.g. after a Target Reset).
      ccc_has_defining_byte <= 1'b0;
      ccc_defining_byte   <= '0;
      daa_start_entdaa    <= 1'b0;
      daa_start_setdasa   <= 1'b0;
      pec_append_req_r    <= 1'b0;  // default deassert
      pec_rx_check_r      <= 1'b0;  // default deassert (re-asserted in CTRL_RX_PEC)

      // Abort check: if abort_req fires during any active state (not IDLE/PUSH_RESP),
      // force STOP and push an aborted response.
      // abort_pending_q ensures STOP is issued even if cmd_toc=0 (abort must
      // always release the bus, regardless of the original TOC setting).
      if (abort_req && state != CTRL_IDLE && state != CTRL_PUSH_RESP &&
          state != CTRL_SEND_STOP ) begin
        fsm_req_stop      <= 1'b1;
        resp_code_r       <= RESP_ABORTED;  // use ABORTED code (0x0B), not NACK_DATA
        abort_pending_q   <= 1'b1;  // mark abort in progress
        state             <= CTRL_SEND_STOP;
      end else
      unique case (state)
        // -------------------------------------------------------------
        CTRL_IDLE: begin
          // Master enable gate: when TRANSACTION_CTRL.EN=0, the FSM stays idle
          // and does not pop the CMD_FIFO. Host uses this to safely disable the
          // controller (e.g. before reprogramming timing registers).
          if (ctrl_en && hj_trigger_daa_w) begin
            //Use spec-compliant CP + CCC opcode
            cmd_cp            <= 1'b1;
            cmd_ccc_opcode    <= 8'h07;  // ENTDAA (broadcast)
            cmd_toc           <= 1'b1;  // always STOP after DAA
            cmd_dev_addr      <= 7'h00;
            cmd_was_read      <= 1'b0;
            bytes_remaining   <= 8'd0;
            word_bytes_used   <= '0;
            rx_byte_idx       <= '0;
            resp_code_r       <= 8'h00;
            resp_xfer_len_r   <= '0;
            resp_nack_r       <= 1'b0;
            resp_timeout_r    <= 1'b0;
            // Auto-ENTDAA is always I3C mode, no PEC
            i2c_mode_q    <= 1'b0;
            cmd_pec_en_q      <= 1'b0;
            cmd_pec_append_q  <= 1'b0;
            cmd_pec_check_q   <= 1'b0;
            state             <= CTRL_DECODE_CMD;
          end else if (ctrl_en && crr_received) begin
            //CRR received from a secondary controller
            // Automatically issue GETACCR to hand off controller role
            cmd_cp            <= 1'b1;
            cmd_ccc_opcode    <= CCC_GETACCR_D;  // 0x91
            cmd_toc           <= 1'b1;  // always STOP after handoff
            cmd_dev_addr      <= crr_dev_addr;
            cmd_was_read      <= 1'b0;
            bytes_remaining   <= 8'd0;
            word_bytes_used   <= '0;
            rx_byte_idx       <= '0;
            resp_code_r       <= 8'h00;
            resp_xfer_len_r   <= '0;
            resp_nack_r       <= 1'b0;
            resp_timeout_r    <= 1'b0;
            i2c_mode_q    <= 1'b0;
            cmd_pec_en_q      <= 1'b0;
            cmd_pec_append_q  <= 1'b0;
            cmd_pec_check_q   <= 1'b0;
            state             <= CTRL_DECODE_CMD;
          end else if (ctrl_en && cmd_fifo_valid) begin
            //Latch spec-compliant command fields
            cmd_cp            <= cmd_dec.cp;
            cmd_ccc_opcode    <= cmd_dec.ccc_opcode;
            cmd_toc           <= cmd_dec.toc;
            cmd_dev_addr      <= cmd_dec.dev_addr;
            cmd_was_read      <= cmd_dec.rnw;
            bytes_remaining   <= cmd_dec.byte_cnt_m1 + 1'b1;  // count DOWN
            word_bytes_used   <= '0;
            rx_byte_idx       <= '0;
            resp_code_r       <= 8'h00;
            resp_xfer_len_r   <= '0;
            resp_nack_r       <= 1'b0;
            resp_timeout_r    <= 1'b0;
            // Latch per-command config
            i2c_mode_q    <= cmd_dec.i2c_mode;
            cmd_pec_en_q      <= cmd_dec.pec_en;
            cmd_pec_append_q  <= cmd_dec.pec_append;
            cmd_pec_check_q   <= cmd_dec.pec_check;
            cmd_fifo_pop      <= 1'b1;
            state             <= CTRL_DECODE_CMD;
          end
        end

        // -------------------------------------------------------------
        CTRL_DECODE_CMD: begin
          //Spec-compliant decode using CP (Command Present) bit
          // Mode guard: when i2c_mode_q=1 (I2C mode), I3C FSM stays idle.
          if (i2c_mode_q == MODE_I2C) begin
            state <= CTRL_IDLE;
          end else if (!cmd_cp) begin
            // CP=0: Private transfer (I3C private read/write).
            // previously a "!cmd_cp && ccc_opcode==0x00" branch
            // here silently treated every private write as a NOP and pushed
            // RESP_SUCCESS with xfer_len=0, skipping the actual bus transaction.
            // ccc_opcode is irrelevant for private transfers (CP=0); the field
            // is reused as a private opcode space and 0x00 is a valid private
            // transfer. Branch deleted — all CP=0 commands go to bus transfer.
            // CP=0: Private transfer (I3C private read/write)
            // Group addressing: if the target address matches a group and
            // the command is a read, reject it (I3C Basic doesn't support
            // group reads).
            if (group_match_w && cmd_was_read) begin
              resp_code_r <= 8'h01;
              state       <= CTRL_PUSH_RESP;
            end else begin
              state <= CTRL_SEND_START;
            end
          end else begin
            // CP=1: CCC (Common Command Code)
            // CCC opcode is in cmd_ccc_opcode (spec-compliant value)
            // Bit [7] of CCC opcode: 0=Broadcast, 1=Direct
            case (cmd_ccc_opcode)
              8'h07: begin
                // ENTDAA — Enter Dynamic Address Assignment
                daa_start_entdaa <= 1'b1;
                state            <= CTRL_RUN_DAA;
              end
              8'h87: begin
                // SETDASA — Set Dynamic Address from Static Address
                daa_start_setdasa  <= 1'b1;
                daa_setdasa_static <= cmd_dev_addr;
                state              <= CTRL_RUN_DAA;
              end
              8'h91: begin
                // GETACCR — Get Accept Controller Role (handoff)
                // CCC opcode comes from descriptor, not WR FIFO
                ccc_opcode    <= CCC_GETACCR_D;  // 0x91
                ccc_is_direct <= 1'b1;
                ccc_target_addr <= cmd_dev_addr;
                ccc_req       <= 1'b1;
                state         <= CTRL_SEND_CCC;
              end
              8'h06: begin
                // RSTDAA — broadcast on bus
                ccc_opcode    <= 8'h06;
                ccc_is_direct <= 1'b0;
                ccc_req       <= 1'b1;
                state         <= CTRL_SEND_CCC;
              end
              8'h00, 8'h01, 8'h80, 8'h81: begin
                // ENEC/DISEC — Enable/Disable Events (Broadcast/Direct)
                // Defining byte comes from WR FIFO (ENIBI/ENHJ/DISIBI/DISHJ bits)
                ccc_opcode          <= cmd_ccc_opcode;
                ccc_is_direct       <= cmd_ccc_opcode[7];
                ccc_target_addr     <= cmd_dev_addr;
                ccc_defining_byte   <= {8'h0, wr_fifo_data[7:0]};
                ccc_has_defining_byte <= 1'b1;
                wr_fifo_pop         <= 1'b1;
                ccc_req             <= 1'b1;
                state               <= CTRL_SEND_CCC;
              end
              default: begin
                // Generic CCC — opcode from descriptor, not WR FIFO
                ccc_opcode    <= cmd_ccc_opcode;
                ccc_is_direct <= cmd_ccc_opcode[7];  // bit 7 = direct
                ccc_target_addr <= cmd_dev_addr;
                ccc_req       <= 1'b1;
                state         <= CTRL_SEND_CCC;
              end
            endcase
          end
          // STOP is controlled by TOC bit at transaction end.
        end

        // -------------------------------------------------------------
        CTRL_SEND_START: begin
          // Repeated START is pure FSM logic: if the bus is held (previous
          // transaction ended without STOP), issue REPEATED_START; else START.
          // Otherwise the byte_serdes sees req_start still high after done
          if (!bus_done) begin
            if (bus_is_held_q) fsm_req_repeat_start <= 1'b1;
            else                fsm_req_start        <= 1'b1;
          end
          if (bus_done) state <= CTRL_SEND_ADDR;
        end

        // -------------------------------------------------------------
        CTRL_SEND_ADDR: begin
          if (!bus_done) begin
            if (cmd_was_read) fsm_req_send_addr_r <= 1'b1;
            else              fsm_req_send_addr_w <= 1'b1;
            fsm_addr_val <= cmd_dev_addr;
          end
          if (bus_done) begin
            if (bus_ack_recv) begin
              if (cmd_was_read) state <= CTRL_RX_DATA;
              else              state <= CTRL_TX_DATA;
            end else begin
              resp_nack_r <= 1'b1;
              resp_code_r <= 8'h01;
              state       <= CTRL_SEND_STOP;
            end
          end
        end

        // -------------------------------------------------------------
        CTRL_TX_DATA: begin
          if (bytes_remaining == 9'd0) begin
            // After last data byte: append PEC CRC if enabled, else STOP.
            if (pec_en_bus & cmd_pec_append_q) begin
              state     <= CTRL_TX_PEC;
              pec_phase <= 1'b0;
            end else
              state <= CTRL_SEND_STOP;
          end else begin
            if (word_bytes_used == '0) begin
              if (wr_fifo_valid) begin
                wr_fifo_pop    <= 1'b1;
                wr_word_buf    <= wr_fifo_data;
                word_bytes_used<= 3'd1;
              end
              // else: stall waiting for WR_FIFO
            end else begin
              if (!bus_done)
                fsm_req_send_byte <= 1'b1;
              case (word_bytes_used)
                3'd1: fsm_byte_tx <= wr_word_buf[7:0];
                3'd2: fsm_byte_tx <= wr_word_buf[15:8];
                3'd3: fsm_byte_tx <= wr_word_buf[23:16];
                3'd4: fsm_byte_tx <= wr_word_buf[31:24];
                default: fsm_byte_tx <= 8'h00;
              endcase
              if (bus_done) begin
                bytes_remaining  <= bytes_remaining - 1'b1;  // count DOWN
                // only count successfully transferred bytes
                if (bus_ack_recv)
                  resp_xfer_len_r  <= resp_xfer_len_r + 1'b1;
                if (word_bytes_used == 3'd4)
                  word_bytes_used <= '0;
                else
                  word_bytes_used <= word_bytes_used + 1'b1;
                if (!bus_ack_recv) begin
                  resp_nack_r <= 1'b1;
                  resp_code_r <= 8'h02;
                  state       <= CTRL_SEND_STOP;
                end
              end
            end
          end
        end

        // -------------------------------------------------------------
        CTRL_RX_DATA: begin
          if (bytes_remaining == 9'd0) begin
            // All bytes transferred.
            if (rx_byte_idx != '0) begin
              rd_fifo_push      <= 1'b1;
              rd_fifo_push_data <= rx_word_buf & (32'hFFFFFFFF >> (32 - 8*rx_byte_idx));
            end
            // After last data byte: check PEC CRC if enabled, else STOP.
            if (pec_en_bus & cmd_pec_check_q) begin
              state           <= CTRL_RX_PEC;
              pec_rx_check_r  <= 1'b1;
            end else
              state <= CTRL_SEND_STOP;
          end else begin
            fsm_req_recv_byte  <= 1'b1;
            fsm_recv_last_byte <= (bytes_remaining == 9'd1) ? 1'b1 : 1'b0;
            if (bus_done) begin
              case (rx_byte_idx)
                3'd0: rx_word_buf[7:0]   <= bus_byte_rx;
                3'd1: rx_word_buf[15:8]  <= bus_byte_rx;
                3'd2: rx_word_buf[23:16] <= bus_byte_rx;
                3'd3: rx_word_buf[31:24] <= bus_byte_rx;
                default: begin
                  // rx_byte_idx is bounded to 0-3 by logic above; this default
                  // is a safety net — if a bug ever lets it exceed 3, clear
                  // the buffer rather than silently dropping the byte.
                  rx_word_buf <= 32'h0;
                end
              endcase
              rx_byte_idx     <= rx_byte_idx + 1'b1;
              bytes_remaining <= bytes_remaining - 1'b1;  // count DOWN
              resp_xfer_len_r <= resp_xfer_len_r + 1'b1;
              if (rx_byte_idx == 3'd3) begin
                rd_fifo_push      <= 1'b1;
                rd_fifo_push_data <= {bus_byte_rx, rx_word_buf[23:16],
                                       rx_word_buf[15:8], rx_word_buf[7:0]};
                rx_byte_idx       <= '0;
              end
            end
          end
        end

        // -------------------------------------------------------------
        CTRL_SEND_CCC: begin
          if (ccc_done) begin
            ccc_req <= 1'b0;  // clear request to prevent CCC handler restart
            if (ccc_error) begin
              resp_nack_r <= 1'b1;
              resp_code_r <= 8'h01;
            end
            if (ccc_resp_valid) begin
              rd_fifo_push      <= 1'b1;
              rd_fifo_push_data <= {24'h0, ccc_resp_byte};
            end
            state <= CTRL_PUSH_RESP;
          end
        end

        // -------------------------------------------------------------
        CTRL_RUN_DAA: begin
          if (daa_done) begin
            daa_start_entdaa  <= 1'b0;  // clear to prevent DAA handler restart
            daa_start_setdasa <= 1'b0;
            state <= CTRL_PUSH_RESP;
          end else if (daa_target_found) begin
            // push all 9 DAA bytes (6 PID + BCR + DCR + DA)
            // across 3 RD FIFO words. The old code only pushed daa_pid[7:0] (1 byte).
            rd_fifo_push      <= 1'b1;
            rd_fifo_push_data <= daa_pid[31:0];  // word 0: PID[31:0]
            daa_rd_push_phase <= 1'b1;  // trigger multi-word push
          end
        end

        // -------------------------------------------------------------
        // PEC append (write side): after last data byte, pulse pec_append_req
        // to latch the CRC, then transmit it as one extra byte.
        // -------------------------------------------------------------
        CTRL_TX_PEC: begin
          if (!pec_phase) begin
            // Phase 0: pulse pec_append_req for one cycle
            pec_append_req_r <= 1'b1;
            pec_phase         <= 1'b1;
          end else begin
            // Phase 1: PEC module outputs pec_tx_byte_valid + pec_tx_byte_value
            pec_append_req_r <= 1'b0;
            if (pec_tx_byte_valid_bus) begin
              fsm_req_send_byte <= 1'b1;
              fsm_byte_tx       <= pec_tx_byte_value_bus;
              if (bus_done) begin
                if (!bus_ack_recv) begin
                  resp_nack_r <= 1'b1;
                  resp_code_r <= 8'h02;
                end
                state <= CTRL_SEND_STOP;
              end
            end
          end
        end

        // -------------------------------------------------------------
        // PEC check (read side): receive one more byte (the PEC byte),
        // feed it to the PEC module for comparison. Do NOT push to RD_FIFO.
        // pec_error_bus is latched into INTERRUPT_STATUS.PEC_ERROR by the
        // register file's hw_err_pec input.
        // -------------------------------------------------------------
        CTRL_RX_PEC: begin
          fsm_req_recv_byte  <= 1'b1;
          fsm_recv_last_byte <= 1'b1;  // NACK the PEC byte (end of read)
          pec_rx_check_r     <= 1'b1;  // re-assert: this RX byte is the PEC byte
          if (bus_done) begin
            pec_rx_check_r <= 1'b0;   // clear after PEC byte received
            state          <= CTRL_SEND_STOP;
          end
        end

        // -------------------------------------------------------------
        //Transaction end — TOC bit decides STOP vs Repeated START
        // TOC=1: issue STOP (release bus)
        // TOC=0: hold bus (set bus_is_held for Repeated START on next command)
        // ABORT: always issue STOP regardless of TOC (abort must release bus)
        CTRL_SEND_STOP: begin
          if (cmd_toc || abort_pending_q) begin
            // TOC=1 or abort: issue STOP on the bus
            if (!bus_done) fsm_req_stop <= 1'b1;
            bus_is_held_q    <= 1'b0;
            // previously this branch had NO state transition
            // on bus_done — the STOP completed (byte_serdes pulsed done) but
            // the controller FSM stayed in CTRL_SEND_STOP forever, so the
            // response was never pushed and pop_resp timed out.
            if (bus_done) begin
              abort_pending_q <= 1'b0;
              state           <= CTRL_PUSH_RESP;
            end
          end else begin
            // TOC=0 (no abort): skip STOP, hold bus for Repeated START
            bus_is_held_q <= 1'b1;
            state <= CTRL_PUSH_RESP;
          end
        end

        // -------------------------------------------------------------
        CTRL_PUSH_RESP: begin
          resp_fifo_push      <= 1'b1;
          // Response word layout per resp_word_t struct (i3c_pkg.sv):
          // [31:19] reserved (13 bits)
          // [18] timeout
          // [17] nack
          // [16] reserved (was pec_err)
          // [15:8] xfer_len (8 bits)
          // [7:0] resp_code
          // timeout at bit 19 (wrong), so software never saw NACK. Also
          // 9-bit resp_xfer_len_r overflowed into reserved bit 16. Now
          // truncated to 8 bits per spec.
          resp_fifo_push_data <= {13'h0,                  // [31:19]
                                   resp_timeout_r,         // [18]
                                   resp_nack_r,            // [17]
                                   1'b0,                   // [16] reserved
                                   resp_xfer_len_r[7:0],   // [15:8]
                                   resp_code_r};           // [7:0]
          state               <= CTRL_IDLE;
        end

        // -------------------------------------------------------------
        // WAIT_BUS_FREE: Wait tBUF cycles after STOP before returning to IDLE.
        // This ensures spec-compliant bus free time between transactions.
        // -------------------------------------------------------------
        CTRL_WAIT_BUS_FREE: begin
          if (bus_free_cnt_q >= cfg_bus_free_time) begin
            bus_free_cnt_q <= '0;
            state          <= CTRL_IDLE;
          end else begin
            bus_free_cnt_q <= bus_free_cnt_q + 1'b1;
          end
        end

        // -------------------------------------------------------------
        // SEND_TGT_RST: Send Target Reset Pattern (0x7E broadcast).
        // Currently a pass-through — the reset pattern is sent via the
        // CCC handler's broadcast path. This state is entered when a
        // RSTACT CCC is decoded, and immediately completes.
        // -------------------------------------------------------------
        CTRL_SEND_TGT_RST: begin
          // Target reset pattern is sent via CCC broadcast (0x7E).
          // This state just waits for bus_done, then pushes response.
          if (bus_done) begin
            state <= CTRL_PUSH_RESP;
          end
        end

        // -------------------------------------------------------------
        default: state <= CTRL_IDLE;
      endcase
    end
  end

  // -------------------------------------------------------------------------
  // Forward primitive requests from CCC / DAA handlers to bus controller.
  // When state is CTRL_RUN_DAA: DAA primitives drive the bus controller.
  // When state is CTRL_SEND_CCC: CCC primitives drive the bus controller.
  // Otherwise: the FSM's own bus_req_* signals drive the bus controller.
  // -------------------------------------------------------------------------
  always_comb begin
    if (state == CTRL_RUN_DAA) begin
      bus_req_start        = daa_req_start;
      bus_req_repeat_start = daa_req_repeat_start;
      bus_req_stop         = daa_req_stop;
      bus_req_send_byte    = daa_req_send_byte;
      bus_byte_tx          = daa_req_send_byte_val;
      bus_req_recv_byte    = daa_req_recv_byte;
      bus_req_send_addr_w  = daa_req_send_addr_w;
      bus_req_send_addr_r  = daa_req_send_addr_r;
      bus_addr_val         = daa_req_addr_val;
      // DAA receives 8 bytes; the last (DCR) must be NACKed.
      bus_recv_last_byte   = daa_recv_last_byte;
    end else if (state == CTRL_SEND_CCC) begin
      bus_req_start        = ccc_start;
      bus_req_repeat_start = ccc_repeat_start;
      bus_req_stop         = ccc_stop;
      bus_req_send_addr_w  = ccc_send_addr_w;
      bus_req_send_addr_r  = ccc_send_addr_r;
      bus_addr_val         = ccc_addr_val;
      bus_req_send_byte    = ccc_send_byte;
      bus_byte_tx          = ccc_byte_val;
      bus_req_recv_byte    = ccc_recv_byte;
      bus_recv_last_byte   = 1'b1; // CCC single-byte responses: NACK
    end else if (ibi_req_bus) begin
      // IBI handler drives the bus controller when processing an IBI
      bus_req_start        = ibi_req_start;
      bus_req_repeat_start = 1'b0;
      bus_req_stop         = ibi_req_stop;
      bus_req_send_addr_w  = 1'b0;
      bus_req_send_addr_r  = 1'b0;
      bus_addr_val         = 7'h00;
      bus_req_send_byte    = 1'b0;
      bus_byte_tx          = 8'h00;
      bus_req_recv_byte    = ibi_req_recv_byte;
      // IBI handler controls ACK/NACK via ibi_req_nack (NACK unwanted address)
      bus_recv_last_byte   = ibi_req_nack;
    end else begin
      // FSM drives the bus controller in all other states
      bus_req_start        = fsm_req_start;
      bus_req_repeat_start = fsm_req_repeat_start;
      bus_req_stop         = fsm_req_stop;
      bus_req_send_addr_w  = fsm_req_send_addr_w;
      bus_req_send_addr_r  = fsm_req_send_addr_r;
      bus_addr_val         = fsm_addr_val;
      bus_req_send_byte    = fsm_req_send_byte;
      bus_byte_tx          = fsm_byte_tx;
      bus_req_recv_byte    = fsm_req_recv_byte;
      bus_recv_last_byte   = fsm_recv_last_byte;
    end
  end

  // Status output: true idle = FSM idle AND bus idle.
  assign controller_idle = (state == CTRL_IDLE);

import i3c_pkg::*;

  // -------------------------------------------------------------------------
  // Internal nets (wiring between sub-module instances)
  // -------------------------------------------------------------------------
  logic        tcmd_start, tcmd_repeat_start, tcmd_stop;
  logic        tcmd_drive_scl_low, tcmd_release_bus;
  logic        tcmd_bit_xfer, tcmd_bit_xfer_od;
  logic        sda_drive_val, mode_pushpull;
  logic        tcmd_done, tcmd_busy;
  logic        sda_sampled;  // sampled SDA value at SCL high (from phy_fsm)

  // Digital PHY -> Mux -> iobuf signals
  // The Digital PHY (i3c_phy_fsm) outputs go through i3c_phy_mux before
  // reaching io_buf. The mux selects between Digital PHY, Target Engine,
  // and Autonomous Bootstrap (TBD).
  logic        dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe;
  logic        dphy_sda_i,  dphy_scl_i;
  logic        pad_sda_o,  pad_sda_oe,  pad_scl_o,  pad_scl_oe;
  logic        pad_sda_i,  pad_scl_i;   // raw from iobuf (before DNF)
  logic        sda_i, scl_i;             // filtered (after DNF)

  // -------------------------------------------------------------------------
  // FIFO interface nets (wiring between FIFOs and controller)
  // -------------------------------------------------------------------------
  logic        cmd_pop;
  logic [31:0] cmd_pop_data;
  logic        cmd_valid;
  logic        wr_pop;
  logic [31:0] wr_pop_data;
  logic        wr_valid;
  logic        rd_push;
  logic [31:0] rd_push_data;
  logic        resp_push;
  logic [31:0] resp_push_data;

  // -------------------------------------------------------------------------
  // Config bus nets (wiring between register map and controller/serdes)
  // -------------------------------------------------------------------------
  // NOTE: cfg_* signals declared above near the Main FSM (Vivado VRFC 10-3380)

  // -------------------------------------------------------------------------
  // I2C speed prescaler → PHY timing mux
  // -------------------------------------------------------------------------
  // In I3C mode: PHY uses cfg_scl_high_time / cfg_scl_low_time (from I3C regfile).
  // In I2C mode: PHY uses i2c_speed_prescaler converted to high/low time.
  // prescaler N → SCL_freq = PCLK / (2*N), so high_time = low_time = N-2.
  // Also use OD (open-drain) timing for I2C, and prescaler-based START/STOP.
  // -------------------------------------------------------------------------
  logic [17:0] phy_scl_high_time, phy_scl_low_time;
  logic [17:0] phy_scl_od_high_time, phy_scl_od_low_time;
  logic [17:0] phy_tsu_start, phy_thd_start, phy_tsu_stop, phy_bus_free_time;
  logic [19:0] i2c_speed_prescaler;

  // Instantiate i2c_prescaler module.
  // This module converts the SPEED_PRESCALER value to SCL high/low times.
  logic [17:0] i2c_scl_high_time_pre, i2c_scl_low_time_pre;
  logic        i2c_prescaler_active;
  i2c_prescaler u_i2c_prescaler (
    .clk               (s_axi_aclk),
    .rst_n             (s_axi_aresetn),
    .speed_prescaler   (i2c_speed_prescaler),
    .i2c_scl_high_time (i2c_scl_high_time_pre),
    .i2c_scl_low_time  (i2c_scl_low_time_pre),
    .prescaler_active  (i2c_prescaler_active)
  );

  always_comb begin
    if (i2c_mode_q) begin
      // I2C mode: use i2c_prescaler output for SCL high/low
      // (prescaler=0 → i2c_prescaler outputs safe default of 50 cycles)
      phy_scl_high_time    = i2c_scl_high_time_pre;
      phy_scl_low_time     = i2c_scl_low_time_pre;
      phy_scl_od_high_time = i2c_scl_high_time_pre;  // I2C is always Open-Drain
      phy_scl_od_low_time  = i2c_scl_low_time_pre;
      // I2C START/STOP/bus_free: use same prescaler-derived timing (simplified)
      phy_tsu_start        = i2c_scl_high_time_pre;
      phy_thd_start        = i2c_scl_high_time_pre;
      phy_tsu_stop         = i2c_scl_high_time_pre;
      phy_bus_free_time    = i2c_scl_high_time_pre;
    end else begin
      // I3C mode: use I3C timing registers directly
      phy_scl_high_time    = cfg_scl_high_time;
      phy_scl_low_time     = cfg_scl_low_time;
      phy_scl_od_high_time = cfg_scl_od_high_time;
      phy_scl_od_low_time  = cfg_scl_od_low_time;
      phy_tsu_start        = cfg_tsu_start;
      phy_thd_start        = cfg_thd_start;
      phy_tsu_stop         = cfg_tsu_stop;
      phy_bus_free_time    = cfg_bus_free_time;
    end
  end

  // -------------------------------------------------------------------------
  // FIFO status nets (only the ones consumed by INTERRUPT_STATUS / FIFO_LVL_STATUS)
  // -------------------------------------------------------------------------
  logic        cmd_almost_full;
  logic [4:0]  cmd_free;
  logic        cmd_overflow, cmd_underflow;
  wire         cmd_overflow_w = cmd_overflow;
  logic        wr_almost_full;
  logic [5:0]  wr_free;
  logic        wr_overflow, wr_underflow;
  wire         wr_overflow_w = wr_overflow;
  logic        rd_almost_full;
  logic [5:0]  rd_level;
  logic        rd_overflow, rd_underflow;
  wire         rd_underflow_w = rd_underflow;
  logic        resp_empty, resp_almost_full;
  assign resp_empty = resp_fifo_empty;
  wire         resp_underflow_w = resp_underflow;
  wire         resp_almost_full_w = resp_almost_full;
  logic [4:0]  resp_level;

  // -------------------------------------------------------------------------
  // FSM status
  // -------------------------------------------------------------------------
  logic        fsm_controller_idle;
  assign fsm_controller_idle = (state == CTRL_IDLE);  // FSM is in IDLE state

  // PEC enable gate: global enable AND per-command PEC enable.
  // The PEC module in byte_serdes_i3c accumulates CRC whenever pec_en_bus=1.
  // The FSM separately controls append (write) and check (read) via state logic.
  assign pec_en_bus = cmd_pec_en_q;  // PEC enabled per-transaction via CMD_FIFO_CTRL[25]

  // -------------------------------------------------------------------------
  // CDC synchronizer: wake_irq from clk_aon domain → s_axi_aclk domain.
  // 3-flop synchronizer captures the edge of the asynchronous wake_irq
  // pulse from the always-on wake detector. The synchronized edge
  // (wake_irq_sync2 & ~wake_irq_meta) feeds INTERRUPT_STATUS.WAKE_EVENT.
  // -------------------------------------------------------------------------
  always_ff @(posedge s_axi_aclk or negedge rst_n) begin
    if (!rst_n) begin
      wake_irq_meta <= 1'b0;
      wake_irq_sync1 <= 1'b0;
      wake_irq_sync2 <= 1'b0;
    end else begin
      wake_irq_meta <= wake_irq;       // async sample (clk_aon)
      wake_irq_sync1 <= wake_irq_meta; // first sync flop
      wake_irq_sync2 <= wake_irq_sync1;// second sync flop (meta-stability resolved)
    end
  end

  // -------------------------------------------------------------------------
  // CDC: role_return (scl_filt → s_axi_aclk) — 3-flop sync + edge detect
  // -------------------------------------------------------------------------
  // Target engine pulses role_return for 1 SCL cycle when it detects GETACCR
  // addressed to us. SCL is slower than AXI, so we need a synchronizer to
  // safely capture the pulse and convert it to a 1-cycle AXI-domain pulse.
  // -------------------------------------------------------------------------
  always_ff @(posedge s_axi_aclk or negedge rst_n) begin
    if (!rst_n) begin
      role_return_sync1 <= 1'b0;
      role_return_sync2 <= 1'b0;
      role_return_sync2_d <= 1'b0;
    end else begin
      role_return_sync1  <= role_return_pulse;  // async sample (scl_filt)
      role_return_sync2  <= role_return_sync1;  // first sync flop
      role_return_sync2_d <= role_return_sync2; // delayed for edge detect
    end
  end
  // Edge-detected pulse: 1 AXI cycle when role_return is first seen
  wire role_return_synced = role_return_sync2 & ~role_return_sync2_d;

  // -------------------------------------------------------------------------
  // AXI <-> Register map interface
  // -------------------------------------------------------------------------
  logic        reg_wr, reg_rd, reg_wr_ack, reg_rd_ack;
  logic [31:0] reg_wr_addr, reg_wr_data, reg_rd_addr, reg_rd_data;
  logic [3:0]  reg_wr_strb;

  // -------------------------------------------------------------------------
  // FIFO push/pop signals
  // -------------------------------------------------------------------------
  logic        cmd_push, wr_push;
  logic [31:0] cmd_push_data, wr_push_data;
  // RD/RESP FIFO pop signals
  logic        rd_pop, resp_pop;
  logic [31:0] rd_pop_data, resp_pop_data;
  // Wire host-side ports to internal FIFO signals
  assign rd_pop          = rd_fifo_pop;
  assign rd_fifo_pop_data = rd_pop_data;
  assign resp_pop         = resp_fifo_pop;
  assign resp_fifo_pop_data = resp_pop_data;
  logic        rd_valid, resp_valid;

  // -------------------------------------------------------------------------
  // Software reset / FIFO flush (from register map)
  // -------------------------------------------------------------------------
  logic        sw_reset;
  logic        sw_flush_cmd, sw_flush_wr, sw_flush_rd, sw_flush_resp;
  logic [2:0]  speed_mode;             // from I3C_SPEED_MODE_CFG (0=SDR)
  // SCL clock-stall detector output (from u_phy_fsm → timing_control)
  logic        clk_stall_bus;
  // Wake-event CDC synchronizer (clk_aon → s_axi_aclk domain)
  // -------------------------------------------------------------------------
  // PEC (Packet Error Code) data-path signals
  // -------------------------------------------------------------------------

  // cmd_pec_append (cmd_word_t.pec_append, bit 27) gates write-side CRC append.
  // cmd_pec_check (cmd_word_t.pec_check, bit 26) gates read-side CRC check.
  // These per-command bits are latched into cmd_pec_append_q / cmd_pec_check_q
  // when the FSM pops a command from the CMD FIFO.
  // The PEC module lives inside byte_serdes_i3c; these signals connect the FSM
  // to the PEC append/check handshake.
  // -------------------------------------------------------------------------
  logic        pec_error_bus;         // byte_serdes_i3c → FSM (CRC mismatch)
  logic [7:0]  pec_crc_out_bus;       // byte_serdes_i3c → FSM (current CRC, de )
  // IBI/Hot-Join/Group/DNF config signals (from register map)
  logic        hj_auto_daa;
  logic        group_enable;
  logic [6:0]  group_count;
  logic [31:0] group_table_0, group_table_1, group_table_2, group_table_3;
  logic [31:0] group_table_4, group_table_5, group_table_6, group_table_7;
  logic [3:0]  dnf_threshold;
  logic        dnf_enable;

  // Wake detector config (from WAKE_CTRL register via regfile)
  logic        wake_en, wake_start_en, wake_scl_en;

  // Target engine config (from TARGET_CTRL register via regfile)
  logic [6:0]  ctrl_dyn_addr;   // Controller own DA

  // Abort / Resume / Controller Role (from register file)
  // Clock gating control (from CLK_GATE_CTRL register at 0x98)
  // [0] = controller-engine gate, [1] = FIFO gate,
  // [2] = auto-gate enable, [3] = reserved
  logic [3:0]  clk_gate_ctrl;

  // Gated clocks (derived from s_axi_aclk via i3c_clock_gate instances)
  // clk_ctrl: gates controller sub-modules (serdes, CCC, DAA, IBI, HJ, group, DNF, phy_fsm)
  // clk_fifo: gates all 6 FIFOs (cmd, wr, rd, resp, i2c_tx, i2c_rx)
  // Note: AXI slave, register file, wake detector, and power controller stay
  // on ungated s_axi_aclk / clk_aon (must always be reachable by host).
  logic        clk_ctrl, clk_fifo;
  logic        clk_ctrl_gated, clk_fifo_gated;  // unused status outputs

  // IBI/Hot-Join handler output wires (stubs — handlers not yet instantiated)
  logic        ibi_fifo_push_wire;
  logic [31:0] ibi_fifo_push_data_wire;
  logic        ibi_irq_wire;
  logic        ibi_active_wire;
  logic        hj_detected_wire;
  logic        hj_clear_wire;

  // -------------------------------------------------------------------------
  // Controller FSM
  // -------------------------------------------------------------------------
  // (FSM logic is inlined above — no separate u_fsm instantiation)

  // -------------------------------------------------------------------------
  // CCC handler
  // -------------------------------------------------------------------------
  // -------------------------------------------------------------------------
  // AXI4-Lite slave
  // -------------------------------------------------------------------------
  axi4_lite_slave #(
    .ADDR_W (32),
    .DATA_W (32)
  ) u_axi4_lite (
    .clk          (s_axi_aclk),
    .rst_n        (rst_n),
    .s_axi_awvalid(s_axi_awvalid), .s_axi_awready(s_axi_awready), .s_axi_awaddr(s_axi_awaddr),
    .s_axi_awprot(s_axi_awprot),
    .s_axi_wvalid (s_axi_wvalid),  .s_axi_wready (s_axi_wready),  .s_axi_wdata (s_axi_wdata), .s_axi_wstrb(s_axi_wstrb),
    .s_axi_bvalid (s_axi_bvalid),  .s_axi_bready (s_axi_bready),  .s_axi_bresp (s_axi_bresp),
    .s_axi_arvalid(s_axi_arvalid), .s_axi_arready(s_axi_arready), .s_axi_araddr(s_axi_araddr),
    .s_axi_arprot(s_axi_arprot),
    .s_axi_rvalid (s_axi_rvalid),  .s_axi_rready (s_axi_rready),  .s_axi_rdata (s_axi_rdata), .s_axi_rresp(s_axi_rresp),
    .reg_wr       (reg_wr),  .reg_wr_addr(reg_wr_addr), .reg_wr_data(reg_wr_data),
    .reg_wr_strb  (reg_wr_strb), .reg_wr_ack(axi_wr_ack_final),   // muxed: I3C or I2C
    .reg_rd       (reg_rd),  .reg_rd_addr(reg_rd_addr), .reg_rd_data(axi_rd_data_final), // muxed
    .reg_rd_ack   (axi_rd_ack_final)  // muxed: I3C or I2C
  );

  // -------------------------------------------------------------------------
  // Register map
  // -------------------------------------------------------------------------
  i3c_register_file #(
    .AXI_CLK_FREQ_HZ (AXI_CLK_FREQ_HZ),
    .SCL_CLK_FREQ_HZ (SCL_CLK_FREQ_HZ),
    .CTRL_PID        (CTRL_PID),
    .CTRL_BCR        (CTRL_BCR),
    .CTRL_DCR        (CTRL_DCR)
  ) u_regfile (
    .clk                   (s_axi_aclk),
    .rst_n                 (rst_n),
    .reg_wr                (reg_wr),  .reg_wr_addr(reg_wr_addr), .reg_wr_data(reg_wr_data),
    .reg_wr_strb           (reg_wr_strb), .reg_wr_ack(reg_wr_ack),
    .reg_rd                (reg_rd),  .reg_rd_addr(reg_rd_addr), .reg_rd_data(reg_rd_data),
    .reg_rd_ack            (reg_rd_ack),
    .hw_bus_busy           (bus_busy),
    .hw_controller_idle    (fsm_controller_idle),
    .hw_bytes_xferd        (resp_xfer_len_r[7:0]),
    .hw_cmd_fifo_free      (cmd_free),
    .hw_resp_fifo_level    (resp_level),
    .hw_wr_fifo_free       (wr_free),
    .hw_rd_fifo_level      (rd_level),
    // FIFOs are accessed via dedicated ports on i3c_controller_top.
    // Register file is CONFIG-ONLY.
    // FIFO level status inputs are wired for diagnostic readback.
    .cfg_scl_high_time     (cfg_scl_high_time),
    .cfg_scl_low_time      (cfg_scl_low_time),
    .cfg_sda_hold_time     (cfg_sda_hold_time),
    .cfg_bus_free_time     (cfg_bus_free_time),
    .cfg_tsu_start         (cfg_tsu_start),
    .cfg_thd_start         (cfg_thd_start),
    .cfg_tsu_stop          (cfg_tsu_stop),
    .cfg_scl_od_high_time  (cfg_scl_od_high_time),
    .cfg_scl_od_low_time   (cfg_scl_od_low_time),
    .hw_err_timeout        (resp_timeout_r),
    .hw_err_nack_addr      (resp_nack_r && resp_code_r == 8'h01),
    .hw_err_nack_data      (resp_nack_r && resp_code_r == 8'h02),
    //ACK_STATUS inputs — derived from response codes and CCC handler status
    // Private transfers: use resp_code_r
    .hw_xfer_addr_ack      (resp_fifo_push && !resp_nack_r && resp_code_r == 8'h00),
    .hw_xfer_addr_nack     (resp_nack_r && resp_code_r == 8'h01),
    .hw_xfer_data_ack      (resp_fifo_push && !resp_nack_r && resp_code_r == 8'h00),
    .hw_xfer_data_nack     (resp_nack_r && resp_code_r == 8'h02),
    // Broadcast CCCs: ACK if ccc_done and no NACK (covers ENEC, DISEC, RSTDAA, ENTDAA, SETMRL, SETMWL, ENDXFER)
    //CCC ACK/NACK: use resp_fifo_push (not ccc_done) to align with ack_status_q latch
    .hw_ccc_opcode_ack     (resp_fifo_push && !ccc_is_direct && !ccc_error),
    .hw_ccc_opcode_nack    (resp_fifo_push && !ccc_is_direct && ccc_error),
    .hw_ccc_direct_ack     (resp_fifo_push && ccc_is_direct && !ccc_error),
    .hw_ccc_direct_nack    (resp_fifo_push && ccc_is_direct && ccc_error),
    .hw_err_fifo_overflow  (cmd_overflow | wr_overflow | rd_overflow | resp_overflow),
    .hw_err_fifo_underflow (cmd_underflow | wr_underflow | rd_underflow | resp_underflow),
    .hw_err_pec            (pec_error_bus),
    // Event status inputs (sticky in INTERRUPT_STATUS)
    .hw_xfer_done          (resp_fifo_push),       // command completion pulse
    .hw_ibi_received       (ibi_irq_wire),         // IBI received pulse
    .hw_hj_received        (hj_detected_wire),     // HJ detected
    .hw_wake_event         (wake_irq_sync2 & ~wake_irq_meta), // CDC-synced wake edge
    .hw_clk_stall          (clk_stall_bus),        // SCL stretch from timing_control
    //Handoff/reclaim events from role_manager
      .hw_handoff_done       (handoff_done_pulse),
      .hw_handoff_failed     (handoff_failed_pulse),
      .hw_reclaim_done       (reclaim_done_pulse),   // pulse when RECLAIMING -> ACTIVE
      // FIFO level status inputs (live RO bits in INTERRUPT_STATUS)
      .hw_cmd_fifo_almost_full (cmd_almost_full),
      .hw_target_addressed   (target_addressed),
      .hw_target_busy        (target_busy),
      .hw_target_rx_done     (target_rx_done),
      .hw_target_tx_req      (target_tx_req),
      .hw_target_nack_sent   (target_nack_sent),
      .hw_wr_fifo_almost_full  (wr_almost_full),
      .hw_rd_fifo_almost_full  (rd_almost_full),
      .hw_resp_fifo_not_empty  (~resp_empty),
      .hw_cmd_fifo_overflow    (cmd_overflow_w),
      .hw_cmd_fifo_underflow   (1'b0),  // CMD FIFO is write-only from host
      .hw_wr_fifo_overflow     (wr_overflow_w),
      .hw_wr_fifo_underflow    (1'b0),  // WR FIFO is write-only from host
      .hw_rd_fifo_overflow     (1'b0),  // RD FIFO is read-only from host
      .hw_rd_fifo_underflow    (rd_underflow_w),
      .hw_resp_fifo_overflow   (1'b0),  // RESP FIFO is write-only from controller
      .hw_resp_fifo_underflow  (resp_underflow_w),
      .hw_resp_fifo_almost_full(resp_almost_full_w),
      .sw_reset              (sw_reset),
      .sw_flush_cmd           (sw_flush_cmd),
      .sw_flush_wr            (sw_flush_wr),
      .sw_flush_rd            (sw_flush_rd),
      .sw_flush_resp          (sw_flush_resp),
      .clk_gate_ctrl          (clk_gate_ctrl),
      .speed_mode             (speed_mode),
      .ctrl_en                (ctrl_en),
      .ibi_fifo_push          (ibi_fifo_push_wire),
      .ibi_fifo_push_data     (ibi_fifo_push_data_wire),
      .ibi_irq                (ibi_irq_wire),
      .ibi_active             (ibi_active_wire),
      .ibi_accepted           (ibi_req_ack_w),
      .ibi_rejected           (ibi_req_nack_w),
      .hj_auto_daa            (hj_auto_daa),
      .hj_detected            (hj_detected_wire),
      .hj_pending             (hj_pending_wire),
      .hj_clear               (hj_clear_wire),
      .group_enable           (group_enable),
      .group_count            (group_count),
      .group_table_0          (group_table_0),
      .group_table_1          (group_table_1),
      .group_table_2          (group_table_2),
      .group_table_3          (group_table_3),
      .group_table_4          (group_table_4),
      .group_table_5          (group_table_5),
      .group_table_6          (group_table_6),
      .group_table_7          (group_table_7),
      .dnf_threshold          (dnf_threshold),
      .dnf_enable             (dnf_enable),
      .wake_en                (wake_en),
      .wake_start_en          (wake_start_en),
      .wake_scl_en            (wake_scl_en),
      .ctrl_dyn_addr          (ctrl_dyn_addr),
      .abort_req              (abort_req),
      .resume_req             (resume_req),
      //Bus configuration (BUS_CONFIG register)
      .bus_type               (bus_type),
      //Reclaim configuration (RECLAIM_CONFIG register)
      .reclaim_en             (reclaim_en),
      .reclaim_timeout_us     (reclaim_timeout_us),
      //Mixed-bus SCL high time (SCL_HIGH_TIME_MIXED_CFG register)
      .scl_high_time_mixed    (scl_high_time_mixed),
      //Role state readback (from role_manager)
      .role_state_in          (role_state_out),
      .handoff_status_in      (handoff_status),
      // Aggregated IRQ output
      .irq                    (i3c_irq)
      // FIFOs accessed via dedicated ports on i3c_controller_top.
    );

  assign cfg_scl_high_time_mixed = scl_high_time_mixed;

  // ===========================================================================
  // Clock Gating — two i3c_clock_gate instances
  // ===========================================================================
  // 1. Controller-engine gate (CLK_GATE_CTRL[0]):
  // Gates the clock to serdes, CCC, DAA, IBI, HJ, group, DNF, phy_fsm.
  // The host should only assert this gate when the controller FSM is in
  // CTRL_IDLE and all sub-modules are idle. When gated, these blocks
  // consume zero dynamic power.
  // 2. FIFO gate (CLK_GATE_CTRL[1]):
  // Gates the clock to all 6 FIFOs (cmd, wr, rd, resp, i2c_tx, i2c_rx).
  // The host should only assert this gate when all FIFOs are empty and
  // no push/pop is pending.
  // Both gates are manual-only (AUTO_GATE=0). The host writes CLK_GATE_CTRL
  // to gate/un-gate. Auto-gating (CLK_GATE_CTRL[2]) is available as a future
  // enhancement — when enabled, the clock auto-gates after GATE_CYCLES of
  // inactivity, and re-enables immediately on the activity input.
  // Note: The inlined controller FSM stays on ungated s_axi_aclk because it
  // contains CDC synchronizers (wake_irq, bus_idle) that must remain in the
  // s_axi_aclk domain. The FSM communicates with sub-modules on clk_ctrl;
  // when the gate is open, clk_ctrl = s_axi_aclk (same domain, no CDC).
  // When the gate is closed, the FSM is in CTRL_IDLE and not communicating
  // with any sub-module, so no CDC issue arises.
  // ===========================================================================

  // Activity signals for auto-gate (OR of all relevant push/pop/busy signals)
  logic fifo_activity;
  logic ctrl_activity;

  // FIFO activity: any FIFO push or pop
  // FIFO activity: includes ctrl_activity so clk_fifo stays alive
  // whenever the controller FSM is active (FSM generates 1-cycle FIFO
  // push/pop pulses that must not be missed due to clock gate latency).
  assign fifo_activity = cmd_push | cmd_pop | wr_push | wr_pop |
                         rd_push | rd_pop | resp_push | resp_pop |
                         i2c_tx_fifo_wr | i2c_tx_fifo_rd |
                         i2c_rx_fifo_wr | i2c_rx_fifo_rd |
                         ctrl_activity |   // keep FIFOs clocked when I3C FSM is active
                         i2c_busy;         // keep FIFOs clocked when I2C FSM is active

  // Controller activity: FSM not idle, or bus busy, or any handler active
  // FSM was in CTRL_IDLE (which it is during I2C transfers, since i2c_mode_q=1
  // forces the I3C FSM to stay idle), ctrl_activity was 0. This gated clk_ctrl,
  // which stopped the PHY FSM (clocked by clk_ctrl). The I2C FSM's phy_req_*
  // signals reached the PHY FSM but the PHY FSM couldn't process them because
  // its clock was gated off. Result: I2C FSM hung in I2C_START forever.
  assign ctrl_activity = (state != CTRL_IDLE) | bus_busy |
                         ccc_req | daa_start_entdaa | daa_start_setdasa |
                         ibi_active_w | hj_pending_w |
                         i2c_busy;  // keep clk_ctrl alive during I2C transfers

  // Controller-engine clock gate
  // [0] GLOBAL: gates ALL clocks (overrides everything)
  // [1] CTRL_ENGINE: gate controller engine when in Target role
  // [3] FIFO: auto-gate FIFOs when no activity
  i3c_clock_gate #(
    .AUTO_GATE   (1'b1),
    .GATE_CYCLES (8)
  ) u_clk_gate_ctrl (
    .clk_in          (s_axi_aclk),
    .rst_n           (rst_n),
    .manual_gate_en  (clk_gate_ctrl[0] | clk_gate_ctrl[1]),  // GLOBAL or CTRL_ENGINE
    .auto_gate_en    (1'b0),  // controller engine: manual gate only (no auto)
    .activity        (ctrl_activity),
    .clk_out         (clk_ctrl),
    .gated           (clk_ctrl_gated)
  );

  // FIFO clock gate
  i3c_clock_gate #(
    .AUTO_GATE   (1'b1),
    .GATE_CYCLES (4)
  ) u_clk_gate_fifo (
    .clk_in          (s_axi_aclk),
    .rst_n           (rst_n),
    .manual_gate_en  (clk_gate_ctrl[0]),  // GLOBAL only (FIFO manual gate = global)
    .auto_gate_en    (clk_gate_ctrl[3]),  // FIFO auto-gate enable
    .activity        (fifo_activity),
    .clk_out         (clk_fifo),
    .gated           (clk_fifo_gated)
  );

  // -------------------------------------------------------------------------
  // FIFOs
  // -------------------------------------------------------------------------
  assign cmd_push      = cmd_fifo_push;
  assign cmd_push_data = cmd_fifo_push_data;
  i3c_cmd_fifo #(.DEPTH(CMD_FIFO_DEPTH)) u_cmd_fifo (
    .clk(clk_fifo), .rst_n(rst_n),
    .push(cmd_push), .push_data(cmd_push_data),
    .pop(cmd_pop), .pop_data(cmd_pop_data), .pop_valid(cmd_valid),
    .empty(cmd_fifo_empty), .full(cmd_fifo_full), .almost_full(cmd_almost_full), .level(cmd_free),
    .overflow(cmd_overflow), .underflow(cmd_underflow),
    .flush(sw_flush_cmd | sw_reset));

  // WR FIFO push driven by host-side port
  assign wr_push       = wr_fifo_push;
  assign wr_push_data  = wr_fifo_push_data;
  i3c_wr_fifo #(.DEPTH(WR_FIFO_DEPTH)) u_wr_fifo (
    .clk(clk_fifo), .rst_n(rst_n),
    .push(wr_push), .push_data(wr_push_data),
    .pop(wr_pop), .pop_data(wr_pop_data), .pop_valid(wr_valid),
    .empty(wr_fifo_empty), .full(wr_fifo_full), .almost_full(wr_almost_full), .level(wr_free),
    .overflow(wr_overflow), .underflow(wr_underflow),
    .flush(sw_flush_wr | sw_reset));

  i3c_rd_fifo #(.DEPTH(RD_FIFO_DEPTH)) u_rd_fifo (
    .clk(clk_fifo), .rst_n(rst_n),
    .push(rd_push), .push_data(rd_push_data),
    .pop(rd_pop), .pop_data(rd_pop_data), .pop_valid(rd_valid),
    .empty(rd_fifo_empty), .full(rd_fifo_full), .almost_full(rd_almost_full), .level(rd_level),
    .overflow(rd_overflow), .underflow(rd_underflow),
    .flush(sw_flush_rd | sw_reset));

  i3c_resp_fifo #(.DEPTH(RESP_FIFO_DEPTH)) u_resp_fifo (
    .clk(clk_fifo), .rst_n(rst_n),
    .push(resp_push), .push_data(resp_push_data),
    .pop(resp_pop), .pop_data(resp_pop_data), .pop_valid(resp_valid),
    .empty(resp_fifo_empty), .full(resp_fifo_full), .almost_full(resp_almost_full), .level(resp_level),
    .overflow(resp_overflow), .underflow(resp_underflow),
    .flush(sw_flush_resp | sw_reset));

  // -------------------------------------------------------------------------
  // FSM ↔ FIFO signal bridge
  // -------------------------------------------------------------------------
  // The FSM uses *_fifo_* names; the FIFO instances use bare names. Bridge them.
  // -------------------------------------------------------------------------
  assign cmd_pop          = cmd_fifo_pop;
  assign cmd_fifo_data    = cmd_pop_data;
  assign cmd_fifo_valid   = cmd_valid;
  assign wr_pop           = wr_fifo_pop;
  assign wr_fifo_data     = wr_pop_data;
  assign wr_fifo_valid    = wr_valid;
  assign rd_push          = rd_fifo_push;
  assign rd_push_data     = rd_fifo_push_data;
  assign resp_push        = resp_fifo_push;
  assign resp_push_data   = resp_fifo_push_data;

  // -------------------------------------------------------------------------
  // CCC handler
  // -------------------------------------------------------------------------
  logic [7:0] ccc_getrtgl_byte_w;  // group_addr response byte for GETRTGL
  logic       ccc_getrtgl_valid_w;

  i3c_ccc_handler u_ccc (
    .clk                   (clk_ctrl),
    .rst_n                 (rst_n),
    .cfg_mwl               (16'd0), // Not implemented in top level
    .cfg_mrl               (16'd0), // Not implemented in top level
    .ccc_req               (ccc_req),
    .ccc_is_direct         (ccc_is_direct),
    .ccc_opcode            (ccc_opcode),
    .ccc_target_addr       (ccc_target_addr),
    .ccc_defining_byte     (ccc_defining_byte),
    .ccc_has_defining_byte (ccc_has_defining_byte),
    .ccc_start             (ccc_start),
    .ccc_repeat_start      (ccc_repeat_start),
    .ccc_stop              (ccc_stop),
    .ccc_send_addr_w       (ccc_send_addr_w),
    .ccc_send_addr_r       (ccc_send_addr_r),
    .ccc_addr_val          (ccc_addr_val),
    .ccc_send_byte         (ccc_send_byte),
    .ccc_byte_val          (ccc_byte_val),
    .ccc_recv_byte         (ccc_recv_byte),
    .ccc_expect_response   (ccc_expect_response),
    .ccc_done              (ccc_done),
    .ccc_resp_valid        (ccc_resp_valid),
    .ccc_resp_byte         (ccc_resp_byte),
    //GETACCR status outputs (for role_manager)
    .ccc_getacccr_addr_nack (ccc_getacccr_addr_nack),
    .ccc_getacccr_data_nack (ccc_getacccr_data_nack),
    .ccc_getacccr_ack       (ccc_getacccr_ack),
    .ccc_error              (ccc_error),
    .prim_done             (bus_done),
    .prim_ack_recv         (bus_ack_recv),
    .prim_byte_recv        (bus_byte_rx)
  );


  // -------------------------------------------------------------------------
  // DAA sequencer
  // -------------------------------------------------------------------------
  i3c_daa u_daa (
    .clk                    (clk_ctrl),
    .rst_n                  (rst_n),
    .start_entdaa           (daa_start_entdaa),
    .start_setdasa          (daa_start_setdasa),
    .setdasa_static_addr    (daa_setdasa_static),
    .tgt_table_full         (tgt_table_full),
    .tgt_table_count        (tgt_table_count[3:0]),
    .req_start              (daa_req_start),
    .req_repeat_start       (daa_req_repeat_start),
    .req_stop               (daa_req_stop),
    .req_send_byte          (daa_req_send_byte),
    .req_send_byte_val      (daa_req_send_byte_val),
    .req_recv_byte          (daa_req_recv_byte),
    .req_send_ack           (daa_req_send_ack),
    .req_send_nack          (daa_req_send_nack),
    .req_send_addr_w        (daa_req_send_addr_w),
    .req_send_addr_r        (daa_req_send_addr_r),
    .req_addr_val           (daa_req_addr_val),
    .prim_done              (bus_done),
    .prim_ack_recv          (bus_ack_recv),
    .prim_byte_recv         (bus_byte_rx),
    .daa_done               (daa_done),
    .daa_target_found       (daa_target_found),
    .daa_pid                (daa_pid),
    .daa_bcr                (daa_bcr),
    .daa_dcr                (daa_dcr),
    .daa_dyn_addr_assigned  (daa_dyn_addr_assigned),
    .daa_recv_last_byte     (daa_recv_last_byte)
  );

  // -------------------------------------------------------------------------
  // Bus controller + timing control
  // byte_serdes_i3c is the I3C bus controller wrapper (byte shift + START/STOP
  // + PEC). It instantiates i3c_pec internally.
  // -------------------------------------------------------------------------
  byte_serdes_i3c u_bus_ctrl (
    .clk                   (clk_ctrl),
    .rst_n                 (rst_n),
    .req_start             (bus_req_start),
    .req_repeat_start      (bus_req_repeat_start),
    .req_stop              (bus_req_stop),
    .req_send_addr_w       (bus_req_send_addr_w),
    .req_send_addr_r       (bus_req_send_addr_r),
    .addr_val              (bus_addr_val),
    .req_send_byte         (bus_req_send_byte),
    .byte_tx               (bus_byte_tx),
    .req_recv_byte         (bus_req_recv_byte),
    .recv_last_byte        (bus_recv_last_byte),
    .i2c_mode              (1'b0),  // I3C controller always uses push-pull; I2C mode is handled by the separate I2C FSM
    .done                  (bus_done),
    .ack_recv              (bus_ack_recv),
    .byte_rx               (bus_byte_rx),
    .busy                  (bus_busy),
    .idle                  (bus_idle_i3c),    // I3C SerDes idle (was bus_idle)
    .tcmd_start            (tcmd_start),
    .tcmd_repeat_start     (tcmd_repeat_start),
    .tcmd_stop             (tcmd_stop),
    .tcmd_drive_scl_low    (tcmd_drive_scl_low),
    .tcmd_release_bus      (tcmd_release_bus),
    .tcmd_bit_xfer         (tcmd_bit_xfer),
    .tcmd_bit_xfer_od      (tcmd_bit_xfer_od),
    .sda_drive_val         (sda_drive_val),
    .mode_pushpull         (mode_pushpull),
    .tcmd_done             (tcmd_done),
    .sda_sampled           (sda_sampled),
    .pec_en                (pec_en_bus),
    .pec_append_req        (pec_append_req_r),
    .pec_rx_check          (pec_rx_check_r),
    .pec_error             (pec_error_bus),
    .pec_crc_out           (pec_crc_out_bus),
    .pec_tx_byte_valid     (pec_tx_byte_valid_bus),
    .pec_tx_byte_value     (pec_tx_byte_value_bus)
  );

  // ---------------------------------------------------------------------------
  // Digital PHY FSM — coordinates timing_control + start_stop_gen
  // Receives tcmd_* commands from byte_serdes_i3c, routes to appropriate sub-
  // module, and outputs aggregated SDA/SCL drive signals (dphy_*).
  // The dphy_* outputs go through i3c_phy_mux before reaching io_buf.
  // ---------------------------------------------------------------------------
  i3c_phy_fsm u_phy_fsm (
    .clk                   (clk_ctrl),
    .rst_n                 (rst_n),  // synchronized reset
    .cfg_scl_high_time     (phy_scl_high_time),
    .cfg_scl_low_time      (phy_scl_low_time),
    .cfg_sda_hold_time     (cfg_sda_hold_time),
    .cfg_bus_free_time     (phy_bus_free_time),
    .cfg_tsu_start         (phy_tsu_start),
    .cfg_thd_start         (phy_thd_start),
    .cfg_tsu_stop          (phy_tsu_stop),
    .cfg_scl_od_high_time  (phy_scl_od_high_time),
    .cfg_scl_od_low_time   (phy_scl_od_low_time),
    //Mixed-bus timing support
    .bus_type              (bus_type),
    .cfg_scl_high_time_mixed (cfg_scl_high_time_mixed),
    .cmd_start             (mux_cmd_start),          // i2c_mode_q muxed
    .cmd_repeat_start      (mux_cmd_repeat_start),   // i2c_mode_q muxed
    .cmd_stop              (mux_cmd_stop),           // i2c_mode_q muxed
    .cmd_drive_scl_low     (mux_cmd_drive_scl_low),  // i2c_mode_q muxed
    .cmd_release_bus       (mux_cmd_release_bus),    // i2c_mode_q muxed
    .cmd_bit_xfer          (mux_cmd_bit_xfer),       // i2c_mode_q muxed
    .cmd_bit_xfer_od       (mux_cmd_bit_xfer_od),    // i2c_mode_q muxed
    .sda_drive_val         (mux_sda_drive_val),      // i2c_mode_q muxed
    .mode_pushpull         (mux_mode_pushpull),       // i2c_mode_q muxed
    .done                  (tcmd_done),
    .busy                  (tcmd_busy),
    .sda_sampled           (sda_sampled),
    .stretch_detected      (clk_stall_bus),  // SCL stretch → INTERRUPT_STATUS.CLK_STALL
    // Pad drive (to mux)
    .sda_o                 (dphy_sda_o),
    .sda_oe                (dphy_sda_oe),
    .scl_o                 (dphy_scl_o),
    .scl_oe                (dphy_scl_oe),
    // Pad readback (from mux, filtered by DNF)
    .sda_i                 (sda_i),
    .scl_i                 (scl_i)
  );

  // ---------------------------------------------------------------------------
  //Role Manager — Figure 186 reclaim FSM + 100µs bus-idle monitor
  // Owns the phy_mux select bits. Software NEVER writes the select directly.
  // ---------------------------------------------------------------------------
  logic handoff_trigger_internal_d;
  logic handoff_trigger_pulse;

  i3c_role_manager u_role_manager (
    .clk_sys               (s_axi_aclk),
    .rst_sys_n             (rst_n),
    // Config from register file
    .reclaim_en            (reclaim_en),
    .reclaim_timeout_us    (reclaim_timeout_us),
    // Handoff control — wired to CCC handler GETACCR detection
    .handoff_trigger       (handoff_trigger_pulse),
    .getacccr_done         (getacccr_done_internal),
    .getacccr_ack          (getacccr_ack_internal),
    .getacccr_addr_nack    (getacccr_addr_nack_internal),
    .getacccr_data_nack    (getacccr_data_nack_internal),
    // Bus activity detection (from DNF filtered SCL/SDA)
    .scl_falling           (scl_falling_det),
    .sda_falling           (sda_falling_det),
    // Filtered SCL/SDA levels (TB-only hooks, not used internally)
    .scl_filt              (scl_i),
    .sda_filt              (sda_i),
    // Bootstrap (TBD)
    .bootstrap_active      (bootstrap_active),
    // Outputs to controller FSM
    .role_is_controller    (role_is_controller),
    .role_is_target        (role_is_target),
    .reclaim_in_progress   (reclaim_in_progress),
    .handoff_done_pulse    (handoff_done_pulse),
    .handoff_failed_pulse  (handoff_failed_pulse),
    .handoff_fail_reason   (handoff_fail_reason),
    .handoff_status        (handoff_status),
    // Outputs to phy_mux
    .phy_mux_sel           (phy_mux_sel),
    // Outputs to target_engine
    .target_engine_en      (role_target_en),  // from role_manager
    //Voluntary return input (from target engine)
    .role_return           (role_return_synced),  // CDC: scl_filt → s_axi_aclk
    // Output to register file (status readback)
    .role_state_out        (role_state_out)
  );

  //Simple SCL/SDA falling-edge detectors for the role_manager
  logic scl_prev_det, sda_prev_det;
  always_ff @(posedge s_axi_aclk or negedge rst_n) begin
    if (!rst_n) begin
      scl_prev_det <= 1'b1;
      sda_prev_det <= 1'b1;
    end else begin
      scl_prev_det <= scl_i;
      sda_prev_det <= sda_i;
    end
  end
  assign scl_falling_det = scl_prev_det && !scl_i;
  assign sda_falling_det = sda_prev_det && !sda_i;

  //Wire handoff_trigger and GETACCR status from controller FSM / CCC handler
  // to the role_manager.
  // handoff_trigger: pulses when CMD_GETACCR is popped from the CMD FIFO
  // (the controller FSM enters CTRL_SEND_CCC with ccc_opcode=0x91)
  // getacccr_done: pulses when the CCC handler finishes (ccc_done)
  // getacccr_ack: 1 if target ACKed (Format 1: Accepted)
  // getacccr_addr_nack: 1 if target address NACKed (no device)
  // getacccr_data_nack: 1 if target data NACKed (not capable / rejected)
  // The controller FSM's CTRL_DECODE_CMD state sets ccc_req=1 when CMD_GETACCR
  // is decoded. We detect this as handoff_trigger.
  // The CCC handler's ccc_done signals completion.
  // The CCC handler's ccc_getacccr_* outputs carry the ACK/NACK result.
  //handoff_trigger — pulses when GETACCR (CP=1, ccc_opcode=0x91) is decoded
  assign handoff_trigger_internal = (state == CTRL_DECODE_CMD) &&
                                    cmd_cp && (cmd_ccc_opcode == CCC_GETACCR_D);

  // Pulse generator: convert level signal to 1-cycle pulse
  // Prevents multiple triggers if controller FSM stalls in CTRL_DECODE_CMD
  always_ff @(posedge s_axi_aclk or negedge rst_n) begin
    if (!rst_n)
      handoff_trigger_internal_d <= 1'b0;
    else
      handoff_trigger_internal_d <= handoff_trigger_internal;
  end
  assign handoff_trigger_pulse = handoff_trigger_internal && !handoff_trigger_internal_d;


  // Reclaim done pulse: detect RECLAIMING(4) -> ACTIVE(0) transition
  logic [2:0] role_state_out_d;
  always_ff @(posedge s_axi_aclk or negedge rst_n) begin
    if (!rst_n)
      role_state_out_d <= 3'd0;
    else
      role_state_out_d <= role_state_out;
  end
  assign reclaim_done_pulse = (role_state_out_d == 3'd4) && (role_state_out == 3'd0);


  // role_return_sync1/sync2 already declared above

  // Use pulse versions for role_manager connections
  // (the FSM will enter CTRL_SEND_CCC next cycle)
  // For robustness, also accept the case where wr_fifo isn't needed

  assign getacccr_done_internal         = ccc_done && (ccc_opcode == CCC_GETACCR_D);
  assign getacccr_ack_internal          = ccc_getacccr_ack;

  // -------------------------------------------------------------------------
  // SETMRL/SETMWL CCC decode → target table update (NEW )
  // -------------------------------------------------------------------------
  always_ff @(posedge clk_ctrl or negedge rst_n) begin
    if (!rst_n) begin
      tgt_table_ccc_wr <= 1'b0;
      tgt_table_ccc_idx <= '0;
      tgt_table_ccc_wr_mrl <= 1'b0;
      tgt_table_ccc_wr_mwl <= 1'b0;
      tgt_table_ccc_wr_ibi <= 1'b0;
      tgt_table_ccc_mrl_val <= '0;
      tgt_table_ccc_mwl_val <= '0;
      tgt_table_ccc_ibi_val <= '0;
      ccc_tgt_da       <= '0;
      ccc_mrl_captured <= '0;
      ccc_mwl_captured <= '0;
      ccc_ibi_max_captured <= '0;
    end else begin
      // capture target DA when a Direct CCC is dispatched
      if (state == CTRL_DECODE_CMD && cmd_cp && cmd_dec.dev_addr != '0)
        ccc_tgt_da <= cmd_dev_addr;
      // capture outgoing CCC TX payload bytes for target table
      // The CCC handler sends MRL/MWL/IBI-max via ccc_byte_val when ccc_send_byte=1.
      // We capture these bytes so the target table can be updated when ccc_done fires.
      // Per spec Table 16: SETMWL=0x09 (broadcast) / 0x89 (direct);
      //                     SETMRL=0x0A (broadcast) / 0x8A (direct)
      if (state == CTRL_SEND_CCC && ccc_send_byte) begin
        if (ccc_opcode == CCC_SETMWL_B || ccc_opcode == CCC_SETMWL_D) begin  // SETMWL
          if (ccc_mwl_captured == '0)
            ccc_mwl_captured[15:8] <= ccc_byte_val;
          else
            ccc_mwl_captured[7:0] <= ccc_byte_val;
        end
        if (ccc_opcode == CCC_SETMRL_B || ccc_opcode == CCC_SETMRL_D) begin  // SETMRL
          if (ccc_mrl_captured == '0)
            ccc_mrl_captured[15:8] <= ccc_byte_val;
          else
            ccc_mrl_captured[7:0] <= ccc_byte_val;
        end
      end
      tgt_table_ccc_wr <= 1'b0;
      tgt_table_ccc_wr_mrl <= 1'b0;
      tgt_table_ccc_wr_mwl <= 1'b0;
      tgt_table_ccc_wr_ibi <= 1'b0;
      if (ccc_done) begin
        // SETMWL broadcast (0x09) or direct (0x89)
        if (ccc_opcode == CCC_SETMWL_B || ccc_opcode == CCC_SETMWL_D) begin
          for (int i = 0; i < 16; i++) begin
            if (tgt_table_valid[i] &&
                (ccc_opcode == CCC_SETMWL_B || tgt_table_da[i] == ccc_tgt_da)) begin
              tgt_table_ccc_wr     <= 1'b1;
              tgt_table_ccc_idx    <= i[3:0];
              tgt_table_ccc_wr_mwl <= 1'b1;
              tgt_table_ccc_mwl_val<= ccc_mwl_captured;
            end
          end
        end
        // SETMRL broadcast (0x0A) or direct (0x8A)
        if (ccc_opcode == CCC_SETMRL_B || ccc_opcode == CCC_SETMRL_D) begin
          for (int i = 0; i < 16; i++) begin
            if (tgt_table_valid[i] &&
                (ccc_opcode == CCC_SETMRL_B || tgt_table_da[i] == ccc_tgt_da)) begin
              tgt_table_ccc_wr     <= 1'b1;
              tgt_table_ccc_idx    <= i[3:0];
              tgt_table_ccc_wr_mrl <= 1'b1;
              tgt_table_ccc_mrl_val<= ccc_mrl_captured;
              tgt_table_ccc_wr_ibi <= 1'b1;
              tgt_table_ccc_ibi_val<= ccc_ibi_max_captured;
            end
          end
        end
      end
    end
  end

  assign getacccr_addr_nack_internal    = ccc_getacccr_addr_nack;
  assign getacccr_data_nack_internal    = ccc_getacccr_data_nack;

  //Reclaim test active — high when role_manager is in ROLE_TESTING_NEW
  assign reclaim_test_active = (role_state_out == 3'd3);  // ROLE_TESTING_NEW

  // ---------------------------------------------------------------------------
  //PHY Mux — clean 3:1 mux with 2-bit role-FSM select
  // Inputs: Digital PHY (controller), Target Engine (target), Autonomous Bootstrap (TBD)
  // Select driven by i3c_role_manager (NEVER by software directly)
  // ---------------------------------------------------------------------------
  logic        tgt_sda_o, tgt_sda_oe;
  // Bootstrap signals (placeholder — Autonomous Bootstrap (TBD) not implemented)
  logic        boot_sda_o  = 1'b1;
  logic        boot_sda_oe = 1'b0;
  logic        boot_scl_o  = 1'b1;
  logic        boot_scl_oe = 1'b0;
  // Bootstrap readback (unused — tied to pad readback)
  logic        boot_sda_i, boot_scl_i;
  // Target engine readback
  logic        tgt_sda_i, tgt_scl_i;

  i3c_phy_mux u_phy_mux (
    .phy_mux_sel  (phy_mux_sel),
    // Digital PHY side (sel=00)
    .dphy_sda_o   (dphy_sda_o),
    .dphy_sda_oe  (dphy_sda_oe),
    .dphy_scl_o   (dphy_scl_o),
    .dphy_scl_oe  (dphy_scl_oe),
    // Target Engine side (sel=01) — SDA only
    .tgt_sda_o    (tgt_sda_o),
    .tgt_sda_oe   (tgt_sda_oe),
    // TBD Bootstrap side (sel=10) — SDA + SCL
    // Autonomous Bootstrap (TBD) placeholder
    .boot_sda_o   (boot_sda_o),
    .boot_sda_oe  (boot_sda_oe),
    .boot_scl_o   (boot_scl_o),
    .boot_scl_oe  (boot_scl_oe),
    // Pad side (to iobuf)
    .pad_sda_o    (pad_sda_o),
    .pad_sda_oe   (pad_sda_oe),
    .pad_scl_o    (pad_scl_o),
    .pad_scl_oe   (pad_scl_oe),
    // Pad readback (from iobuf, raw)
    .pad_sda_i    (pad_sda_i),
    .pad_scl_i    (pad_scl_i),
    // Readback to all three blocks (broadcast)
    .dphy_sda_i   (dphy_sda_i),
    .dphy_scl_i   (dphy_scl_i),
    .tgt_sda_i    (tgt_sda_i),
    .tgt_scl_i    (tgt_scl_i),
    .boot_sda_i   (boot_sda_i),
    .boot_scl_i   (boot_scl_i)
  );

  // Note: dphy_sda_i / dphy_scl_i from the mux are the RAW pad signals.
  // The DNF filters them before they reach the phy_fsm (sda_i / scl_i).


  // ---------------------------------------------------------------------------
  // Pad instantiation (SDA + SCL) — tri-state buffers.
  // The mux output (pad_sda_o/oe, pad_scl_o/oe) drives the pads.
  // Raw pad signals (pad_sda_i, pad_scl_i) go to the mux and DNF.
  // ---------------------------------------------------------------------------

  io_buf #(.INST_PULLUP(INST_PULLUP)) u_iobuf_sda (
    .pad_o      (pad_sda_o),
    .pad_oe     (pad_sda_oe),
    .pad_pullup (sda_pullup_en),
    .pad        (sda),
    .pad_i      (pad_sda_i)
  );

  io_buf #(.INST_PULLUP(INST_PULLUP)) u_iobuf_scl (
    .pad_o      (pad_scl_o),
    .pad_oe     (pad_scl_oe),
    .pad_pullup (scl_pullup_en),
    .pad        (scl),
    .pad_i      (pad_scl_i)
  );

  // ---------------------------------------------------------------------------
  // Digital Noise Filter — inserted between iobuf (raw) and phy_fsm (filtered)
  // Filters glitches on SDA/SCL up to DNF_THRESHOLD PCLK cycles.
  // Only the Digital PHY path uses DNF. The Autonomous Bootstrap (TBD) path
  // receives raw pad signals and must do its own filtering if needed.
  // ---------------------------------------------------------------------------
  i3c_dnf u_dnf (
    .clk            (s_axi_aclk),  // DNF on ungated clock — must stay alive in Target mode
    .rst_n          (rst_n),  // synchronized reset
    .dnf_threshold  (dnf_threshold),
    .dnf_enable     (dnf_enable),
    .sda_raw        (dphy_sda_i),  // raw from mux (iobuf readback)
    .scl_raw        (dphy_scl_i),
    .sda_filtered   (sda_i),       // filtered -> phy_fsm
    .scl_filtered   (scl_i)
  );

  // -------------------------------------------------------------------------
  // IBI Handler — monitors bus for In-Band Interrupts during idle
  // -------------------------------------------------------------------------
  // Target Table (NEW )
  // -------------------------------------------------------------------------
  i3c_target_table u_target_table (
    .clk              (clk_ctrl),
    .rst_n            (rst_n),
    .daa_wr_en        (tgt_table_daa_wr),
    .daa_wr_idx       (tgt_table_daa_idx),
    .daa_wr_da        (tgt_table_daa_da),
    .daa_wr_bcr       (tgt_table_daa_bcr),
    .daa_wr_dcr       (tgt_table_daa_dcr),
    .daa_wr_pid       (tgt_table_daa_pid),
    .ccc_wr_en        (tgt_table_ccc_wr),
    .ccc_wr_idx       (tgt_table_ccc_idx),
    .ccc_wr_mrl       (tgt_table_ccc_wr_mrl),
    .ccc_wr_mwl       (tgt_table_ccc_wr_mwl),
    .ccc_wr_ibi_max   (tgt_table_ccc_wr_ibi),
    .ccc_wr_mrl_val   (tgt_table_ccc_mrl_val),
    .ccc_wr_mwl_val   (tgt_table_ccc_mwl_val),
    .ccc_wr_ibi_val   (tgt_table_ccc_ibi_val),
    .ibi_lookup_da    (ibi_lookup_da),
    .ibi_lookup_idx   (ibi_lookup_idx),
    .ibi_lookup_valid (ibi_lookup_valid),
    .ibi_lookup_mrl   (ibi_lookup_mrl),
    .ibi_lookup_ibi_max(ibi_lookup_ibi_max),
    .ibi_lookup_bcr   (ibi_lookup_bcr),
    .tgt_table_da     (tgt_table_da),
    .tgt_table_valid  (tgt_table_valid),
    .reg_addr         (4'h0),
    .reg_wr_en        (1'b0),
    .reg_wr_data      (128'h0),
    .reg_rd_data      (),
    .tgt_count        (tgt_table_count),
    .tgt_valid        (),
    .tgt_table_full   (tgt_table_full)  // wire up full flag
  );

  // -------------------------------------------------------------------------
  // IBI Handler — monitors bus for In-Band Interrupts during idle
  // -------------------------------------------------------------------------
  logic [31:0] ibi_fifo_push_data_w;

  i3c_ibi_handler u_ibi (
    .clk              (clk_ctrl),
    .rst_n            (rst_n),
    .ibi_enable       (ctrl_en),
    .bus_idle         (bus_idle),
    .controller_idle  (fsm_controller_idle),
    .sda_i            (sda_i),
    .scl_i            (scl_i),
    .ibi_req_bus      (ibi_req_bus),
    .ibi_req_recv_byte(ibi_req_recv_byte),
    .ibi_req_nack     (ibi_req_nack),
    .ibi_req_start    (ibi_req_start),
    .ibi_req_stop     (ibi_req_stop),
    .bus_done         (bus_done),
    .bus_ack_recv     (bus_ack_recv),
    .bus_byte_rx      (bus_byte_rx),
    .ibi_fifo_push    (ibi_fifo_push_w),
    .ibi_fifo_push_data(ibi_fifo_push_data_w),
    .ibi_irq          (ibi_irq_w),
    .ibi_active       (ibi_active_w),
    .crr_received     (crr_received),
    .crr_dev_addr     (crr_dev_addr),
    .hj_received      (hj_detected_via_ibi_w),  // IBI handler also detects HJ (0x02/W)
    .ibi_detected_addr(),
    .ibi_lookup_da     (ibi_lookup_da),
    .ibi_lookup_idx    (ibi_lookup_idx),
    .ibi_lookup_valid  (ibi_lookup_valid),
    .ibi_lookup_mrl    (ibi_lookup_mrl),
    .ibi_lookup_ibi_max(ibi_lookup_ibi_max),
    .ibi_lookup_bcr    (ibi_lookup_bcr)
  );
  // Wire IBI handler outputs back to register map inputs
  assign ibi_fifo_push_wire      = ibi_fifo_push_w;
  assign ibi_fifo_push_data_wire = ibi_fifo_push_data_w;
  assign ibi_irq_wire            = ibi_irq_w;
  assign ibi_active_wire         = ibi_active_w;

  // -------------------------------------------------------------------------
  // Hot-Join Handler — detects new devices joining the bus
  // -------------------------------------------------------------------------

  i3c_hotjoin_handler u_hj (
    .clk              (clk_ctrl),
    .rst_n            (rst_n),
    // HJ is enabled only when both gates are set:
    .hj_enable        (ctrl_en),
    .hj_auto_daa      (hj_auto_daa),
    .controller_idle  (fsm_controller_idle),
    .bus_idle         (bus_idle),
    .sda_i            (sda_i),
    .scl_i            (scl_i),
    .hj_trigger_daa   (hj_trigger_daa_w),
    .hj_detected      (hj_detected_w),
    .hj_pending       (hj_pending_w),
    .hj_clear         (hj_clear_wire),
    .ibi_active       (ibi_active_w)
  );

  assign hj_detected_wire = hj_detected_w | hj_detected_via_ibi_w;
  assign hj_pending_wire  = hj_pending_w;
  // HJ clear is driven by the register file (SW write to HJ_STATUS[0]).
  // The register file's hj_clear output is wired directly to the HJ handler.

  // HJ auto-ENTDAA trigger is wired to the FSM (CTRL_IDLE state checks
  // hj_trigger_daa_w && hj_auto_daa to auto-start ENTDAA).
  // For now, it sets a flag that software can poll and then issue ENTDAA manually

  // -------------------------------------------------------------------------
  // Group Addressing — checks if target address is a group address
  // -------------------------------------------------------------------------
  logic [2:0]  group_idx_w;
  logic [15:0] group_targets_w;

  i3c_group_addr u_group (
    .clk              (clk_ctrl),
    .rst_n            (rst_n),
    .group_enable     (group_enable),
    .group_count      (group_count),
    .group_table_0     (group_table_0),
    .group_table_1     (group_table_1),
    .group_table_2     (group_table_2),
    .group_table_3     (group_table_3),
    .group_table_4     (group_table_4),
    .group_table_5     (group_table_5),
    .group_table_6     (group_table_6),
    .group_table_7     (group_table_7),
    .addr_val         (cmd_dev_addr),
    .group_match      (group_match_w),
    .group_idx        (group_idx_w),
    .group_targets    (group_targets_w),
    .ccc_setrtgl      (1'b0),
    .ccc_getrtgl      (ccc_done && (ccc_opcode == 8'h8A)),  // GETRTGL trigger
    .ccc_payload_byte (8'h00),
    .ccc_response_byte(ccc_getrtgl_byte_w),    // group_addr GETRTGL response
    .ccc_response_valid(ccc_getrtgl_valid_w)
  );

  // Group addressing: u_group checks the outgoing command's target address
  // against the group table. If group_match_w=1 and the command is a write,
  // the group address goes on the bus and all member targets ACK (broadcast).
  // Group reads are rejected in CTRL_DECODE_CMD (I3C Basic doesn't support them).

  // Pull-up enable signals (output to top-level pad control if needed)
  assign sda_pullup_en = 1'b0; // controlled externally or via attribute
  assign scl_pullup_en = 1'b0;

  // Polled status outputs (no interrupt line).
  assign controller_busy = bus_busy | ibi_active_w;
  // (controller_idle is assigned by the FSM logic above)

  // ===========================================================================
  // Wake Detector — lives in PD_AON, monitors SDA/SCL for START/SCL edges
  // ===========================================================================
  // Wake config is driven by the WAKE_CTRL register (offset 0x90) via the
  // register file. The host writes WAKE_CTRL to enable/disable wake detection
  // and select wake sources (START, SCL edge, or both).
  // wake_en/wake_start_en/wake_scl_en cross from s_axi_aclk
  // (justified by "slow config changes" comment, but technically a CDC
  // violation). Now they go through 2-flop synchronizers in clk_aon domain.
  logic wake_clear_wire;
  // Wake clear: pulse when host writes 1 to WAKE_STATUS register (W1C)
  // CDC fix: stretch the single-cycle s_axi_aclk pulse into a multi-cycle
  // level signal that the slow clk_aon (32 kHz) domain can reliably sample.
  // We use a toggle + 2-flop sync + edge-detect pattern:
  //   1. On each wake_clear pulse (s_axi_aclk), toggle a request flag
  //   2. Sync the request flag into clk_aon domain (2-flop)
  //   3. Edge-detect the synced flag in clk_aon to produce a 1-cycle pulse
  //   4. Stretch the pulse to 4 clk_aon cycles for safe sampling by wake_detector
  logic wake_clear_toggle_q;  // s_axi_aclk domain toggle
  logic wake_clear_sync_meta, wake_clear_sync_aon;  // clk_aon domain synced
  logic wake_clear_sync_prev;  // clk_aon domain previous (for edge detect)
  logic wake_clear_stretched_q;  // clk_aon domain stretched pulse
  logic [1:0] wake_clear_stretch_cnt;  // stretch counter (4 cycles)

  // s_axi_aclk domain: toggle on each wake_clear pulse
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      wake_clear_toggle_q <= 1'b0;
    else if (reg_wr && (reg_wr_addr[7:0] == WAKE_STATUS_ADDR[7:0]) && (reg_wr_data[0] | reg_wr_data[1]))
      wake_clear_toggle_q <= ~wake_clear_toggle_q;
  end

  // clk_aon domain: 2-flop sync + edge detect + stretch
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      wake_clear_sync_meta    <= 1'b0;
      wake_clear_sync_aon     <= 1'b0;
      wake_clear_sync_prev    <= 1'b0;
      wake_clear_stretched_q  <= 1'b0;
      wake_clear_stretch_cnt  <= 2'h0;
    end else begin
      wake_clear_sync_meta <= wake_clear_toggle_q;
      wake_clear_sync_aon  <= wake_clear_sync_meta;
      wake_clear_sync_prev <= wake_clear_sync_aon;

      // Edge detect: rising or falling edge of the synced toggle
      if (wake_clear_sync_aon != wake_clear_sync_prev) begin
        wake_clear_stretched_q <= 1'b1;
        wake_clear_stretch_cnt <= 2'h0;
      end else if (wake_clear_stretched_q) begin
        if (wake_clear_stretch_cnt >= 2'd3) begin
          wake_clear_stretched_q <= 1'b0;
          wake_clear_stretch_cnt  <= 2'h0;
        end else begin
          wake_clear_stretch_cnt <= wake_clear_stretch_cnt + 1'b1;
        end
      end
    end
  end

  assign wake_clear_wire = wake_clear_stretched_q;

  // 2-flop synchronizers for wake config signals (s_axi_aclk → clk_aon)
  logic wake_en_meta, wake_en_aon;
  logic wake_start_en_meta, wake_start_en_aon;
  logic wake_scl_en_meta, wake_scl_en_aon;
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      wake_en_meta       <= 1'b0;
      wake_en_aon        <= 1'b0;
      wake_start_en_meta <= 1'b0;
      wake_start_en_aon  <= 1'b0;
      wake_scl_en_meta   <= 1'b0;
      wake_scl_en_aon    <= 1'b0;
    end else begin
      wake_en_meta       <= wake_en;
      wake_en_aon        <= wake_en_meta;
      wake_start_en_meta <= wake_start_en;
      wake_start_en_aon  <= wake_start_en_meta;
      wake_scl_en_meta   <= wake_scl_en;
      wake_scl_en_aon    <= wake_scl_en_meta;
    end
  end

  i3c_wake_detector u_wake (
    .clk_aon          (clk_aon),
    .rst_aon_n        (rst_aon_n),
    .sda_raw          (pad_sda_i),   // raw pad readback directly from iobuf (NOT from mux)
    .scl_raw          (pad_scl_i),
    .wake_en          (wake_en_aon),       // synchronized to clk_aon
    .wake_start_en    (wake_start_en_aon), // synchronized to clk_aon
    .wake_scl_en      (wake_scl_en_aon),   // synchronized to clk_aon
    .wake_irq         (wake_irq),
    .wake_src_start   (wake_src_start),
    .wake_src_scl     (wake_src_scl),
    .wake_clear       (wake_clear_wire)
  );

  // ===========================================================================
  // Power Controller — manages PD_AON <-> PD_CORE power-domain handshake
  // ===========================================================================
  // bus_idle must be synchronized to clk_aon domain (2-stage synchronizer)
  logic bus_idle_meta, bus_idle_aon;
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      bus_idle_meta <= 1'b1;
      bus_idle_aon  <= 1'b1;
    end else begin
      bus_idle_meta <= bus_idle;
      bus_idle_aon  <= bus_idle_meta;
    end
  end

  i3c_power_controller u_power (
    .clk_aon          (clk_aon),
    .rst_aon_n        (rst_aon_n),
    .pd_core_req      (pd_core_req),
    .pd_core_off      (pd_core_off),
    .pd_core_ack      (pd_core_ack),
    .wake_irq         (wake_irq),       // from wake detector (same clk_aon domain)
    .bus_idle         (bus_idle_aon),   // synchronized to clk_aon
    .pd_core_sw_en    (pd_core_sw_en),
    .pd_core_iso_en   (pd_core_iso_en),
    .pd_core_rst      (pd_core_rst),
    .wake_to_host     (wake_to_host)
  );

  // ===========================================================================
  // Target Engine — responds to commands from another controller on the bus
  // ===========================================================================
  // Target config is driven by the TARGET_CTRL register (offset 0xA0) via the
  // register file. The host writes TARGET_CTRL to enable Target mode, set the
  // dynamic address, and enable Target-initiated IBI.
  // The scl_filt_rst_n is a synchronized reset to the SCL domain.
  // Uses async-assert / sync-deassert pattern: rst_n immediately forces
  // the output low (async, via combinational AND), but release waits for
  // posedge scl_i (sync deassert via 2-flop). This ensures reset propagates
  // even if SCL is stopped (e.g., during bus hang).
  always_ff @(posedge scl_i or negedge rst_n) begin
    if (!rst_n) begin
      scl_filt_rst_n_sync_meta <= 1'b0;
      scl_filt_rst_n_sync      <= 1'b0;
    end else begin
      scl_filt_rst_n_sync_meta <= rst_n;
      scl_filt_rst_n_sync      <= scl_filt_rst_n_sync_meta;
    end
  end
  // Async assert override: if rst_n is low, force output low immediately
  // (regardless of SCL state). This covers the case where SCL is stopped.
  wire scl_filt_rst_n_eff = rst_n & scl_filt_rst_n_sync;

  // CDC: role_is_target (s_axi_aclk → scl_filt) — 2-flop synchronizer
  // Target engine needs role_is_target to know when it's in target mode.
  // This signal crosses from AXI domain to SCL domain.
  always_ff @(posedge scl_i or negedge scl_filt_rst_n_eff) begin
    if (!scl_filt_rst_n_eff) begin
      role_is_target_sync1 <= 1'b0;
      role_is_target_sync2 <= 1'b0;
    end else begin
      role_is_target_sync1 <= role_is_target;  // async sample (s_axi_aclk)
      role_is_target_sync2 <= role_is_target_sync1;
    end
  end

  i3c_target_engine u_target (
    .clk_sys            (s_axi_aclk),
    .rst_sys_n          (rst_n),
    .scl_filt           (scl_i),                  // filtered SCL as target clock
    .sda_filt           (sda_i),                  // filtered SDA
    .scl_filt_rst_n     (scl_filt_rst_n_eff),    // synced reset for SCL domain (async-assert)
    .target_en          (role_is_target_synced | role_target_en),  // Auto-enabled on GETACCR handoff
    .target_dyn_addr    (7'h00), // Default, could be programmed
    .target_ibi_en      (1'b0),  // Target IBI not supported yet
    .reclaim_test_active(reclaim_test_active),  // TB hook
    .ccc_getrtgl_byte   (ccc_getrtgl_byte_w),   // GETRTGL byte from group_addr
    .ccc_getrtgl_valid  (ccc_getrtgl_valid_w),  // GETRTGL byte valid
    .target_addressed   (target_addressed),
    .target_busy        (target_busy),
    .target_rx_done     (target_rx_done),
    .target_rx_byte     (target_rx_byte),
    .target_tx_req      (target_tx_req),
    .target_tx_byte     (target_tx_byte),
    .target_tx_valid    (target_tx_valid),
    .target_ibi_req     (target_ibi_req),
    .tgt_sda_o          (tgt_sda_o),              //SDA drive to phy_mux
    .tgt_sda_oe         (tgt_sda_oe),             //SDA output enable
    .target_nack_sent   (target_nack_sent),
    .role_return        (role_return_pulse)  //voluntary return signal
  );

  // ===========================================================================
  // Async FIFO (CDC) — available for SoC integrations where the host needs
  // to be on a different clock. In the current single-clock design, the
  // synchronous i3c_fifo.sv is used for all 4 FIFOs. This instance is
  // instantiated but not connected to any datapath — it is available as a
  // ready-to-use CDC primitive for integration (e.g., when adding a
  // separate host clock domain or for the Target engine RX/TX CDC).
  // ===========================================================================
  // I2C Controller Register File — separate register map at 0x100..0x138
  // ===========================================================================
  // AXI address decode for I2C registers: if addr in [I2C_REG_BASE, I2C_REG_BASE+0x38],
  // route to the I2C register file.
  //I2C_REG_BASE = 0x100 (page-aligned) with a 16-register
  // reserved gap (0xC4..0xFC) between the last I3C register (0xC0) and I2C.
  // This decouples I2C offsets from I3C register additions.
  logic        i2c_reg_wr, i2c_reg_rd;
  logic        i2c_reg_wr_ack, i2c_reg_rd_ack;
  logic [31:0] i2c_reg_rd_data;

  assign i2c_reg_wr = reg_wr && (reg_wr_addr[15:0] >= I2C_REG_BASE) && (reg_wr_addr[15:0] <= (I2C_REG_BASE + 16'h0038));
  assign i2c_reg_rd = reg_rd && (reg_rd_addr[15:0] >= I2C_REG_BASE) && (reg_rd_addr[15:0] <= (I2C_REG_BASE + 16'h0038));

  // I2C config/control signals — from register file
  logic        i2c_sw_reset;
  logic [7:0]  i2c_tx_data, i2c_rx_data;
  logic [7:0]  i2c_bytes_xferd;
  logic        i2c_trans_aborted, i2c_slv_addr_ack, i2c_data_nack;
  logic [7:0]  i2c_target_addr;
  logic [7:0]  i2c_xfer_length;
  logic [15:0] i2c_timeout;

  // I2C TX/RX FIFO interface signals
  logic [7:0]  i2c_tx_fifo_wr_data;
  logic [7:0]  i2c_rx_fifo_rd_data;
  logic        i2c_tx_fifo_flush, i2c_rx_fifo_flush;
  logic        i2c_tx_fifo_full,  i2c_tx_fifo_empty;
  logic        i2c_rx_fifo_full,  i2c_rx_fifo_empty;

  //I2C FIFO extended status wires (now connected)
  logic        i2c_tx_fifo_afull,   i2c_tx_fifo_aempty;
  logic        i2c_rx_fifo_afull,   i2c_rx_fifo_aempty;
  logic [4:0]  i2c_tx_fifo_count_w, i2c_rx_fifo_count_w;  // raw 5-bit from FIFO (DEPTH=16)
  logic [3:0]  i2c_tx_fifo_count,   i2c_rx_fifo_count;    // sliced to 4-bit for regfile
  logic        i2c_tx_fifo_overflow, i2c_tx_fifo_underflow;
  logic        i2c_rx_fifo_overflow, i2c_rx_fifo_underflow;

  // I2C FSM FIFO-control outputs
  logic        i2c_is_read;        // 1 = read transaction (RnW=1)
  logic        i2c_tx_byte_req;    // pulse: FSM loading new TX byte → pop TX FIFO
  logic        i2c_rx_byte_valid;  // pulse: full RX byte valid → push RX FIFO
  logic        i2c_fsm_idle;       // 1 = I2C FSM in IDLE state

  // I2C PHY interface signals (shared with I3C phy_fsm, open-drain mode)
  // (declared once above at line ~1501 — no duplicate here)

  // I2C PHY interface signals
  logic        i2c_phy_req_start, i2c_phy_req_repeat_start, i2c_phy_req_stop, i2c_phy_req_bit_xfer;
  logic        i2c_phy_req_release, i2c_phy_sda_drive;

  i2c_register_file u_i2c_regfile (
    .clk                   (s_axi_aclk),
    .rst_n                 (rst_n),
    .reg_wr                (i2c_reg_wr),
    .reg_wr_addr           (reg_wr_addr[31:0]),
    .reg_wr_data           (reg_wr_data[31:0]),
    .reg_wr_ack            (i2c_reg_wr_ack),
    .reg_rd                (i2c_reg_rd),
    .reg_rd_addr           (reg_rd_addr[31:0]),
    .reg_rd_data           (i2c_reg_rd_data),
    .reg_rd_ack            (i2c_reg_rd_ack),
    // Status inputs from I2C FSM
    .i2c_xfer_done         (i2c_xfer_done),
    .i2c_busy              (i2c_busy),
    .i2c_bytes_xferd       (i2c_bytes_xferd),
    .i2c_trans_aborted     (i2c_trans_aborted),
    .i2c_slv_addr_ack      (i2c_slv_addr_ack),
    .i2c_data_nack         (i2c_data_nack),
    //FIFO-level status inputs (from i3c_fifo instances)
    .i2c_tx_fifo_overflow  (i2c_tx_fifo_overflow),
    .i2c_rx_fifo_overflow  (i2c_rx_fifo_overflow),
    .i2c_rx_fifo_underflow (i2c_rx_fifo_underflow),
    .i2c_tx_fifo_afull     (i2c_tx_fifo_afull),
    .i2c_rx_fifo_aempty    (i2c_rx_fifo_aempty),
    .i2c_tx_fifo_count     (i2c_tx_fifo_count),
    .i2c_rx_fifo_count     (i2c_rx_fifo_count),
    // Config outputs to I2C FSM
    .i2c_enable            (i2c_trans_en),
    .i2c_sw_reset          (i2c_sw_reset),
    // i2c_tx_data is driven directly by the I2C TX FIFO (u_i2c_tx_fifo)
    // via .rd_data(). The register file does not have an i2c_tx_data port.
    .i2c_target_addr       (i2c_target_addr),
    .i2c_xfer_length       (i2c_xfer_length),
    .i2c_timeout           (i2c_timeout),
    .i2c_speed_prescaler   (i2c_speed_prescaler),
    // IRQ output
    .i2c_irq               (i2c_irq),
    // TX/RX FIFO interface
    .tx_fifo_wr_data       (i2c_tx_fifo_wr_data),
    .tx_fifo_wr            (i2c_tx_fifo_wr),
    .rx_fifo_rd_data       (i2c_rx_fifo_rd_data),
    .rx_fifo_rd            (i2c_rx_fifo_rd),
    .tx_fifo_flush         (i2c_tx_fifo_flush),
    .rx_fifo_flush         (i2c_rx_fifo_flush),
    .tx_fifo_full          (i2c_tx_fifo_full),
    .tx_fifo_empty         (i2c_tx_fifo_empty),
    .rx_fifo_full          (i2c_rx_fifo_full),
    .rx_fifo_empty         (i2c_rx_fifo_empty)
  );

  // -------------------------------------------------------------------------
  // I2C TX/RX FIFOs — 8-bit wide, depth 16. The host pushes TX bytes via
  // I2C_WDATA_TXFIFO; the I2C FSM reads them via i2c_tx_data (pops TX FIFO
  // when i2c_tx_byte_req pulses). The I2C FSM writes RX bytes via i2c_rx_data
  // when i2c_rx_byte_valid pulses; the host reads them via I2C_RDATA_RXFIFO.
  // -------------------------------------------------------------------------

  // TX FIFO pop — only pop when the FSM is actively loading a new
  // TX byte (i2c_tx_byte_req pulse). This pops once per byte
  // which popped every cycle, draining the FIFO far too fast and losing data.
  // Now it pops exactly once per byte, synchronized to the FSM's TX_BYTE load.
  assign i2c_tx_fifo_rd = i2c_tx_byte_req & i2c_mode_q;

  i3c_fifo #(
    .WIDTH (8),
    .DEPTH (16),
    .REG_OUT (1'b0)
  ) u_i2c_tx_fifo (
    .clk          (clk_fifo),
    .rst_n        (rst_n),
    .wr_en        (i2c_tx_fifo_wr),
    .wr_data      (i2c_tx_fifo_wr_data),
    .rd_en        (i2c_tx_fifo_rd),
    .rd_data      (i2c_tx_data),           // TX FIFO output feeds FSM directly
    .empty        (i2c_tx_fifo_empty),
    .full         (i2c_tx_fifo_full),
    .almost_full  (i2c_tx_fifo_afull),     //TX_FIFO_AFULL watermark
    .almost_empty (i2c_tx_fifo_aempty),    //diagnostic
    .data_count   (i2c_tx_fifo_count_w),   //TX_FIFO_COUNT (5-bit raw)
    .overflow     (i2c_tx_fifo_overflow),  //TX_FIFO_OVERFLOW source
    .underflow    (i2c_tx_fifo_underflow), //diagnostic
    .flush        (i2c_tx_fifo_flush | i2c_sw_reset)
  );

  // Slice 5-bit count to 4-bit for the register field
  assign i2c_tx_fifo_count = i2c_tx_fifo_count_w[3:0];

  // RX FIFO push — push when the I2C FSM has received a full
  // byte (i2c_rx_byte_valid pulse) AND this is a read transaction (i2c_is_read).
  // - wr_en was hardcoded to 1'b0 (RX FIFO never received any data)
  // - i2c_rx_fifo_wr used `~i2c_tx_data` (bitwise NOT of 8-bit value,
  // almost always nonzero, doesn't actually detect read mode)
  // (clean 1-cycle pulse per received byte, only in read mode)
  assign i2c_rx_fifo_wr = i2c_rx_byte_valid & i2c_is_read & i2c_mode_q;

  i3c_fifo #(
    .WIDTH (8),
    .DEPTH (16),
    .REG_OUT (1'b0)
  ) u_i2c_rx_fifo (
    .clk          (clk_fifo),
    .rst_n        (rst_n),
    .wr_en        (i2c_rx_fifo_wr),         // was missing entirely
    .wr_data      (i2c_rx_data),            // from I2C FSM
    .rd_en        (i2c_rx_fifo_rd),
    .rd_data      (i2c_rx_fifo_rd_data),
    .empty        (i2c_rx_fifo_empty),
    .full         (i2c_rx_fifo_full),
    .almost_full  (i2c_rx_fifo_afull),      //diagnostic
    .almost_empty (i2c_rx_fifo_aempty),     //RX_FIFO_AEMPTY watermark
    .data_count   (i2c_rx_fifo_count_w),    //RX_FIFO_COUNT (5-bit raw)
    .overflow     (i2c_rx_fifo_overflow),   //RX_FIFO_OVERFLOW source
    .underflow    (i2c_rx_fifo_underflow),  //RX_FIFO_UNDERFLOW status bit
    .flush        (i2c_rx_fifo_flush | i2c_sw_reset)
  );

  // Slice 5-bit count to 4-bit for the register field
  assign i2c_rx_fifo_count = i2c_rx_fifo_count_w[3:0];

  // ===========================================================================
  // I2C Controller FSM — handles I2C legacy protocol when i2c_mode_q=1
  // ===========================================================================
  i2c_controller_fsm u_i2c_fsm (
    .clk               (s_axi_aclk),         // I2C FSM clock
    .rst_n             (rst_n),              // I2C FSM reset (active-low)
    .i2c_enable        (i2c_trans_en),       // TRANS_EN pulse triggers full transaction
    .i2c_sw_reset      (i2c_sw_reset),       // SW_RESET pulse
    .i2c_tx_data       (i2c_tx_data),
    .i2c_rx_data       (i2c_rx_data),
    .i2c_target_addr   (i2c_target_addr),
    .i2c_xfer_length   (i2c_xfer_length),    // XFER_LENGTH from I2C_TRANS_CFG
    .i2c_timeout       (i2c_timeout),
    // Status outputs (to register file)
    .i2c_xfer_done     (i2c_xfer_done),
    .i2c_busy          (i2c_busy),
    .i2c_bytes_xferd   (i2c_bytes_xferd),
    .i2c_trans_aborted   (i2c_trans_aborted),
    .i2c_slv_addr_ack  (i2c_slv_addr_ack),
    .i2c_data_nack     (i2c_data_nack),
    // FIFO interface outputs
    .i2c_is_read       (i2c_is_read),        // RnW flag → qualifies RX FIFO push
    .i2c_tx_byte_req   (i2c_tx_byte_req),    // pulse → pops TX FIFO once per byte
    .i2c_rx_byte_valid (i2c_rx_byte_valid),  // pulse → pushes RX FIFO once per byte
    .i2c_fsm_idle      (i2c_fsm_idle),       // FSM idle status → bus_idle muxing
    // Note: i2c_irq is generated by the I2C register file (aggregated from
    // INT_STATUS & INT_EN_CTRL). The FSM does not drive i2c_irq.
    // PHY interface (muxed with I3C FSM outputs based on i2c_mode_q)
    .phy_req_start     (i2c_phy_req_start),
    .phy_req_repeat_start (i2c_phy_req_repeat_start),
    .phy_req_stop      (i2c_phy_req_stop),
    .phy_req_bit_xfer  (i2c_phy_req_bit_xfer),
    .phy_req_release   (i2c_phy_req_release),
    .phy_sda_drive     (i2c_phy_sda_drive),
    .phy_done          (tcmd_done),
    .phy_sda_sampled   (sda_sampled),
    .i2c_tx_fifo_empty (i2c_tx_fifo_empty),  //TX FIFO empty flag for write wait
    .bus_idle          (bus_idle_i3c)        // I2C FSM sees I3C SerDes idle
  );

  // Combined bus_idle = I3C SerDes idle AND I2C FSM idle.
  // This is the signal consumed by IBI handler, HJ handler, controller_idle
  // output, and the CDC synchronizer to clk_aon (for the power controller).
  // When either FSM is active, bus_idle=0 → prevents IBI/HJ from triggering
  // and prevents the power controller from powering down mid-transaction.
  assign bus_idle = bus_idle_i3c & i2c_fsm_idle;

  // ===========================================================================
  // Mode-select MUX — routes PHY commands from the active controller FSM
  // ===========================================================================
  // When i2c_mode_q=0 (I3C): I3C FSM commands (via byte_serdes_i3c tcmd_*) pass to phy_fsm
  // When i2c_mode_q=1 (I2C): I2C FSM commands (i2c_phy_req_*) pass to phy_fsm
  // The mux is combinational — the inactive FSM's commands are blocked.
  // Additionally, when i2c_mode_q=1, the I3C FSM is forced to CTRL_IDLE.
  // =============================================================================

  // Override tcmd_* signals with muxed version when in I2C mode
  // Note: tcmd_* are already driven by the I3C byte_serdes_i3c (u_bus_ctrl).
  // We create muxed versions and reassign the phy_fsm inputs.
  // Since SystemVerilog doesn't allow re-driving a wire, we use a separate
  // set of wires for the muxed output and wire them to u_phy_fsm.

  // mux_cmd_*, mux_sda_drive_val, mux_mode_pushpull are driven by the
  // always_comb block below.

  always_comb begin
    if (i2c_mode_q == MODE_I2C) begin
      // I2C mode: I2C FSM drives the PHY (open-drain)
      mux_cmd_start         = i2c_phy_req_start;
      mux_cmd_repeat_start  = i2c_phy_req_repeat_start;  // I2C Repeated START
      mux_cmd_stop          = i2c_phy_req_stop;
      mux_cmd_drive_scl_low = 1'b0;
      mux_cmd_release_bus   = i2c_phy_req_release;
      mux_cmd_bit_xfer      = i2c_phy_req_bit_xfer;
      mux_cmd_bit_xfer_od   = i2c_phy_req_bit_xfer; // always open-drain in I2C mode
      mux_sda_drive_val     = i2c_phy_sda_drive;
      mux_mode_pushpull     = 1'b0;  // force open-drain in I2C mode
    end else begin
      // I3C mode: I3C byte_serdes_i3c drives the PHY
      mux_cmd_start         = tcmd_start;
      mux_cmd_repeat_start  = tcmd_repeat_start;
      mux_cmd_stop          = tcmd_stop;
      mux_cmd_drive_scl_low = tcmd_drive_scl_low;
      mux_cmd_release_bus   = tcmd_release_bus;
      mux_cmd_bit_xfer      = tcmd_bit_xfer;
      mux_cmd_bit_xfer_od   = tcmd_bit_xfer_od;
      mux_sda_drive_val     = sda_drive_val;
      mux_mode_pushpull     = mode_pushpull;
    end
  end

  // The u_phy_fsm instance uses mux_* signals, so the i2c_mode_q mux is
  // correctly wired — I3C FSM commands pass through when i2c_mode_q=0,
  // I2C FSM commands pass through when i2c_mode_q=1.

  // ===========================================================================
  // I3C FSM mode guard — force I3C FSM to IDLE when in I2C mode
  // ===========================================================================
  // When i2c_mode_q=1 (I2C mode), the I3C controller FSM must not issue any
  // commands. This is enforced by gating the command decode:
  // In the FSM's CTRL_DECODE_CMD state, if i2c_mode_q=1, skip to CTRL_IDLE.
  // (This is implemented as a combinational override on the next-state logic.)

  // ===========================================================================
  // AXI read path mux — route I2C regfile reads back to AXI slave
  // ===========================================================================
  // When AXI read address >= 0xD0, route i2c_reg_rd_data to the AXI slave
  // instead of the I3C regfile's reg_rd_data.
  // The AXI slave (u_axi4_lite) reads reg_rd_data/reg_rd_ack from u_regfile.
  // We override these when the address is in I2C range.
  // Note: This requires modifying the AXI slave's read data path. Since
  // u_axi4_lite is already instantiated, we use a wire override approach:
  // The actual reg_rd_data/reg_rd_ack from u_regfile are used for I3C addresses.
  // For I2C addresses, i2c_reg_rd_data/i2c_reg_rd_ack should be used.
  // This mux is implemented here:

  // Final muxed AXI read/write response

  always_comb begin
    if (reg_rd_addr[15:0] >= I2C_REG_BASE) begin
      // I2C register space
      axi_rd_data_final = i2c_reg_rd_data;
      axi_rd_ack_final  = i2c_reg_rd_ack;
    end else begin
      // I3C register space
      axi_rd_data_final = reg_rd_data;
      axi_rd_ack_final  = reg_rd_ack;
    end
  end

  always_comb begin
    if (reg_wr_addr[15:0] >= I2C_REG_BASE) begin
      // I2C register space
      axi_wr_ack_final = i2c_reg_wr_ack;
    end else begin
      // I3C register space
      axi_wr_ack_final = reg_wr_ack;
    end
  end

  // -------------------------------------------------------------------------
  // Combined interrupt output: OR of I3C and I2C interrupt requests.
  // This provides a single interrupt line to the host SoC. The host ISR
  // reads INTERRUPT_STATUS (0x18) and I2C_INT_STATUS (0x38) to determine
  // which controller generated the interrupt.
  // -------------------------------------------------------------------------
  assign irq = i3c_irq | i2c_irq;

endmodule : i3c_primary_controller_sdr

