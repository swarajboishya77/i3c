// =============================================================================
// byte_serdes_i3c.sv — I3C Bus Controller (Byte SerDes + Transaction Wrapper + PEC)
// -----------------------------------------------------------------------------
// This module is the I3C-side bus controller. It wraps:
// 1. Transaction-level command interface (START/STOP/addr/byte TX/byte RX)
// 2. Byte-level shift engine (8-bit MSB-first + 9th-bit T-Bit handling)
// 3. PEC (CRC-8) generator/checker (i3c_pec instance)
// The I3C controller FSM issues high-level primitives (req_start, req_send_byte,
// etc.) to this module. This module translates them to low-level PHY commands
// (tcmd_start, tcmd_bit_xfer, etc.) for i3c_phy_fsm, and handles the byte-level
// shifting and 9th-bit T-Bit protocol.
// PEC (Packet Error Code) is integrated here because PEC operates at the byte
// level — every TX/RX byte is fed to the CRC-8 engine. The FSM controls PEC
// via pec_en (per-transaction enable), pec_append_req (TX side: latch CRC and
// output as final byte), and pec_rx_check (RX side: next received byte is the
// PEC byte, compare it).
// Mode Selection:
// i2c_mode = 0 → I3C mode (T-Bit: parity on write, end-of-data on read)
// i2c_mode = 1 → I2C mode (ACK/NACK: target ACKs on write, controller ACKs on read)
// (Note: I2C mode is kept for compatibility; the separate I2C FSM typically
// drives the PHY directly without using this wrapper.)
// Location: controller/ — this is protocol logic, not PHY logic.
// =============================================================================

module byte_serdes_i3c (
    input  logic        clk,
    input  logic        rst_n,

    // ------------------------------------------------------------------
    // Transaction-level command interface (from I3C controller FSM)
    // ------------------------------------------------------------------
    input  logic        req_start,          // issue START condition
    input  logic        req_repeat_start,   // issue Repeated START
    input  logic        req_stop,           // issue STOP condition
    input  logic        req_send_addr_w,    // send address byte (write)
    input  logic        req_send_addr_r,    // send address byte (read)
    input  logic [6:0]  addr_val,           // 7-bit target address
    input  logic        req_send_byte,      // send 8-bit data byte
    input  logic [7:0]  byte_tx,            // data byte to transmit
    input  logic        req_recv_byte,      // receive 8-bit data byte
    input  logic        recv_last_byte,     // 1 = NACK on last read byte
    input  logic        i2c_mode,           // 0=I3C (T-Bit), 1=I2C (ACK/NACK)

    // ------------------------------------------------------------------
    // Status to FSM
    // ------------------------------------------------------------------
    output logic        done,               // pulse: primitive complete
    output logic        ack_recv,           // I2C: 1=NACK from target
    output logic [7:0]  byte_rx,            // received byte value
    output logic        busy,               // 1 = controller is active
    output logic        idle,               // 1 = controller is idle

    // ------------------------------------------------------------------
    // PHY primitive interface (to i3c_phy_fsm)
    // ------------------------------------------------------------------
    output logic        tcmd_start,
    output logic        tcmd_repeat_start,
    output logic        tcmd_stop,
    output logic        tcmd_drive_scl_low,
    output logic        tcmd_release_bus,
    output logic        tcmd_bit_xfer,
    output logic        tcmd_bit_xfer_od,   // 1 = open-drain bit, 0 = push-pull
    output logic        sda_drive_val,      // SDA value to drive (when driving)
    output logic        mode_pushpull,      // 1 = push-pull, 0 = open-drain
    input  logic        tcmd_done,          // 1 = PHY primitive complete
    input  logic        sda_sampled,        // SDA value sampled at SCL high

    // ------------------------------------------------------------------
    // PEC interface (to/from I3C controller FSM)
    // ------------------------------------------------------------------
    input  logic        pec_en,             // 1 = PEC enabled for this transaction
    input  logic        pec_append_req,     // pulse: latch CRC, output as TX byte
    input  logic        pec_rx_check,       // 1 = next RX byte is the PEC byte
    output logic        pec_error,          // 1 = CRC mismatch (RX PEC byte != computed)
    output logic [7:0]  pec_crc_out,        // current CRC value (de )
    output logic        pec_tx_byte_valid,  // 1 = PEC TX byte is ready
    output logic [7:0]  pec_tx_byte_value   // PEC byte to transmit
);

    // ------------------------------------------------------------------
    // Wrapper FSM States
    // ------------------------------------------------------------------
    typedef enum logic [2:0] {
        WR_IDLE,
        WR_START,           // issue START, wait for tcmd_done
        WR_REPEAT_START,    // issue Repeated START, wait for tcmd_done
        WR_STOP,            // issue STOP, wait for tcmd_done
        WR_SHIFT,           // shift 8 data bits (TX or RX)
        WR_NINTH_BIT,       // 9th bit phase (T-Bit or ACK/NACK)
        WR_DONE             // pulse done, return to IDLE
    } wr_state_e;

    wr_state_e  wr_state_q, wr_state_d;

    // Byte-level shift registers
    logic [7:0] shift_reg_q, shift_reg_d;
    logic [3:0] bit_cnt_q, bit_cnt_d;
    logic       is_recv_q, is_recv_d;
    logic       is_last_q, is_last_d;
    logic       is_addr_q, is_addr_d;

    // Latched TX byte (for PEC feed — shift_reg_q is modified during shifting)
    logic [7:0] byte_tx_latched_q, byte_tx_latched_d;

    // Status outputs
    // driven by BOTH always_ff (reset/default) AND always_comb (state set),
    // causing multi-driver synthesis failure. Also always_comb used <=
    // - introducing _d next-state vars computed in always_comb (with =)
    // - updating _r flops ONLY in always_ff (with <=)
    logic       done_r;
    logic       ack_nack_r;         // I2C: 1=NACK, 0=ACK

    logic       done_d;
    logic       ack_nack_d;


    // PEC-related internal signals
    logic       pec_reset_int;      // pulse: reset CRC at start of new transfer
    logic       byte_valid_int;     // pulse: a byte completed (feed to PEC CRC)
    logic [7:0] byte_for_pec;       // byte value to feed into PEC
    logic       pec_byte_rx_int;    // pulse: this RX byte is the PEC byte
    logic [7:0] pec_rx_value_int;   // received PEC byte value

    // Track whether the current TX byte is the PEC byte (suppress CRC feed)
    logic       is_pec_tx_byte_q, is_pec_tx_byte_d;

    // I3C T-Bit parity calculation
    logic       parity_calc;

    // ------------------------------------------------------------------
    // PEC (CRC-8) instance
    // ------------------------------------------------------------------
    i3c_pec u_pec (
        .clk            (clk),
        .rst_n          (rst_n),
        .pec_en         (pec_en),
        .pec_reset      (pec_reset_int),
        .byte_valid     (byte_valid_int),
        .byte_in        (byte_for_pec),
        .crc_out        (pec_crc_out),
        .pec_byte_rx    (pec_byte_rx_int),
        .pec_rx_value   (pec_rx_value_int),
        .pec_error      (pec_error),
        .pec_append     (pec_append_req),
        .pec_tx_valid   (pec_tx_byte_valid),
        .pec_tx_value   (pec_tx_byte_value)
    );

    // ------------------------------------------------------------------
    // Sequential
    // ------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_state_q         <= WR_IDLE;
            shift_reg_q        <= 8'h00;
            bit_cnt_q          <= 4'd0;
            is_recv_q          <= 1'b0;
            is_last_q          <= 1'b0;
            is_addr_q          <= 1'b0;
            byte_tx_latched_q  <= 8'h00;
            done_r             <= 1'b0;
            ack_nack_r         <= 1'b0;

            is_pec_tx_byte_q   <= 1'b0;
        end else begin
            wr_state_q         <= wr_state_d;
            shift_reg_q        <= shift_reg_d;
            bit_cnt_q          <= bit_cnt_d;
            is_recv_q          <= is_recv_d;
            is_last_q          <= is_last_d;
            is_addr_q          <= is_addr_d;
            byte_tx_latched_q  <= byte_tx_latched_d;
            done_r             <= done_d;
            ack_nack_r         <= ack_nack_d;

            is_pec_tx_byte_q   <= is_pec_tx_byte_d;
        end
    end

    // ------------------------------------------------------------------
    // I3C T-Bit parity per MIPI I3C Basic Section 4.3.2.3.3:
    // "The value of this Parity bit shall be the XOR of the 8 Data bits
    // with 1, i.e.: XOR( Data[7:0], 1 )."
    // This is ODD parity: total number of 1s in 9 bits is always odd.
    // ~(^byte) (odd parity). With even parity, every write byte had the
    // wrong T-bit, causing every I3C target to NACK on parity error.
    // Examples from spec:
    // 0xFF (8 ones): ^byte=0, ~(^byte)=1 → spec says parity=1 ✓
    // 0x00 (0 ones): ^byte=0, ~(^byte)=1 → spec says parity=1 ✓
    // 0xFE (7 ones): ^byte=1, ~(^byte)=0 → spec says parity=0 ✓
    // 0x01 (1 one): ^byte=1, ~(^byte)=0 → spec says parity=0 ✓
    // ------------------------------------------------------------------
    assign parity_calc = ~(^byte_tx_latched_q);

    // ------------------------------------------------------------------
    // PEC signal generation
    // ------------------------------------------------------------------
    // pec_reset: pulse when accepting req_start or req_repeat_start
    assign pec_reset_int = (wr_state_q == WR_IDLE) &&
                          (req_start || req_repeat_start);

    // byte_for_pec: TX byte = latched value, RX byte = shift_reg (after shifting)
    assign byte_for_pec = is_recv_q ? 
                          ((wr_state_q == WR_SHIFT && wr_state_d == WR_NINTH_BIT) ? {shift_reg_q[6:0], sda_sampled} : shift_reg_q) 
                          : byte_tx_latched_q;

    // byte_valid: pulse when 8-bit shift completes (entering NINTH_BIT state)
    // Suppress for TX PEC byte (is_pec_tx_byte_q) and RX PEC byte (pec_rx_check)
    assign byte_valid_int = (wr_state_q == WR_SHIFT && wr_state_d == WR_NINTH_BIT) &&
                           !(is_pec_tx_byte_q && !is_recv_q) &&
                           !(is_recv_q && pec_rx_check);

    // pec_byte_rx: pulse when RX byte completes AND pec_rx_check is asserted
    assign pec_byte_rx_int = (wr_state_q == WR_SHIFT && wr_state_d == WR_NINTH_BIT) &&
                            is_recv_q && pec_rx_check;

    // pec_rx_value: the received byte
    assign pec_rx_value_int = (wr_state_q == WR_SHIFT && wr_state_d == WR_NINTH_BIT)
                              ? {shift_reg_q[6:0], sda_sampled}
                              : shift_reg_q;

    // byte_rx is assigned at the bottom of the module

    // ------------------------------------------------------------------
    // Combinational logic (next-state + outputs)
    // ------------------------------------------------------------------
    always_comb begin
        // Defaults: hold current values
        wr_state_d         = wr_state_q;
        shift_reg_d        = shift_reg_q;
        bit_cnt_d          = bit_cnt_q;
        is_recv_d          = is_recv_q;
        is_last_d          = is_last_q;
        is_addr_d          = is_addr_q;
        byte_tx_latched_d  = byte_tx_latched_q;
        is_pec_tx_byte_d   = is_pec_tx_byte_q;

        // next byte overwrites them)
        done_d             = 1'b0;
        ack_nack_d         = ack_nack_r;

        // PHY outputs default
        tcmd_start         = 1'b0;
        tcmd_repeat_start  = 1'b0;
        tcmd_stop          = 1'b0;
        tcmd_drive_scl_low = 1'b0;
        tcmd_release_bus   = 1'b0;
        tcmd_bit_xfer      = 1'b0;
        tcmd_bit_xfer_od   = 1'b0;
        sda_drive_val      = 1'b1;   // default: release SDA (High-Z)
        mode_pushpull      = 1'b0;   // default: Open-Drain

        unique case (wr_state_q)

            // ----------------------------------------------------------
            // IDLE: Wait for a transaction-level command
            // ----------------------------------------------------------
            WR_IDLE: begin
                // still asserted. This prevents duplicate command execution
                // when the controller FSM's request signals are still high
                // in the same cycle that done_r fires.
                if (!done_r) begin
                if (req_start) begin
                    wr_state_d = WR_START;
                end else if (req_repeat_start) begin
                    wr_state_d = WR_REPEAT_START;
                end else if (req_stop) begin
                    wr_state_d = WR_STOP;
                end else if (req_send_addr_w) begin
                    shift_reg_d       = {addr_val, 1'b0};  // addr + W bit
                    byte_tx_latched_d = {addr_val, 1'b0};
                    is_recv_d         = 1'b0;
                    is_last_d         = 1'b0;
                    is_addr_d         = 1'b1;
                    is_pec_tx_byte_d  = 1'b0;
                    bit_cnt_d         = 4'd8;
                    wr_state_d        = WR_SHIFT;
                end else if (req_send_addr_r) begin
                    shift_reg_d       = {addr_val, 1'b1};  // addr + R bit
                    byte_tx_latched_d = {addr_val, 1'b1};
                    is_recv_d         = 1'b0;
                    is_last_d         = 1'b0;
                    is_addr_d         = 1'b1;
                    is_pec_tx_byte_d  = 1'b0;
                    bit_cnt_d         = 4'd8;
                    wr_state_d        = WR_SHIFT;
                end else if (req_send_byte) begin
                    shift_reg_d       = byte_tx;
                    byte_tx_latched_d = byte_tx;
                    is_recv_d         = 1'b0;
                    is_last_d         = 1'b0;
                    is_addr_d         = 1'b0;
                    // Track if this is the PEC byte (FSM sends pec_tx_byte_value
                    // after pulsing pec_append_req; pec_tx_byte_valid is asserted
                    // by the PEC module on the cycle after pec_append_req)
                    is_pec_tx_byte_d  = pec_en && pec_tx_byte_valid;
                    bit_cnt_d         = 4'd8;
                    wr_state_d        = WR_SHIFT;
                end else if (req_recv_byte) begin
                    shift_reg_d       = 8'h00;
                    byte_tx_latched_d = 8'h00;
                    is_recv_d         = 1'b1;
                    is_last_d         = recv_last_byte;
                    is_addr_d         = 1'b0;
                    is_pec_tx_byte_d  = 1'b0;
                    bit_cnt_d         = 4'd8;
                    wr_state_d        = WR_SHIFT;
                end
                end
            end
            // START: Issue START condition to PHY, wait for completion
            // ----------------------------------------------------------
            WR_START: begin
                tcmd_start = 1'b1;
                if (tcmd_done) begin
                    done_d     = 1'b1;
                    wr_state_d = WR_IDLE;
                end
            end

            // ----------------------------------------------------------
            // REPEAT_START: Issue Repeated START to PHY, wait for done
            // ----------------------------------------------------------
            WR_REPEAT_START: begin
                tcmd_repeat_start = 1'b1;
                if (tcmd_done) begin
                    done_d     = 1'b1;
                    wr_state_d = WR_IDLE;
                end
            end

            // ----------------------------------------------------------
            // STOP: Issue STOP condition to PHY, wait for completion
            // ----------------------------------------------------------
            WR_STOP: begin
                tcmd_stop = 1'b1;
                if (tcmd_done) begin
                    done_d     = 1'b1;
                    wr_state_d = WR_IDLE;
                end
            end

            // ----------------------------------------------------------
            // SHIFT: Shift 8 bits MSB first
            // ----------------------------------------------------------
            WR_SHIFT: begin
                tcmd_bit_xfer = 1'b1;

                // Determine drive mode for this bit
                if (i2c_mode) begin
                    // I2C: always Open-Drain
                    mode_pushpull      = 1'b0;
                    tcmd_bit_xfer_od   = 1'b1;
                end else if (is_recv_q) begin
                    // I3C receive bits must be Open-Drain so the
                    // controller RELEASES SDA (high-Z) for the target to drive.
                    // In push-pull mode, sda_drive_val=1 drives SDA HIGH, which
                    // prevents the target from pulling SDA low. Force OD for RX.
                    mode_pushpull      = 1'b0;
                    tcmd_bit_xfer_od   = 1'b1;
                end else begin
                    // I3C TX: depends on address phase and bit position
                    if (is_addr_q && bit_cnt_q > 4'd5) begin
                        // Address bits [7:5]: Open-Drain (arbitration)
                        mode_pushpull    = 1'b0;
                        tcmd_bit_xfer_od = 1'b1;
                    end else begin
                        // Address bits [4:0] and data: Push-Pull
                        mode_pushpull    = 1'b1;
                        tcmd_bit_xfer_od = 1'b0;
                    end
                end

                if (is_recv_q) begin
                    // Receive: release SDA, sample on tcmd_done
                    sda_drive_val = 1'b1;  // High-Z
                    if (tcmd_done) begin
                        shift_reg_d = {shift_reg_q[6:0], sda_sampled};
                        bit_cnt_d   = bit_cnt_q - 1'b1;
                        if (bit_cnt_q == 4'd1)
                            wr_state_d = WR_NINTH_BIT;
                        if (bit_cnt_q == 4'd1) begin
                            wr_state_d = WR_NINTH_BIT;
                        end
                    end
                end else begin
                    // Transmit: drive SDA with MSB
                    sda_drive_val = shift_reg_q[7];
                    if (tcmd_done) begin
                        shift_reg_d = {shift_reg_q[6:0], 1'b0};
                        bit_cnt_d   = bit_cnt_q - 1'b1;
                        if (bit_cnt_q == 4'd1)
                            wr_state_d = WR_NINTH_BIT;
                    end
                end
            end

            // ----------------------------------------------------------
            // NINTH_BIT: 9th bit handling (T-Bit or ACK/NACK)
            // Always Open-Drain (target or controller drives ACK/T)
            // But in I3C, the ADDRESS byte's 9th bit is ACK/NACK (target drives),
            // NOT a T-bit. Only DATA bytes use T-bit. The correct discriminator
            // is is_addr_q, not i2c_mode:
            // - Address byte (is_addr_q=1): ACK/NACK (target drives, ctrl samples)
            // Same for both I2C and I3C.
            // - I3C data write (!is_addr_q, !is_recv_q): T-bit (ctrl drives parity)
            // - I3C data read (!is_addr_q, is_recv_q): T-bit (target drives)
            // - I2C data write: ACK/NACK (target drives)
            // - I2C data read: ACK/NACK (controller drives)
            // ----------------------------------------------------------
            WR_NINTH_BIT: begin
                tcmd_bit_xfer    = 1'b1;
                tcmd_bit_xfer_od = 1'b1;   // 9th bit always Open-Drain
                mode_pushpull    = 1'b0;

                if (is_addr_q || i2c_mode) begin
                    // --- Address byte OR I2C mode: ACK/NACK ---
                    if (is_recv_q && !is_addr_q) begin
                        // I2C data read: Controller drives ACK (0) or NACK (1, last byte)
                        sda_drive_val = is_last_q ? 1'b1 : 1'b0;
                    end else begin
                        // Address byte (both I2C and I3C) OR I2C data write:
                        // Controller releases SDA, target drives ACK/NACK
                        sda_drive_val = 1'b1;  // High-Z
                    end
                end else begin
                    // --- I3C data byte: T-Bit ---
                    if (is_recv_q) begin
                        // Read: Target drives T-Bit. Controller releases SDA.
                        sda_drive_val = 1'b1;  // High-Z
                    end else begin
                        // Write: Controller drives T-Bit = ~(^byte) (odd parity)
                        sda_drive_val = parity_calc;
                    end
                end

                if (tcmd_done) begin
                    // Sample 9th bit
                    if ((is_addr_q || (i2c_mode && !is_recv_q))) begin
                        // Address byte (I2C+I3C) or I2C data write:
                        // sample ACK/NACK from target
                        ack_nack_d = sda_sampled;  // 1=NACK, 0=ACK
                    end else if (!i2c_mode && is_recv_q && !is_addr_q) begin
                        // I3C data read: sample T-Bit from target

                    end
                    // For I3C data write (!is_recv_q, !is_addr_q): controller
                    // drove T-bit, nothing to sample.
                    wr_state_d = WR_DONE;
                end
            end

            // ----------------------------------------------------------
            // DONE: Pulse done, return to IDLE
            // ----------------------------------------------------------
            WR_DONE: begin
                done_d           = 1'b1;
                is_pec_tx_byte_d = 1'b0;   // clear PEC byte flag
                wr_state_d       = WR_IDLE;
            end

            default: wr_state_d = WR_IDLE;
        endcase
    end

    // ------------------------------------------------------------------
    // Output assignments
    // ------------------------------------------------------------------
    assign byte_rx    = shift_reg_q;
    assign done       = done_r;
    // ack_nack_r is 0 when the target ACKs (SDA=0). The controller FSM treats
    // bus_ack_recv=1 as "target ACKed", so we invert the polarity here.
    assign ack_recv   = ~ack_nack_r;
    assign busy       = (wr_state_q != WR_IDLE);
    assign idle       = (wr_state_q == WR_IDLE);

endmodule : byte_serdes_i3c

