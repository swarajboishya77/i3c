// =============================================================================
// io_buf.sv
// Tri-state I/O buffer wrapper for SDA and SCL.
// ASIC: maps to pad library cell. FPGA: maps to IOBUF.
// Pullup is handled externally by the SoC pad ring.
// =============================================================================

module io_buf #(
  parameter bit INST_PULLUP = 1'b0
) (
    input  logic pad_o,
    input  logic pad_oe,
    input  logic pad_pullup,   // TB hook: external pad-ring pull-up control (passed through to top-level)
    inout  wire  pad,
    output logic pad_i
);
  assign pad   = pad_oe ? pad_o : 1'bz;
  assign pad_i = pad;
endmodule : io_buf
