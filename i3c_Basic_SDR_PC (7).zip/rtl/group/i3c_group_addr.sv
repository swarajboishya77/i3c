// =============================================================================
// i3c_group_addr.sv
// -----------------------------------------------------------------------------
// Group Addressing module for I3C Basic.
// Supports up to 8 group addresses. Each group can contain multiple targets.
// When a group address is sent on the bus, all targets in that group respond.
// Group addressing is configured via CCC commands:
// - SETRTGL (0x89): Set Ring Target Group List — assigns targets to groups
// - GETRTGL (0x8A): Get Ring Target Group List — reads group assignments
// This module stores the group address table and provides match logic.
// The controller FSM checks group_addr_match before sending a private
// transfer — if the target address matches a group, the transfer is
// broadcast to all members of that group.
// Group Address Table Format (32-bit per entry):
// [31:25] = group address (7 bits)
// [24:8] = target address bitmap (up to 16 targets per group)
// [7:0] = reserved
// =============================================================================

module i3c_group_addr (
  input  logic        clk,
  input  logic        rst_n,

  // Configuration (from register map)
  input  logic        group_enable,       // 1 = group addressing enabled
  input  logic [6:0]  group_count,        // number of active groups (0-8)

  // Group address table (8 entries, 32-bit each)
  input  logic [31:0] group_table_0,
  input  logic [31:0] group_table_1,
  input  logic [31:0] group_table_2,
  input  logic [31:0] group_table_3,
  input  logic [31:0] group_table_4,
  input  logic [31:0] group_table_5,
  input  logic [31:0] group_table_6,
  input  logic [31:0] group_table_7,

  // Address match (from controller FSM)
  input  logic [6:0]  addr_val,           // target address being sent
  output logic        group_match,        // 1 = addr_val matches a group
  output logic [2:0]  group_idx,          // which group matched
  output logic [15:0] group_targets,      // bitmap of targets in matched group

  // CCC interface (for SETRTGL/GETRTGL)
  input  logic        ccc_setrtgl,        // pulse: SETRTGL CCC received
  input  logic        ccc_getrtgl,        // pulse: GETRTGL CCC received
  input  logic [7:0]  ccc_payload_byte,   // payload byte from CCC
  output logic [7:0]  ccc_response_byte,  // response byte for GETRTGL
  output logic        ccc_response_valid
);

  // -------------------------------------------------------------------------
  // Group address table storage
  // -------------------------------------------------------------------------
  // Group table is stored in the register map, passed as individual signals
  // No internal storage needed — use the inputs directly
  wire [31:0] group_table_r [0:7];
  wire [7:0] _group_rsvd_bits = {group_table_r[0][8], group_table_r[1][8], group_table_r[2][8], group_table_r[3][8], group_table_r[4][8], group_table_r[5][8], group_table_r[6][8], group_table_r[7][8]};
  assign group_table_r[0] = group_table_0;
  assign group_table_r[1] = group_table_1;
  assign group_table_r[2] = group_table_2;
  assign group_table_r[3] = group_table_3;
  assign group_table_r[4] = group_table_4;
  assign group_table_r[5] = group_table_5;
  assign group_table_r[6] = group_table_6;
  assign group_table_r[7] = group_table_7;

  // -------------------------------------------------------------------------
  // Address match logic
  // -------------------------------------------------------------------------
  always_comb begin
    group_match   = 1'b0;
    group_idx     = 3'd0;
    group_targets = 16'h0;

    if (group_enable) begin
      for (logic [3:0] i = 4'd0; i < 4'd8; i++) begin
        if (i < group_count) begin
          if (group_table_r[i][31:25] == addr_val) begin
            // First match wins (priority order — lowest index)
            if (!group_match) begin
              group_match   = 1'b1;
              group_idx     = i[2:0];
              group_targets = group_table_r[i][24:9];  // 16-bit target bitmap
            end
          end
        end
      end
    end
  end

  // -------------------------------------------------------------------------
  // CCC SETRTGL/GETRTGL support
  // -------------------------------------------------------------------------
  // SETRTGL: software writes group table via register map, CCC just acknowledges
  // GETRTGL: return group table entries as response bytes

  logic [2:0] getrtgl_idx;
  logic       getrtgl_prev_q;  // holds ccc_getrtgl for 1 extra cycle
  logic [2:0] wrap_val;        // index wrap point (group_count, capped at 7)

  assign wrap_val = (group_count == 7'd0) ? 3'd0 :
                    (group_count >= 7'd8) ? 3'd7 : group_count[2:0] - 1'b1;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      getrtgl_idx      <= 3'd0;
      ccc_response_valid <= 1'b0;
      ccc_response_byte  <= 8'h0;
      getrtgl_prev_q     <= 1'b0;
    end else begin
      getrtgl_prev_q <= ccc_getrtgl;
      ccc_response_valid <= 1'b0;

      if (ccc_setrtgl) begin
        // SETRTGL resets the GETRTGL read pointer to 0
        getrtgl_idx <= 3'd0;
      end else if (ccc_getrtgl) begin
        // Return entry[getrtgl_idx][7:0] and increment/wrap index.
        ccc_response_byte  <= group_table_r[getrtgl_idx][7:0];
        ccc_response_valid <= 1'b1;
        // Wrap after reading the last valid index (group_count - 1)
        if (getrtgl_idx >= wrap_val)
          getrtgl_idx <= 3'd0;
        else
          getrtgl_idx <= getrtgl_idx + 1'b1;
      end else if (getrtgl_prev_q) begin
        // Hold response valid for 1 extra cycle (don't increment index)
        ccc_response_valid <= 1'b1;
      end
    end
  end

endmodule : i3c_group_addr

