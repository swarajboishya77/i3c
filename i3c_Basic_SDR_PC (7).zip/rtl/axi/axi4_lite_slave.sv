// =============================================================================
// axi4_lite_slave.sv
// -----------------------------------------------------------------------------
// AXI4-Lite slave interface for the I3C Controller register file.
// 32-bit data width, 32-bit address width.
// Single outstanding transaction only (sufficient for register access).
// Protocol:
// - AW + W + B handshake (write)
// - AR + R handshake (read)
// - All five channels use VALID/READY.
// - BRESP / RRESP are always OKAY (decoding errors are surfaced as 0xFF
// read data with ack=0 from the register file; the parent may map that
// to SLVERR if desired).
// The slave decodes which register is being accessed and forwards the
// request to i3c_register_file on the cycle following the address.
// =============================================================================

module axi4_lite_slave #(
  parameter int unsigned ADDR_W = 32,
  parameter int unsigned DATA_W = 32
) (
  input  logic             clk,
  input  logic             rst_n,

  // ---------------- AXI4-Lite slave ports ----------------
  // Write address channel
  input  logic             s_axi_awvalid,
  output logic             s_axi_awready,
  input  logic [ADDR_W-1:0] s_axi_awaddr,
  input  logic [2:0]       s_axi_awprot,    // AMBA AXI4-Lite required (Table B1-1)
  // Write data channel
  input  logic             s_axi_wvalid,
  output logic             s_axi_wready,
  input  logic [DATA_W-1:0] s_axi_wdata,
  input  logic [DATA_W/8-1:0] s_axi_wstrb,
  // Write response channel
  output logic             s_axi_bvalid,
  input  logic             s_axi_bready,
  output logic [1:0]       s_axi_bresp,
  // Read address channel
  input  logic             s_axi_arvalid,
  output logic             s_axi_arready,
  input  logic [ADDR_W-1:0] s_axi_araddr,
  input  logic [2:0]       s_axi_arprot,    // AMBA AXI4-Lite required (Table B1-1)
  // Read data channel
  output logic             s_axi_rvalid,
  input  logic             s_axi_rready,
  output logic [DATA_W-1:0] s_axi_rdata,
  output logic [1:0]       s_axi_rresp,

  // ---------------- Register-file interface ----------------
  output logic             reg_wr,
  output logic [ADDR_W-1:0] reg_wr_addr,
  output logic [DATA_W-1:0] reg_wr_data,
  output logic [DATA_W/8-1:0] reg_wr_strb,
  input  logic             reg_wr_ack,

  output logic             reg_rd,
  output logic [ADDR_W-1:0] reg_rd_addr,
  input  logic [DATA_W-1:0] reg_rd_data,
  input  logic             reg_rd_ack
);

  // -------------------------------------------------------------------------
  // Write channel FSM
  // -------------------------------------------------------------------------
  typedef enum logic [1:0] {
    W_IDLE,
    W_ADDR_DATA,
    W_RESP
  } w_state_e;

  w_state_e w_state;

  logic [ADDR_W-1:0]   aw_addr_lat;
  logic [DATA_W-1:0]   w_data_lat;
  logic [DATA_W/8-1:0] w_strb_lat;
  logic                aw_done, w_done;
  // BUGFIX: declare b_ack_lat BEFORE the always_ff that uses it (VRFC 10-3380)
  logic                b_ack_lat;

  // Aw / W can be accepted in any order; both must be seen before B.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      w_state    <= W_IDLE;
      aw_addr_lat<= '0;
      w_data_lat <= '0;
      w_strb_lat <= '0;
      aw_done    <= 1'b0;
      w_done     <= 1'b0;
      b_ack_lat  <= 1'b1;  // default OKAY
    end else begin
      unique case (w_state)
        W_IDLE: begin
          if (s_axi_awvalid & s_axi_awready) begin
            aw_addr_lat <= s_axi_awaddr;
            aw_done     <= 1'b1;
          end
          if (s_axi_wvalid & s_axi_wready) begin
            w_data_lat  <= s_axi_wdata;
            w_strb_lat  <= s_axi_wstrb;
            w_done      <= 1'b1;
          end
          if ((aw_done || (s_axi_awvalid & s_axi_awready)) &&
              (w_done  || (s_axi_wvalid & s_axi_wready))) begin
            // both received this cycle or earlier
            w_state <= W_ADDR_DATA;
          end
        end
        W_ADDR_DATA: begin
          // One cycle to drive reg_wr pulse
          w_state <= W_RESP;
          aw_done <= 1'b0;
          w_done  <= 1'b0;
          // Capture the actual write acknowledgment from the register file
          b_ack_lat <= reg_wr_ack;
        end
        W_RESP: begin
          if (s_axi_bvalid & s_axi_bready)
            w_state <= W_IDLE;
        end
        default: w_state <= W_IDLE;
      endcase
    end
  end

  // Combinational ready/valid
  assign s_axi_awready = (w_state == W_IDLE) && !aw_done;
  assign s_axi_wready  = (w_state == W_IDLE) && !w_done;

  // Single-cycle reg_wr pulse when both AW and W have been captured
  assign reg_wr       = (w_state == W_ADDR_DATA);
  assign reg_wr_addr  = aw_addr_lat;
  assign reg_wr_data  = w_data_lat;
  assign reg_wr_strb  = w_strb_lat;

  // B response: SLVERR if the register file rejected the write address,
  // otherwise OKAY.
  // BUGFIX: b_ack_lat was in a separate always_ff from w_state, causing a
  // timing gap where the default OKAY could persist for invalid addresses.
  // Merged into the w_state FSM so b_ack_lat is updated in the SAME always_ff
  // as the state transition, matching the read path pattern (r_ack_lat).
  // (b_ack_lat declared above with aw_done/w_done — VRFC 10-3380)
  assign s_axi_bvalid = (w_state == W_RESP);
  // AMBA IHI 0022H §R3.1: OKAY=0b00, SLVERR=0b10 (slave error), DECERR=0b11
  // A slave reporting its own internal error MUST use SLVERR (0b10), not
  // DECERR (0b11) which is reserved for interconnect decode failures.
  assign s_axi_bresp  = b_ack_lat ? 2'b00  // OKAY
                                  : 2'b10; // SLVERR (register rejected write)

  // -------------------------------------------------------------------------
  // Read channel FSM (single outstanding)
  // -------------------------------------------------------------------------
  typedef enum logic [1:0] {
    RD_IDLE,
    RD_DATA
  } r_state_e;

  r_state_e r_state;
  logic [ADDR_W-1:0] ar_addr_lat;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_state     <= RD_IDLE;
      ar_addr_lat <= '0;
    end else begin
      unique case (r_state)
        RD_IDLE: begin
          if (s_axi_arvalid & s_axi_arready) begin
            ar_addr_lat <= s_axi_araddr;
            r_state     <= RD_DATA;
          end
        end
        RD_DATA: begin
          if (s_axi_rvalid & s_axi_rready)
            r_state <= RD_IDLE;
        end
        default: r_state <= RD_IDLE;
      endcase
    end
  end

  assign s_axi_arready = (r_state == RD_IDLE);
  assign reg_rd        = (r_state == RD_IDLE) && s_axi_arvalid && s_axi_arready;
  assign reg_rd_addr   = s_axi_arvalid ? s_axi_araddr : ar_addr_lat;

  // The register file returns data combinationally in the same cycle.
  // We register it for one cycle so that RD_DATA state returns valid data.
  logic [DATA_W-1:0] r_data_lat;
  logic              r_ack_lat;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_data_lat <= '0;
      r_ack_lat  <= 1'b1; // default OKAY; cleared if reg_rd_ack=0
    end else if (reg_rd) begin
      r_data_lat <= reg_rd_data;
      r_ack_lat  <= reg_rd_ack;
    end
  end

  assign s_axi_rvalid = (r_state == RD_DATA);
  assign s_axi_rdata  = r_data_lat;
  // AMBA IHI 0022H §R3.1: OKAY=0b00, SLVERR=0b10 (slave error).
  // Register-file address rejection = SLVERR (not DECERR).
  assign s_axi_rresp  = r_ack_lat ? 2'b00  // OKAY
                                  : 2'b10; // SLVERR (register rejected read)

endmodule : axi4_lite_slave

