// =============================================================================
// i3c_pec.sv
// -----------------------------------------------------------------------------
// PEC (Packet Error Code) — CRC-8 generator and checker.
// PEC uses CRC-8 with polynomial 0x07 (x^8 + x^2 + x + 1), which is the
// standard SMBus/I3C PEC polynomial. The CRC is computed over all bytes
// in a transfer (address + command + data) and appended as the last byte.
// The receiver recomputes the CRC and compares it to the received PEC byte.
// A mismatch indicates data corruption — the transfer is flagged as a PEC error.
// This module provides:
// - CRC-8 computation (combinational, byte-at-a-time)
// - PEC generation (for transmit: compute and append)
// - PEC checking (for receive: compute and compare)
// Enabled by pec_en input (driven from TRANSACTION_CTRL.PEC_EN, bit 3 of 0x54).
// When pec_en = 0, this module is bypassed (no CRC accumulated, no PEC appended/checked).
// =============================================================================

module i3c_pec (
  input  logic        clk,
  input  logic        rst_n,

  // Configuration
  input  logic        pec_en,         // 1 = PEC enabled (from CONTROL.PEC_EN)
  input  logic        pec_reset,      // pulse: reset CRC to 0 (start of new transfer)

  // Byte input (one byte per cycle, MSB first)
  input  logic        byte_valid,     // 1 = byte_in is valid this cycle
  input  logic [7:0]  byte_in,        // data byte to feed into CRC

  // CRC output (current accumulated CRC value)
  output logic [7:0]  crc_out,        // current CRC value (for readback/de )

  // PEC check interface (for receive path)
  input  logic        pec_byte_rx,    // 1 = this byte is the received PEC byte
  input  logic [7:0]  pec_rx_value,   // received PEC byte value
  output logic        pec_error,      // 1 = CRC mismatch (received PEC != computed)

  // PEC generate interface (for transmit path)
  input  logic        pec_append,     // pulse: append computed CRC as last TX byte
  output logic        pec_tx_valid,   // 1 = PEC TX byte is valid
  output logic [7:0]  pec_tx_value    // PEC byte to transmit
);

  // -------------------------------------------------------------------------
  // CRC-8 computation (polynomial 0x07)
  // -------------------------------------------------------------------------
  // The CRC is computed one byte at a time. For each incoming byte:
  // crc = crc XOR byte
  // for each of 8 bits:
  // if (crc & 0x80) crc = (crc << 1) ^ 0x07
  // else crc = (crc << 1)
  // This is the standard CRC-8/SMBus algorithm.

  logic [7:0] crc_reg;

  // Combinational CRC-8 update for one byte
  function automatic logic [7:0] crc8_byte(input logic [7:0] crc_in, input logic [7:0] data);
    logic [7:0] crc;
    crc = crc_in ^ data;
    for (logic [3:0] i = 4'd0; i < 4'd8; i++) begin
      if (crc[7])
        crc = (crc << 1) ^ 8'h07;
      else
        crc = (crc << 1);
    end
    return crc;
  endfunction

  // -------------------------------------------------------------------------
  // CRC accumulation register
  // -------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      crc_reg <= 8'h00;
    end else if (pec_reset) begin
      crc_reg <= 8'h00;  // reset CRC at start of new transfer
    end else if (pec_en && byte_valid && !pec_byte_rx && !pec_append) begin
      crc_reg <= crc8_byte(crc_reg, byte_in);
    end
  end

  assign crc_out = crc_reg;

  // -------------------------------------------------------------------------
  // PEC check (receive path): compare received PEC byte with computed CRC
  // -------------------------------------------------------------------------
  logic pec_error_r;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pec_error_r <= 1'b0;
    end else if (pec_reset) begin
      pec_error_r <= 1'b0;
    end else if (pec_en && pec_byte_rx) begin
      // Compare the received PEC byte with our computed CRC
      pec_error_r <= (pec_rx_value != crc_reg);
    end
  end

  assign pec_error = pec_error_r;

  // -------------------------------------------------------------------------
  // PEC generate (transmit path): output the computed CRC as the PEC byte
  // -------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pec_tx_valid <= 1'b0;
      pec_tx_value <= 8'h00;
    end else begin
      pec_tx_valid <= 1'b0;
      if (pec_en && pec_append) begin
        pec_tx_valid <= 1'b1;
        pec_tx_value <= crc_reg;  // current CRC = PEC byte to append
      end
    end
  end

endmodule : i3c_pec

