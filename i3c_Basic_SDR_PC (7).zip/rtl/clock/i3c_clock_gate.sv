// =============================================================================
// i3c_clock_gate.sv
// -----------------------------------------------------------------------------
// Hierarchical Clock Gating Cell for ASIC power management.
// Provides three levels of gating:
// 1. Global gate (top-level — controlled by PMU or REG_CLK_EN)
// 2. Sub-module gate (per-engine — Controller, Target, FIFOs)
// 3. Automatic gate (activity-based — gates when no pending work)
// The cell uses a standard latch-based clock gate:
// - Enable is synchronized to the falling edge of the clock to avoid
// glitches on the gated clock output.
// - On ASIC, this maps to a library clock-gating cell (e.g., ICG cell).
// - On FPGA, this maps to a BUFGCE primitive.
// Parameters:
// AUTO_GATE — 1 = automatically gate when auto_gate_en is asserted and
// no activity is detected for GATE_CYCLES cycles
// =============================================================================

module i3c_clock_gate #(
  parameter bit AUTO_GATE    = 1'b0,
  parameter int unsigned GATE_CYCLES  = 8
) (
  input  logic        clk_in,          // original clock
  input  logic        rst_n,
  input  logic        manual_gate_en,  // 1 = force gate off (manual)
  input  logic        auto_gate_en,    // 1 = enable automatic gating
  input  logic        activity,        // 1 = module is active (prevents auto-gate)
  output logic        clk_out,         // gated clock
  output logic        gated            // 1 = clock is currently gated off
);

  // -------------------------------------------------------------------------
  // Manual gate: when manual_gate_en = 1, clock is always gated
  // -------------------------------------------------------------------------
  logic manual_enable;
  assign manual_enable = !manual_gate_en;  // enable = NOT gate

  // -------------------------------------------------------------------------
  // Automatic gate: gate off after GATE_CYCLES of inactivity
  // -------------------------------------------------------------------------
  logic [$clog2(GATE_CYCLES+1)-1:0] idle_cnt;
  logic auto_enable;

  generate
    if (AUTO_GATE) begin : gen_auto_gate
      always_ff @(posedge clk_in or negedge rst_n) begin
        if (!rst_n) begin
          idle_cnt <= '0;
          auto_enable <= 1'b1;  // start enabled
        end else begin
          if (activity) begin
            idle_cnt <= '0;
            auto_enable <= 1'b1;  // active = keep clock on
          end else if (auto_gate_en) begin
            if (idle_cnt < GATE_CYCLES) begin
              idle_cnt <= idle_cnt + 1'b1;
            end else begin
              auto_enable <= 1'b0;  // gate off after timeout
            end
          end else begin
            auto_enable <= 1'b1;  // auto-gate disabled = always on
          end
        end
      end
    end else begin : gen_no_auto
      assign auto_enable = 1'b1;
    end
  endgenerate

  // Combined enable
  logic clk_enable;
  assign clk_enable = manual_enable && auto_enable;

  // -------------------------------------------------------------------------
  // Glitch-free clock gate (latch-based, falling-edge enabled)
  // -------------------------------------------------------------------------
  // ASIC: synthesis tool maps this to an ICG (Integrated Clock Gating) cell
  // FPGA: maps to BUFGCE
  logic clk_enable_latched;

  always_latch begin
    if (!clk_in)           // latch on falling edge
      clk_enable_latched = clk_enable;
  end

  assign clk_out = clk_in && clk_enable_latched;
  assign gated   = !clk_enable;

endmodule : i3c_clock_gate

