// =============================================================================
// i3c_async_fifo.sv
// Common reset with cross-domain sync release
// =============================================================================

module i3c_async_fifo #(
  parameter int unsigned WIDTH = 8,
  parameter int unsigned DEPTH = 16,
  parameter int unsigned AW = $clog2(DEPTH),
  parameter bit REG_OUT = 1
) (
  input  logic             wr_clk,
  input  logic             rst_n,        // single common reset
  input  logic             wr_en,
  input  logic [WIDTH-1:0] wr_data,
  output logic             wr_full,
  output logic             wr_overflow,
  input  logic             rd_clk,
  input  logic             rd_en,
  output logic [WIDTH-1:0] rd_data,
  output logic             rd_empty,
  output logic             rd_underflow
);

  // -------------------------------------------------------------------------
  // Reset synchronization: rst_n is async assert, sync deassert per domain
  // -------------------------------------------------------------------------
  logic wr_rst_meta, wr_rst_sync;
  logic rd_rst_meta, rd_rst_sync;

  always_ff @(posedge wr_clk or negedge rst_n) begin
    if (!rst_n) begin wr_rst_meta <= 1'b0; wr_rst_sync <= 1'b0; end
    else begin wr_rst_meta <= 1'b1; wr_rst_sync <= wr_rst_meta; end
  end

  always_ff @(posedge rd_clk or negedge rst_n) begin
    if (!rst_n) begin rd_rst_meta <= 1'b0; rd_rst_sync <= 1'b0; end
    else begin rd_rst_meta <= 1'b1; rd_rst_sync <= rd_rst_meta; end
  end

  // -------------------------------------------------------------------------
  // Memory and pointers
  // -------------------------------------------------------------------------
  logic [WIDTH-1:0] mem [0:DEPTH-1];
  logic [AW:0] wr_ptr, rd_ptr;
  logic [AW:0] wr_ptr_gray, rd_ptr_gray;
  logic [AW:0] wr_ptr_gray_sync1, wr_ptr_gray_sync2;
  logic [AW:0] rd_ptr_gray_sync1, rd_ptr_gray_sync2;

  always_ff @(posedge wr_clk or negedge wr_rst_sync) begin
    if (!wr_rst_sync) wr_ptr <= '0;
    else if (wr_en && !wr_full) begin
      mem[wr_ptr[AW-1:0]] <= wr_data;
      wr_ptr <= wr_ptr + 1'b1;
    end
  end
  assign wr_ptr_gray = wr_ptr ^ (wr_ptr >> 1);

  always_ff @(posedge rd_clk or negedge rd_rst_sync) begin
    if (!rd_rst_sync) rd_ptr <= '0;
    else if (rd_en && !rd_empty) rd_ptr <= rd_ptr + 1'b1;
  end
  assign rd_ptr_gray = rd_ptr ^ (rd_ptr >> 1);

  // Sync wr_ptr_gray to rd_clk domain
  always_ff @(posedge rd_clk or negedge rd_rst_sync) begin
    if (!rd_rst_sync) begin
      wr_ptr_gray_sync1 <= '0;
      wr_ptr_gray_sync2 <= '0;
    end else begin
      wr_ptr_gray_sync1 <= wr_ptr_gray;
      wr_ptr_gray_sync2 <= wr_ptr_gray_sync1;
    end
  end

  // Sync rd_ptr_gray to wr_clk domain
  always_ff @(posedge wr_clk or negedge wr_rst_sync) begin
    if (!wr_rst_sync) begin
      rd_ptr_gray_sync1 <= '0;
      rd_ptr_gray_sync2 <= '0;
    end else begin
      rd_ptr_gray_sync1 <= rd_ptr_gray;
      rd_ptr_gray_sync2 <= rd_ptr_gray_sync1;
    end
  end

  // -------------------------------------------------------------------------
  // Empty / Full detection
  // -------------------------------------------------------------------------
  assign rd_empty = (rd_ptr_gray == wr_ptr_gray_sync2);

  logic [AW:0] rd_ptr_bin_sync2;
  always_comb begin
    rd_ptr_bin_sync2[AW] = rd_ptr_gray_sync2[AW];
    for (int i = AW-1; i >= 0; i--)
      rd_ptr_bin_sync2[i] = rd_ptr_bin_sync2[i+1] ^ rd_ptr_gray_sync2[i];
  end

  logic [AW:0] rd_ptr_full_gray;
  assign rd_ptr_full_gray = (rd_ptr_bin_sync2 ^ {1'b1, {AW{1'b0}}}) ^
                            ((rd_ptr_bin_sync2 ^ {1'b1, {AW{1'b0}}}) >> 1);
  assign wr_full = (wr_ptr_gray == rd_ptr_full_gray);

  // -------------------------------------------------------------------------
  // Sticky error flags (clear on common reset only)
  // -------------------------------------------------------------------------
  always_ff @(posedge wr_clk or negedge wr_rst_sync) begin
    if (!wr_rst_sync) wr_overflow <= 1'b0;
    else if (wr_en && wr_full) wr_overflow <= 1'b1;
  end

  always_ff @(posedge rd_clk or negedge rd_rst_sync) begin
    if (!rd_rst_sync) rd_underflow <= 1'b0;
    else if (rd_en && rd_empty) rd_underflow <= 1'b1;
  end

  // -------------------------------------------------------------------------
  // Read data output
  // -------------------------------------------------------------------------
  logic [WIDTH-1:0] rd_data_comb;
  assign rd_data_comb = mem[rd_ptr[AW-1:0]];

  generate
    if (REG_OUT) begin : gen_reg_out
      // register rd_data from CURRENT rd_ptr (before advance).
      // The old code registered rd_data_comb = mem[rd_ptr] on rd_en, but rd_ptr
      // also advances on rd_en (NBA). So rd_data_comb uses the OLD rd_ptr, but
      // the next read sees the NEW rd_ptr. This creates an off-by-one: the first
      // read returns entry 0, but the second read also returns entry 0 (because
      // rd_data was registered from entry 0 before rd_ptr advanced to 1).
      // register rd_data from mem[rd_ptr] (current), and advance rd_ptr
      // on the SAME cycle. The registered rd_data holds the value that was
      // at rd_ptr when rd_en was asserted.
      always_ff @(posedge rd_clk or negedge rd_rst_sync) begin
        if (!rd_rst_sync) rd_data <= '0;
        else if (rd_en && !rd_empty) rd_data <= mem[rd_ptr[AW-1:0]];
      end
    end else begin : gen_comb_out
      assign rd_data = rd_data_comb;
    end
  endgenerate

endmodule : i3c_async_fifo

