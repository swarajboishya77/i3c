// =============================================================================
// i3c_wake_detector.sv
// -----------------------------------------------------------------------------
// Asynchronous Wake-Up Detector for I3C Controller with Target capability.
// Lives in the ALWAYS-ON power domain (PD_AON). Never powers down.
// Detects two wake-up scenarios:
// Scenario A (Controller Mode, bus idle):
// A remote target pulls SDA low while SCL high (START condition) to signal
// an IBI or Hot-Join. The async START detector fires a wake interrupt to
// the PMU to restore clk_sys and clk_i3c_core.
// Scenario B (Target Mode, clocks off):
// An external master starts clocking SCL to address this IP's Target face.
// The SCL edge detector fires a wake interrupt so the Target engine's
// clock distribution can be restored before the address phase arrives.
// All detection is ASYNCHRONOUS — no clock required. The outputs are
// synchronized to clk_aon (a slow always-on clock, e.g., 32 kHz) before
// being sent to the PMU.
// =============================================================================

module i3c_wake_detector (
  // Always-on clock (slow, e.g., 32 kHz RTC)
  input  logic        clk_aon,
  input  logic        rst_aon_n,       // always-on reset (async, from PD_AON)

  // Raw pad inputs (NO clock gating — directly from pads)
  input  logic        sda_raw,
  input  logic        scl_raw,

  // Configuration (from register map, latched before power-down)
  input  logic        wake_en,          // global wake enable
  input  logic        wake_start_en,    // detect START as wake (Scenario A)
  input  logic        wake_scl_en,      // detect SCL edges as wake (Scenario B)

  // Wake-up outputs (synchronized to clk_aon)
  output logic        wake_irq,         // interrupt to PMU
  output logic        wake_src_start,   // 1 = woken by START condition
  output logic        wake_src_scl,     // 1 = woken by SCL edge
  input  logic        wake_clear        // host clears wake status
);

  // -------------------------------------------------------------------------
  // Async START condition detector (combinational, no clock)
  // -------------------------------------------------------------------------
  // START = SDA falls while SCL is high
  // We detect: SCL high AND SDA low AND SDA was high (falling edge)
  // (stage 1 = metastability-prone) into edge detection. Stage 1 may
  // settle to a different value than what was sampled, causing false
  // edges or missed edges. Correct pattern is 3 stages:
  // stage 1 (sda_meta_aon) = metastability filter (NOT used downstream)
  // stage 2 (sda_sync_aon) = stable "current" value
  // stage 3 (sda_prev_aon) = stable "previous" value
  // Edge detection compares stage 2 (current) with stage 3 (previous).
  logic        sda_meta_aon, sda_sync_aon, sda_prev_aon;
  logic        scl_meta_aon, scl_sync_aon;

  // 3-stage synchronizer to clk_aon for SDA and SCL
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      sda_meta_aon <= 1'b1;  // idle bus = high
      sda_sync_aon <= 1'b1;  // stable current
      sda_prev_aon <= 1'b1;  // stable previous
      scl_meta_aon <= 1'b1;
      scl_sync_aon <= 1'b1;
    end else begin
      sda_meta_aon <= sda_raw;     // stage 1: metastability filter (do NOT use downstream)
      sda_sync_aon <= sda_meta_aon; // stage 2: stable current
      sda_prev_aon <= sda_sync_aon; // stage 3: stable previous
      scl_meta_aon <= scl_raw;
      scl_sync_aon <= scl_meta_aon;
    end
  end

  // START condition: SCL high, SDA was high, SDA now low
  // Uses stage 2 (sda_sync_aon) and stage 3 (sda_prev_aon) - both stable.
  logic start_detected;
  assign start_detected = wake_en && wake_start_en &&
                          scl_sync_aon && sda_prev_aon && !sda_sync_aon;

  // SCL edge detector: any transition on SCL (rising or falling)
  logic       scl_prev_aon;
  logic       scl_edge_detected;
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) scl_prev_aon <= 1'b1;
    else            scl_prev_aon <= scl_sync_aon;
  end
  assign scl_edge_detected = wake_en && wake_scl_en && (scl_sync_aon != scl_prev_aon);

  // -------------------------------------------------------------------------
  // Wake status (sticky, cleared by host)
  // -------------------------------------------------------------------------
  logic wake_irq_r, wake_src_start_r, wake_src_scl_r;

  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      wake_irq_r       <= 1'b0;
      wake_src_start_r <= 1'b0;
      wake_src_scl_r   <= 1'b0;
    end else begin
      // wake_clear could overwrite a new wake event firing in
      // the same cycle. Use else-if to give set priority over clear.
      if (start_detected) begin
        wake_irq_r       <= 1'b1;
        wake_src_start_r <= 1'b1;
      end else if (scl_edge_detected) begin
        wake_irq_r     <= 1'b1;
        wake_src_scl_r <= 1'b1;
      end else if (wake_clear) begin
        wake_irq_r       <= 1'b0;
        wake_src_start_r <= 1'b0;
        wake_src_scl_r   <= 1'b0;
      end
    end
  end

  assign wake_irq       = wake_irq_r;
  assign wake_src_start = wake_src_start_r;
  assign wake_src_scl   = wake_src_scl_r;

endmodule : i3c_wake_detector

