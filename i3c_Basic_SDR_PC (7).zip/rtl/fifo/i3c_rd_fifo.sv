// =============================================================================
// i3c_rd_fifo.sv
// -----------------------------------------------------------------------------
// Read-data FIFO. Width = 32 bits.
// Controller pushes received bytes packed into 32-bit words (LSB-first
// within each word); software pops them via RD_FIFO_STATUS_ADDR.
// =============================================================================

module i3c_rd_fifo #(
  parameter int unsigned DEPTH = 32
) (
  input  logic        clk,
  input  logic        rst_n,

  // Push port (from controller)
  input  logic        push,
  input  logic [31:0] push_data,

  // Pop port (software reads RD_FIFO_STATUS_ADDR)
  input  logic        pop,
  output logic [31:0] pop_data,
  output logic        pop_valid,

  output logic        empty,
  output logic        full,
  output logic        almost_full,
  output logic [5:0]  level,          // words available
  output logic        overflow,
  output logic        underflow,
  input  logic        flush
);

  import i3c_pkg::*;

  localparam int unsigned CW = $clog2(DEPTH+1);

  logic [CW-1:0] count_lo;
  logic        almost_empty_w;
  logic        overflow_w, underflow_w;

  i3c_fifo #(
    .WIDTH     (32),
    .DEPTH     (DEPTH),
    .AFULL_TH  (DEPTH-2),
    .AEMPTY_TH (2),
    .REG_OUT   (1'b0)
  ) u_fifo (
    .clk          (clk),
    .rst_n        (rst_n),
    .wr_en        (push),
    .wr_data      (push_data),
    .rd_en        (pop),
    .rd_data      (pop_data),
    .empty        (empty),
    .full         (full),
    .almost_full  (almost_full),
    .almost_empty (almost_empty_w),
    .data_count   (count_lo),
    .overflow     (overflow_w),
    .underflow    (underflow_w),
    .flush        (flush)
  );

  assign pop_valid = ~empty;
  assign level     = count_lo;
  assign overflow  = overflow_w;
  assign underflow = underflow_w;

endmodule : i3c_rd_fifo

