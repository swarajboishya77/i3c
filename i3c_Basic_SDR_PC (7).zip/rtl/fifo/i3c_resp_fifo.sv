// =============================================================================
// i3c_resp_fifo.sv
// -----------------------------------------------------------------------------
// Response FIFO. Width = 32 bits (resp_word_t packed).
// Controller pushes one response per completed command; software pops them
// =============================================================================

module i3c_resp_fifo #(
  parameter int unsigned DEPTH = 16
) (
  input  logic        clk,
  input  logic        rst_n,

  input  logic        push,
  input  logic [31:0] push_data,

  input  logic        pop,
  output logic [31:0] pop_data,
  output logic        pop_valid,

  output logic        empty,
  output logic        full,
  output logic        almost_full,
  output logic [4:0]  level,
  output logic        overflow,
  output logic        underflow,
  input  logic        flush
);

  import i3c_pkg::*;

  localparam int unsigned CW = $clog2(DEPTH+1);

  logic [CW-1:0] count_lo;
  logic        almost_empty_w;
  logic        overflow_w, underflow_w;

  i3c_fifo #(
    .WIDTH     (32),
    .DEPTH     (DEPTH),
    .AFULL_TH  (DEPTH-2),
    .AEMPTY_TH (1),
    .REG_OUT   (1'b0)
  ) u_fifo (
    .clk          (clk),
    .rst_n        (rst_n),
    .wr_en        (push),
    .wr_data      (push_data),
    .rd_en        (pop),
    .rd_data      (pop_data),
    .empty        (empty),
    .full         (full),
    .almost_full  (almost_full),
    .almost_empty (almost_empty_w),
    .data_count   (count_lo),
    .overflow     (overflow_w),
    .underflow    (underflow_w),
    .flush        (flush)
  );

  assign pop_valid = ~empty;
  assign level     = count_lo;
  assign overflow  = overflow_w;
  assign underflow = underflow_w;

endmodule : i3c_resp_fifo

