// =============================================================================
// i3c_cmd_fifo.sv
// -----------------------------------------------------------------------------
// Command FIFO wrapper. Width = 32 bits (cmd_word_t packed).
// Stores Controller-mode commands pushed by software via CMD_FIFO_CTRL_ADDR.
// =============================================================================

module i3c_cmd_fifo #(
  parameter int unsigned DEPTH = 16
) (
  input  logic        clk,
  input  logic        rst_n,

  // Push port (from AXI write to CMD_FIFO_CTRL_ADDR)
  input  logic        push,
  input  logic [31:0] push_data,

  // Pop port (controller FSM)
  input  logic        pop,
  output logic [31:0] pop_data,
  output logic        pop_valid,

  // Status
  output logic        empty,
  output logic        full,
  output logic        almost_full,
  output logic [4:0]  level,      // free-space count (parametrizable via DEPTH)
  output logic        overflow,   // sticky: write while full
  output logic        underflow,  // sticky: read while empty
  input  logic        flush       // software flush
);

  import i3c_pkg::*;

  localparam int unsigned CW = $clog2(DEPTH+1);

  logic [CW-1:0] count_lo;
  logic        almost_empty_w;
  logic        overflow_w, underflow_w;

  i3c_fifo #(
    .WIDTH     (32),
    .DEPTH     (DEPTH),
    .AFULL_TH  (DEPTH-2),
    .AEMPTY_TH (1),
    .REG_OUT   (1'b0)
  ) u_fifo (
    .clk          (clk),
    .rst_n        (rst_n),
    .wr_en        (push),
    .wr_data      (push_data),
    .rd_en        (pop),
    .rd_data      (pop_data),
    .empty        (empty),
    .full         (full),
    .almost_full  (almost_full),
    .almost_empty (almost_empty_w),
    .data_count   (count_lo),
    .overflow     (overflow_w),
    .underflow    (underflow_w),
    .flush        (flush)
  );

  assign pop_valid = ~empty;
  assign level     = DEPTH - count_lo;
  assign overflow  = overflow_w;
  assign underflow = underflow_w;

endmodule : i3c_cmd_fifo

