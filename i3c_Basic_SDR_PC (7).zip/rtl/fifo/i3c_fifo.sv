// =============================================================================
// i3c_fifo.sv
// Generic parameterizable FIFO with:
// - Almost-full / almost-empty watermarks
// - Sticky overflow / underflow flags
// - Optional registered output (REG_OUT=1 adds 1-cycle read latency)
// - Flush port
// =============================================================================

module i3c_fifo #(
  parameter int unsigned WIDTH     = 32,
  parameter int unsigned DEPTH     = 16,
  parameter int unsigned AFULL_TH  = DEPTH-2,
  parameter int unsigned AEMPTY_TH = 1,
  parameter bit          REG_OUT   = 1'b1,
  parameter int unsigned AW        = $clog2(DEPTH)
) (
    input  logic             clk,
    input  logic             rst_n,
    input  logic             wr_en,
    input  logic [WIDTH-1:0] wr_data,
    input  logic             rd_en,
    output logic [WIDTH-1:0] rd_data,
    output logic             empty,
    output logic             full,
    output logic             almost_full,
    output logic             almost_empty,
    output logic [AW:0]      data_count,
    output logic             overflow,
    output logic             underflow,
    input  logic             flush
);
  logic [WIDTH-1:0] mem [0:DEPTH-1];
  logic [AW:0] wr_ptr, rd_ptr;

  assign full        = (wr_ptr == (rd_ptr ^ {1'b1, {AW{1'b0}}}));
  assign empty       = (wr_ptr == rd_ptr);
  assign data_count  = wr_ptr - rd_ptr;
  assign almost_full  = (data_count >= AFULL_TH);
  assign almost_empty = (data_count <= AEMPTY_TH);

  // Write pointer + sticky overflow
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr   <= '0;
      overflow <= 1'b0;
    end else if (flush) begin
      wr_ptr   <= '0;
      // overflow is STICKY — flush should NOT clear it.
      // Only reset or explicit SW write-to-clear should clear sticky flags.
    end else begin
      if (wr_en && !full) begin
        wr_ptr <= wr_ptr + 1'b1;
      end else if (wr_en && full) begin
        overflow <= 1'b1;
      end
    end
  end

  // Memory array write (synchronous only)
  always_ff @(posedge clk) begin
    if (wr_en && !full) begin
      mem[wr_ptr[AW-1:0]] <= wr_data;
    end
  end

  // Read pointer + sticky underflow
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr    <= '0;
      underflow <= 1'b0;
    end else if (flush) begin
      rd_ptr    <= '0;
      underflow <= 1'b0;
    end else begin
      if (rd_en && !empty) begin
        rd_ptr <= rd_ptr + 1'b1;
      end else if (rd_en && empty) begin
        underflow <= 1'b1;
      end
    end
  end

  // Read data: combinational (REG_OUT=0) or registered (REG_OUT=1)
  generate
    if (REG_OUT) begin : gen_reg_out
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
          rd_data <= '0;
        else if (flush)
          rd_data <= '0;
        else if (rd_en && !empty)
          rd_data <= mem[rd_ptr[AW-1:0]];
      end
    end else begin : gen_comb_out
      assign rd_data = mem[rd_ptr[AW-1:0]];
    end
  endgenerate

endmodule : i3c_fifo

