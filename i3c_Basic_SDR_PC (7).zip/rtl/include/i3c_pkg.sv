// =============================================================================
// i3c_pkg.sv
// -----------------------------------------------------------------------------
// SystemVerilog package for the I3C Basic SDR Controller IP
// (Controller-only, polled mode, with IBI, HJ, PEC, DAA, CCC, Group, Wake, Target).
// Contains:
// - Global parameters (bus widths, FIFO depths, address map)
// - Typedefs for AXI4-Lite buses
// - Enums for the main controller FSM, CCC opcodes, response codes
// - Helper functions (parity, address conversion)
// Spec reference:
// - MIPI I3C Basic Specification
// NOT IMPLEMENTED (per user requirement):
// - Target mode
// - Secondary Controller (SC) mode
// - HDR-DDR / HDR-BT / Multi-Lane
// - Interrupts (polling-only status via FIFO_LVL_STS / bus_busy)
// - IBI / Hot-Join handler
// - PEC (CRC-8) append/check
// =============================================================================

package i3c_pkg;

  // -------------------------------------------------------------------------
  // Global widths
  // -------------------------------------------------------------------------
  localparam int unsigned AXI_ADDR_W = 32;
  localparam int unsigned AXI_DATA_W = 32;
  localparam int unsigned AXI_STRB_W = AXI_DATA_W/8;

  localparam int unsigned I3C_ADDR_W = 7;   // I3C dynamic / static address
  localparam int unsigned PID_W       = 48; // Provisioned ID
  localparam int unsigned BCR_W       = 8;
  localparam int unsigned DCR_W       = 8;
  localparam int unsigned MWL_W       = 16;
  localparam int unsigned MRL_W       = 16;

  // -------------------------------------------------------------------------
  // Timing guard and protocol constants ()
  // -------------------------------------------------------------------------
  localparam int unsigned TIMING_GUARD_EN_DEFAULT = 1;  // Default enabled per reg map xlsx

  // I3C Basic minimum timing values (in ns, for 12.5 MHz SCL)
  localparam int unsigned TBUF_MIN_PURE_NS   = 250;   // tBUF min pure I3C
  localparam int unsigned TBUF_MIN_MIXED_NS = 1300;  // tBUF min mixed bus
  localparam int unsigned THD_STA_MIN_NS    = 250;   // tHD;STA min
  localparam int unsigned TSU_STA_MIN_NS    = 250;   // tSU;STA min
  localparam int unsigned TSU_STO_MIN_NS    = 250;   // tSU;STO min
  localparam int unsigned TLOW_MIN_NS       = 200;   // tLOW min (pure I3C)
  localparam int unsigned THIGH_MIN_NS      = 200;   // tHIGH min (pure I3C)

  // DAA protocol constants
  localparam int unsigned DAA_FIRST_BIT_STALL_US = 1;  // Stall after DAA addr assignment (I3C §4.1.4)
  localparam int unsigned DAA_PID_READ_TIMEOUT_US = 100; // Timeout for PID read during DAA

  // IBI priority levels (BCR[2:0])
  localparam int unsigned IBI_PRIORITY_LEVELS = 8;

  // Hot-Join debounce (glitch filter)
  localparam int unsigned HJ_DEBOUNCE_CYCLES = 4;  // SCL-filter clock cycles

  // PHY / Target timeout
  localparam int unsigned PHY_TIMEOUT_US_DEFAULT = 1000;  // 1ms PHY operation timeout
  localparam int unsigned TARGET_TIMEOUT_US_DEFAULT = 1000; // 1ms target watchdog

  // FIFO error flags
  localparam int unsigned FIFO_ERR_OVERFLOW  = 1;
  localparam int unsigned FIFO_ERR_UNDERFLOW = 2;


  // FIFO depths (words). Default 16, overridable at top-level.
  localparam int unsigned CMD_FIFO_DEPTH_DFLT  = 16;
  localparam int unsigned WR_FIFO_DEPTH_DFLT   = 32;
  localparam int unsigned RD_FIFO_DEPTH_DFLT   = 32;
  localparam int unsigned RESP_FIFO_DEPTH_DFLT = 16;

  // -------------------------------------------------------------------------
  // Register map (offsets, byte addressed)
  // I3C Register File: 44 native config registers (0x00-0xAC)
  // FIFOs are accessed via dedicated ports on i3c_controller_top
  // Extended registers: 7 registers (0xB0-0xCC) — serial after 0xAC
  // I2C Register File: 15 registers (0xD0-0x108) — after I3C extended block
  // -------------------------------------------------------------------------
  localparam logic [AXI_ADDR_W-1:0]
    VERSION_ADDR                             = 32'h00, // RO
    I3C_SPEED_MODE_CFG_ADDR                  = 32'h08, // R/W — [2:0]SPEED_MODE (0=SDR only)
    TRANSACTION_CTRL_ADDR                    = 32'h0C, // R/W — [0] EN
    TRANSACTION_STATUS_ADDR                  = 32'h10, // RO
    INTERRUPT_ENABLE_CTRL_ADDR               = 32'h14, // R/W
    INTERRUPT_STATUS_ADDR                    = 32'h18, // W1C
    IBI_STATUS_ADDR                          = 32'h1C, // W1C
    IBI_QUEUE_STATUS_ADDR                    = 32'h20, // RO
    HJ_STATUS_ADDR                           = 32'h24, // W1C
    // 0x2C-0x38: RESERVED (was CMD_FIFO_CTRL, WR_FIFO_CTRL, RD_FIFO_STATUS,
    FIFO_LVL_STATUS_ADDR                     = 32'h28, // RO — FIFO fill levels (diagnostic)
    FIFO_LVL_STATUS_1_ADDR                   = 32'h2C, // RO
    TX_FIFO_STATUS_ADDR                      = 32'h30, // RO
    RX_FIFO_STATUS_ADDR                      = 32'h34, // RO
    ACK_STATUS_ADDR                          = 32'h38, // RO
    SW_RESET_CTRL_ADDR                       = 32'h3C, // RWSC
    SW_RESET_STATUS_ADDR                     = 32'h40, // W1C
    FIFO_FLUSH_CTRL_ADDR                     = 32'h44, // RWSC
    ABORT_CTRL_ADDR                          = 32'h48, // RWSC
    SCL_HIGH_TIME_CFG_ADDR                   = 32'h4C, // R/W
    SCL_LOW_TIME_CFG_ADDR                    = 32'h50, // R/W
    SDA_HOLD_TIME_CFG_ADDR                   = 32'h54, // R/W
    BUS_FREE_TIME_CFG_ADDR                   = 32'h58, // R/W
    TSU_START_CFG_ADDR                       = 32'h5C, // R/W
    THD_START_CFG_ADDR                       = 32'h60, // R/W
    TSU_STOP_CFG_ADDR                        = 32'h64, // R/W
    SCL_OD_HIGH_TIME_CFG_ADDR                = 32'h68, // R/W
    SCL_OD_LOW_TIME_CFG_ADDR                 = 32'h6C, // R/W
    DNF_CTRL_ADDR                            = 32'h70, // R/W
    WAKE_CTRL_ADDR                           = 32'h74, // R/W
    WAKE_STATUS_ADDR                         = 32'h78, // W1C
    CLK_GATE_CTRL_ADDR                       = 32'h7C, // R/W
    POWER_CTRL_ADDR                          = 32'h80, // R/W
    CTRL_DYN_ADDR_CFG_ADDR                   = 32'h04, // R/W — Controller own dynamic address
    TARGET_STATUS_ADDR                       = 32'h84, // RO
    GROUP_ADDR_CFG_ADDR                      = 32'h88, // R/W
    GROUP_ADDR_TBL_CFG_ADDR                  = 32'h8C, // R/W
    PID0_STATUS_ADDR                         = 32'h90, // RO
    PID1_BCR_DCR_STATUS_ADDR                 = 32'h94, // RO
    // --- Extended registers: serial after 0xAC, before I2C block ---
    BUS_CONFIG_ADDR                          = 32'h98, // R/W — [1:0]BUS_TYPE
    ROLE_STATE_ADDR                          = 32'h9C, // RO — [2:0]role FSM state
    HANDOFF_STATUS_ADDR                      = 32'hA0, // RO — [1:0]handoff result
    RECLAIM_CONFIG_ADDR                      = 32'hA4, // R/W — [15:0]RECLAIM_TIMEOUT_US, [0]RECLAIM_EN
    SCL_HIGH_TIME_MIXED_CFG_ADDR             = 32'hA8, // R/W — [17:0]tDIG_H_MIXED
    TIMING_GUARD_CTRL_ADDR                   = 32'hAC, // R/W — [0]TIMING_GUARD_EN
    TIMING_VIOLATION_STATUS_ADDR             = 32'hB0; // W1C — [9:0]timing violation flags

  // -------------------------------------------------------------------------
  // RESERVED GAP: 0xC4 .. 0xFC (16 registers, 64 bytes)
  // -------------------------------------------------------------------------
  // This gap is intentionally reserved as a growth buffer for I3C
  // registers. It decouples the I3C register map from the I2C register map:
  // - Adding new I3C registers here does NOT shift I2C_REG_BASE.
  // - I2C_REG_BASE stays at 0x100 until this gap is exhausted.
  // - The gap provides room for up to 16 new I3C registers before I2C
  // would need to move.
  // Do NOT assign these offsets to any register. Reads return 0, writes
  // are ignored (treated as undefined by the AXI slave).
  // -------------------------------------------------------------------------

  // I2C register base offset in the AXI address map.
  // at 0x100 (page-aligned, 64 bytes after last I3C register at 0xC0).
  // The 0xC4..0xFC range is reserved as a growth buffer for I3C — see above.
  // The I2C register file internally uses 0x00-0x38; this constant is subtracted
  // by the AXI address decoder so the I2C module sees its own 0x00-based offsets.
  localparam logic [15:0] I2C_REG_BASE = 16'h0100;  // page-aligned, decoupled from I3C growth

  // I2C Register offsets (0x00-0x38 within I2C register file)
  // Base address offset 0xD0 is added by the AXI address decoder in
  // i3c_primary_controller_sdr.sv. The I2C register file sees 0x00-0x38.
  // Order matches I2C_Controller_Registers.xlsx
  localparam logic [AXI_ADDR_W-1:0]
    I2C_SPD_MODE_CFG_ADDR          = 32'h00, // R/W — SCL clock prescaler
    I2C_TRANS_CFG_ADDR             = 32'h04, // R/W — [7:0]XFER_LENGTH
    I2C_TRANS_EN_CTRL_ADDR         = 32'h08, // RWSC — [0]TRANS_EN
    I2C_TRANS_STATUS_ADDR          = 32'h0C, // RO — transaction status
    I2C_SW_RST_CTRL_ADDR           = 32'h10, // RWSC — I2C FSM reset
    I2C_SW_RST_STATUS_ADDR         = 32'h14, // W1C — I2C reset status
    I2C_TARGET_ADDR_CFG_ADDR       = 32'h18, // R/W — target address + RnW
    I2C_TIMEOUT_CFG_ADDR           = 32'h1C, // R/W — I2C bus idle timeout
    I2C_ACK_STATUS_ADDR            = 32'h20, // RO — [3:0]ACK/NACK status (4-bit)
    I2C_FIFO_CTRL_ADDR             = 32'h24, // RWSC — TX/RX FIFO flush
    I2C_FIFO_STATUS_ADDR           = 32'h28, // RO — FIFO full/empty/clear
    I2C_WDATA_TXFIFO_ADDR          = 32'h2C, // WO — TX FIFO data input
    I2C_RDATA_RXFIFO_ADDR          = 32'h30, // RO — RX FIFO data output
    I2C_INT_EN_CTRL_ADDR           = 32'h34, // R/W — interrupt enable
    I2C_INT_STATUS_ADDR            = 32'h38; // W1C — interrupt status

  // -------------------------------------------------------------------------
  // Mode select enum — per-transaction mode selection via cmd_desc[25]
  // -------------------------------------------------------------------------
  typedef enum logic {
    MODE_I3C = 1'b0,  // I3C Basic SDR mode (default)
    MODE_I2C = 1'b1   // I2C legacy mode (speed set by I2C_SPD_MODE_CFG.SPEED_PRESCALER)
  } mode_sel_e;

  // -------------------------------------------------------------------------
  // Primary Controller SDR FSM states
  // (defined below — single definition)

  // -------------------------------------------------------------------------
  // Response codes for RESP_FIFO
  // -------------------------------------------------------------------------
  typedef enum logic [7:0] {
    RESP_OK             = 8'h00,  // also RESP_SUCCESS
    RESP_NACK_ADDR      = 8'h01,
    RESP_NACK_DATA      = 8'h02,
    RESP_TIMEOUT        = 8'h04,
    RESP_ARB_LOST       = 8'h05,
    RESP_BUS_ERR        = 8'h06,
    RESP_OVERRUN        = 8'h07,
    RESP_FIFO_OVERFLOW  = 8'h08,
    RESP_PEC_ERR        = 8'h09,
    RESP_INVALID_CMD    = 8'h0A,
    RESP_ABORTED        = 8'h0B,
    RESP_BUSY           = 8'h0C,
    RESP_DAA_COLLISION  = 8'h0D,
    RESP_IBI_NACK       = 8'h0E
  } resp_code_e;

  localparam resp_code_e RESP_SUCCESS        = RESP_OK;
  localparam resp_code_e RESP_FIFO_UNDERFLOW = RESP_OVERRUN;

  // -------------------------------------------------------------------------
  // Command FIFO (32-bit) layout — Spec-compliant (TCRI-inspired)
  // bit 31 : TOC — Terminate on Completion (1=STOP after, 0=Repeated START)
  // bit 30 : CP — Command Present (1=CCC, 0=private transfer)
  // bits 29..28 : RESERVED
  // bit 27 : PEC_APPEND (append PEC on write)
  // bit 26 : PEC_CHECK (check PEC on read)
  // bit 25 : PEC_EN (enable PEC for this transaction)
  // bit 24 : I2C_MODE (0=I3C SDR, 1=I2C mode)
  // bits 23..16 : byte count - 1 (0..255 -> 1..256 bytes) = XFER_LENGTH
  // bits 15..9 : 7-bit device address (target dynamic address)
  // bit 8 : RnW (1 = read, 0 = write)
  // bits 7..0 : CCC opcode (actual I3C spec CCC code, valid when CP=1)
  // DECODE RULES:
  // CP=0: Private transfer. Use dev_addr, rnw, byte_cnt_m1.
  // If i2c_mode=1, route to I2C FSM. Else route to I3C FSM.
  // CP=1: CCC. ccc_opcode[7]=0 → Broadcast CCC (send to 7E).
  // ccc_opcode[7]=1 → Direct CCC (send to 7E, then dev_addr).
  // Special CCCs trigger sub-FSMs:
  // 0x07 = ENTDAA → DAA sequencer
  // 0x87 = SETDASA → DAA sequencer (static addr mode)
  // 0x91 = GETACCR → Controller role handoff
  // 0x06 = RSTDAA → Reset all dynamic addresses
  // TOC=1: Issue STOP after this transaction (bus released).
  // TOC=0: Hold bus (no STOP). Next command issues Repeated START.
  // CP=0 AND ccc_opcode=0x00: NOP (no operation, just push a response).
  // -------------------------------------------------------------------------
  typedef struct packed {
    logic        toc;            // [31] Terminate on Completion
    logic        cp;             // [30] Command Present (1=CCC, 0=private xfer)
    logic [1:0]  rsvd;           // [29:28]
    logic        pec_append;     // [27]
    logic        pec_check;      // [26]
    logic        pec_en;         // [25]
    logic        i2c_mode;       // [24]
    logic [7:0]  byte_cnt_m1;    // [23:16] = XFER_LENGTH-1
    logic [6:0]  dev_addr;       // [15:9] target dynamic address
    logic        rnw;            // [8] Read/Write
    logic [7:0]  ccc_opcode;     // [7:0] CCC opcode (spec-compliant, valid when CP=1)
  } cmd_word_t;

  // CCC opcode constants (per MIPI I3C Basic Section 5.1)
  // These are the actual spec values — used directly in cmd_word_t.ccc_opcode
  // Broadcast CCCs: 0x00-0x7F (bit 7 = 0)
  // Direct CCCs: 0x80-0xFF (bit 7 = 1)

  // -------------------------------------------------------------------------
  // Response FIFO (32-bit) layout
  // bits 7..0 : response code (resp_code_e)
  // bits 15..8 : byte count actually transferred
  // bit 16 : reserved (was PEC error)
  // bit 17 : NACK received
  // bit 19 : timeout
  // bits 31..20 : reserved
  // -------------------------------------------------------------------------
  // Note: the FSM assembles the response word via explicit concatenation
  // (see i3c_primary_controller_sdr.sv). This struct is kept for documentation.
  typedef struct packed {
    logic [12:0] rsvd;          // bits [31:19]
    logic        timeout;       // bit 18
    logic        nack;          // bit 17
    logic        rsvd_pec;      // bit 16 (reserved)
    logic [7:0]  xfer_len;     // bits [15:8]
    logic [7:0]  code;         // bits [7:0]
  } resp_word_t;

  // resp_code_e defined above (single definition)

  // -------------------------------------------------------------------------
  // I3C bus states
  // -------------------------------------------------------------------------
  typedef enum logic [3:0] {
    BUS_IDLE              = 4'd0,
    BUS_START             = 4'd1,
    BUS_ADDR_PHASE        = 4'd2,  // 7-bit addr + RnW
    BUS_ADDR_ACK          = 4'd3,
    BUS_TX_BYTE           = 4'd4,
    BUS_TX_ACK            = 4'd5,
    BUS_RX_BYTE           = 4'd6,
    BUS_RX_ACK            = 4'd7,
    BUS_REPEATED_START    = 4'd8,
    BUS_STOP              = 4'd9,
    BUS_DAA_START         = 4'd10,
    BUS_DAA_BCAST         = 4'd11, // ENTDAA broadcast address phase
    BUS_DAA_RX_PID        = 4'd12, // Receive 6-byte PID + BCR + DCR
    BUS_DAA_TX_DA         = 4'd13, // Send dynamic address
    BUS_TGT_RST_PATTERN   = 4'd15  // Send Target Reset Pattern
  } bus_state_e;

  // -------------------------------------------------------------------------
  // Bus configuration (BUS_CONFIG register)
  // Per MIPI I3C Basic §4.3.2.4 (Table 11):
  // Pure Bus — only I3C devices, max SCL 12.5 MHz, tDIG_H = 32 ns
  // Mixed Fast Bus — I3C + I2C with 50ns spike filter; tDIG_H_MIXED ≤ 45 ns ← DEFAULT
  // Mixed Slow Bus — I3C + I2C without spike filter; must clock at I2C speed
  // Reset default is MIXED_FAST because this IP implements an I2C fallback
  // FSM and ships with Fm+ timing defaults in all OD/START/STOP registers.
  // Software may write 0 (PURE) if no I2C devices are present on the bus.
  // -------------------------------------------------------------------------
  typedef enum logic [1:0] {
    BUS_TYPE_PURE        = 2'd0, // Pure I3C bus (no I2C devices)
    BUS_TYPE_MIXED_FAST  = 2'd1, // Mixed Fast Bus (I3C + I2C w/ 50ns filter) — DEFAULT
    BUS_TYPE_MIXED_SLOW  = 2'd2  // Mixed Slow/Limited Bus (I3C + I2C w/o filter)
  } bus_type_e;

  // -------------------------------------------------------------------------
  // Role Manager FSM states (per Figure 186 — Controller Regaining Bus Ownership)
  // The role manager owns the phy_mux select bits and tracks whether this IP
  // is currently Active Controller or Target.
  // -------------------------------------------------------------------------
  typedef enum logic [2:0] {
    ROLE_ACTIVE_CONTROLLER = 3'd0, // default at reset; mux = DPHY
    ROLE_PREPARING_HANDOFF = 3'd1, // controller issued GETACCCR, waiting
    ROLE_MONITORING_NEW    = 3'd2, // handoff done; 100µs timer running
    ROLE_TESTING_NEW       = 3'd3, // pull SDA low, check new controller
    ROLE_RECLAIMING        = 3'd4, // pull SCL low, become Active again
    ROLE_TARGET            = 3'd5, // operating as target (steady state)
    ROLE_HANDOFF_FAILED    = 3'd6, // GETACCCR NACKed; stayed as controller
    ROLE_BOOTSTRAP         = 3'd7  // Autonomous Bootstrap (TBD) owns the bus
  } role_state_e;

  // phy_mux select values (driven by role_manager)
  typedef enum logic [1:0] {
    PHY_MUX_DPHY    = 2'd0, // Digital PHY drives pads (Active Controller)
    PHY_MUX_TARGET  = 2'd1, // Target Engine drives SDA (we are target)
    PHY_MUX_BOOT    = 2'd2, // Autonomous Bootstrap (TBD) drives pads
    PHY_MUX_RSV     = 2'd3  // reserved
  } phy_mux_sel_e;

  // -------------------------------------------------------------------------
  // Controller FSM top-level states
  // -------------------------------------------------------------------------
  typedef enum logic [4:0] {
    CTRL_IDLE             = 5'd0,
    CTRL_DECODE_CMD       = 5'd1,
    CTRL_SEND_START       = 5'd2,
    CTRL_SEND_ADDR        = 5'd3,
    CTRL_TX_DATA          = 5'd5,
    CTRL_RX_DATA          = 5'd6,
    CTRL_SEND_CCC         = 5'd7,
    CTRL_RUN_DAA          = 5'd8,
    CTRL_SEND_TGT_RST     = 5'd9,
    CTRL_SEND_STOP        = 5'd10,
    CTRL_PUSH_RESP        = 5'd11,
    CTRL_WAIT_BUS_FREE    = 5'd12,
    CTRL_TX_PEC           = 5'd13,  // append PEC CRC byte after write data
    CTRL_RX_PEC           = 5'd14   // receive and check PEC CRC byte after read data
  } ctrl_state_e;

  // -------------------------------------------------------------------------
  // CCC opcodes — ONLY implemented commands (per MIPI I3C Basic Section 5.1)
  // These are the actual spec values used directly in cmd_word_t.ccc_opcode
  // Broadcast CCCs (0x00-0x7F, bit 7 = 0):
  localparam logic [7:0]
    CCC_ENEC_B            = 8'h00, // Enable Event(s) (Broadcast)
    CCC_DISEC_B           = 8'h01, // Disable Event(s) (Broadcast)
    CCC_RSTDAA_B          = 8'h06, // Reset Dynamic Address Assignment (Broadcast)
    CCC_ENTDAA_B          = 8'h07, // Enter Dynamic Address Assignment (Broadcast)
    CCC_DEFTGTS_B         = 8'h08, // Define List of Targets (Broadcast)
    CCC_SETMWL_B          = 8'h09, // Set Max Write Length (Broadcast)  [spec §4.3.7.3.5]
    CCC_SETMRL_B          = 8'h0A, // Set Max Read Length (Broadcast)   [spec §4.3.7.3.6]
    CCC_ENTTM_B           = 8'h0B, // Enter Test Mode (Broadcast)
    CCC_ENDXFER_B         = 8'h11, // End Data Transfer (Broadcast)
    CCC_RSTACT_B          = 8'h2A, // Target Reset Action (Broadcast)   [spec §4.3.9, Required]
    // Direct CCCs (0x80-0xFF, bit 7 = 1):
    CCC_ENEC_D            = 8'h80, // Enable Event(s) (Direct)
    CCC_DISEC_D           = 8'h81, // Disable Event(s) (Direct)
    CCC_SETDASA_D         = 8'h87, // Set Dynamic Address from Static Address (Direct)
    CCC_SETNEWDA_D        = 8'h88, // Set New Dynamic Address (Direct)
    CCC_SETMWL_D          = 8'h89, // Set Max Write Length (Direct)     [spec §4.3.7.3.5]
    CCC_SETMRL_D          = 8'h8A, // Set Max Read Length (Direct)      [spec §4.3.7.3.6]
    CCC_GETMWL_D          = 8'h8B, // Get Max Write Length (Direct)     [spec §4.3.7.3.5]
    CCC_GETMRL_D          = 8'h8C, // Get Max Read Length (Direct)      [spec §4.3.7.3.6]
    CCC_GETPID_D          = 8'h8D, // Get Provisioned ID (Direct)       [spec §4.3.7.3.12]
    CCC_GETBCR_D          = 8'h8E, // Get Bus Characteristics Register  [spec §4.3.7.3.13]
    CCC_GETDCR_D          = 8'h8F, // Get Device Characteristics Reg    [spec §4.3.7.3.14]
    CCC_GETSTATUS_D       = 8'h90, // Get Device Status (Direct)        [spec §4.3.7.3.15]
    CCC_GETACCR_D         = 8'h91, // Get Accept Controller Role (Direct) — handoff [spec §4.3.7.3.16]
    CCC_RSTACT_D          = 8'h9A, // Target Reset Action (Direct)      [spec §4.3.9, Required]
    CCC_GETRTGL_D         = 8'hE0; // Get Root Topology Group List (Direct) — group table query (vendor extension)

  // RSTACT defining byte values (spec §4.3.9, Table 38)
  localparam logic [7:0]
    RSTACT_RESET_WHOLE_DEVICE   = 8'h00, // Whole device reset
    RSTACT_RESET_PERIPHERAL_ONLY = 8'h01, // I3C peripheral reset only
    RSTACT_RESET_VIRTUAL_TGT    = 8'h02, // Virtual Target reset
    RSTACT_NO_RESET_QUERY_ONLY  = 8'h03; // No reset, just query (with Direct Read)

  // -------------------------------------------------------------------------
  // Helper: odd-parity bit for a 7-bit field.
  // Per MIPI I3C Basic v1.2 §4.3.4.2 step 9: PAR = ~XOR(dynamic_address[7:1]).
  // Used for I3C dynamic address parity in DAA and GETACCR.
  // -------------------------------------------------------------------------
  function automatic logic parity7_odd(input logic [6:0] data);
    // Odd parity = inverse of XOR (so total number of 1s including PAR is odd)
    return ~(^data);
  endfunction

  // Backward-compat alias (old name; maps to odd parity per spec)
  function automatic logic parity7(input logic [6:0] data);
    return parity7_odd(data);
  endfunction

  // I3C dynamic address: 7-bit addr with ODD parity in bit 0.
  // Per spec §4.3.4.2 step 9: PAR = ~XOR(addr[6:0]) (odd parity).
  function automatic logic [7:0] make_dyn_addr(input logic [6:0] addr);
    logic [7:0] out;
    out[7:1] = addr;
    out[0]   = parity7_odd(addr); // odd parity across bits [7:1]
    return out;
  endfunction

endpackage : i3c_pkg

