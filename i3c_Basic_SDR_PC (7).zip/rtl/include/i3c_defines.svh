// =============================================================================
// i3c_defines.svh
// -----------------------------------------------------------------------------
// Compile-time macros for the I3C Controller IP.
// ASIC-synthesizable: no simulation-only macros.
// =============================================================================

`define I3C_PKG_INST   "i3c_pkg::*"

// Reset polarity (active-low by default; flip if your SoC uses active-high)
`define I3C_RST_ACTIVE_LOW 1

