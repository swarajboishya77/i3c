// =============================================================================
// i3c_dnf.sv
// -----------------------------------------------------------------------------
// Digital Noise Filter for SCL and SDA inputs.
// Suppresses noise spikes shorter than a configurable threshold (0-15 PCLK
// cycles). A spike must persist for DNF_THRESHOLD+1 consecutive clock cycles
// before the output reflects the input.
// When DNF_THRESHOLD = 0, the filter is bypassed (output = input, 0-cycle delay).
// When DNF_THRESHOLD = N, the filter adds N+1 cycles of latency.
// Placed between io_buf.pad_i and i3c_timing_control.sda_i/scl_i.
// =============================================================================

module i3c_dnf #(
  parameter int unsigned MAX_THRESHOLD = 15  // max filter depth
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic [$clog2(MAX_THRESHOLD+1)-1:0] dnf_threshold,  // 0 = bypass
  input  logic              dnf_enable,       // 1 = filter active, 0 = bypass

  // Raw inputs from pad
  input  logic              sda_raw,
  input  logic              scl_raw,

  // Filtered outputs to timing control
  output logic              sda_filtered,
  output logic              scl_filtered
);

  // -------------------------------------------------------------------------
  // Shift register based filter
  // The shift register holds the last MAX_THRESHOLD samples (NOT including
  // the current sda_raw). We compute the match based on {shift, sda_raw}
  // (i.e. including the current sample) so that the filter requires
  // threshold+1 consecutive equal samples BEFORE propagating.
  // -------------------------------------------------------------------------
  logic [MAX_THRESHOLD:0] sda_shift;
  logic [MAX_THRESHOLD:0] scl_shift;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sda_shift <= '1;  // default high (idle bus)
      scl_shift <= '1;
    end else begin
      sda_shift <= {sda_shift[MAX_THRESHOLD-1:0], sda_raw};
      scl_shift <= {scl_shift[MAX_THRESHOLD-1:0], scl_raw};
    end
  end

  // -------------------------------------------------------------------------
  // Stability check: all samples in the window (including current) must agree
  // We use {shift, raw} so the match reflects the threshold+1 most recent
  // samples. This prevents a glitch from propagating on the first cycle
  // (the OLD shift register might still be all-equal from before the glitch).
  // -------------------------------------------------------------------------
  logic sda_all_match, scl_all_match;
  logic [MAX_THRESHOLD:0] sda_window;  // {shift, raw} = next shift value
  logic [MAX_THRESHOLD:0] scl_window;

  assign sda_window = {sda_shift[MAX_THRESHOLD-1:0], sda_raw};
  assign scl_window = {scl_shift[MAX_THRESHOLD-1:0], scl_raw};

  always_comb begin
    sda_all_match = 1'b1;
    scl_all_match = 1'b1;

    if (dnf_enable && dnf_threshold > 0) begin
      unique case (dnf_threshold)
        4'd1:  begin sda_all_match = (sda_window[1:0] == 2'b00) | (sda_window[1:0] == 2'b11);
                     scl_all_match = (scl_window[1:0] == 2'b00) | (scl_window[1:0] == 2'b11); end
        4'd2:  begin sda_all_match = (sda_window[2:0] == 3'b000) | (sda_window[2:0] == 3'b111);
                     scl_all_match = (scl_window[2:0] == 3'b000) | (scl_window[2:0] == 3'b111); end
        4'd3:  begin sda_all_match = (sda_window[3:0] == 4'b0000) | (sda_window[3:0] == 4'b1111);
                     scl_all_match = (scl_window[3:0] == 4'b0000) | (scl_window[3:0] == 4'b1111); end
        4'd4:  begin sda_all_match = (sda_window[4:0] == 5'b00000) | (sda_window[4:0] == 5'b11111);
                     scl_all_match = (scl_window[4:0] == 5'b00000) | (scl_window[4:0] == 5'b11111); end
        4'd5:  begin sda_all_match = (sda_window[5:0] == 6'b000000) | (sda_window[5:0] == 6'b111111);
                     scl_all_match = (scl_window[5:0] == 6'b000000) | (scl_window[5:0] == 6'b111111); end
        4'd6:  begin sda_all_match = (sda_window[6:0] == 7'b0000000) | (sda_window[6:0] == 7'b1111111);
                     scl_all_match = (scl_window[6:0] == 7'b0000000) | (scl_window[6:0] == 7'b1111111); end
        4'd7:  begin sda_all_match = (sda_window[7:0] == 8'b00000000) | (sda_window[7:0] == 8'b11111111);
                     scl_all_match = (scl_window[7:0] == 8'b00000000) | (scl_window[7:0] == 8'b11111111); end
        4'd8:  begin sda_all_match = (sda_window[8:0] == 9'b000000000) | (sda_window[8:0] == 9'b111111111);
                     scl_all_match = (scl_window[8:0] == 9'b000000000) | (scl_window[8:0] == 9'b111111111); end
        4'd9:  begin sda_all_match = (sda_window[9:0] == 10'b0000000000) | (sda_window[9:0] == 10'b1111111111);
                     scl_all_match = (scl_window[9:0] == 10'b0000000000) | (scl_window[9:0] == 10'b1111111111); end
        4'd10: begin sda_all_match = (sda_window[10:0] == 11'b00000000000) | (sda_window[10:0] == 11'b11111111111);
                     scl_all_match = (scl_window[10:0] == 11'b00000000000) | (scl_window[10:0] == 11'b11111111111); end
        4'd11: begin sda_all_match = (sda_window[11:0] == 12'b000000000000) | (sda_window[11:0] == 12'b111111111111);
                     scl_all_match = (scl_window[11:0] == 12'b000000000000) | (scl_window[11:0] == 12'b111111111111); end
        4'd12: begin sda_all_match = (sda_window[12:0] == 13'b0000000000000) | (sda_window[12:0] == 13'b1111111111111);
                     scl_all_match = (scl_window[12:0] == 13'b0000000000000) | (scl_window[12:0] == 13'b1111111111111); end
        4'd13: begin sda_all_match = (sda_window[13:0] == 14'b00000000000000) | (sda_window[13:0] == 14'b11111111111111);
                     scl_all_match = (scl_window[13:0] == 14'b00000000000000) | (scl_window[13:0] == 14'b11111111111111); end
        4'd14: begin sda_all_match = (sda_window[14:0] == 15'b000000000000000) | (sda_window[14:0] == 15'b111111111111111);
                     scl_all_match = (scl_window[14:0] == 15'b000000000000000) | (scl_window[14:0] == 15'b111111111111111); end
        4'd15: begin sda_all_match = (sda_window[15:0] == 16'b0000000000000000) | (sda_window[15:0] == 16'b1111111111111111);
                     scl_all_match = (scl_window[15:0] == 16'b0000000000000000) | (scl_window[15:0] == 16'b1111111111111111); end
        default: begin sda_all_match = 1'b1; scl_all_match = 1'b1; end
      endcase
    end
  end

  // -------------------------------------------------------------------------
  // Output: when stable (threshold+1 consecutive equal samples including
  // the current one), output the current raw value. When unstable, hold.
  // -------------------------------------------------------------------------
  logic sda_held, scl_held;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sda_held <= 1'b1;
      scl_held <= 1'b1;
    end else begin
      if (sda_all_match) sda_held <= sda_raw;  // stable: update to current value
      if (scl_all_match) scl_held <= scl_raw;  // stable: update to current value
    end
  end

  assign sda_filtered = (dnf_enable && (dnf_threshold > 0)) ? sda_held : sda_raw;
  assign scl_filtered = (dnf_enable && (dnf_threshold > 0)) ? scl_held : scl_raw;

endmodule : i3c_dnf

