// =============================================================================
// i3c_ccc_handler.sv
// CCC engine: broadcast + direct CCCs per MIPI I3C Basic
// =============================================================================

import i3c_pkg::*;

module i3c_ccc_handler (
    input  logic        clk,
    input  logic        rst_n,
    input  logic [15:0] cfg_mwl,
    input  logic [15:0] cfg_mrl,
    input  logic        ccc_req,
    input  logic        ccc_is_direct,
    input  logic [7:0]  ccc_opcode,
    input  logic [6:0]  ccc_target_addr,
    input  logic [15:0] ccc_defining_byte,
    input  logic        ccc_has_defining_byte,
    input  logic        prim_done,
    input  logic        prim_ack_recv,
    input  logic [7:0]  prim_byte_recv,
    output logic        ccc_start,
    output logic        ccc_repeat_start,
    output logic        ccc_stop,
    output logic        ccc_send_addr_w,
    output logic        ccc_send_addr_r,
    output logic [6:0]  ccc_addr_val,
    output logic        ccc_send_byte,
    output logic [7:0]  ccc_byte_val,
    output logic        ccc_recv_byte,
    output logic        ccc_expect_response,
    output logic        ccc_done,
    output logic        ccc_resp_valid,
    output logic [7:0]  ccc_resp_byte,
    output logic        ccc_getacccr_ack,
    output logic        ccc_getacccr_addr_nack,
    output logic        ccc_getacccr_data_nack,
    output logic        ccc_error
);

  typedef enum logic [4:0] {
    C_IDLE, C_START, C_ADDR_7E_W, C_ADDR_7E_ACK, C_TX_OPCODE, C_TX_OPCODE_ACK,
    C_TX_DEF_BYTE, C_TX_DEF_BYTE_ACK, C_REP_START, C_DIRECT_ADDR, C_DIRECT_ADDR_ACK,
    C_TX_PAYLOAD, C_TX_PAYLOAD_ACK, C_RX_PAYLOAD, C_RX_PAYLOAD_ACK,
    C_STOP, C_DONE, C_ERROR
  } ccc_state_e;

  ccc_state_e state, next_state;
  logic [15:0] payload_cnt;
  logic [7:0]  resp_byte_q;  // captured response byte
  logic [7:0]  addr_7e_w;
  logic        error_q;

  // GETACCR status flags must be sticky (registered)
  logic getacccr_ack_q;
  logic getacccr_addr_nack_q;
  logic getacccr_data_nack_q;

  assign addr_7e_w = {7'h7E, 1'b0};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state       <= C_IDLE;
      payload_cnt <= '0;
      resp_byte_q <= 8'h00;
      error_q     <= 1'b0;
      // clear sticky GETACCR flags on reset
      getacccr_ack_q       <= 1'b0;
      getacccr_addr_nack_q <= 1'b0;
      getacccr_data_nack_q <= 1'b0;
    end else begin
      state <= next_state;
      // Clear sticky flags on new CCC request
      if (state == C_IDLE && ccc_req) begin
        getacccr_ack_q       <= 1'b0;
        getacccr_addr_nack_q <= 1'b0;
        getacccr_data_nack_q <= 1'b0;
      end
      // Set GETACCR ack when target accepts (in C_DIRECT_ADDR_ACK)
      if (state == C_DIRECT_ADDR_ACK && prim_done && prim_ack_recv &&
          ccc_opcode == CCC_GETACCR_D)
        getacccr_ack_q <= 1'b1;
      // Set GETACCR addr_nack when target address NACKed
      if (state == C_DIRECT_ADDR_ACK && prim_done && !prim_ack_recv &&
          ccc_opcode == CCC_GETACCR_D) begin
        getacccr_addr_nack_q <= 1'b1;
        error_q <= 1'b1;  // set error on addr NACK
      end
      // GETACCR per spec §4.3.7.3.16: target returns 7-bit DA + PAR (odd parity).
      // Verify: (a) returned DA matches target_addr, (b) PAR = ~XOR(DA[6:0]).
      // If either fails → data_nack (treat as rejection / incorrect cancel).
      if (state == C_RX_PAYLOAD_ACK && prim_done && ccc_opcode == CCC_GETACCR_D) begin
        // Spec: returned 7-bit DA must equal target_addr, and PAR bit must be
        // odd parity of those 7 bits: PAR = ~(^DA[6:0]).
        // Inline the verification to avoid unused sequential element warnings.
        getacccr_data_nack_q <= !((prim_byte_recv[7:1] == ccc_target_addr) &&
                                  (prim_byte_recv[0] == ~(^prim_byte_recv[7:1])));
        if (!((prim_byte_recv[7:1] == ccc_target_addr) &&
              (prim_byte_recv[0] == ~(^prim_byte_recv[7:1])))) begin
          getacccr_ack_q <= 1'b0;  // rejection clears ack
          error_q <= 1'b1;  // set error on GETACCR rejection
        end
      end
      // GET CCC response byte counts per MIPI I3C Basic v1.2 Table 16:
      //   GETPID    = 6 bytes (48-bit PID)
      //   GETMRL    = 2 bytes (16-bit MRL)
      //   GETMWL    = 2 bytes (16-bit MWL)
      //   GETSTATUS = 2 bytes (16-bit status)
      //   GETBCR    = 1 byte
      //   GETDCR    = 1 byte
      //   GETACCR   = 1 byte (7-bit DA + PAR)
      if (state == C_IDLE && ccc_req) begin
        if (ccc_is_direct) begin
          // Direct CCC: payload_cnt = number of bytes to TX (for SETs) or RX (for GETs)
          unique case (ccc_opcode)
            // Direct GETs (receive N bytes from target)
            CCC_GETPID_D:     payload_cnt <= 16'd6;  // 48-bit PID
            CCC_GETMRL_D:     payload_cnt <= 16'd2;  // 16-bit MRL
            CCC_GETMWL_D:     payload_cnt <= 16'd2;  // 16-bit MWL
            CCC_GETSTATUS_D:  payload_cnt <= 16'd2;  // 16-bit status
            CCC_GETBCR_D:     payload_cnt <= 16'd1;
            CCC_GETDCR_D:     payload_cnt <= 16'd1;
            CCC_GETACCR_D:    payload_cnt <= 16'd1;  // 7-bit DA + PAR
            // Direct SETs (send N bytes to target after target address)
            CCC_SETMWL_D:     payload_cnt <= 16'd2;  // 16-bit MWL
            CCC_SETMRL_D:     payload_cnt <= 16'd2;  // 16-bit MRL (+ optional IBI size, not supported here)
            CCC_SETDASA_D:    payload_cnt <= 16'd1;  // 1 byte: dynamic address to assign
            CCC_SETNEWDA_D:   payload_cnt <= 16'd1;  // 1 byte: new dynamic address
            // RSTACT Direct: 0 payload bytes (just defining byte + ack)
            // RSTACT Direct Read (query): handled by RX path with payload_cnt set in C_DIRECT_ADDR_ACK
            default:          payload_cnt <= 16'd0;
          endcase
        end else begin
          // Broadcast CCC: payload_cnt = number of TX payload bytes (after defining byte)
          // Per spec Table 16:
          //   SETMWL (0x09) = 2 bytes (MWL MSB, MWL LSB)
          //   SETMRL (0x0A) = 2 or 3 bytes (MRL MSB, MRL LSB, optional IBI Payload Size)
          //   RSTACT (0x2A) = 0 bytes (defining byte only, handled via ccc_has_defining_byte)
          if (ccc_opcode == CCC_SETMWL_B)
            payload_cnt <= 16'd2;
          else if (ccc_opcode == CCC_SETMRL_B)
            payload_cnt <= 16'd2;  // 3rd IBI Payload Size byte handled separately if BCR[2]=1
          else
            payload_cnt <= 16'd0;
        end
      end else if ((state == C_TX_PAYLOAD_ACK || state == C_RX_PAYLOAD_ACK) && prim_done && prim_ack_recv)
        payload_cnt <= payload_cnt - 1'b1;
      // capture response byte in always_ff, not always_comb
      if (state == C_RX_PAYLOAD_ACK && prim_done)
        resp_byte_q <= prim_byte_recv;
      if (next_state == C_ERROR)
        error_q <= 1'b1;
      else if (next_state == C_IDLE)
        error_q <= 1'b0;
    end
  end

  always_comb begin
    next_state          = state;
    ccc_start           = 1'b0;
    ccc_repeat_start    = 1'b0;
    ccc_stop            = 1'b0;
    ccc_send_addr_w     = 1'b0;
    ccc_send_addr_r     = 1'b0;
    ccc_addr_val        = 7'h00;
    ccc_send_byte       = 1'b0;
    ccc_byte_val        = 8'h00;
    ccc_recv_byte       = 1'b0;
    ccc_expect_response = 1'b0;
    ccc_done            = 1'b0;
    ccc_resp_valid      = 1'b0;
    ccc_resp_byte       = 8'h00;
    ccc_getacccr_ack    = getacccr_ack_q;       // use sticky registered flag
    ccc_getacccr_addr_nack = getacccr_addr_nack_q;
    ccc_getacccr_data_nack = getacccr_data_nack_q;
    ccc_error           = error_q;

    unique case (state)
      C_IDLE: if (ccc_req) next_state = C_START;
      C_START: begin ccc_start = 1'b1; next_state = C_ADDR_7E_W; end
      C_ADDR_7E_W: begin ccc_send_byte = 1'b1; ccc_byte_val = addr_7e_w; if (prim_done) next_state = C_ADDR_7E_ACK; end
      C_ADDR_7E_ACK: if (prim_done) begin if (prim_ack_recv) next_state = C_TX_OPCODE; else next_state = C_ERROR; end
      C_TX_OPCODE: begin ccc_send_byte = 1'b1; ccc_byte_val = ccc_opcode; next_state = C_TX_OPCODE_ACK; end
      C_TX_OPCODE_ACK: begin
        if (prim_done) begin
          if (prim_ack_recv) begin
            if (ccc_has_defining_byte) next_state = C_TX_DEF_BYTE;
            else if (ccc_is_direct) next_state = C_REP_START;  // Direct CCC needs Repeated START
            // Broadcast SETMWL (0x09) and SETMRL (0x0A) have 2-byte payload after opcode
            else if (ccc_opcode == CCC_SETMWL_B || ccc_opcode == CCC_SETMRL_B) next_state = C_TX_PAYLOAD;
            else next_state = C_STOP;
          end else next_state = C_ERROR;
        end
      end
      C_TX_DEF_BYTE: begin ccc_send_byte = 1'b1; ccc_byte_val = ccc_defining_byte[7:0]; next_state = C_TX_DEF_BYTE_ACK; end
      C_TX_DEF_BYTE_ACK: begin
        if (prim_done) begin
          if (prim_ack_recv) begin
            // after defining byte, check if there's TX payload
            if (ccc_is_direct) next_state = C_REP_START;  // Direct CCC needs Repeated START
            // Broadcast SETMWL (0x09) and SETMRL (0x0A) have payload after defining byte
            else if (ccc_opcode == CCC_SETMWL_B || ccc_opcode == CCC_SETMRL_B)
              next_state = C_TX_PAYLOAD;
            // RSTACT broadcast (0x2A): defining byte only, no payload → STOP
            else next_state = C_STOP;
          end else next_state = C_ERROR;
        end
      end
      // Direct CCCs need Repeated START before target address
      C_REP_START: begin ccc_repeat_start = 1'b1; next_state = C_DIRECT_ADDR; end
      // C_TX_PAYLOAD sends 2 payload bytes for SETMRL/SETMWL
      // Per spec: MSB first, then LSB
      C_TX_PAYLOAD: begin
        ccc_send_byte = 1'b1;
        // send high byte first (payload_cnt=2), then low byte (payload_cnt=1)
        // Per spec Table 16: SETMWL=0x09 (broadcast) / 0x89 (direct);
        //                     SETMRL=0x0A (broadcast) / 0x8A (direct)
        if (ccc_opcode == CCC_SETMWL_B || ccc_opcode == CCC_SETMWL_D)
          ccc_byte_val = (payload_cnt == 16'd2) ? cfg_mwl[15:8] : cfg_mwl[7:0];
        else  // SETMRL (broadcast 0x0A or direct 0x8A)
          ccc_byte_val = (payload_cnt == 16'd2) ? cfg_mrl[15:8] : cfg_mrl[7:0];
        next_state = C_TX_PAYLOAD_ACK;
      end
      C_TX_PAYLOAD_ACK: begin
        if (prim_done) begin
          if (prim_ack_recv) begin
            if (payload_cnt <= 16'd1) next_state = C_STOP;
            else next_state = C_TX_PAYLOAD;  // send next byte
          end else next_state = C_ERROR;
        end
      end
      C_DIRECT_ADDR: begin ccc_send_byte = 1'b1; ccc_byte_val = {ccc_target_addr, 1'b0}; next_state = C_DIRECT_ADDR_ACK; end
      C_DIRECT_ADDR_ACK: begin
        if (prim_done) begin
          if (prim_ack_recv) begin
            // Direct SET CCCs (SETMWL=0x89, SETMRL=0x8A, SETDASA=0x87, SETNEWDA=0x88)
            // send TX payload after target address.
            // Direct GET CCCs (GETPID, GETBCR, GETDCR, GETSTATUS, GETACCR, GETMRL, GETMWL)
            // receive RX payload from target.
            // RSTACT Direct (0x9A) is a Direct Read/Write — depends on defining byte
            //   (per spec §4.3.9: defining byte 0x03 = query/read, others = write action)
            if (ccc_opcode == CCC_SETMWL_D || ccc_opcode == CCC_SETMRL_D ||
                ccc_opcode == CCC_SETDASA_D || ccc_opcode == CCC_SETNEWDA_D ||
                (ccc_opcode == CCC_RSTACT_D && ccc_defining_byte[7:0] != RSTACT_NO_RESET_QUERY_ONLY))
              next_state = C_TX_PAYLOAD;  // Direct SET: send payload bytes
            else begin
              // Direct GET or RSTACT-query: receive payload
              // RSTACT Direct query returns 2 bytes per spec §4.3.9 (reset type + extra info)
              ccc_expect_response = 1'b1;
              next_state = C_RX_PAYLOAD;
            end
          end else begin
            next_state = C_STOP;
          end
        end
      end
      C_RX_PAYLOAD: begin ccc_recv_byte = 1'b1; ccc_expect_response = 1'b1; next_state = C_RX_PAYLOAD_ACK; end
      C_RX_PAYLOAD_ACK: if (prim_done) begin if (payload_cnt == 0) next_state = C_STOP; else next_state = C_RX_PAYLOAD; end
      C_STOP: begin ccc_stop = 1'b1; next_state = C_DONE; end
      C_DONE: begin ccc_done = 1'b1; ccc_resp_valid = 1'b1; ccc_resp_byte = error_q ? 8'h06 : resp_byte_q; next_state = C_IDLE; end
      C_ERROR: begin ccc_done = 1'b1; ccc_resp_valid = 1'b1; ccc_resp_byte = 8'h06; ccc_error = 1'b1; next_state = C_IDLE; end
      default: next_state = C_IDLE;
    endcase
  end

endmodule : i3c_ccc_handler

