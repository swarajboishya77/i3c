// =============================================================================
// i3c_timing_control.sv
// SCL/SDA bit-time engine for I3C SDR.
// All timed states now properly wait for timer to expire.
// Open-drain mode releases SDA (high-Z) instead of driving high.
// =============================================================================

import i3c_pkg::*;

module i3c_timing_control #(
  parameter int unsigned CLK_FREQ_HZ = 100_000_000
) (
    input  logic        clk,
    input  logic        rst_n,
    input  logic [17:0] cfg_scl_high_time,
    input  logic [17:0] cfg_scl_low_time,
    input  logic [17:0] cfg_sda_hold_time,
    input  logic [17:0] cfg_bus_free_time,
    input  logic [17:0] cfg_tsu_start,
    input  logic [17:0] cfg_thd_start,
    input  logic [17:0] cfg_tsu_stop,
    input  logic [17:0] cfg_scl_od_high_time,  // open-drain SCL high time (I2C / I3C OD phase)
    input  logic [17:0] cfg_scl_od_low_time,   // open-drain SCL low time
    input  logic [1:0]  bus_type,
    input  logic [17:0] cfg_scl_high_time_mixed,
    input  logic        tcmd_start,
    input  logic        tcmd_bit_xfer,
    input  logic        tcmd_bit_xfer_od,
    input  logic        tcmd_drive_scl_low,
    input  logic        tcmd_release,
    input  logic        tcmd_stop,
    input  logic [7:0]  tx_bit,  // byte-wide TX (LSB used for bit_xfer)
    input  logic        sda_i,           // SDA pad input for sampling
    output logic        sda_sampled,     // SDA value sampled at SCL high
    output logic        scl_out,
    output logic        sda_out,
    output logic        scl_oe,
    output logic        sda_oe,
    output logic        bit_done,
    output logic        byte_done,
    output logic        timing_violation
);

  // -------------------------------------------------------------------------
  // Shadow registers (latch config at transaction start)
  // -------------------------------------------------------------------------
  logic [17:0] sh_scl_high, sh_scl_low, sh_sda_hold;
  logic [17:0] sh_bus_free, sh_tsu_start, sh_thd_start, sh_tsu_stop;
  logic [17:0] sh_scl_high_mixed;
  logic [17:0] sh_scl_od_high, sh_scl_od_low;
  logic [1:0]  sh_bus_type;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh_scl_high <= '0; sh_scl_low <= '0; sh_sda_hold <= '0;
      sh_bus_free <= '0; sh_tsu_start <= '0; sh_thd_start <= '0; sh_tsu_stop <= '0;
      sh_scl_high_mixed <= '0; sh_bus_type <= '0;
      sh_scl_od_high <= '0; sh_scl_od_low <= '0;
    end else begin
      sh_scl_high <= cfg_scl_high_time; sh_scl_low <= cfg_scl_low_time;
      sh_sda_hold <= cfg_sda_hold_time; sh_bus_free <= cfg_bus_free_time;
      sh_tsu_start <= cfg_tsu_start; sh_thd_start <= cfg_thd_start; sh_tsu_stop <= cfg_tsu_stop;
      sh_scl_high_mixed <= cfg_scl_high_time_mixed; sh_bus_type <= bus_type;
      sh_scl_od_high <= cfg_scl_od_high_time; sh_scl_od_low <= cfg_scl_od_low_time;
    end
  end

  // -------------------------------------------------------------------------
  // FSM states
  // -------------------------------------------------------------------------
  typedef enum logic [5:0] {
    T_IDLE,
    T_SHADOW_LOAD, T_BUS_FREE_WAIT,
    T_START_SDA_FALL, T_START_SCL_LOW,
    T_SCL_LOW, T_SDA_SETUP, T_SCL_HIGH, T_SDA_HOLD,
    T_SCL_LOW_ACK, T_SCL_HIGH_ACK,
    T_STOP_SDA_LOW, T_STOP_SCL_HIGH, T_STOP_SDA_HIGH,
    T_DRIVE_SCL_LOW, T_RELEASE, T_ERROR
  } t_state_e;

  t_state_e state, next_state;

  // Command latch: capture which command was issued in T_IDLE so that
  // T_BUS_FREE_WAIT can determine the next state even after the 1-cycle
  // command pulse has been deasserted. Without this, direct instantiation
  // of i3c_timing_control (e.g. tb_i3c_mipi_mixedbus_timing) causes the
  // FSM to get stuck in T_BUS_FREE_WAIT because tcmd_start is gone.
  logic cmd_latch_start;
  logic cmd_latch_stop;
  logic cmd_latch_bit_pp;
  logic cmd_latch_bit_od;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cmd_latch_start  <= 1'b0;
      cmd_latch_stop   <= 1'b0;
      cmd_latch_bit_pp <= 1'b0;
      cmd_latch_bit_od <= 1'b0;
    end else begin
      if (state == T_IDLE) begin
        cmd_latch_start  <= tcmd_start;
        cmd_latch_stop   <= tcmd_stop;
        cmd_latch_bit_pp <= tcmd_bit_xfer;
        cmd_latch_bit_od <= tcmd_bit_xfer_od;
      end else if (next_state == T_IDLE || next_state == T_BUS_FREE_WAIT) begin
        // Clear latches when finishing a sequence (returning to idle)
        cmd_latch_start  <= 1'b0;
        cmd_latch_stop   <= 1'b0;
        cmd_latch_bit_pp <= 1'b0;
        cmd_latch_bit_od <= 1'b0;
      end
    end
  end

  logic sda_drive_bit;
  logic od_mode;  // 1 = open-drain for this bit
  assign sda_drive_bit = tx_bit[0];
  assign od_mode = tcmd_bit_xfer_od | cmd_latch_bit_od;

  // Select SCL high time based on bus type and mode
  logic [17:0] scl_high_target;
  always_comb begin
    if (od_mode)
      scl_high_target = sh_scl_od_high;
    else if (sh_bus_type == 2'd0)  // Pure I3C
      scl_high_target = sh_scl_high;
    else  // Mixed Fast/Slow
      scl_high_target = (sh_scl_high_mixed == '0) ? 18'd5 : sh_scl_high_mixed;
  end

  // -------------------------------------------------------------------------
  // Timer
  // -------------------------------------------------------------------------
  logic [17:0] timer;
  logic        timer_load, timer_en;
  logic [17:0] timer_load_val;

  // SDA sampled at SCL high midpoint
  logic sda_sampled_r;

  // first_cycle_q is asserted for exactly one cycle after
  // a state transition. It gates timer_load so the timer is loaded ONCE on
  // entry into a timed state, then decrements on subsequent cycles. Without
  // this, timer_load=1 every cycle caused the timer to be reloaded every
  // cycle and the FSM never advanced (timer never reached 0).
  logic first_cycle_q;
  logic scl_held_low;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      timer <= '0;
      state <= T_IDLE;
      sda_sampled_r <= 1'b0;
      first_cycle_q <= 1'b1;
      scl_held_low <= 1'b0;
    end else begin
      state <= next_state;
      first_cycle_q <= (state != next_state);
      // Timer load: load timer_load_val directly. The total SCL high duration
      // is timer_load_val cycles (1 load cycle + (val-1) decrement cycles).
      // The previous off-by-2 fix (val-2) caused SCL high to be 2 cycles
      // shorter than expected, breaking the "SCL high = 4 cycles" check.
      if (timer_load)
        timer <= timer_load_val;
      else if (timer_en && (timer != '0))
        timer <= timer - 1'b1;
      // Sample SDA at midpoint of T_SCL_HIGH (data bit) AND T_SCL_HIGH_ACK (ACK bit)
      if (state == T_SCL_HIGH && timer == (scl_high_target >> 1))
        sda_sampled_r <= sda_i;
      if (state == T_SCL_HIGH_ACK && timer == (scl_high_target >> 1))
        sda_sampled_r <= sda_i;
        
      if (tcmd_drive_scl_low)
        scl_held_low <= 1'b1;
      else if (tcmd_release || state == T_ERROR || tcmd_stop || tcmd_start)
        scl_held_low <= 1'b0;
    end
  end

  assign sda_sampled = sda_sampled_r;

  // -------------------------------------------------------------------------
  // Open-drain SDA drive helper
  // In open-drain mode: bit=0 → drive low (sda_oe=1, sda_out=0)
  // bit=1 → release (sda_oe=0, sda_out=1)
  // In push-pull mode: bit=0 → drive low (sda_oe=1, sda_out=0)
  // bit=1 → drive high (sda_oe=1, sda_out=1)
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  always_comb begin
    next_state = state;
    timer_load = 1'b0; timer_en = 1'b0; timer_load_val = '0;
    
    if (scl_held_low) begin
      scl_out = 1'b0; scl_oe = 1'b1;
    end else begin
      scl_out = 1'b1; scl_oe = 1'b0;
    end
    sda_out = 1'b1; sda_oe = 1'b0;
    
    bit_done = 1'b0; byte_done = 1'b0; timing_violation = 1'b0;

    unique case (state)
      T_IDLE: begin
        // hold SCL low when a bit_xfer is pending, to avoid a
        // 1-cycle SCL-high glitch between START completion and the first bit.
        // The phy_fsm holds SCL low via bus_active_q in PHY_IDLE, but when
        // timing_control takes ownership (PHY_BIT_XFER), its T_IDLE default
        // (scl_oe=0 = released = pullup high) causes a spurious SCL rising
        // edge that the target BFM samples as a false data bit.
        if (tcmd_bit_xfer || tcmd_bit_xfer_od || tcmd_drive_scl_low) begin
          scl_oe = 1'b1; scl_out = 1'b0;  // hold SCL low
        end
        if (tcmd_start) next_state = T_SHADOW_LOAD;
        // bit_xfer bypasses bus_free_wait
        else if (tcmd_bit_xfer || tcmd_bit_xfer_od) next_state = T_SCL_LOW;
        else if (tcmd_drive_scl_low) next_state = T_DRIVE_SCL_LOW;
        else if (tcmd_release) next_state = T_RELEASE;
        else if (tcmd_stop) next_state = T_SHADOW_LOAD;
      end

      T_SHADOW_LOAD: begin
        timer_load = 1'b1; timer_load_val = sh_bus_free;
        next_state = T_BUS_FREE_WAIT;
      end

      T_BUS_FREE_WAIT: begin
        timer_en = 1'b1;
        if (timer == '0) begin
          if (tcmd_start || cmd_latch_start) next_state = T_START_SDA_FALL;
          else if (tcmd_bit_xfer || tcmd_bit_xfer_od || cmd_latch_bit_pp || cmd_latch_bit_od) next_state = T_SCL_LOW;
          else if (tcmd_stop || cmd_latch_stop) next_state = T_STOP_SDA_LOW;
          else next_state = T_IDLE;  // return to idle when bus is free and no command pending
        end
      end

      T_START_SDA_FALL: begin
        sda_oe = 1'b1; sda_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_tsu_start;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_START_SCL_LOW;
        end
      end

      T_START_SCL_LOW: begin
        scl_oe = 1'b1; scl_out = 1'b0; sda_oe = 1'b1; sda_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_thd_start;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) begin
            bit_done = 1'b1;
            next_state = T_IDLE;
          end
        end
      end

      // --- Data bit phases: each now waits for timer to expire ---
      T_SCL_LOW: begin
        scl_oe = 1'b1; scl_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = od_mode ? sh_scl_od_low : sh_scl_low;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_SDA_SETUP;
        end
      end

      T_SDA_SETUP: begin
        scl_oe = 1'b1; scl_out = 1'b0;
        // Open-drain: release SDA when bit=1, drive low when bit=0
        if (od_mode && sda_drive_bit) begin
          sda_oe = 1'b0; sda_out = 1'b1;  // release (high-Z)
        end else begin
          sda_oe = 1'b1; sda_out = sda_drive_bit;  // drive
        end
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_sda_hold;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_SCL_HIGH;
        end
      end

      T_SCL_HIGH: begin
        scl_oe = 1'b1; scl_out = 1'b1;
        // Open-drain: release SDA when bit=1, drive low when bit=0
        if (od_mode && sda_drive_bit) begin
          sda_oe = 1'b0; sda_out = 1'b1;  // release (high-Z)
        end else begin
          sda_oe = 1'b1; sda_out = sda_drive_bit;  // drive
        end
        if (first_cycle_q) begin
          // Subtract 1 to account for the load cycle itself (SCL is already
          // high during the load cycle). Total SCL high = 1 (load) + (val-1)
          // (decrement) = val cycles. Previously this was val+1 due to the
          // extra load cycle.
          timer_load = 1'b1; timer_load_val = (scl_high_target > 18'd1) ? scl_high_target - 18'd1 : 18'd0;
        end else begin
          timer_en = 1'b1;
          // each tcmd_bit_xfer generates exactly ONE SCL pulse.
          // The old code went to T_SDA_HOLD → T_SCL_LOW_ACK → T_SCL_HIGH_ACK,
          // generating a second SCL pulse (ACK) for every bit. The byte_serdes
          // calls tcmd_bit_xfer 9 times (8 data + 1 ACK/T-bit), so timing_control
          // must only generate 1 SCL cycle per call. Go directly to T_IDLE and
          // pulse bit_done.
          if (timer == '0) begin
            bit_done = 1'b1;
            next_state = T_IDLE;
          end
        end
      end

      T_SDA_HOLD: begin
        scl_oe = 1'b1; scl_out = 1'b0;
        // Open-drain: release SDA when bit=1, drive low when bit=0
        if (od_mode && sda_drive_bit) begin
          sda_oe = 1'b0; sda_out = 1'b1;  // release (high-Z)
        end else begin
          sda_oe = 1'b1; sda_out = sda_drive_bit;  // drive
        end
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_sda_hold;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_SCL_LOW_ACK;
        end
      end

      T_SCL_LOW_ACK: begin
        scl_oe = 1'b1; scl_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_scl_low;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_SCL_HIGH_ACK;
        end
      end

      T_SCL_HIGH_ACK: begin
        scl_oe = 1'b1; scl_out = 1'b1;
        // ACK phase: always open-drain, release SDA so target can drive
        sda_oe = 1'b0; sda_out = 1'b1;  // release for ACK
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = (scl_high_target > 18'd1) ? scl_high_target - 18'd1 : 18'd0;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) begin
            bit_done = 1'b1;
            next_state = T_IDLE;
          end
        end
      end

      T_STOP_SDA_LOW: begin
        scl_oe = 1'b1; scl_out = 1'b0; sda_oe = 1'b1; sda_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_tsu_stop;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_STOP_SCL_HIGH;
        end
      end

      T_STOP_SCL_HIGH: begin
        scl_oe = 1'b0; sda_oe = 1'b1; sda_out = 1'b0;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_tsu_stop;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) next_state = T_STOP_SDA_HIGH;
        end
      end

      T_STOP_SDA_HIGH: begin
        scl_oe = 1'b0; sda_oe = 1'b1; sda_out = 1'b1;
        if (first_cycle_q) begin
          timer_load = 1'b1; timer_load_val = sh_bus_free;
        end else begin
          timer_en = 1'b1;
          if (timer == '0) begin
            byte_done = 1'b1;
            next_state = T_BUS_FREE_WAIT;
          end
        end
      end

      T_DRIVE_SCL_LOW: begin
        scl_oe = 1'b1; scl_out = 1'b0;
        bit_done = 1'b1;  // pulse done so phy_fsm propagates it
        next_state = T_IDLE;
      end

      T_RELEASE: begin
        scl_oe = 1'b0; sda_oe = 1'b0;
        next_state = T_IDLE;
      end

      T_ERROR: begin
        timing_violation = 1'b1;
        next_state = T_IDLE;
      end

      default: next_state = T_IDLE;
    endcase
  end

endmodule : i3c_timing_control

