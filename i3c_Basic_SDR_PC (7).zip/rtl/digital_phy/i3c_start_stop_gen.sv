// =============================================================================
// i3c_start_stop_gen.sv
// -----------------------------------------------------------------------------
// Standalone START / Repeated-START / STOP condition generator for the I3C
// Digital PHY. This module produces the SDA/SCL drive signals required to
// generate I3C/I2C START, Repeated-START and STOP conditions, plus the bus
// release (high-Z) and post-STOP bus-free wait.
// All timing is parameterized through the cfg_* inputs which originate from
// the register file (programmed via the AXI4-Lite slave):
// cfg_tsu_start - START setup time (SCL high, SDA high->low)
// cfg_thd_start - START hold time (SCL low after START)
// cfg_tsu_stop - STOP setup time (SCL high, SDA low->high)
// cfg_bus_free_time - Bus free time between STOP and next START
// The module drives sda_o/sda_oe/scl_o/scl_oe ONLY when busy. When idle,
// all output enables are deasserted (high-Z), allowing another PHY block
// (e.g. i3c_timing_control during bit_xfer) to own the pads.
// This module is instantiated inside i3c_phy_fsm.sv and is selected by the
// PHY FSM whenever a START / Repeated-START / STOP / release command is
// requested by the byte serializer/deserializer.
// I3C Basic reference: Section 5.1.2 (START Condition), Section 5.1.3
// (STOP Condition), Section 5.1.4 (Repeated START Condition), Section 5.1.5
// (Bus Free Time).
// =============================================================================

import i3c_pkg::*;

module i3c_start_stop_gen (
    input  logic        clk,
    input  logic        rst_n,

    // ------------------------------------------------------------------
    // Timing configuration (from register file, programmed via AXI4-Lite)
    // ------------------------------------------------------------------
    input  logic [17:0] cfg_tsu_start,
    input  logic [17:0] cfg_thd_start,
    input  logic [17:0] cfg_tsu_stop,
    input  logic [17:0] cfg_bus_free_time,

    // ------------------------------------------------------------------
    // Command interface (single-cycle pulse, one at a time)
    // ------------------------------------------------------------------
    input  logic        cmd_start,          // generate START condition
    input  logic        cmd_repeat_start,   // generate Repeated START
    input  logic        cmd_stop,           // generate STOP condition
    input  logic        cmd_release,        // release bus (high-Z)

    // ------------------------------------------------------------------
    // Status
    // ------------------------------------------------------------------
    output logic        done,               // pulse when operation completes
    output logic        busy,               // 1 = generator is active

    // ------------------------------------------------------------------
    // SDA/SCL drive (only driven when busy; high-Z when idle)
    // ------------------------------------------------------------------
    output logic        sda_o,
    output logic        sda_oe,
    output logic        scl_o,
    output logic        scl_oe
);

    // ------------------------------------------------------------------
    // FSM states
    // ------------------------------------------------------------------
    typedef enum logic [3:0] {
        SS_IDLE,
        SS_TSU_START_WAIT,   // wait tsu_start before SDA fall (START)
        SS_START_SDA_FALL,   // SDA low while SCL high
        SS_START_SCL_FALL,   // SCL low (end of START)
        SS_THD_START_WAIT,   // wait thd_start after SCL fall
        SS_STOP_SCL_HIGH,    // SCL high while SDA low (STOP setup)
        SS_STOP_SDA_RISE,    // SDA rises while SCL high (STOP)
        SS_BUS_FREE_WAIT,    // wait bus_free_time after STOP
        SS_RELEASE           // release bus (high-Z)
    } ss_state_e;

    ss_state_e state_q, state_d;

    logic [17:0] timer_q;
    logic        done_r;
    logic        busy_r;
    logic        sda_o_r, sda_oe_r;
    logic        scl_o_r, scl_oe_r;

    // ------------------------------------------------------------------
    // State register
    // ------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q  <= SS_IDLE;
            timer_q  <= 18'd0;
            done_r   <= 1'b0;
            busy_r   <= 1'b0;
            sda_o_r  <= 1'b1;   // idle high
            sda_oe_r <= 1'b0;   // high-Z when idle
            scl_o_r  <= 1'b1;   // idle high
            scl_oe_r <= 1'b0;   // high-Z when idle
        end else begin
            done_r <= 1'b0;     // default: clear done pulse
            unique case (state_q)
                SS_IDLE: begin
                    busy_r <= 1'b0;
                    sda_o_r  <= 1'b1;
                    sda_oe_r <= 1'b0;
                    scl_o_r  <= 1'b1;
                    scl_oe_r <= 1'b0;
                    if (cmd_start) begin
                        state_q  <= SS_TSU_START_WAIT;
                        timer_q  <= cfg_tsu_start;
                        busy_r   <= 1'b1;
                        sda_o_r  <= 1'b1;
                        sda_oe_r <= 1'b1;
                        scl_o_r  <= 1'b1;
                        scl_oe_r <= 1'b1;
                    end else if (cmd_repeat_start) begin
                        // Repeated START — SCL high, SDA must go
                        // HIGH first (prepare), then fall (START condition).
                        // The old code kept SDA low, so the BFM never saw an SDA
                        // falling edge while SCL high — no START was detected.
                        state_q  <= SS_TSU_START_WAIT;
                        timer_q  <= cfg_tsu_start;
                        busy_r   <= 1'b1;
                        sda_o_r  <= 1'b1;  // SDA high (prepare for falling edge)
                        sda_oe_r <= 1'b1;
                        scl_o_r  <= 1'b1;
                        scl_oe_r <= 1'b1;
                    end else if (cmd_stop) begin
                        state_q  <= SS_STOP_SCL_HIGH;
                        timer_q  <= cfg_tsu_stop;
                        busy_r   <= 1'b1;
                        // Pre-STOP: SDA low, SCL high
                        sda_o_r  <= 1'b0;
                        sda_oe_r <= 1'b1;
                        scl_o_r  <= 1'b1;
                        scl_oe_r <= 1'b1;
                    end else if (cmd_release) begin
                        state_q  <= SS_RELEASE;
                        busy_r   <= 1'b1;
                    end
                end

                SS_TSU_START_WAIT: begin
                    if (timer_q == 18'd0) begin
                        state_q <= SS_START_SDA_FALL;
                        // SDA falls while SCL high -> START condition
                        sda_o_r  <= 1'b0;
                        sda_oe_r <= 1'b1;
                        scl_o_r  <= 1'b1;
                        scl_oe_r <= 1'b1;
                        timer_q <= cfg_tsu_start;
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_START_SDA_FALL: begin
                    if (timer_q == 18'd0) begin
                        state_q <= SS_START_SCL_FALL;
                        // SCL falls
                        scl_o_r  <= 1'b0;
                        scl_oe_r <= 1'b1;
                        sda_o_r  <= 1'b0;
                        sda_oe_r <= 1'b1;
                        timer_q <= cfg_thd_start;
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_START_SCL_FALL: begin
                    if (timer_q == 18'd0) begin
                        // START complete -> return to IDLE, pulse done
                        state_q  <= SS_IDLE;
                        done_r   <= 1'b1;
                        busy_r   <= 1'b0;
                        // Releasing SCL here causes a false SCL rising edge that
                        // the target model samples as a spurious first data bit.
                        // The phy_fsm will hold SCL low (via bus_active_q) until
                        // the first cmd_bit_xfer arrives from the byte_serdes.
                        sda_o_r  <= 1'b1;
                        sda_oe_r <= 1'b0;  // release SDA
                        scl_o_r  <= 1'b0;  // keep SCL low
                        scl_oe_r <= 1'b1;  // keep driving SCL low
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_STOP_SCL_HIGH: begin
                    if (timer_q == 18'd0) begin
                        state_q <= SS_STOP_SDA_RISE;
                        // SDA rises while SCL high -> STOP condition
                        sda_o_r  <= 1'b1;
                        sda_oe_r <= 1'b1;
                        scl_o_r  <= 1'b1;
                        scl_oe_r <= 1'b1;
                        timer_q <= cfg_tsu_stop;
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_STOP_SDA_RISE: begin
                    if (timer_q == 18'd0) begin
                        state_q <= SS_BUS_FREE_WAIT;
                        // Release bus
                        sda_oe_r <= 1'b0;
                        scl_oe_r <= 1'b0;
                        timer_q <= cfg_bus_free_time;
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_BUS_FREE_WAIT: begin
                    if (timer_q == 18'd0) begin
                        state_q <= SS_IDLE;
                        done_r  <= 1'b1;
                        busy_r  <= 1'b0;
                    end else begin
                        timer_q <= timer_q - 18'd1;
                    end
                end

                SS_RELEASE: begin
                    // Release bus immediately
                    sda_o_r  <= 1'b1;
                    sda_oe_r <= 1'b0;
                    scl_o_r  <= 1'b1;
                    scl_oe_r <= 1'b0;
                    state_q  <= SS_IDLE;
                    done_r   <= 1'b1;
                    busy_r   <= 1'b0;
                end

                default: begin
                    state_q <= SS_IDLE;
                end
            endcase
        end
    end

    assign done   = done_r;
    assign busy   = busy_r;
    assign sda_o  = sda_o_r;
    assign sda_oe = sda_oe_r;
    assign scl_o  = scl_o_r;
    assign scl_oe = scl_oe_r;

endmodule : i3c_start_stop_gen

