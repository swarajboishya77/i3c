// =============================================================================
// i3c_phy_mux.sv
// -----------------------------------------------------------------------------
// Clean 3:1 multiplexer for the SDA/SCL pad drive signals.
// Three SDA drivers compete for one physical SDA pad:
// 1. Digital PHY (i3c_phy_fsm) — active when this IP is the Active Controller
// 2. Target Engine (i3c_target_engine) — active when this IP is a Target
// 3. TBD Bootstrap (future autonomous bring-up logic) — placeholder for now
// The 2-bit select is driven by the role_manager FSM (i3c_role_manager.sv),
// NEVER by software directly. Software influences the select indirectly by
// issuing handoff commands and configuring the role FSM.
// Mutual exclusion is guaranteed by the role_manager: exactly one of the
// three drivers is selected at any clock. There is no priority encoder and
// no software-controlled override.
// SCL pad:
// - Driven by Digital PHY when this IP is Active Controller
// - Driven by TBD Bootstrap when in bootstrap mode
// - NEVER driven by Target Engine (target uses external SCL as its clock;
// it samples SCL, never drives it)
// Pad readback (sda_i, scl_i from io_buf) is broadcast to all three blocks
// so each can observe bus state independently of who is currently driving.
// This module is purely combinational — no clock, no reset, no state.
// =============================================================================


module i3c_phy_mux (
    // ------------------------------------------------------------------
    // Select — 2 bits, driven by role_manager FSM
    // ------------------------------------------------------------------
    input  logic [1:0]  phy_mux_sel,   // phy_mux_sel_e enum

    // ------------------------------------------------------------------
    // Input 0 (sel=2'b00): Digital PHY (Active Controller mode)
    // ------------------------------------------------------------------
    input  logic        dphy_sda_o,
    input  logic        dphy_sda_oe,
    input  logic        dphy_scl_o,
    input  logic        dphy_scl_oe,

    // ------------------------------------------------------------------
    // Input 1 (sel=2'b01): Target Engine (Target mode — SDA only)
    // Target never drives SCL; scl_o/scl_oe tied to 0 internally.
    // ------------------------------------------------------------------
    input  logic        tgt_sda_o,
    input  logic        tgt_sda_oe,

    // ------------------------------------------------------------------
    // Input 2 (sel=2'b10): TBD Bootstrap (future autonomous logic)
    // Drives both SDA and SCL.
    // ------------------------------------------------------------------
    input  logic        boot_sda_o,
    input  logic        boot_sda_oe,
    input  logic        boot_scl_o,
    input  logic        boot_scl_oe,

    // ------------------------------------------------------------------
    // Output to io_buf (pad drive)
    // ------------------------------------------------------------------
    output logic        pad_sda_o,
    output logic        pad_sda_oe,
    output logic        pad_scl_o,
    output logic        pad_scl_oe,

    // ------------------------------------------------------------------
    // Pad readback from io_buf (broadcast to all blocks)
    // ------------------------------------------------------------------
    input  logic        pad_sda_i,
    input  logic        pad_scl_i,
    output logic        dphy_sda_i,
    output logic        dphy_scl_i,
    output logic        tgt_sda_i,
    output logic        tgt_scl_i,
    output logic        boot_sda_i,
    output logic        boot_scl_i
);

    // ------------------------------------------------------------------
    // SDA output mux — pure 3:1 with explicit case
    // ------------------------------------------------------------------
    always_comb begin
        // Default: release (high-Z, bus pulled high externally)
        pad_sda_o  = 1'b1;
        pad_sda_oe = 1'b0;

        unique case (phy_mux_sel)
            2'd0: begin  // PHY_MUX_DPHY
                pad_sda_o  = dphy_sda_o;
                pad_sda_oe = dphy_sda_oe;
            end
            2'd1: begin  // PHY_MUX_TARGET
                pad_sda_o  = tgt_sda_o;
                pad_sda_oe = tgt_sda_oe;
            end
            2'd2: begin  // PHY_MUX_BOOT
                pad_sda_o  = boot_sda_o;
                pad_sda_oe = boot_sda_oe;
            end
            2'd3: begin  // PHY_MUX_RSV — release the bus
                pad_sda_o  = 1'b1;
                pad_sda_oe = 1'b0;
            end
        endcase
    end

    // ------------------------------------------------------------------
    // SCL output mux — only DPHY and BOOT can drive SCL
    // Target mode (sel=2'b01) NEVER drives SCL (scl_oe = 0)
    // ------------------------------------------------------------------
    always_comb begin
        // Default: release (high-Z, bus pulled high externally)
        pad_scl_o  = 1'b1;
        pad_scl_oe = 1'b0;

        unique case (phy_mux_sel)
            2'd0: begin  // PHY_MUX_DPHY
                pad_scl_o  = dphy_scl_o;
                pad_scl_oe = dphy_scl_oe;
            end
            2'd1: begin  // PHY_MUX_TARGET — never drive SCL
                pad_scl_o  = 1'b1;
                pad_scl_oe = 1'b0;
            end
            2'd2: begin  // PHY_MUX_BOOT
                pad_scl_o  = boot_scl_o;
                pad_scl_oe = boot_scl_oe;
            end
            2'd3: begin  // PHY_MUX_RSV
                pad_scl_o  = 1'b1;
                pad_scl_oe = 1'b0;
            end
        endcase
    end

    // ------------------------------------------------------------------
    // Pad readback broadcast: all three blocks observe the same pad state.
    // No muxing needed for inputs — every block can always see the bus.
    // ------------------------------------------------------------------
    assign dphy_sda_i = pad_sda_i;
    assign dphy_scl_i = pad_scl_i;
    assign tgt_sda_i  = pad_sda_i;
    assign tgt_scl_i  = pad_scl_i;
    assign boot_sda_i = pad_sda_i;
    assign boot_scl_i = pad_scl_i;

endmodule : i3c_phy_mux

