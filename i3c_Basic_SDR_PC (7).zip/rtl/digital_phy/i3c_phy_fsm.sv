// =============================================================================
// i3c_phy_fsm.sv
// Digital PHY FSM: routes commands to timing_control + start_stop_gen
// cmd_repeat_start forwarded to start_stop_gen
// bit_xfer bypasses bus_free_wait (goes straight to SCL_LOW)
// =============================================================================

import i3c_pkg::*;

module i3c_phy_fsm (
    input  logic        clk,
    input  logic        rst_n,
    input  logic [17:0] cfg_scl_high_time,
    input  logic [17:0] cfg_scl_low_time,
    input  logic [17:0] cfg_sda_hold_time,
    input  logic [17:0] cfg_bus_free_time,
    input  logic [17:0] cfg_tsu_start,
    input  logic [17:0] cfg_thd_start,
    input  logic [17:0] cfg_tsu_stop,
    input  logic [17:0] cfg_scl_od_high_time,
    input  logic [17:0] cfg_scl_od_low_time,
    input  logic [1:0]  bus_type,
    input  logic [17:0] cfg_scl_high_time_mixed,
    input  logic        cmd_start,
    input  logic        cmd_repeat_start,
    input  logic        cmd_stop,
    input  logic        cmd_drive_scl_low,
    input  logic        cmd_release_bus,
    input  logic        cmd_bit_xfer,
    input  logic        cmd_bit_xfer_od,
    input  logic        sda_drive_val,
    input  logic        mode_pushpull,
    output logic        done,
    output logic        busy,
    output logic        sda_sampled,
    output logic        stretch_detected,
    output logic        sda_o,
    output logic        sda_oe,
    output logic        scl_o,
    output logic        scl_oe,
    input  logic        sda_i,
    input  logic        scl_i               // filtered SCL input (TB hook; sampled for stretch detection)
);

  // -------------------------------------------------------------------------
  // PHY FSM states — routes START/STOP/Repeated START to start_stop_gen,
  // and bit_xfer to timing_control
  // -------------------------------------------------------------------------
  typedef enum logic [2:0] {
    PHY_IDLE,
    PHY_START_STOP,     // start_stop_gen handling START/STOP/Repeated START
    PHY_BIT_XFER,       // timing_control handling bit transfer
    PHY_DRIVE_SCL_LOW,  // timing_control driving SCL low
    PHY_RELEASE         // start_stop_gen releasing bus
    // PHY_WAIT_DONE removed — was dead code, never entered from any state
  } phy_state_e;

  phy_state_e state_q, next_state;
  logic        bus_active_q;  // tracks if bus is active (after START, before STOP)

  // Internal start_stop_gen signals
  logic        ss_cmd_start;
  logic        ss_cmd_repeat_start;
  logic        ss_cmd_stop;
  logic        ss_cmd_release;
  logic        ss_done;
  logic        ss_sda_o, ss_sda_oe, ss_scl_o, ss_scl_oe;

  // Internal timing_control signals
  logic        tc_done;
  logic        tc_timing_violation;
  logic [17:0] tc_scl_high;
  logic [17:0] tc_scl_low;
  logic        tc_sda_sampled;
  logic        tc_sda_o, tc_sda_oe, tc_scl_o, tc_scl_oe;

  // Select SCL high/low based on mode
  assign tc_scl_high = mode_pushpull ? (bus_type != 2'd0 ? 
                     (cfg_scl_high_time_mixed != '0 ? cfg_scl_high_time_mixed : 18'd5) : 
                     cfg_scl_high_time) : cfg_scl_od_high_time;
  assign tc_scl_low  = mode_pushpull ? cfg_scl_low_time : cfg_scl_od_low_time;

  // -------------------------------------------------------------------------
  // State register
  // -------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) state_q <= PHY_IDLE;
    else state_q <= next_state;
  end

  // -------------------------------------------------------------------------
  // Bus active tracking
  // -------------------------------------------------------------------------
  logic pending_stop_q;  // remembers if STOP was issued

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bus_active_q <= 1'b0;
      pending_stop_q <= 1'b0;
    end else begin
      // Latch which command was issued when entering PHY_START_STOP
      if (state_q == PHY_IDLE && next_state == PHY_START_STOP) begin
        if (cmd_start || cmd_repeat_start)
          bus_active_q <= 1'b1;
        if (cmd_stop)
          pending_stop_q <= 1'b1;
      end
      // Clear bus_active when START_STOP completes if it was a STOP
      if (state_q == PHY_START_STOP && next_state == PHY_IDLE && pending_stop_q) begin
        bus_active_q <= 1'b0;
        pending_stop_q <= 1'b0;
      end
      if (state_q == PHY_RELEASE) begin
        bus_active_q <= 1'b0;
        pending_stop_q <= 1'b0;
      end
    end
  end

  // -------------------------------------------------------------------------
  // Next-state + command routing
  // -------------------------------------------------------------------------
  always_comb begin
    next_state          = state_q;
    ss_cmd_start        = 1'b0;
    ss_cmd_repeat_start = 1'b0;
    ss_cmd_stop         = 1'b0;
    ss_cmd_release      = 1'b0;
    // timing_control commands
    // (timing_control has its own FSM — we pulse the command for 1 cycle)

    unique case (state_q)
      PHY_IDLE: begin
        if (cmd_start) begin
          ss_cmd_start = 1'b1;
          next_state   = PHY_START_STOP;
          // bus_active_q set in always_ff
        end else if (cmd_repeat_start) begin
          ss_cmd_repeat_start = 1'b1;
          next_state          = PHY_START_STOP;
        end else if (cmd_stop) begin
          ss_cmd_stop = 1'b1;
          next_state  = PHY_START_STOP;
        end else if (cmd_release_bus) begin
          ss_cmd_release = 1'b1;
          next_state     = PHY_RELEASE;
        end else if (cmd_bit_xfer || cmd_bit_xfer_od) begin
          next_state = PHY_BIT_XFER;
        end else if (cmd_drive_scl_low) begin
          next_state = PHY_DRIVE_SCL_LOW;
        end
      end

      PHY_START_STOP: begin
        if (ss_done) next_state = PHY_IDLE;  // go directly to IDLE
      end

      PHY_BIT_XFER: begin
        if (tc_done) next_state = PHY_IDLE;  // go directly to IDLE, not WAIT_DONE
      end

      PHY_DRIVE_SCL_LOW: begin
        next_state = PHY_IDLE;  // go directly to IDLE
      end

      PHY_RELEASE: begin
        if (ss_done) next_state = PHY_IDLE;  // go directly to IDLE
      end

      default: next_state = PHY_IDLE;
    endcase
  end

  // -------------------------------------------------------------------------
  // Output muxing: select which sub-module drives the pads
  // -------------------------------------------------------------------------
  always_comb begin
    // Default: high-Z, idle high
    // hold SCL low in PHY_IDLE when bus is active
    sda_o  = 1'b1;
    sda_oe = 1'b0;
    if (bus_active_q && state_q == PHY_IDLE) begin
      scl_o  = 1'b0;   // hold SCL low between bits
      scl_oe = 1'b1;
    end else begin
      scl_o  = 1'b1;   // release SCL (idle)
      scl_oe = 1'b0;
    end

    if (state_q == PHY_START_STOP || state_q == PHY_RELEASE) begin
      // start_stop_gen owns the pads
      sda_o  = ss_sda_o;
      sda_oe = ss_sda_oe;
      scl_o  = ss_scl_o;
      scl_oe = ss_scl_oe;
    end else if (state_q == PHY_BIT_XFER || state_q == PHY_DRIVE_SCL_LOW) begin
      // timing_control owns the pads — route tc_* to outputs
      sda_o  = tc_sda_o;
      sda_oe = tc_sda_oe;
      scl_o  = tc_scl_o;
      scl_oe = tc_scl_oe;
    end
  end

  // -------------------------------------------------------------------------
  // Status aggregation
  // -------------------------------------------------------------------------
  always_comb begin
    unique case (state_q)
      PHY_IDLE: begin
        done = 1'b0;
        busy = 1'b0;
      end
      PHY_START_STOP, PHY_RELEASE: begin
        done = ss_done;
        busy = 1'b1;
      end
      PHY_BIT_XFER, PHY_DRIVE_SCL_LOW: begin
        done = tc_done;
        busy = 1'b1;
      end
      default: begin
        done = 1'b0;
        busy = 1'b0;
      end
    endcase
  end

  assign sda_sampled      = tc_sda_sampled;
  assign stretch_detected = tc_timing_violation;

  // -------------------------------------------------------------------------
  // Start/Stop condition generator
  // -------------------------------------------------------------------------
  i3c_start_stop_gen u_start_stop_gen (
    .clk              (clk),
    .rst_n            (rst_n),
    .cfg_tsu_start    (cfg_tsu_start),
    .cfg_thd_start    (cfg_thd_start),
    .cfg_tsu_stop     (cfg_tsu_stop),
    .cfg_bus_free_time(cfg_bus_free_time),
    .cmd_start        (ss_cmd_start),
    .cmd_repeat_start (ss_cmd_repeat_start),
    .cmd_stop         (ss_cmd_stop),
    .cmd_release      (ss_cmd_release),
    .done             (ss_done),
    .busy             (),
    .sda_o            (ss_sda_o),
    .sda_oe           (ss_sda_oe),
    .scl_o            (ss_scl_o),
    .scl_oe           (ss_scl_oe)
  );

  // -------------------------------------------------------------------------
  // Bit-level timing controller (handles bit_xfer, drive_scl_low)
  // -------------------------------------------------------------------------
  i3c_timing_control u_timing_control (
    .clk                (clk),
    .rst_n              (rst_n),
    .cfg_scl_high_time  (tc_scl_high),
    .cfg_scl_low_time   (tc_scl_low),
    .cfg_sda_hold_time  (cfg_sda_hold_time),
    .cfg_bus_free_time  (cfg_bus_free_time),
    .cfg_tsu_start      (cfg_tsu_start),
    .cfg_thd_start      (cfg_thd_start),
    .cfg_tsu_stop       (cfg_tsu_stop),
    .cfg_scl_od_high_time (cfg_scl_od_high_time),
    .cfg_scl_od_low_time  (cfg_scl_od_low_time),
            .bus_type           (bus_type),
    .cfg_scl_high_time_mixed (cfg_scl_high_time_mixed),
        .tcmd_start         (1'b0),  // START handled by start_stop_gen
    .tcmd_stop          (1'b0),  // STOP handled by start_stop_gen
    .tcmd_bit_xfer      (cmd_bit_xfer),
    .tcmd_bit_xfer_od   (cmd_bit_xfer_od),
    .tcmd_drive_scl_low (cmd_drive_scl_low),
    .tcmd_release       (1'b0),  // RELEASE handled by start_stop_gen
    .tx_bit             ({7'b0, sda_drive_val}),
    .sda_i              (sda_i),
    .sda_sampled        (tc_sda_sampled),
    .scl_out            (tc_scl_o),
    .sda_out            (tc_sda_o),
    .scl_oe             (tc_scl_oe),
    .sda_oe             (tc_sda_oe),
    .bit_done           (tc_done),
    .byte_done          (),
    .timing_violation   (tc_timing_violation)
  );

endmodule : i3c_phy_fsm

