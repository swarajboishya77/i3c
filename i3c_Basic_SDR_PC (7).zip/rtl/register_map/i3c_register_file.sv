// =============================================================================
// i3c_register_file.sv
// -----------------------------------------------------------------------------
// Register file for the I3C Basic SDR Controller.
// Implements the register map listed in i3c_pkg::R_* offsets.
// Controller-only mode: registers specific to Target / Secondary Controller
// modes (per PG439) are NOT implemented.
// This variant is INTERRUPT-FREE: software polls FIFO_LVL_STS and the
// Notes:
// - All registers are 32 bits wide, accessed via AXI4-Lite.
// - Read-only registers return their stored value; writes are ignored.
// - Read-write registers update on AXI write.
// - Timing registers default to values derived from C_AXI_CLK_FREQ /
// C_SCL_CLK_FREQ at configuration time (passed in as parameters).
// next word from the corresponding FIFO and asserts the pop enable for
// one cycle.
// Spec reference: MIPI I3C Basic register layout.
// =============================================================================

module i3c_register_file #(
  parameter int unsigned AXI_CLK_FREQ_HZ = 100_000_000,
  parameter int unsigned SCL_CLK_FREQ_HZ = 12_500_000,
  parameter logic [47:0] CTRL_PID        = 48'h0000_0000_0001,
  parameter logic [7:0]  CTRL_BCR        = 8'h00,
  parameter logic [7:0]  CTRL_DCR        = 8'h00
) (
  input  logic        clk,
  input  logic        rst_n,

  // AXI write channel
  input  logic        reg_wr,
  input  logic [31:0] reg_wr_addr,
  input  logic [31:0] reg_wr_data,
  input  logic [3:0]  reg_wr_strb,
  output logic        reg_wr_ack,

  // AXI read channel
  input  logic        reg_rd,
  input  logic [31:0] reg_rd_addr,
  output logic [31:0] reg_rd_data,
  output logic        reg_rd_ack,

  // --- Controller status ---
  input  logic        hw_bus_busy,
  input  logic        hw_controller_idle,
  input  logic [7:0]  hw_bytes_xferd,       // bytes transferred (for TRANSACTION_STATUS read)

  // --- FIFO levels (polled by software) ---
  input  logic [4:0]  hw_cmd_fifo_free,
  input  logic [4:0]  hw_resp_fifo_level,
  input  logic [5:0]  hw_wr_fifo_free,
  input  logic [5:0]  hw_rd_fifo_level,

  // --- FIFO pop interfaces (read side) ---
  // The 4 FIFOs (CMD, WR, RD, RESP) are accessed via dedicated ports on
  // i3c_controller_top, driven by a TCRI/HCI wrapper. This register file is
  // CONFIG-ONLY. FIFO level status inputs are kept for diagnostic readback
  // (FIFO_LVL_STATUS).

  // --- Configuration outputs to hw ---
  output logic [17:0] cfg_scl_high_time,
  output logic [17:0] cfg_scl_low_time,
  output logic [17:0] cfg_sda_hold_time,
  output logic [17:0] cfg_bus_free_time,
  output logic [17:0] cfg_tsu_start,
  output logic [17:0] cfg_thd_start,
  output logic [17:0] cfg_tsu_stop,
  output logic [17:0] cfg_scl_od_high_time,
  output logic [17:0] cfg_scl_od_low_time,



  // --- Error status inputs from controller ---
  input  logic        hw_err_timeout,
  input  logic        hw_err_nack_addr,
  input  logic        hw_err_nack_data,
  input  logic        hw_err_fifo_overflow,
  input  logic        hw_err_fifo_underflow,
  input  logic        hw_err_pec,           // PEC CRC-8 mismatch (from byte_serdes)

  // --- ACK_STATUS inputs (8-bit RO, separate ACK/NACK per phase) ---
  input  logic        hw_xfer_addr_ack,     // 1 = private transfer address ACKed
  input  logic        hw_xfer_addr_nack,    // 1 = private transfer address NACKed
  input  logic        hw_xfer_data_ack,     // 1 = private transfer data ACKed
  input  logic        hw_xfer_data_nack,    // 1 = private transfer data NACKed
  input  logic        hw_ccc_opcode_ack,    // 1 = CCC broadcast opcode ACKed
  input  logic        hw_ccc_opcode_nack,   // 1 = CCC broadcast opcode NACKed
  input  logic        hw_ccc_direct_ack,    // 1 = CCC direct address ACKed
  input  logic        hw_ccc_direct_nack,   // 1 = CCC direct address NACKed

  // --- Event status inputs (sticky in INTERRUPT_STATUS) ---
  input  logic        hw_xfer_done,         // command completed (resp_fifo_push pulse)
  input  logic        hw_ibi_received,      // IBI received (from ibi_handler)
  input  logic        hw_hj_received,       // Hot-Join received (from hj_handler)
  input  logic        hw_wake_event,        // wake event (from wake controller via CDC synchronizer)
  input  logic        hw_clk_stall,         // SCL stretch detected (from timing_control via phy_fsm)
  //Handoff/reclaim event inputs (from role_manager)
  input  logic        hw_handoff_done,      // handoff succeeded (we are now target)
  input  logic        hw_handoff_failed,    // handoff failed (NACK from target)
  input  logic        hw_reclaim_done,      // reclaim completed (we are active again)

  // --- FIFO level status inputs (live RO bits in INTERRUPT_STATUS) ---
  input  logic        hw_cmd_fifo_almost_full,  // CMD FIFO crossed almost-full threshold
  input  logic        hw_wr_fifo_almost_full,   // WR FIFO crossed almost-full threshold
  input  logic        hw_rd_fifo_almost_full,   // RD FIFO crossed almost-full threshold
  input  logic        hw_resp_fifo_not_empty,   // RESP FIFO has data available to read
  input  logic        hw_cmd_fifo_overflow,     // CMD FIFO overflow (sticky)
  input  logic        hw_cmd_fifo_underflow,    // CMD FIFO underflow (sticky)
  input  logic        hw_wr_fifo_overflow,      // WR FIFO overflow (sticky)
  input  logic        hw_wr_fifo_underflow,     // WR FIFO underflow (sticky)
  input  logic        hw_rd_fifo_overflow,      // RD FIFO overflow (sticky)
  input  logic        hw_rd_fifo_underflow,     // RD FIFO underflow (sticky)
  input  logic        hw_resp_fifo_overflow,    // RESP FIFO overflow (sticky)
  input  logic        hw_resp_fifo_underflow,   // RESP FIFO underflow (sticky)
  input  logic        hw_resp_fifo_almost_full, // RESP FIFO almost-full

  // --- Software reset / FIFO flush outputs to controller ---
  output logic        sw_reset,
  output logic        sw_flush_cmd,
  output logic        sw_flush_wr,
  output logic        sw_flush_rd,
  output logic        sw_flush_resp,

  // --- Clock gating control (CLK_GATE_CTRL at 0x7C, bits [3:0]) ---
  // [3] = FIFO gate (auto-gates clk_fifo when no active TX/RX)
  // [2] = target-engine gate (gates target engine clock)
  // [1] = controller-engine gate (gates serdes + CCC + DAA + IBI + HJ + group + DNF + phy_fsm)
  // [0] = global gate (gates ALL clocks to core logic, overrides sub-module gates)
  output logic [3:0]  clk_gate_ctrl,

  // --- Speed mode configuration (I3C_SPEED_MODE_CFG at 0x04) ---
  // [2:0] SPEED_MODE: 0=SDR, 1=HDR-DDR, 2=HDR-BT (SDR only in this IP).
  output logic [2:0]  speed_mode,

  // --- Transaction control (TRANSACTION_CTRL at 0x08) ---
  // [0] EN = global controller enable
  // [1] CONTROLLER_IBI_EN = global IBI accept gate (controller mode)
  output logic        ctrl_en,              // [0] master controller enable

  // --- IBI handler interface ---
  input  logic        ibi_fifo_push,
  input  logic [31:0] ibi_fifo_push_data,
  input  logic        ibi_irq,
  input  logic        ibi_active,
  input  logic        ibi_accepted,       // pulse: IBI address ACKed (accepted)
  input  logic        ibi_rejected,       // pulse: IBI address NACKed (rejected)

  // --- Hot-Join handler interface ---
  output logic        hj_auto_daa,
  input  logic        hj_detected,
  input  logic        hj_pending,
  output logic        hj_clear,

  // --- Group addressing interface ---
  output logic        group_enable,
  output logic [6:0]  group_count,
  output logic [31:0] group_table_0,
  output logic [31:0] group_table_1,
  output logic [31:0] group_table_2,
  output logic [31:0] group_table_3,
  output logic [31:0] group_table_4,
  output logic [31:0] group_table_5,
  output logic [31:0] group_table_6,
  output logic [31:0] group_table_7,

  // --- Digital Noise Filter interface ---
  output logic [3:0]  dnf_threshold,
  output logic        dnf_enable,

  // --- Wake detector interface (config from WAKE_CTRL register) ---
  output logic        wake_en,
  output logic        wake_start_en,
  output logic        wake_scl_en,

  // --- Target engine status inputs (for TARGET_STATUS register) ---
  input  logic        hw_target_addressed,
  input  logic        hw_target_busy,
  input  logic        hw_target_rx_done,
  input  logic        hw_target_tx_req,
  input  logic        hw_target_nack_sent,

  // --- Controller own dynamic address ---
  output logic [6:0]  ctrl_dyn_addr,      // Controller own DA (for target engine + private transfers)

  // --- Abort / Controller Role (RWSC triggers + config) ---
  output logic        abort_req,            // ABORT_CTRL[0] -- RWSC trigger
  output logic        resume_req,           // ABORT_CTRL[1] -- RWSC trigger

  // ---Bus configuration (BUS_CONFIG register) ---
  // Per MIPI I3C Basic §4.3.2.4 (Table 11):
  // 0=Pure Bus, 1=Mixed Fast Bus, 2=Mixed Slow Bus
  // Drives tDIG_H vs tDIG_H_MIXED selection in i3c_timing_control.
  output logic [1:0]  bus_type,             // BUS_CONFIG[1:0]

  // ---Reclaim config (RECLAIM_CONFIG register) ---
  output logic        reclaim_en,           // RECLAIM_CONFIG[0]
  output logic [15:0] reclaim_timeout_us,   // RECLAIM_CONFIG[15:0] (default 100)

  // ---Mixed-bus SCL high time (SCL_HIGH_TIME_MIXED_CFG register) ---
  // tDIG_H_MIXED per MIPI I3C Basic Table 50 (default 5 = ~50ns @ 100MHz)
  output logic [17:0] scl_high_time_mixed,

  // ---Role state readback (from i3c_role_manager) ---
  input  logic [2:0]  role_state_in,        // role_state_e from role_manager
  input  logic [1:0]  handoff_status_in,    // handoff result (0=idle,1=ok,2=fail_no_tgt,3=fail_not_capable)

  // --- Aggregated IRQ output ---
  // i3c_irq = OR(INTERRUPT_STATUS[18:0] & INTERRUPT_ENABLE_CTRL[18:0])
  // Live RO bits [9:6] are excluded from IRQ (they are status, not events).
  // DATA_LOST [18] = OR of FIFO_OVERFLOW [3] + DATA_NACK [1] (aggregated data loss).
  output logic        irq
);

  import i3c_pkg::*;

  // -------------------------------------------------------------------------
  //Spec-compliance timing guards
  // -------------------------------------------------------------------------
  // Per MIPI I3C Basic Tables 48, 49, 50.
  // This controller targets a MIXED BUS topology (I3C + legacy I2C devices
  // on the same SDA/SCL pair) — see BUS_CONFIG. Mixed-Bus timing minimums
  // are stricter than Pure-I3C-Bus because START/STOP conditions and any
  // Open-Drain phase must satisfy the legacy I2C device on the bus.
  // We use Fm+ (1 MHz I2C) as the conservative default — it is stricter
  // than Fm (400 kHz) and faster than Standard-mode (100 kHz). If a slower
  // I2C device is present, software must reprogram SCL_OD_*/TSU_*/THD_*
  // accordingly.
  // When TIMING_GUARD_EN=1 (default), out-of-spec writes are clamped to the
  // nearest spec-conformant value. The original (rejected) value is NOT stored.
  // A sticky bit in TIMING_VIOLATION_STATUS is set so software can detect
  // that clamping occurred.
  // Spec limits are in nanoseconds. We convert to PCLK cycles using:
  // cycles = ceil(ns_value * AXI_CLK_FREQ_HZ / 1e9)
  // For 100 MHz PCLK (10 ns period):
  // 24 ns -> 3 cycles (tHIGH_MIXED, tLOW, tHIGH min - push-pull)
  // 32 ns -> 4 cycles (tDIG_H, tDIG_L, tDIG_H_MIXED min)
  // 45 ns -> 4 cycles (tDIG_H_MIXED MAX -- floor, since it's a max)
  // 260 ns -> 26 cycles (Fm+ tSU_STA, tHD_STA, tSU_STO, tHIGH_OD)
  // 500 ns -> 50 cycles (Fm+ tLOW_OD, tBUF Mixed)
  // 1300 ns -> 130 cycles (Pure-Bus tBUF)
  // 600 ns -> 60 cycles (Fm 400 kHz: tSU_STA, tHD_STA, tSU_STO)
  // -------------------------------------------------------------------------
  localparam PCLK_NS_X1000 = 64'd1_000_000_000_000 / AXI_CLK_FREQ_HZ;

  // Spec limits computed at elaboration time (integer arithmetic).
  // ceil(a/b) = (a + b - 1) / b ; floor(a/b) = a / b
  // For 100 MHz PCLK (PCLK_NS_X1000 = 10000):
  // 24 ns -> ceil(24000/10000) = 3 cycles
  // 32 ns -> ceil(32000/10000) = 4 cycles
  // 45 ns -> floor(45000/10000) = 4 cycles (MAX, so floor)
  // 260 ns -> ceil(260000/10000) = 26 cycles
  // 500 ns -> ceil(500000/10000) = 50 cycles
  // 1300 ns -> ceil(1300000/10000) = 130 cycles
  // 600 ns -> ceil(600000/10000) = 60 cycles
  localparam logic [17:0] SPEC_TDIG_H_MIN       = (32_000     + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 4
  localparam logic [17:0] SPEC_TDIG_L_MIN       = (32_000     + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 4
  localparam logic [17:0] SPEC_TDIG_H_MIXED_MIN = (32_000     + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 4
  localparam logic [17:0] SPEC_TDIG_H_MIXED_MAX =  45_000     / PCLK_NS_X1000;                       // 4 (max, so floor)
  localparam logic [17:0] SPEC_TSU_STA_MIN      = (260_000    + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 26 (Fm+)
  localparam logic [17:0] SPEC_THD_STA_MIN      = (260_000    + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 26 (Fm+)
  localparam logic [17:0] SPEC_TSU_STO_MIN      = (260_000    + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 26 (Fm+)
  localparam logic [17:0] SPEC_TBUF_MIN         = (1_300_000  + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 130 (Pure)
  localparam logic [17:0] SPEC_TDIG_OD_H_MIN    = (260_000    + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 26 (Fm+ tHIGH_OD)
  localparam logic [17:0] SPEC_TDIG_OD_L_MIN    = (500_000    + PCLK_NS_X1000 - 1) / PCLK_NS_X1000;  // 50 (Fm+ tLOW_OD)

  // -------------------------------------------------------------------------
  // Computed reset values for timing registers.
  // MIXED BUS DEFAULTS per MIPI I3C Basic Tables 48, 49, 50.
  // All values below are the raw register contents AND the on-bus PCLK count.
  // The PHY FSM in i3c_timing_control.sv uses these as the timer target;
  // any extra pipeline latency in the FSM only ADDS to the on-bus time,
  // making timing MORE conservative (never less). So no "-2" compensation
  // is applied — the register value the software reads equals the
  // documentation value equals the MIPI spec minimum.
  // Push-Pull I3C timing (default SDR mode on Mixed Bus):
  // tHIGH/tLOW = 4 cycles = 40 ns (>= 24 ns min, within 32-45 ns Mixed)
  // tDIG_H_MIXED = 4 cycles = 40 ns (>= 32 ns min, <= 45 ns max)
  // tSDA_HOLD = 4 cycles = 40 ns (>= 3 ns min)
  // tBUF = 130 cyc = 1.3 us (>= 1.3 us Pure, >= 0.5 us Mixed)
  // Open-Drain timing (I2C fallback + START/STOP conditions):
  // tSU_STA/tHD_STA/tSU_STO = 26 cyc = 260 ns (>= 260 ns Fm+ min)
  // tHIGH_OD = 26 cyc = 260 ns (>= 260 ns Fm+ tHIGH)
  // tLOW_OD = 50 cyc = 500 ns (>= 500 ns Fm+ tLOW)
  // -------------------------------------------------------------------------
  localparam logic [17:0] RST_SCL_THIGH =
    // Push-pull SCL high: 4 cycles = 40 ns.
    // Meets MIPI tHIGH min 24 ns, within tDIG_H_MIXED 32-45 ns range.
    18'd4;
  localparam logic [17:0] RST_SCL_TLOW  = RST_SCL_THIGH;       // 4 = 40 ns (>= 24 ns min)
  localparam logic [17:0] RST_SDA_HOLD  =
    // SDA hold: 4 cycles = 40 ns (>= 3 ns tSU_PP min)
    18'd4;
  // BUS_FREE: 1.3 us minimum between STOP and START (Pure-Bus tBUF).
  // Also satisfies Mixed-Bus-with-Fm-I2C tBUF of 0.5 us.
  // 1.3 us = 1/(769_230 Hz); 769_230 derived from 1e6/1.3.
  localparam logic [17:0] RST_BUS_FREE  =
    (AXI_CLK_FREQ_HZ / 769_230);                              // 130 = 1.3 us
  // START/STOP setup/hold: always Open-Drain, must meet Fm+ 260 ns min.
  localparam logic [17:0] RST_TSU_START = SPEC_TSU_STA_MIN;   // 26 = 260 ns (Fm+)
  localparam logic [17:0] RST_THD_START = SPEC_THD_STA_MIN;   // 26 = 260 ns (Fm+)
  localparam logic [17:0] RST_TSU_STOP  = SPEC_TSU_STO_MIN;   // 26 = 260 ns (Fm+)
  // Open-Drain SCL high/low for I2C fallback: Fm+ minimums.
  localparam logic [17:0] RST_SCL_OD_HIGH = SPEC_TDIG_OD_H_MIN; // 26 = 260 ns (Fm+ tHIGH_OD)
  localparam logic [17:0] RST_SCL_OD_LOW  = SPEC_TDIG_OD_L_MIN; // 50 = 500 ns (Fm+ tLOW_OD)

  // -------------------------------------------------------------------------
  // Register storage
  // -------------------------------------------------------------------------
  logic [17:0] scl_high_time_q;
  logic [17:0] scl_low_time_q;
  logic [17:0] sda_hold_time_q;
  logic [17:0] bus_free_time_q;
  logic [17:0] tsu_start_q;
  logic [17:0] thd_start_q;
  logic [17:0] tsu_stop_q;
  logic [17:0] scl_od_high_q;
  logic [17:0] scl_od_low_q;


  logic [7:0]  control_q;
  logic [2:0]  speed_mode_q;     // I3C_SPEED_MODE_CFG[2:0] at 0x04 (0=SDR)

  // PID / BCR / DCR are read-only from AXI; come from compile-time params
  logic [47:0] pid_q;
  logic [7:0]  bcr_q;
  logic [7:0]  dcr_q;

  // --- RWSC registers (self-clearing) ---
  logic        sw_reset_q;       // SW reset -- auto-clears after 2 cycles
  logic [3:0]  fifo_flush_q;     // FIFO flush -- auto-clears after 2 cycles
  logic [1:0]  sw_reset_cnt;     // 2-cycle countdown for auto-clear
  logic [1:0]  flush_cnt;        // 2-cycle countdown for auto-clear
  logic [1:0]  abort_cnt;        // 2-cycle countdown for abort auto-clear
  logic [1:0]  resume_cnt;       // 2-cycle countdown for resume auto-clear

  // --- IBI registers ---

  logic        ibi_detected_q;   // sticky W1C
  logic        ibi_irq_status_q; // sticky W1C
  logic        ibi_accepted_q;   // sticky W1C: IBI address ACKed
  logic        ibi_rejected_q;   // sticky W1C: IBI address NACKed

  // --- Hot-Join registers ---
  logic        hj_detected_q;    // sticky W1C (from handler)

  // --- Group addressing registers ---
  logic        group_enable_q;
  logic [6:0]  group_count_q;
  logic [31:0] group_table_q [0:7];
  logic [2:0]  group_rd_idx_q;    // read index for GROUP_ADDR_TBL_CFG (bits [10:8] of GROUP_ADDR_CFG)

  // --- DNF register ---
  logic [3:0]  dnf_threshold_q;
  logic        dnf_enable_q;

  //int_enable_q is 19-bit [18:0].
  // [18] DATA_LOST_EN -- enable IRQ from aggregated DATA_LOST bit.
  // [17:0] legacy event enables (unchanged).
  logic [18:0] int_enable_q;        // INTERRUPT_ENABLE_CTRL (0x10) -- 19-bit enable mask
  logic        err_data_lost_q;     // INTERRUPT_STATUS [18] -- DATA_LOST (OR of FIFO_OVF + DATA_NACK)
  logic        sw_reset_status_q;   // SW_RESET_STATUS (0x54) -- W1C, survives all resets
  logic        abort_req_q;         // ABORT_CTRL (0x5C) bit 0 -- RWSC abort trigger
  logic        resume_req_q;        // ABORT_CTRL (0x5C) bit 1 -- RWSC resume trigger
  logic        wake_src_start_q;    // WAKE_STATUS (0x94) bit 1 -- W1C
  logic        wake_src_scl_q;      // WAKE_STATUS (0x94) bit 0 -- W1C
  logic [3:0]  clk_gate_q;          // CLK_GATE_CTRL (0x98) bits [3:0]
  logic [1:0]  power_ctrl_q;        // POWER_CTRL (0x80) bits [1:0]

  // --- Wake detector config (WAKE_CTRL at 0x90) ---
  // bit[0] WAKE_EN -- global wake enable
  // bit[1] WAKE_START_EN -- detect START as wake source
  // bit[2] WAKE_SCL_EN -- detect SCL edges as wake source
  logic        wake_en_q;
  logic        wake_start_en_q;
  logic        wake_scl_en_q;

  // --- Target engine config (TARGET_CTRL at 0xA0) ---
  // bit[0] TARGET_EN -- enable Target mode
  // bits[7:1] TARGET_DYN_ADDR -- 7-bit dynamic address
  // bit[8] TARGET_IBI_EN -- allow Target to raise IBI
  logic [6:0]  ctrl_dyn_addr_q;     // Controller own DA (self-assigned via AXI)

  // ---Bus configuration (BUS_CONFIG at 0x100) ---
  // bits[1:0] BUS_TYPE -- 0=Pure, 1=Mixed Fast, 2=Mixed Slow
  // bits[31:2] RESERVED
  logic [1:0]  bus_type_q;

  // ---Reclaim configuration (RECLAIM_CONFIG at 0x10C) ---
  // bit[0] RECLAIM_EN -- enable reclaim monitor after handoff
  // bits[15:0] RECLAIM_TIMEOUT_US -- bus idle timeout (default 100 µs)
  logic        reclaim_en_q;
  logic [15:0] reclaim_timeout_us_q;

  // ---Mixed-bus SCL high time (SCL_HIGH_TIME_MIXED_CFG at 0x110) ---
  logic [17:0] scl_high_time_mixed_q;

  // ---Timing guard control (TIMING_GUARD_CTRL at 0x114) ---
  // [0] TIMING_GUARD_EN -- 1=clamp out-of-spec writes (default), 0=bypass
  logic        timing_guard_en_q;

  // ---Timing violation status (TIMING_VIOLATION_STATUS at 0x118) ---
  // W1C sticky bits -- set when a timing register write was clamped
  // [0] SCL_HIGH_TIME [5] TSU_STOP
  // [1] SCL_LOW_TIME [6] SCL_OD_HIGH_TIME
  // [2] SCL_HIGH_TIME_MIXED [7] SCL_OD_LOW_TIME
  // [3] TSU_START [8] BUS_FREE_TIME
  // [4] THD_START [9] (reserved)
  logic [9:0]  timing_violation_q;

  // Extension registers at 0xB0-0xC8 (normal address range, no extended decode)
  logic [9:0]  timing_violation_clr;

  // --- W1C register (sticky error status) ---
  logic        err_timeout_q;
  logic        err_nack_addr_q;
  logic        err_nack_data_q;
  //ACK_STATUS — 8-bit RO, latched on transaction completion
  logic [7:0]  ack_status_q;       // [7]=CCC_DIRECT_NACK [6]=CCC_DIRECT_ACK
                                    // [5]=CCC_OPCODE_NACK [4]=CCC_OPCODE_ACK
                                    // [3]=XFER_DATA_NACK [2]=XFER_DATA_ACK
                                    // [1]=XFER_ADDR_NACK [0]=XFER_ADDR_ACK
  logic        err_fifo_ovf_q;
  logic        err_fifo_unf_q;
  logic        err_pec_q;          // bit 5 -- PEC CRC-8 mismatch

  // --- W1C register (sticky event status) -- INTERRUPT_STATUS bits [14:10] ---
  logic        status_xfer_done_q;   // bit 10
  logic        status_ibi_q;         // bit 11
  //new sticky event bits [17:15]
  logic        status_handoff_done_q;   // bit 15 -- handoff succeeded
  logic        status_handoff_failed_q; // bit 16 -- handoff failed
  logic        status_reclaim_done_q;   // bit 17 -- reclaim completed
  logic        status_hj_q;          // bit 12
  logic        status_clkstall_q;    // bit 13
  logic        status_wake_q;        // bit 14

  // -------------------------------------------------------------------------
  // Address decode (low byte)
  // -------------------------------------------------------------------------
  logic [7:0] addr_lo;
  logic [7:0] rd_addr_lo;
  assign addr_lo    = reg_wr_addr[7:0];
  assign rd_addr_lo = reg_rd_addr[7:0];

  // -------------------------------------------------------------------------
  // Write decode
  // -------------------------------------------------------------------------
  // reg_wr_ack is asserted for any recognized register offset.
  // Writes to RO (read-only) registers return OKAY (ack=1) but the data is
  // silently ignored by the always_ff write logic. This follows the AXI spec:
  // writes to unmapped addresses cause SLVERR; writes to mapped RO registers
  // return OKAY with no side effect.
  always_comb begin
    reg_wr_ack = 1'b1;
    case (addr_lo)
      // Writable registers (R/W, RWSC, W1C)
      SW_RESET_CTRL_ADDR[7:0], FIFO_FLUSH_CTRL_ADDR[7:0],
      INTERRUPT_STATUS_ADDR[7:0], INTERRUPT_ENABLE_CTRL_ADDR[7:0],
      SW_RESET_STATUS_ADDR[7:0], ABORT_CTRL_ADDR[7:0],
      WAKE_STATUS_ADDR[7:0], CLK_GATE_CTRL_ADDR[7:0], POWER_CTRL_ADDR[7:0],
      IBI_STATUS_ADDR[7:0],
      HJ_STATUS_ADDR[7:0],
      GROUP_ADDR_CFG_ADDR[7:0], GROUP_ADDR_TBL_CFG_ADDR[7:0],
      DNF_CTRL_ADDR[7:0],
      SCL_HIGH_TIME_CFG_ADDR[7:0], SCL_LOW_TIME_CFG_ADDR[7:0],
      SDA_HOLD_TIME_CFG_ADDR[7:0], BUS_FREE_TIME_CFG_ADDR[7:0],
      TSU_START_CFG_ADDR[7:0], THD_START_CFG_ADDR[7:0], TSU_STOP_CFG_ADDR[7:0],
      SCL_OD_HIGH_TIME_CFG_ADDR[7:0], SCL_OD_LOW_TIME_CFG_ADDR[7:0],
      WAKE_CTRL_ADDR[7:0], CTRL_DYN_ADDR_CFG_ADDR[7:0],
      I3C_SPEED_MODE_CFG_ADDR[7:0], TRANSACTION_CTRL_ADDR[7:0],
      BUS_CONFIG_ADDR[7:0], RECLAIM_CONFIG_ADDR[7:0],
      SCL_HIGH_TIME_MIXED_CFG_ADDR[7:0], TIMING_GUARD_CTRL_ADDR[7:0],
      TIMING_VIOLATION_STATUS_ADDR[7:0]:
        reg_wr_ack = 1'b1;
      // Read-only registers — ack the write (OKAY) but data is ignored
      VERSION_ADDR[7:0],
      TRANSACTION_STATUS_ADDR[7:0],
      TX_FIFO_STATUS_ADDR[7:0],
      RX_FIFO_STATUS_ADDR[7:0],
      ACK_STATUS_ADDR[7:0],
      TARGET_STATUS_ADDR[7:0],
      ROLE_STATE_ADDR[7:0],
      HANDOFF_STATUS_ADDR[7:0],
      PID0_STATUS_ADDR[7:0],
      PID1_BCR_DCR_STATUS_ADDR[7:0],
      IBI_QUEUE_STATUS_ADDR[7:0],
      FIFO_LVL_STATUS_ADDR[7:0],
      FIFO_LVL_STATUS_1_ADDR[7:0]:
        reg_wr_ack = 1'b1;  // RO register: write accepted but ignored
      default: reg_wr_ack = 1'b0;  // unmapped address → SLVERR
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scl_high_time_q    <= RST_SCL_THIGH;
      scl_low_time_q     <= RST_SCL_TLOW;
      sda_hold_time_q    <= RST_SDA_HOLD;
      bus_free_time_q    <= RST_BUS_FREE;
      tsu_start_q        <= RST_TSU_START;
      thd_start_q        <= RST_THD_START;
      tsu_stop_q         <= RST_TSU_STOP;
      scl_od_high_q      <= RST_SCL_OD_HIGH;
      scl_od_low_q       <= RST_SCL_OD_LOW;


      control_q          <= 8'h00;
      speed_mode_q      <= 3'h0;   // SDR

      pid_q              <= CTRL_PID;
      bcr_q              <= CTRL_BCR;
      dcr_q              <= CTRL_DCR;

      // RWSC registers reset to 0
      sw_reset_q          <= 1'b0;
      fifo_flush_q        <= 4'h0;
      sw_reset_cnt        <= 2'd0;
      flush_cnt           <= 2'd0;
      abort_cnt           <= 2'd0;
      resume_cnt          <= 2'd0;

      // W1C error status reset to 0
      err_timeout_q       <= 1'b0;
      err_nack_addr_q     <= 1'b0;
      err_nack_data_q     <= 1'b0;
      ack_status_q        <= 8'h0;       //ACK_STATUS reset = no transaction
      err_fifo_ovf_q      <= 1'b0;
      err_fifo_unf_q      <= 1'b0;
      err_data_lost_q     <= 1'b0;       //DATA_LOST reset
      err_pec_q           <= 1'b0;

      // W1C event status reset to 0
      status_xfer_done_q  <= 1'b0;
      status_ibi_q        <= 1'b0;
      //reset new event bits
      status_handoff_done_q   <= 1'b0;
      status_handoff_failed_q <= 1'b0;
      status_reclaim_done_q   <= 1'b0;
      status_hj_q         <= 1'b0;
      status_clkstall_q   <= 1'b0;
      status_wake_q       <= 1'b0;

      // IBI registers


      ibi_detected_q    <= 1'b0;
      ibi_irq_status_q  <= 1'b0;
      ibi_accepted_q    <= 1'b0;
      ibi_rejected_q    <= 1'b0;

      // Hot-Join registers
      hj_detected_q     <= 1'b0;

      // Group registers
      group_enable_q    <= 1'b0;
      group_count_q     <= 7'h0;
      for (int i = 0; i < 8; i++) group_table_q[i] <= 32'h0;
      group_rd_idx_q    <= 3'h0;

      // DNF register
      dnf_threshold_q   <= 4'h0;
      dnf_enable_q      <= 1'b0;

      int_enable_q         <= 19'h0;
      sw_reset_status_q    <= 1'b0;      // Cleared at power-on, survives soft resets
      abort_req_q          <= 1'b0;
      resume_req_q         <= 1'b0;
      wake_src_start_q     <= 1'b0;
      wake_src_scl_q       <= 1'b0;
      clk_gate_q           <= 4'h0;
      power_ctrl_q         <= 2'h0;

      // Wake detector config -- disabled at reset (host must enable)
      wake_en_q         <= 1'b0;
      wake_start_en_q   <= 1'b0;
      wake_scl_en_q     <= 1'b0;

      // Target engine config -- disabled at reset (controller-only by default)
      ctrl_dyn_addr_q   <= 7'h00;

      //Bus config -- default to MIXED FAST BUS.
      //This controller implements an I2C fallback FSM (i2c_controller_fsm.sv)
      //and Mixed-Bus Fm+ timing defaults (TSU_START=260ns, SCL_OD_HIGH=260ns,
      //SCL_OD_LOW=500ns, etc.). Setting BUS_TYPE=MIXED_FAST at reset makes the
      //topology match the timing defaults, so the IP is ready to talk to I3C +
      //Fm+ I2C devices out of the box without software reprogramming BUS_CONFIG.
      //Per MIPI I3C Basic §4.3.2.4 Table 11:
      // 0=Pure (I3C only, tDIG_H=32ns min)
      // 1=Mixed Fast (I3C + I2C w/ 50ns spike filter, tDIG_H_MIXED 32-45ns)
      // 2=Mixed Slow (I3C + I2C w/o spike filter, must clock at I2C speed)
      //Software can write 0 to switch to Pure Bus if NO I2C devices are present.
      bus_type_q          <= 2'd1;  // BUS_TYPE_MIXED_FAST

      //Reclaim config -- enabled with 100 µs default timeout
      reclaim_en_q        <= 1'b1;
      reclaim_timeout_us_q<= 16'd100;

      //Mixed-bus SCL high time -- 4 cycles = 40 ns.
      //Meets MIPI Table 50 tDIG_H_MIXED 32-45 ns range (max 45 ns to avoid
      //confusing I2C devices with 50 ns spike filters).
      scl_high_time_mixed_q <= 18'd4;

      //Timing guard -- enabled by default (spec compliance)
      timing_guard_en_q     <= 1'b1;
      // NOTE: timing_violation_q is reset in its own always_ff block below (W1C sticky)
    end else begin
      // ---- RWSC auto-clear logic ----
      if (sw_reset_q) begin
        if (sw_reset_cnt >= 2'd1) begin
          sw_reset_q   <= 1'b0;
          sw_reset_cnt <= 2'd0;
        end else begin
          sw_reset_cnt <= sw_reset_cnt + 1'b1;
        end
      end

      if (fifo_flush_q != 4'h0) begin
        if (flush_cnt >= 2'd1) begin
          fifo_flush_q <= 4'h0;
          flush_cnt    <= 2'd0;
        end else begin
          flush_cnt    <= flush_cnt + 1'b1;
        end
      end

      // Self-clearing: ABORT_REQ
      if (abort_cnt >= 2'd1) begin
        abort_req_q  <= 1'b0;
        abort_cnt    <= 2'd0;
      end else if (abort_req_q) begin
        abort_cnt <= abort_cnt + 1'b1;
      end

      // Self-clearing: RESUME_REQ
      if (resume_cnt >= 2'd1) begin
        resume_req_q <= 1'b0;
        resume_cnt   <= 2'd0;
      end else if (resume_req_q) begin
        resume_cnt <= resume_cnt + 1'b1;
      end


      // ---- W1C error status: set by hardware, cleared by software write-1 ----
      if (sw_reset_q) sw_reset_status_q <= 1'b1;  // SW_RESET_STATUS set on reset pulse
      if (hw_err_timeout)    err_timeout_q    <= 1'b1;
      if (hw_err_nack_addr)  err_nack_addr_q  <= 1'b1;
      if (hw_err_nack_data)  err_nack_data_q  <= 1'b1;

      //ACK_STATUS — latch on transaction completion, clear on next command start
      if (hw_xfer_done) begin
        ack_status_q[0] <= hw_xfer_addr_ack;    // XFER_ADDR_ACK
        ack_status_q[1] <= hw_xfer_addr_nack;   // XFER_ADDR_NACK
        ack_status_q[2] <= hw_xfer_data_ack;    // XFER_DATA_ACK
        ack_status_q[3] <= hw_xfer_data_nack;   // XFER_DATA_NACK
        ack_status_q[4] <= hw_ccc_opcode_ack;   // CCC_OPCODE_ACK
        ack_status_q[5] <= hw_ccc_opcode_nack;  // CCC_OPCODE_NACK
        ack_status_q[6] <= hw_ccc_direct_ack;   // CCC_DIRECT_ACK
        ack_status_q[7] <= hw_ccc_direct_nack;  // CCC_DIRECT_NACK
      end
      if (hw_err_fifo_overflow)  err_fifo_ovf_q  <= 1'b1;
      if (hw_err_fifo_underflow) err_fifo_unf_q  <= 1'b1;
      //DATA_LOST [18] = OR of FIFO_OVERFLOW [3] + DATA_NACK [1]
      // Set when any FIFO overflows OR target NACKs a data byte (data is lost in both cases).
      if (hw_err_fifo_overflow | hw_err_nack_data)
        err_data_lost_q <= 1'b1;
      if (hw_err_pec)        err_pec_q        <= 1'b1;

      // ---- W1C event status: set by hardware, cleared by software write-1 ----
      if (hw_xfer_done)      status_xfer_done_q <= 1'b1;
      if (hw_ibi_received)   status_ibi_q       <= 1'b1;
      //set handoff/reclaim event bits
      if (hw_handoff_done)   status_handoff_done_q   <= 1'b1;
      if (hw_handoff_failed) status_handoff_failed_q <= 1'b1;
      if (hw_reclaim_done)   status_reclaim_done_q   <= 1'b1;
      if (hw_hj_received)    status_hj_q        <= 1'b1;
      if (hw_clk_stall)      status_clkstall_q  <= 1'b1;
      if (hw_wake_event)     status_wake_q      <= 1'b1;

      // ---- IBI/HJ sticky flags: set by hardware inputs ----
      if (ibi_irq)           ibi_irq_status_q   <= 1'b1;
      if (hj_detected)       hj_detected_q      <= 1'b1;
      if (ibi_fifo_push)     ibi_detected_q     <= 1'b1;
      if (ibi_accepted)      ibi_accepted_q     <= 1'b1;
      if (ibi_rejected)      ibi_rejected_q     <= 1'b1;

      // ---- AXI write ----
      if (reg_wr) begin
        case (addr_lo)
          SW_RESET_CTRL_ADDR[7:0]: begin
            if (reg_wr_data[0]) sw_reset_q <= 1'b1;
          end
          FIFO_FLUSH_CTRL_ADDR[7:0]: begin
            fifo_flush_q <= reg_wr_data[3:0]; // [0]=CMD, [1]=WR, [2]=RD, [3]=RESP
          end
          INTERRUPT_STATUS_ADDR[7:0]: begin
            // W1C: writing 1 clears the corresponding sticky bit.
            // HARDWARE-SET PRIORITY: if hardware sets a bit in the same cycle
            // as a software clear, the hardware set wins (event is not lost).
            // This is achieved by gating the clear with !hw_set.
            // Bitfield per XLSX:
            // [18]=DATA_LOST, [17]=RECLAIM_DONE, [16]=HANDOFF_FAILED, [15]=HANDOFF_DONE,
            // [14]=WAKE_EVENT, [13]=PEC_ERROR, [12]=CLK_STALL, [11]=HJ_RECEIVED,
            // [10]=IBI_RECEIVED, [9]=RESP_FIFO_NOT_EMPTY, [8]=RD_FIFO_ALMOST_FULL,
            // [7]=WR_FIFO_ALMOST_FULL, [6]=CMD_FIFO_ALMOST_FULL, [5]=FIFO_UNDERFLOW,
            // [4]=FIFO_OVERFLOW, [3]=TIMEOUT, [2]=DATA_NACK, [1]=ADDR_NACK, [0]=TRANSFER_DONE
            // Bits [9:6] are live RO level indicators (writes ignored).
            if (reg_wr_data[0]  && !hw_xfer_done)                       status_xfer_done_q  <= 1'b0;
            if (reg_wr_data[1]  && !hw_err_nack_addr)                   err_nack_addr_q     <= 1'b0;
            if (reg_wr_data[2]  && !hw_err_nack_data)                   err_nack_data_q     <= 1'b0;
            if (reg_wr_data[3]  && !hw_err_timeout)                     err_timeout_q       <= 1'b0;
            if (reg_wr_data[4]  && !hw_err_fifo_overflow)               err_fifo_ovf_q      <= 1'b0;
            if (reg_wr_data[5]  && !hw_err_fifo_underflow)              err_fifo_unf_q      <= 1'b0;
            //DATA_LOST [18] W1C -- also clears FIFO_OVERFLOW [4] and DATA_NACK [2]
            if (reg_wr_data[18] && !(hw_err_fifo_overflow | hw_err_nack_data)) begin
              err_data_lost_q  <= 1'b0;
              err_fifo_ovf_q   <= 1'b0;
              err_nack_data_q  <= 1'b0;
            end
            if (reg_wr_data[10] && !hw_ibi_received)                    status_ibi_q        <= 1'b0;
            if (reg_wr_data[11] && !hw_hj_received)                     status_hj_q         <= 1'b0;
            if (reg_wr_data[12] && !hw_clk_stall)                       status_clkstall_q   <= 1'b0;
            if (reg_wr_data[13] && !hw_err_pec)                         err_pec_q           <= 1'b0;
            if (reg_wr_data[14] && !hw_wake_event)                      status_wake_q       <= 1'b0;
            //W1C clear for handoff/reclaim event bits
            if (reg_wr_data[15] && !hw_handoff_done)                    status_handoff_done_q   <= 1'b0;
            if (reg_wr_data[16] && !hw_handoff_failed)                  status_handoff_failed_q <= 1'b0;
            if (reg_wr_data[17] && !hw_reclaim_done)                    status_reclaim_done_q   <= 1'b0;
          end
                    IBI_STATUS_ADDR[7:0]: begin
                      if (reg_wr_data[0]) ibi_detected_q   <= 1'b0;
                      if (reg_wr_data[1]) ibi_irq_status_q <= 1'b0;
                      if (reg_wr_data[3]) ibi_accepted_q   <= 1'b0;
                      if (reg_wr_data[4]) ibi_rejected_q   <= 1'b0;
                    end
                    GROUP_ADDR_CFG_ADDR[7:0]: begin
                      group_enable_q <= reg_wr_data[0];
                      group_count_q  <= reg_wr_data[7:1];
                    end
                    GROUP_ADDR_TBL_CFG_ADDR[7:0]: begin
                      group_table_q[reg_wr_data[25:23]] <= reg_wr_data[31:0];
                      group_rd_idx_q <= reg_wr_data[25:23];  // latch write index as read index
                    end
                    DNF_CTRL_ADDR[7:0]: begin
                      dnf_threshold_q <= reg_wr_data[3:1];
                      dnf_enable_q    <= reg_wr_data[0];
                    end
                    WAKE_CTRL_ADDR[7:0]: begin
                      wake_en_q       <= reg_wr_data[0];
                      wake_start_en_q <= reg_wr_data[1];
                      wake_scl_en_q   <= reg_wr_data[2];
                    end
                    CTRL_DYN_ADDR_CFG_ADDR[7:0]: begin
                      ctrl_dyn_addr_q   <= reg_wr_data[6:0];
                    end
          SCL_HIGH_TIME_CFG_ADDR[7:0]:
            scl_high_time_q   <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TDIG_H_MIN) ? SPEC_TDIG_H_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          SCL_LOW_TIME_CFG_ADDR[7:0]:
            scl_low_time_q    <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TDIG_L_MIN) ? SPEC_TDIG_L_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          SDA_HOLD_TIME_CFG_ADDR[7:0]:
            sda_hold_time_q   <= reg_wr_data[17:0];  // no spec min (0 ns)
          BUS_FREE_TIME_CFG_ADDR[7:0]:
            bus_free_time_q   <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TBUF_MIN) ? SPEC_TBUF_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          TSU_START_CFG_ADDR[7:0]:
            tsu_start_q       <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TSU_STA_MIN) ? SPEC_TSU_STA_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          THD_START_CFG_ADDR[7:0]:
            thd_start_q       <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_THD_STA_MIN) ? SPEC_THD_STA_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          TSU_STOP_CFG_ADDR[7:0]:
            tsu_stop_q        <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TSU_STO_MIN) ? SPEC_TSU_STO_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          SCL_OD_HIGH_TIME_CFG_ADDR[7:0]:
            scl_od_high_q     <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TDIG_OD_H_MIN) ? SPEC_TDIG_OD_H_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];
          SCL_OD_LOW_TIME_CFG_ADDR[7:0]:
            scl_od_low_q      <= timing_guard_en_q ?
                                  ((reg_wr_data[17:0] < SPEC_TDIG_OD_L_MIN) ? SPEC_TDIG_OD_L_MIN : reg_wr_data[17:0])
                                  : reg_wr_data[17:0];

          //Set violation sticky bits when timing writes are clamped
          // (checked in same cycle as the write above)
          // Note: these are OR'd into the existing violation_q via the
          // combinational logic below -- see timing_violation_set block.
          I3C_SPEED_MODE_CFG_ADDR[7:0]:
            speed_mode_q   <= reg_wr_data[2:0];
          TRANSACTION_CTRL_ADDR[7:0]:
            control_q        <= reg_wr_data[7:0];
          // These addresses are reserved — writes ignored.
          INTERRUPT_ENABLE_CTRL_ADDR[7:0]: int_enable_q <= reg_wr_data[18:0];
          SW_RESET_STATUS_ADDR[7:0]: begin
            if (reg_wr_data[0]) sw_reset_status_q <= 1'b0; // W1C
          end
          ABORT_CTRL_ADDR[7:0]: begin
            if (reg_wr_data[0]) abort_req_q  <= 1'b1; // RWSC trigger
            if (reg_wr_data[1]) resume_req_q <= 1'b1; // RWSC trigger
          end


          WAKE_STATUS_ADDR[7:0]: begin
            if (reg_wr_data[0]) wake_src_scl_q   <= 1'b0; // W1C
            if (reg_wr_data[1]) wake_src_start_q <= 1'b0; // W1C
          end
          CLK_GATE_CTRL_ADDR[7:0]: clk_gate_q <= reg_wr_data[3:0];
          POWER_CTRL_ADDR[7:0]:    power_ctrl_q <= reg_wr_data[1:0];
          //Extended registers (0xB0-0xC8)
          BUS_CONFIG_ADDR[7:0]: bus_type_q <= reg_wr_data[1:0];
          RECLAIM_CONFIG_ADDR[7:0]: begin
            reclaim_en_q         <= reg_wr_data[0];
            reclaim_timeout_us_q <= reg_wr_data[16:1];  // [16:1] = timeout, [0] = enable
          end
          SCL_HIGH_TIME_MIXED_CFG_ADDR[7:0]: begin
            if (timing_guard_en_q) begin
              if (reg_wr_data[17:0] < SPEC_TDIG_H_MIXED_MIN)
                scl_high_time_mixed_q <= SPEC_TDIG_H_MIXED_MIN;
              else if (reg_wr_data[17:0] > SPEC_TDIG_H_MIXED_MAX)
                scl_high_time_mixed_q <= SPEC_TDIG_H_MIXED_MAX;
              else
                scl_high_time_mixed_q <= reg_wr_data[17:0];
            end else begin
              scl_high_time_mixed_q <= reg_wr_data[17:0];
            end
          end
          TIMING_GUARD_CTRL_ADDR[7:0]: timing_guard_en_q <= reg_wr_data[0];
          default: ; // intentionally empty: RO/W1C regs ignore writes; new RW regs must add explicit case arm above
        endcase
      end
    end
  end

  // =========================================================================
  //Timing violation detection (single combinational block)
  // =========================================================================
  logic [9:0] timing_violation_set;
  always_comb begin
    timing_violation_set = 10'h0;
    timing_violation_clr = 10'h0;

    // W1C clear for TIMING_VIOLATION_STATUS
    if (reg_wr && (addr_lo == TIMING_VIOLATION_STATUS_ADDR[7:0])) begin
      timing_violation_clr = reg_wr_data[9:0];
    end

    // Violation detection
    if (reg_wr && timing_guard_en_q) begin
      // Legacy space (0x00-0xFF) timing registers
      case (addr_lo)
        SCL_HIGH_TIME_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TDIG_H_MIN)
            timing_violation_set[0] = 1'b1;
        SCL_LOW_TIME_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TDIG_L_MIN)
            timing_violation_set[1] = 1'b1;
        TSU_START_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TSU_STA_MIN)
            timing_violation_set[3] = 1'b1;
        THD_START_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_THD_STA_MIN)
            timing_violation_set[4] = 1'b1;
        TSU_STOP_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TSU_STO_MIN)
            timing_violation_set[5] = 1'b1;
        SCL_OD_HIGH_TIME_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TDIG_OD_H_MIN)
            timing_violation_set[6] = 1'b1;
        SCL_OD_LOW_TIME_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TDIG_OD_L_MIN)
            timing_violation_set[7] = 1'b1;
        BUS_FREE_TIME_CFG_ADDR[7:0]:
          if (reg_wr_data[17:0] < SPEC_TBUF_MIN)
            timing_violation_set[8] = 1'b1;
        default: ; // registers with no spec min (e.g., SDA_HOLD_TIME_CFG) — no violation check
      endcase
      // Extended space: SCL_HIGH_TIME_MIXED_CFG (0x110)
      if (addr_lo == SCL_HIGH_TIME_MIXED_CFG_ADDR[7:0]) begin
        if ((reg_wr_data[17:0] < SPEC_TDIG_H_MIXED_MIN) ||
            (reg_wr_data[17:0] > SPEC_TDIG_H_MIXED_MAX))
          timing_violation_set[2] = 1'b1;
      end
    end
  end

  // Sticky set for timing violations (W1C via TIMING_VIOLATION_STATUS)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      timing_violation_q <= 10'h0;
    end else begin
      // W1C clear + set (unrolled for iverilog compatibility)
      if (timing_violation_clr[0])      timing_violation_q[0]  <= 1'b0;
      else if (timing_violation_set[0]) timing_violation_q[0]  <= 1'b1;
      if (timing_violation_clr[1])      timing_violation_q[1]  <= 1'b0;
      else if (timing_violation_set[1]) timing_violation_q[1]  <= 1'b1;
      if (timing_violation_clr[2])      timing_violation_q[2]  <= 1'b0;
      else if (timing_violation_set[2]) timing_violation_q[2]  <= 1'b1;
      if (timing_violation_clr[3])      timing_violation_q[3]  <= 1'b0;
      else if (timing_violation_set[3]) timing_violation_q[3]  <= 1'b1;
      if (timing_violation_clr[4])      timing_violation_q[4]  <= 1'b0;
      else if (timing_violation_set[4]) timing_violation_q[4]  <= 1'b1;
      if (timing_violation_clr[5])      timing_violation_q[5]  <= 1'b0;
      else if (timing_violation_set[5]) timing_violation_q[5]  <= 1'b1;
      if (timing_violation_clr[6])      timing_violation_q[6]  <= 1'b0;
      else if (timing_violation_set[6]) timing_violation_q[6]  <= 1'b1;
      if (timing_violation_clr[7])      timing_violation_q[7]  <= 1'b0;
      else if (timing_violation_set[7]) timing_violation_q[7]  <= 1'b1;
      if (timing_violation_clr[8])      timing_violation_q[8]  <= 1'b0;
      else if (timing_violation_set[8]) timing_violation_q[8]  <= 1'b1;
      if (timing_violation_clr[9])      timing_violation_q[9]  <= 1'b0;
      else if (timing_violation_set[9]) timing_violation_q[9]  <= 1'b1;
    end
  end

  // -------------------------------------------------------------------------
  // FIFO pop strobes: asserted for one cycle when reg_rd targets a FIFO.
  // -------------------------------------------------------------------------
  // FIFO access is via dedicated ports on i3c_controller_top (TCRI/HCI wrapper).

  // -------------------------------------------------------------------------
  // Read decode
  // -------------------------------------------------------------------------
  // No extended address decode needed (extension regs at 0xB0-0xC8)
  always_comb begin
    reg_rd_data = 32'h0;
    reg_rd_ack  = 1'b1;
    case (rd_addr_lo)
      SW_RESET_CTRL_ADDR[7:0]:      reg_rd_data = {31'h0, sw_reset_q};
      FIFO_FLUSH_CTRL_ADDR[7:0]:    reg_rd_data = {28'h0, fifo_flush_q};
      INTERRUPT_STATUS_ADDR[7:0]:   reg_rd_data = {13'h0,
                                               err_data_lost_q,           // bit 18
                                               status_reclaim_done_q,     // bit 17
                                               status_handoff_failed_q,   // bit 16
                                               status_handoff_done_q,     // bit 15
                                               status_wake_q,             // bit 14
                                               err_pec_q,                 // bit 13
                                               status_clkstall_q,         // bit 12
                                               status_hj_q,               // bit 11
                                               status_ibi_q,              // bit 10
                                               hw_resp_fifo_not_empty,    // bit 9
                                               hw_rd_fifo_almost_full,    // bit 8
                                               hw_wr_fifo_almost_full,    // bit 7
                                               hw_cmd_fifo_almost_full,   // bit 6
                                               err_fifo_unf_q,            // bit 5
                                               err_fifo_ovf_q,            // bit 4
                                               err_timeout_q,             // bit 3
                                               err_nack_data_q,           // bit 2
                                               err_nack_addr_q,           // bit 1
                                               status_xfer_done_q};       // bit 0
      IBI_STATUS_ADDR[7:0]:        reg_rd_data = {27'h0, ibi_rejected_q, ibi_accepted_q, ibi_active, ibi_irq_status_q, ibi_detected_q};
      IBI_QUEUE_STATUS_ADDR[7:0]:         reg_rd_data = ibi_fifo_push_data;  // last IBI event data
      HJ_STATUS_ADDR[7:0]:         reg_rd_data = {30'h0, hj_pending, hj_detected_q};
      GROUP_ADDR_CFG_ADDR[7:0]:    reg_rd_data = {24'h0, group_count_q, group_enable_q};
      GROUP_ADDR_TBL_CFG_ADDR[7:0]:    reg_rd_data = group_table_q[group_rd_idx_q];
      DNF_CTRL_ADDR[7:0]:          reg_rd_data = {28'h0, dnf_threshold_q, dnf_enable_q};
      WAKE_CTRL_ADDR[7:0]:         reg_rd_data = {29'h0, wake_scl_en_q, wake_start_en_q, wake_en_q};
      CTRL_DYN_ADDR_CFG_ADDR[7:0]: reg_rd_data = {25'h0, ctrl_dyn_addr_q};  // [6:0]=controller DA
      // [9:5]=WR_FIFO_FREE, [4:0]=CMD_FIFO_FREE (per XLSX)
      // WR_FIFO depth=32, but field is 5 bits (0-31). Saturate at 31 (0x1F=empty).
      // CMD_FIFO depth=16, fits in 5 bits.
      FIFO_LVL_STATUS_ADDR[7:0]:       reg_rd_data = {22'h0,
                                                (hw_wr_fifo_free > 6'd31) ? 5'd31 : hw_wr_fifo_free[4:0],
                                                hw_cmd_fifo_free};
      // [9:5]=RD_FIFO_LEVEL, [4:0]=RESP_FIFO_LEVEL (per XLSX)
      // RD_FIFO depth=32, but field is 5 bits (0-31). Saturate at 31 (0x1F=full).
      // RESP_FIFO depth=16, fits in 5 bits.
      FIFO_LVL_STATUS_1_ADDR[7:0]:     reg_rd_data = {22'h0,
                                                (hw_rd_fifo_level > 6'd31) ? 5'd31 : hw_rd_fifo_level[4:0],
                                                hw_resp_fifo_level};
      // FIFO_LVL_STATUS etc. at new offsets) return 0 for unmapped reads.
      // The new offsets are handled by their own case entries above.
      SCL_HIGH_TIME_CFG_ADDR[7:0]:      reg_rd_data = {14'h0, scl_high_time_q};
      SCL_LOW_TIME_CFG_ADDR[7:0]:       reg_rd_data = {14'h0, scl_low_time_q};
      SDA_HOLD_TIME_CFG_ADDR[7:0]:      reg_rd_data = {14'h0, sda_hold_time_q};
      BUS_FREE_TIME_CFG_ADDR[7:0]:      reg_rd_data = {14'h0, bus_free_time_q};
      TSU_START_CFG_ADDR[7:0]:          reg_rd_data = {14'h0, tsu_start_q};
      THD_START_CFG_ADDR[7:0]:          reg_rd_data = {14'h0, thd_start_q};
      TSU_STOP_CFG_ADDR[7:0]:           reg_rd_data = {14'h0, tsu_stop_q};
      SCL_OD_HIGH_TIME_CFG_ADDR[7:0]:   reg_rd_data = {14'h0, scl_od_high_q};
      SCL_OD_LOW_TIME_CFG_ADDR[7:0]:    reg_rd_data = {14'h0, scl_od_low_q};
      PID0_STATUS_ADDR[7:0]:               reg_rd_data = pid_q[31:0];
      PID1_BCR_DCR_STATUS_ADDR[7:0]:       reg_rd_data = {dcr_q, bcr_q, pid_q[47:32]}; // 8+8+16=32
      // MWL (bytes 0..1) and MRL (bytes 2..3): 16 + 16 = 32 bits, no padding.
      I3C_SPEED_MODE_CFG_ADDR[7:0]:         reg_rd_data = {29'h0, speed_mode_q};
      TRANSACTION_CTRL_ADDR[7:0]:            reg_rd_data = {29'h0, control_q[0]};  // [0]=EN, [31:1] reserved
      // TRANSACTION_STATUS (0x0C) -- live RO status
      // [15:8]=BYTES_XFERD, [7:4]=ACTIVE_OPCODE(not avail), [3]=CLK_STALL,
      // [2]=CONTROLLER_BUSY, [1]=XFER_DONE, [0]=BUS_ACTIVE
      TRANSACTION_STATUS_ADDR[7:0]:         reg_rd_data = {8'h0, hw_bytes_xferd, 4'h0,
                                                          hw_clk_stall, ~hw_controller_idle,
                                                          hw_xfer_done, hw_bus_busy};
      // TX_FIFO_STATUS (0x30) -- RO
      // [7] WR_FIFO_OVERFLOW [6] WR_FIFO_FULL
      // [5] WR_FIFO_ALMOST_FULL [4] WR_FIFO_EMPTY
      // [3] CMD_FIFO_OVERFLOW [2] CMD_FIFO_FULL
      // [1] CMD_FIFO_ALMOST_FULL [0] CMD_FIFO_EMPTY
      TX_FIFO_STATUS_ADDR[7:0]:    reg_rd_data = {24'h0,
                                                   hw_wr_fifo_overflow,         // [7]
                                                   (hw_wr_fifo_free == 6'h0),   // [6] WR full
                                                   hw_wr_fifo_almost_full,      // [5]
                                                   (hw_wr_fifo_free == 6'd32),  // [4] WR empty
                                                   hw_cmd_fifo_overflow,        // [3]
                                                   (hw_cmd_fifo_free == 5'h0),  // [2] CMD full
                                                   hw_cmd_fifo_almost_full,     // [1]
                                                   (hw_cmd_fifo_free == 5'd16)};// [0] CMD empty
      // RX_FIFO_STATUS (0x34) -- RO
      // [7] RD_FIFO_UNDERFLOW [6] RD_FIFO_FULL
      // [5] RD_FIFO_ALMOST_FULL [4] RD_FIFO_EMPTY
      // [3] RESP_FIFO_UNDERFLOW [2] RESP_FIFO_FULL
      // [1] RESP_FIFO_ALMOST_FULL [0] RESP_FIFO_EMPTY
      RX_FIFO_STATUS_ADDR[7:0]:    reg_rd_data = {24'h0,
                                                   hw_rd_fifo_underflow,
                                                   (hw_rd_fifo_level == 6'd32),   // RD full
                                                   hw_rd_fifo_almost_full,
                                                   (hw_rd_fifo_level == 6'h0),    // RD empty
                                                   hw_resp_fifo_underflow,
                                                   (hw_resp_fifo_level == 5'd16), // RESP full
                                                   hw_resp_fifo_almost_full,
                                                   (hw_resp_fifo_level == 5'h0)}; // RESP empty
      //ACK_STATUS — 8-bit RO, latched on transaction completion
      ACK_STATUS_ADDR[7:0]:                 reg_rd_data = {24'h0, ack_status_q};
      // TARGET_STATUS (0xA4) -- RO
      TARGET_STATUS_ADDR[7:0]:              reg_rd_data = {27'h0, hw_target_nack_sent, hw_target_tx_req, hw_target_rx_done, hw_target_busy, hw_target_addressed};
      // WO registers -- reads return 0x0000_0000 with OKAY
      //Extended registers (0xB0-0xC8)
      BUS_CONFIG_ADDR[7:0]:               reg_rd_data = {30'h0, bus_type_q};
      ROLE_STATE_ADDR[7:0]:               reg_rd_data = {29'h0, role_state_in};
      HANDOFF_STATUS_ADDR[7:0]:           reg_rd_data = {30'h0, handoff_status_in};
      RECLAIM_CONFIG_ADDR[7:0]:           reg_rd_data = {15'h0, reclaim_timeout_us_q, reclaim_en_q};
      SCL_HIGH_TIME_MIXED_CFG_ADDR[7:0]:  reg_rd_data = {14'h0, scl_high_time_mixed_q};
      TIMING_GUARD_CTRL_ADDR[7:0]:        reg_rd_data = {31'h0, timing_guard_en_q};
      TIMING_VIOLATION_STATUS_ADDR[7:0]:  reg_rd_data = {22'h0, timing_violation_q};
      INTERRUPT_ENABLE_CTRL_ADDR[7:0]:      reg_rd_data = {13'h0, int_enable_q};
      SW_RESET_STATUS_ADDR[7:0]:            reg_rd_data = {31'h0, sw_reset_status_q};
      ABORT_CTRL_ADDR[7:0]:                 reg_rd_data = {30'h0, resume_req_q, abort_req_q};
      WAKE_STATUS_ADDR[7:0]:                reg_rd_data = {30'h0, wake_src_start_q, wake_src_scl_q};
      CLK_GATE_CTRL_ADDR[7:0]:              reg_rd_data = {28'h0, clk_gate_q};
      POWER_CTRL_ADDR[7:0]:                 reg_rd_data = {30'h0, power_ctrl_q};
      VERSION_ADDR[7:0]:            reg_rd_data = 32'h0001_0002; // (MIPI I3C Basic)
      default: begin
        reg_rd_data = 32'h0;
        reg_rd_ack  = 1'b0; // unsupported address
      end
    endcase
  end  // closes always_comb

  // -------------------------------------------------------------------------
  // Configuration outputs to hardware
  // -------------------------------------------------------------------------
  assign cfg_scl_high_time    = scl_high_time_q;
  assign cfg_scl_low_time     = scl_low_time_q;
  assign cfg_sda_hold_time    = sda_hold_time_q;
  assign cfg_bus_free_time    = bus_free_time_q;
  assign cfg_tsu_start        = tsu_start_q;
  assign cfg_thd_start        = thd_start_q;
  assign cfg_tsu_stop         = tsu_stop_q;
  assign cfg_scl_od_high_time = scl_od_high_q;
  assign cfg_scl_od_low_time  = scl_od_low_q;

  // --- RWSC outputs to controller ---
  assign sw_reset     = sw_reset_q;
  assign sw_flush_cmd  = fifo_flush_q[0];
  assign sw_flush_wr   = fifo_flush_q[1];
  assign sw_flush_rd   = fifo_flush_q[2];
  assign sw_flush_resp = fifo_flush_q[3];

  // --- Clock gating control output (from CLK_GATE_CTRL at 0x98) ---
  assign clk_gate_ctrl = clk_gate_q;


  // --- IBI outputs ---


  // --- Hot-Join outputs ---
  assign hj_clear    = reg_wr && (addr_lo == HJ_STATUS_ADDR[7:0]) && reg_wr_data[0];
  assign hj_auto_daa = 1'b0; // NOT IMPLEMENTED

  // --- Group outputs ---
  assign group_enable  = group_enable_q;
  assign group_count   = group_count_q;
  assign group_table_0 = group_table_q[0];
  assign group_table_1 = group_table_q[1];
  assign group_table_2 = group_table_q[2];
  assign group_table_3 = group_table_q[3];
  assign group_table_4 = group_table_q[4];
  assign group_table_5 = group_table_q[5];
  assign group_table_6 = group_table_q[6];
  assign group_table_7 = group_table_q[7];

  // --- DNF outputs ---
  assign dnf_threshold = dnf_threshold_q;
  assign dnf_enable    = dnf_enable_q;

  // --- Wake detector outputs (driven by WAKE_CTRL register) ---
  assign wake_en       = wake_en_q;
  assign wake_start_en = wake_start_en_q;
  assign wake_scl_en   = wake_scl_en_q;

  // --- Target engine outputs (driven by TARGET_CTRL register) ---
  assign ctrl_dyn_addr   = ctrl_dyn_addr_q;

  // --- Abort / Controller Role outputs ---
  assign abort_req          = abort_req_q;
  assign resume_req         = resume_req_q;

  // ---Bus configuration output ---
  assign bus_type           = bus_type_q;

  // ---Reclaim configuration outputs ---
  assign reclaim_en         = reclaim_en_q;
  assign reclaim_timeout_us = reclaim_timeout_us_q;

  // ---Mixed-bus SCL high time output ---
  assign scl_high_time_mixed = scl_high_time_mixed_q;


  // =========================================================================
  // =========================================================================
  // =========================================================================
  // TCRI back-door FIFO interface (passthrough to internal FIFOs)
  // =========================================================================
  // The actual FIFO instances live in the parent module (i3c_primary_controller_sdr).
  // This block exposes them via the tcri_* ports so a TCRI wrapper can drive
  // them in parallel with AXI register access.
  // The parent must wire tcri_* ports to the actual FIFOs. This module just
  // declares the interface; no internal logic is needed here.
  // When tcri_present=0, the parent should leave these ports unconnected
  // (they are outputs from the regfile's perspective -- declared as inputs
  // above for the wrapper to drive).

  // TCRI status outputs come from the parent (FIFO instances)
  // -- these are just pass-through wires driven by the parent module.
  // (Implementation: the parent assigns tcri_cmd_full = cmd_fifo_full, etc.)

  // --- Speed mode configuration output (from I3C_SPEED_MODE_CFG at 0x04) ---
  assign speed_mode     = speed_mode_q;

  // --- Transaction control outputs (from TRANSACTION_CTRL at 0x08) ---
  assign ctrl_en               = control_q[0];

  // control_q[7:4] reserved -- write 0, reads as 0.

  // -------------------------------------------------------------------------
  // Aggregated IRQ output
  // -------------------------------------------------------------------------
  // i3c_irq = OR(INTERRUPT_STATUS[18:0] & INTERRUPT_ENABLE_CTRL[18:0])
  //Bits [9:6] (FIFO almost-full / not-empty) are INCLUDED in IRQ
  // aggregation. They are live RO status bits, but when enabled via
  // INT_EN_CTRL[9:6], they generate preventive watermark IRQs.
  // Bit map (19-bit):
  // [18]=DATA_LOST_EN [18]=DATA_LOST (sticky, aggregate)
  // [17]=RECLAIM_DONE_EN [17]=RECLAIM_DONE (sticky)
  // [16]=HANDOFF_FAILED_EN [16]=HANDOFF_FAILED (sticky)
  // [15]=HANDOFF_DONE_EN [15]=HANDOFF_DONE (sticky, not impl)
  // [14:10]=event EN [14:10]=event status (sticky)
  // [9:6]=FIFO level EN [9:6]=FIFO level RO (live, CAN generate IRQ if enabled)
  // [5]=PEC_ERROR_EN [5]=PEC_ERROR (sticky)
  // [4]=FIFO_UNDERFLOW_EN [4]=FIFO_UNDERFLOW (sticky)
  // [3]=FIFO_OVERFLOW_EN [3]=FIFO_OVERFLOW (sticky)
  // [2]=TIMEOUT_EN [2]=TIMEOUT (sticky)
  // [1]=DATA_NACK_EN [1]=DATA_NACK (sticky)
  // [0]=ADDR_NACK_EN [0]=ADDR_NACK (sticky)
  // -------------------------------------------------------------------------
  logic [18:0] irq_status_vec;
  assign irq_status_vec = {
    err_data_lost_q,                  // [18]
    status_reclaim_done_q,            // [17]
    status_handoff_failed_q,          // [16]
    status_handoff_done_q,            // [15]
    status_wake_q,                    // [14]
    err_pec_q,                        // [13]
    status_clkstall_q,                // [12]
    status_hj_q,                      // [11]
    status_ibi_q,                     // [10]
    //AFULL IRQ enable bits [9:6] now included in IRQ aggregation.
    // These are live RO status bits, but when enabled via INT_EN_CTRL[9:6],
    // they CAN generate IRQs (preventive watermark IRQs).
    hw_resp_fifo_not_empty,           // [9]
    hw_rd_fifo_almost_full,           // [8]
    hw_wr_fifo_almost_full,           // [7]
    hw_cmd_fifo_almost_full,          // [6]
    err_fifo_unf_q,                   // [5]
    err_fifo_ovf_q,                   // [4]
    err_timeout_q,                    // [3]
    err_nack_data_q,                  // [2]
    err_nack_addr_q,                  // [1]
    status_xfer_done_q                // [0]
  };
  assign irq = | (irq_status_vec & int_enable_q);

endmodule : i3c_register_file

