// =============================================================================
// i2c_register_file.sv
// -----------------------------------------------------------------------------
// I2C Controller Register File — 15 registers, all 32-bit.
// Internal offsets 0x00..0x38 (4-byte stride). Absolute AXI address =
// I2C_REG_BASE (0x100) + internal offset.
// - TX_FIFO_OVERFLOW added (new bit)
// - DATA_LOST aggregate added (OR of TX/RX overflow + DATA_NACK)
// - TX_FIFO_AFULL live watermark added to INT_STATUS (preventive IRQ)
// - FIFO_STATUS expanded with AFULL/AEMPTY/UNDERFLOW/COUNT fields
// - FIFO overflow/underflow/afull/count signals wired from i3c_fifo
// 0x00 I2C_SPD_MODE_CFG R/W [31:20]RESERVED, [19:0]SPEED_PRESCALER
// 0x04 I2C_TRANS_CFG R/W [31:8]RESERVED, [7:0]XFER_LENGTH (default=1)
// 0x08 I2C_TRANS_EN_CTRL RWSC [31:1]RESERVED, [0]TRANS_EN (cond. self-clear)
// 0x0C I2C_TRANS_STATUS RO [31:12]RESERVED, [11:4]BYTES_XFERD,
// [3]RESERVED, [2]TRANS_ABORTED, [1]BUSY, [0]XFER_DONE
// 0x10 I2C_SW_RST_CTRL RWSC [31:1]RESERVED, [0]SW_RESET
// 0x14 I2C_SW_RST_STATUS W1C [31:1]RESERVED, [0]SW_RST_OCCURRED
// 0x18 I2C_TARGET_ADDR_CFG R/W [31:8]RESERVED, [7:1]TARGET_ADDR, [0]RnW
// 0x1C I2C_TIMEOUT_CFG R/W [31:16]RESERVED, [15:0]TIMEOUT
// 0x20 I2C_ACK_STATUS RO [31:4]RESERVED, [3:0]={DATA_NACK,DATA_ACK,SLV_ADDR_NACK,SLV_ADDR_ACK}
// 0x24 I2C_FIFO_CTRL RWSC [31:2]RESERVED, [1]RX_FIFO_FLUSH, [0]TX_FIFO_FLUSH
// 0x28 I2C_FIFO_STATUS RO [31:17]RESERVED, [16]RX_FIFO_AEMPTY,
// [15]TX_FIFO_AFULL, [14]RX_FIFO_UNDERFLOW,
// [13:10]RX_FIFO_COUNT, [9:6]TX_FIFO_COUNT,
// [5:0]={RX/TX_FIFO_CLEAR/FULL/EMPTY}
// 0x2C I2C_WDATA_TXFIFO WO [31:8]RESERVED, [7:0]TXDATA
// 0x30 I2C_RDATA_RXFIFO RO [31:8]RESERVED, [7:0]RXDATA
// 0x34 I2C_INT_EN_CTRL R/W [31:8]RESERVED, [7]XFER_DONE_EN,
// [6]TX_FIFO_AFULL_EN, [5]DATA_LOST_EN, [4]TX_FIFO_OVERFLOW_EN,
// [3]RX_FIFO_OVERFLOW_EN, [2]TRANS_ABORTED_EN,
// [1]DATA_NACK_EN, [0]ADDR_NACK_EN
// 0x38 I2C_INT_STATUS W1C [31:8]RESERVED, [7]XFER_DONE (sticky W1C),
// [6]TX_FIFO_AFULL (live RO), [5]DATA_LOST (aggregate),
// [4]TX_FIFO_OVERFLOW, [3]RX_FIFO_OVERFLOW,
// [2]TRANS_ABORTED, [1]DATA_NACK, [0]ADDR_NACK
// =============================================================================

import i3c_pkg::*;

module i2c_register_file (
    input  logic        clk,
    input  logic        rst_n,

    // AXI write channel
    input  logic        reg_wr,
    input  logic [31:0] reg_wr_addr,
    input  logic [31:0] reg_wr_data,
    output logic        reg_wr_ack,

    // AXI read channel
    input  logic        reg_rd,
    input  logic [31:0] reg_rd_addr,
    output logic [31:0] reg_rd_data,
    output logic        reg_rd_ack,

    // --- Status inputs from I2C FSM ---
    input  logic        i2c_xfer_done,
    input  logic        i2c_busy,
    input  logic [7:0]  i2c_bytes_xferd,
    input  logic        i2c_trans_aborted,
    input  logic        i2c_slv_addr_ack,
    input  logic        i2c_data_nack,

    // --- FIFO-level status inputs (from i3c_fifo instances) ---
    input  logic        i2c_tx_fifo_overflow,   // TX FIFO overflow (host push dropped)
    input  logic        i2c_rx_fifo_overflow,   // RX FIFO overflow (FSM push dropped)
    input  logic        i2c_rx_fifo_underflow,   // RX FIFO underflow (host read empty)
    input  logic        i2c_tx_fifo_afull,       // TX FIFO almost-full watermark (live)
    input  logic        i2c_rx_fifo_aempty,      // RX FIFO almost-empty watermark (live)
    input  logic [3:0]  i2c_tx_fifo_count,       // TX FIFO live fill level (0..15)
    input  logic [3:0]  i2c_rx_fifo_count,       // RX FIFO live fill level (0..15)

    // --- Config outputs to I2C FSM ---
    output logic        i2c_enable,
    output logic        i2c_sw_reset,
    output logic [7:0]  i2c_target_addr,
    output logic [7:0]  i2c_xfer_length,
    output logic [15:0] i2c_timeout,
    output logic [19:0] i2c_speed_prescaler,

    // --- IRQ output ---
    output logic        i2c_irq,

    // --- TX/RX FIFO interface ---
    output logic [7:0]  tx_fifo_wr_data,
    output logic        tx_fifo_wr,
    input  logic [7:0]  rx_fifo_rd_data,
    output logic        rx_fifo_rd,
    output logic        tx_fifo_flush,
    output logic        rx_fifo_flush,
    input  logic        tx_fifo_full,
    input  logic        tx_fifo_empty,
    input  logic        rx_fifo_full,
    input  logic        rx_fifo_empty
);

    // -------------------------------------------------------------------------
    // Storage
    // -------------------------------------------------------------------------
    logic [7:0]  trans_cfg_q;
    logic        trans_en_ctrl_q;
    logic        sw_rst_ctrl_q;
    logic        sw_rst_status_q;
    logic [19:0] spd_mode_cfg_q;
    logic [7:0]  target_addr_cfg_q;
    logic [15:0] timeout_cfg_q;
    logic [3:0]  ack_status_q;
    logic [1:0]  fifo_ctrl_q;
    logic [7:0]  int_enable_q;       // [7:0]: XFER_DONE_EN + AFULL_EN + DATA_LOST_EN + 5 event enables
    logic [7:0]  int_status_q;       // [7:0] sticky W1C (AFULL [6] is live RO, not stored; [7]=XFER_DONE)

    logic [1:0] sw_rst_cnt;
    logic [1:0] fifo_ctrl_cnt;

    // Address decode (16-bit to accommodate I2C_REG_BASE = 0x100)
    logic [15:0] addr_lo;
    logic [15:0] rd_addr_lo;
    assign addr_lo    = reg_wr_addr[15:0] - I2C_REG_BASE;
    assign rd_addr_lo = reg_rd_addr[15:0] - I2C_REG_BASE;

    // -------------------------------------------------------------------------
    // Write acknowledge
    // -------------------------------------------------------------------------
    // Writes to RO registers return OKAY (ack=1) but data is silently ignored.
    // Only unmapped addresses cause SLVERR (ack=0).
    always_comb begin
        reg_wr_ack = 1'b1;
        case (addr_lo)
            // Writable registers (R/W, RWSC, W1C)
            I2C_TRANS_CFG_ADDR[7:0], I2C_TRANS_EN_CTRL_ADDR[7:0],
            I2C_SW_RST_CTRL_ADDR[7:0], I2C_SW_RST_STATUS_ADDR[7:0],
            I2C_SPD_MODE_CFG_ADDR[7:0], I2C_TARGET_ADDR_CFG_ADDR[7:0],
            I2C_TIMEOUT_CFG_ADDR[7:0],
            I2C_FIFO_CTRL_ADDR[7:0], I2C_WDATA_TXFIFO_ADDR[7:0],
            I2C_INT_STATUS_ADDR[7:0], I2C_INT_EN_CTRL_ADDR[7:0]:
                reg_wr_ack = 1'b1;
            // Read-only registers — ack the write (OKAY) but data is ignored
            I2C_TRANS_STATUS_ADDR[7:0],
            I2C_ACK_STATUS_ADDR[7:0],
            I2C_FIFO_STATUS_ADDR[7:0],
            I2C_RDATA_RXFIFO_ADDR[7:0]:
                reg_wr_ack = 1'b1;  // RO register: write accepted but ignored
            default: reg_wr_ack = 1'b0;  // unmapped address → SLVERR
        endcase
    end

    // -------------------------------------------------------------------------
    // Sequential logic
    // -------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            trans_cfg_q       <= 8'h01;
            trans_en_ctrl_q   <= 1'b0;
            sw_rst_ctrl_q     <= 1'b0;
            spd_mode_cfg_q    <= 20'h0;
            target_addr_cfg_q <= 8'h0;
            timeout_cfg_q     <= 16'hFFFF;
            ack_status_q      <= 4'h0;
            fifo_ctrl_q       <= 2'h0;
            int_enable_q      <= 7'h0;
            int_status_q      <= 6'h0;
            sw_rst_status_q   <= 1'b0;
            sw_rst_cnt        <= 2'd0;
            fifo_ctrl_cnt     <= 2'd0;
        end else begin
            sw_rst_status_q <= 1'b0;
            // ---- TRANS_EN: conditional self-clear on xfer_done/aborted ----
            if (i2c_xfer_done || i2c_trans_aborted) begin
                trans_en_ctrl_q <= 1'b0;
            end

            // ---- SW_RESET: 3-cycle RWSC pulse ----
            if (sw_rst_cnt >= 2'd1) begin
                sw_rst_ctrl_q <= 1'b0;
                sw_rst_cnt    <= 2'd0;
            end else if (sw_rst_ctrl_q) begin
                sw_rst_cnt <= sw_rst_cnt + 1'b1;
            end

            // ---- ACK_STATUS: RO, hardware-set on completion, cleared on new TRANS_EN ----
            // Priority: latch on xfer_done/aborted FIRST, then clear on new TRANS_EN.
            // This ensures the ACK/NACK result is captured on the DONE cycle
            // (when trans_en_ctrl_q is still 1 but i2c_xfer_done just fired).
            if (i2c_xfer_done || i2c_trans_aborted) begin
                ack_status_q[0] <= i2c_slv_addr_ack;       // SLV_ADDR_ACK
                ack_status_q[1] <= ~i2c_slv_addr_ack;      // SLV_ADDR_NACK
                ack_status_q[2] <= ~i2c_data_nack;          // DATA_ACK
                ack_status_q[3] <= i2c_data_nack;           // DATA_NACK
            end else if (trans_en_ctrl_q) begin
                // New transaction starting — clear old ACK status
                ack_status_q <= 4'h0;
            end

            // ---- FIFO_CTRL: 3-cycle RWSC pulse ----
            if (fifo_ctrl_cnt >= 2'd1) begin
                fifo_ctrl_q   <= 2'h0;
                fifo_ctrl_cnt <= 2'd0;
            end else if (fifo_ctrl_q != 2'h0) begin
                fifo_ctrl_cnt <= fifo_ctrl_cnt + 1'b1;
            end

            // ---- SW_RST_STATUS ----
            if (sw_rst_ctrl_q) sw_rst_status_q <= 1'b1;

            // ---- Sticky INT_STATUS [7:0] ----
            // [7]=XFER_DONE (set when i2c_xfer_done fires — transfer complete)
            // [5]=DATA_LOST (aggregate: OR of [4],[3],[1] — set indirectly)
            // [4]=TX_FIFO_OVERFLOW, [3]=RX_FIFO_OVERFLOW
            // [2]=TRANS_ABORTED, [1]=DATA_NACK, [0]=ADDR_NACK
            if (i2c_xfer_done)            int_status_q[7] <= 1'b1;  // XFER_DONE
            if (i2c_tx_fifo_overflow)     int_status_q[4] <= 1'b1;
            if (i2c_rx_fifo_overflow)     int_status_q[3] <= 1'b1;
            if (i2c_trans_aborted)        int_status_q[2] <= 1'b1;
            if (i2c_data_nack)            int_status_q[1] <= 1'b1;
            // ADDR_NACK [0]: only set when xfer_done AND addr was NACKed
            // (fires at transfer completion, not prematurely at transfer start)
            if (i2c_xfer_done && !i2c_slv_addr_ack) int_status_q[0] <= 1'b1;
            // DATA_LOST [5]: set when any of TX_OVF, RX_Ovf, or DATA_NACK fires
            if (i2c_tx_fifo_overflow | i2c_rx_fifo_overflow | i2c_data_nack)
                int_status_q[5] <= 1'b1;

            // ---- AXI write ----
            if (reg_wr) begin
                case (addr_lo)
                    I2C_TRANS_CFG_ADDR[7:0]: begin
                        trans_cfg_q <= reg_wr_data[7:0];
                    end
                    I2C_TRANS_EN_CTRL_ADDR[7:0]: begin
                        if (reg_wr_data[0]) trans_en_ctrl_q <= 1'b1;
                    end
                    I2C_SW_RST_CTRL_ADDR[7:0]: begin
                        if (reg_wr_data[0]) begin
                            sw_rst_ctrl_q <= 1'b1;
                            sw_rst_cnt    <= 2'd0;
                        end
                    end
                    I2C_SW_RST_STATUS_ADDR[7:0]: begin
                        if (reg_wr_data[0]) sw_rst_status_q <= 1'b0;
                    end
                    I2C_SPD_MODE_CFG_ADDR[7:0]:
                        spd_mode_cfg_q <= reg_wr_data[19:0];
                    I2C_TARGET_ADDR_CFG_ADDR[7:0]:
                        target_addr_cfg_q <= reg_wr_data[7:0];
                    I2C_TIMEOUT_CFG_ADDR[7:0]:
                        timeout_cfg_q <= reg_wr_data[15:0];
                    I2C_ACK_STATUS_ADDR[7:0]: ;  // RO
                    I2C_FIFO_CTRL_ADDR[7:0]: begin
                        fifo_ctrl_q[0] <= reg_wr_data[0];
                        fifo_ctrl_q[1] <= reg_wr_data[1];
                        fifo_ctrl_cnt  <= 2'd0;
                    end
                    I2C_WDATA_TXFIFO_ADDR[7:0]: ;  // WO — push handled by strobe
                    I2C_INT_STATUS_ADDR[7:0]: begin
                        // W1C: clear sticky bits [7:0] (except [6]=AFULL which is live RO)
                        for (int i = 0; i < 8; i++)
                            if (i != 6 && reg_wr_data[i]) int_status_q[i] <= 1'b0;
                        // DATA_LOST [5] W1C also clears underlying [4],[3],[1]
                        if (reg_wr_data[5]) begin
                            int_status_q[4] <= 1'b0;
                            int_status_q[3] <= 1'b0;
                            int_status_q[1] <= 1'b0;
                        end
                    end
                    I2C_INT_EN_CTRL_ADDR[7:0]:
                        int_enable_q <= reg_wr_data[7:0];
                    default: ; // intentionally empty: RO regs ignore writes; new RW regs must add explicit case arm above
                endcase
            end
        end
    end

    // -------------------------------------------------------------------------
    // FIFO strobes
    // -------------------------------------------------------------------------
    assign rx_fifo_rd      = reg_rd && (rd_addr_lo == I2C_RDATA_RXFIFO_ADDR[7:0]);
    assign tx_fifo_wr      = reg_wr && (addr_lo == I2C_WDATA_TXFIFO_ADDR[7:0]);
    assign tx_fifo_wr_data = reg_wr_data[7:0];

    // -------------------------------------------------------------------------
    // Read decode
    // -------------------------------------------------------------------------
    always_comb begin
        reg_rd_data = 32'h0000_0000;
        reg_rd_ack  = 1'b1;
        case (rd_addr_lo)
            I2C_SPD_MODE_CFG_ADDR[7:0]:
                reg_rd_data = {12'h0, spd_mode_cfg_q};
            I2C_TRANS_CFG_ADDR[7:0]:
                reg_rd_data = {24'h0, trans_cfg_q};
            I2C_TRANS_EN_CTRL_ADDR[7:0]:
                reg_rd_data = {31'h0, trans_en_ctrl_q};
            // [11:4]=BYTES_XFERD, [3]=RESERVED, [2]=TRANS_ABORTED, [1]=BUSY, [0]=XFER_DONE
            I2C_TRANS_STATUS_ADDR[7:0]:
                reg_rd_data = {19'h0, i2c_bytes_xferd, 1'b0,
                               i2c_trans_aborted, i2c_busy, i2c_xfer_done};
            I2C_SW_RST_CTRL_ADDR[7:0]:
                reg_rd_data = {31'h0, sw_rst_ctrl_q};
            I2C_SW_RST_STATUS_ADDR[7:0]:
                reg_rd_data = {31'h0, sw_rst_status_q};
            I2C_TARGET_ADDR_CFG_ADDR[7:0]:
                reg_rd_data = {24'h0, target_addr_cfg_q};
            I2C_TIMEOUT_CFG_ADDR[7:0]:
                reg_rd_data = {16'h0, timeout_cfg_q};
            I2C_ACK_STATUS_ADDR[7:0]:
                reg_rd_data = {28'h0, ack_status_q};
            I2C_FIFO_CTRL_ADDR[7:0]:
                reg_rd_data = {30'h0, fifo_ctrl_q};
            //[16]RX_AEMPTY, [15]TX_AFULL, [14]RX_UNDERFLOW,
            // [13:10]RX_COUNT, [9:6]TX_COUNT, [5:0] existing
            I2C_FIFO_STATUS_ADDR[7:0]:
                reg_rd_data = {15'h0,
                               i2c_rx_fifo_aempty, i2c_tx_fifo_afull, i2c_rx_fifo_underflow,
                               i2c_rx_fifo_count, i2c_tx_fifo_count,
                               rx_fifo_flush, tx_fifo_flush,
                               rx_fifo_full, tx_fifo_full,
                               rx_fifo_empty, tx_fifo_empty};
            I2C_WDATA_TXFIFO_ADDR[7:0]:
                reg_rd_data = 32'h0;
            I2C_RDATA_RXFIFO_ADDR[7:0]:
                reg_rd_data = {24'h0, rx_fifo_rd_data};
            I2C_INT_EN_CTRL_ADDR[7:0]:
                reg_rd_data = {24'h0, int_enable_q};
            I2C_INT_STATUS_ADDR[7:0]:
                // [7]=XFER_DONE (sticky W1C), [6]=TX_FIFO_AFULL (live RO),
                // [5:0]=sticky W1C. int_status_q[6] is unused (AFULL is live).
                reg_rd_data = {24'h0, int_status_q[7], i2c_tx_fifo_afull, int_status_q[5:0]};
            default: begin
                reg_rd_data = 32'h0;
                reg_rd_ack  = 1'b0;
            end
        endcase
    end

    // -------------------------------------------------------------------------
    // Output assignments
    // -------------------------------------------------------------------------
    assign i2c_enable          = trans_en_ctrl_q;
    assign i2c_sw_reset        = sw_rst_ctrl_q;
    assign i2c_target_addr     = target_addr_cfg_q;
    assign i2c_xfer_length     = trans_cfg_q;
    assign i2c_timeout         = timeout_cfg_q;
    assign i2c_speed_prescaler = spd_mode_cfg_q;
    assign tx_fifo_flush       = fifo_ctrl_q[0];
    assign rx_fifo_flush       = fifo_ctrl_q[1];

    // IRQ: sticky bits [7],[5:0] AND enable [7],[5:0], OR AFULL [6] AND AFULL_EN [6]
    // [7]=XFER_DONE, [6]=AFULL (live), [5]=DATA_LOST, [4]=TX_OVF, [3]=RX_OVF,
    // [2]=TRANS_ABORTED, [1]=DATA_NACK, [0]=ADDR_NACK
    assign i2c_irq = (int_status_q[7]   & int_enable_q[7])    // XFER_DONE
                   | (i2c_tx_fifo_afull & int_enable_q[6])    // AFULL (live)
                   | (| (int_status_q[5:0] & int_enable_q[5:0])); // sticky [5:0]

endmodule : i2c_register_file

