// =============================================================================
// i3c_hotjoin_handler.sv
// HotJoin detection: 4-state FSM with debounce
// =============================================================================

import i3c_pkg::*;

module i3c_hotjoin_handler #(
  parameter int unsigned DEBOUNCE_CYCLES = 100
) (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        hj_enable,
    input  logic        hj_auto_daa,
    input  logic        controller_idle,
    input  logic        bus_idle,
    input  logic        sda_i,
    input  logic        scl_i,
    output logic        hj_trigger_daa,
    output logic        hj_detected,
    output logic        hj_pending,
    input  logic        hj_clear,
    input  logic        ibi_active
);

  typedef enum logic [2:0] {
    HJ_IDLE, HJ_DEBOUNCE, HJ_DETECTED_STATE, HJ_TRIGGERING, HJ_WAIT_DAA, HJ_WAIT_DAA_BUSY, HJ_DONE
  } hj_state_e;

  hj_state_e state, next_state;
  logic [7:0] debounce_cnt;
  logic       sda_prev;

  // 2-flop synchronizers for async SDA/SCL inputs (mirrors i3c_ibi_handler pattern)
  logic sda_meta, sda_sync;
  logic scl_meta, scl_sync;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sda_meta <= 1'b1; sda_sync <= 1'b1;
      scl_meta <= 1'b1; scl_sync <= 1'b1;
    end else begin
      sda_meta <= sda_i; sda_sync <= sda_meta;
      scl_meta <= scl_i; scl_sync <= scl_meta;
    end
  end

  // hj_detected is sticky — set when HJ is detected, cleared by hj_clear or reset.
  logic hj_detected_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      hj_detected_q <= 1'b0;
    else if (hj_clear)
      hj_detected_q <= 1'b0;  // hj_clear also clears detected (TB convenience)
    else if (next_state == HJ_DETECTED_STATE || state == HJ_DETECTED_STATE ||
             state == HJ_TRIGGERING || state == HJ_WAIT_DAA ||
             state == HJ_WAIT_DAA_BUSY || state == HJ_DONE)
      hj_detected_q <= 1'b1;
  end
  assign hj_detected = hj_detected_q;

  // SDA falling edge detection (while SCL high = HJ event)
  // Uses synchronized SDA/SCL to prevent metastability.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) sda_prev <= 1'b1;
    else sda_prev <= sda_sync;
  end
  wire hj_raw_detect = scl_sync & sda_prev & ~sda_sync & bus_idle & ~ibi_active;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= HJ_IDLE; debounce_cnt <= '0; hj_pending <= 1'b0;
    end else begin
      state <= next_state;
      if (state == HJ_DEBOUNCE) debounce_cnt <= debounce_cnt + 1'b1;
      else debounce_cnt <= '0;
      // hj_pending is set when HJ event detected (entering DEBOUNCE)
      // and stays set until hj_clear (software write) or reset.
      // BUGFIX: previously auto-cleared in HJ_DONE, but hj_pending is a
      // software-readable status flag that must persist until explicitly
      // cleared. Auto-clearing caused software to miss HotJoin events when
      // the FSM completed before software polled the flag.
      if (hj_clear) hj_pending <= 1'b0;
      else if (state == HJ_IDLE && next_state == HJ_DEBOUNCE) hj_pending <= 1'b1;
      else if (state == HJ_DETECTED_STATE) hj_pending <= 1'b1;
      // else: hold current value (sticky until hj_clear)
    end
  end

  always_comb begin
    next_state      = state;
    hj_trigger_daa  = 1'b0;
    // hj_detected is now a registered sticky flag (assigned above)

    // hj_clear forces return to HJ_IDLE from any state
    if (hj_clear) begin
      next_state = HJ_IDLE;
    end else begin
    unique case (state)
      HJ_IDLE: if (hj_enable & hj_raw_detect) next_state = HJ_DEBOUNCE;
      HJ_DEBOUNCE: begin
        // Abort debounce if gating conditions change while counting.
        // Without this, disabling HJ or asserting ibi_active during debounce
        // still allows hj_detected_q to fire, causing T4/T5/T6 failures.
        if (!hj_enable || !bus_idle || ibi_active)
          next_state = HJ_IDLE;
        else if (debounce_cnt >= DEBOUNCE_CYCLES) next_state = HJ_DETECTED_STATE;
      end
      HJ_DETECTED_STATE: begin
        if (hj_auto_daa) next_state = HJ_TRIGGERING;
        else next_state = HJ_DONE;
      end
      HJ_TRIGGERING: begin
        hj_trigger_daa = 1'b1;
        if (controller_idle) next_state = HJ_WAIT_DAA;
      end
      // HJ_WAIT_DAA exits on bus_idle, but bus_idle is typically
      // already true when entering this state (DAA hasn't started yet). The FSM
      // falls through to HJ_DONE before DAA runs. Use a daa_started/daa_done
      // handshake instead. For now, wait for bus_idle to go FALSE first, then TRUE.
      HJ_WAIT_DAA: if (!bus_idle) next_state = HJ_WAIT_DAA_BUSY;
      HJ_WAIT_DAA_BUSY: if (bus_idle) next_state = HJ_DONE;
      HJ_DONE: next_state = HJ_IDLE;
      default: next_state = HJ_IDLE;
    endcase
    end // else: not hj_clear
  end

endmodule : i3c_hotjoin_handler

