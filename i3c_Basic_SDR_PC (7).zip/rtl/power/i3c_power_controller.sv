// =============================================================================
// i3c_power_controller.sv
// Input sync, power stabilization delay, isolation ordering
// =============================================================================
module i3c_power_controller #(
  parameter int unsigned STABILIZE_CYCLES = 16  // Configurable power stabilization
) (
  input  logic        clk_aon,
  input  logic        rst_aon_n,

  // Host interface (sync'd externally, but we double-sync for safety)
  input  logic        pd_core_req,
  output logic        pd_core_off,
  input  logic        pd_core_ack,

  // Wake input (from wake_detector, async — must be sync'd)
  input  logic        wake_irq,

  // Bus status (from controller, async — must be sync'd)
  input  logic        bus_idle,

  // Power control outputs (to PMU / power switch cells)
  output logic        pd_core_sw_en,
  output logic        pd_core_iso_en,
  output logic        pd_core_rst,
  output logic        wake_to_host
);

  typedef enum logic [3:0] {
    PWR_CORE_ON,
    PWR_WAIT_IDLE,
    PWR_ISO_CLOSE,
    PWR_SWITCH_OPEN,
    PWR_CORE_OFF,
    PWR_SWITCH_CLOSE,
    PWR_STABILIZE,
    PWR_CORE_RESET,
    PWR_ISO_OPEN
  } pwr_state_e;

  pwr_state_e pwr_state;
  logic [7:0] timer_q;  // wider timer for longer stabilization

  // -------------------------------------------------------------------------
  // 2-flop synchronizers for async inputs
  // -------------------------------------------------------------------------
  logic pd_core_req_meta, pd_core_req_sync;
  logic pd_core_ack_meta, pd_core_ack_sync;
  logic wake_irq_meta, wake_irq_sync;
  logic bus_idle_meta, bus_idle_sync;

  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      pd_core_req_meta <= 1'b0; pd_core_req_sync <= 1'b0;
      pd_core_ack_meta <= 1'b0; pd_core_ack_sync <= 1'b0;
      wake_irq_meta    <= 1'b0; wake_irq_sync    <= 1'b0;
      bus_idle_meta    <= 1'b0; bus_idle_sync    <= 1'b0;
    end else begin
      pd_core_req_meta <= pd_core_req; pd_core_req_sync <= pd_core_req_meta;
      pd_core_ack_meta <= pd_core_ack; pd_core_ack_sync <= pd_core_ack_meta;
      wake_irq_meta    <= wake_irq;    wake_irq_sync    <= wake_irq_meta;
      bus_idle_meta    <= bus_idle;    bus_idle_sync    <= bus_idle_meta;
    end
  end

  // -------------------------------------------------------------------------
  // Power FSM with correct isolation sequencing
  // -------------------------------------------------------------------------
  always_ff @(posedge clk_aon or negedge rst_aon_n) begin
    if (!rst_aon_n) begin
      pwr_state       <= PWR_CORE_ON;
      pd_core_sw_en   <= 1'b1;
      pd_core_iso_en  <= 1'b0;
      pd_core_rst     <= 1'b0;
      wake_to_host    <= 1'b0;
      timer_q         <= '0;
    end else begin
      unique case (pwr_state)
        PWR_CORE_ON: begin
          wake_to_host <= 1'b0;
          if (pd_core_req_sync && bus_idle_sync)
            pwr_state <= PWR_WAIT_IDLE;
          if (wake_irq_sync)
            wake_to_host <= 1'b1;
        end

        PWR_WAIT_IDLE: begin
          // Wait one cycle AND re-check bus_idle
          if (bus_idle_sync)
            pwr_state <= PWR_ISO_CLOSE;
          else
            pwr_state <= PWR_CORE_ON;  // Bus became active, abort
        end

        PWR_ISO_CLOSE: begin
          pd_core_iso_en <= 1'b1;  // Close isolation BEFORE power-off
          pwr_state      <= PWR_SWITCH_OPEN;
        end

        PWR_SWITCH_OPEN: begin
          pd_core_sw_en <= 1'b0;   // Open power switch
          pwr_state     <= PWR_CORE_OFF;
        end

        PWR_CORE_OFF: begin
          if (wake_irq_sync) begin
            wake_to_host  <= 1'b1;
            pd_core_sw_en <= 1'b1;  // Close power switch
            pwr_state     <= PWR_SWITCH_CLOSE;
          end
        end

        PWR_SWITCH_CLOSE: begin
          // Power switch closed — wait for stabilization BEFORE reset
          timer_q <= STABILIZE_CYCLES;
          pwr_state <= PWR_STABILIZE;
        end

        PWR_STABILIZE: begin
          // Hold in stabilization state until voltage is stable
          if (timer_q > 0)
            timer_q <= timer_q - 1'b1;
          else begin
            pd_core_rst <= 1'b1;  // Assert reset AFTER stabilization
            timer_q <= 8'd8;       // 8 cycles of active reset
            pwr_state <= PWR_CORE_RESET;
          end
        end

        PWR_CORE_RESET: begin
          if (timer_q > 0)
            timer_q <= timer_q - 1'b1;
          else begin
            pd_core_rst <= 1'b0;  // Release reset
            pwr_state   <= PWR_ISO_OPEN;
          end
          if (pd_core_ack_sync)
            wake_to_host <= 1'b0;
        end

        PWR_ISO_OPEN: begin
          pd_core_iso_en <= 1'b0;  // Open isolation AFTER reset release
          pwr_state      <= PWR_CORE_ON;
        end

        default: pwr_state <= PWR_CORE_ON;
      endcase
    end
  end

  // pd_core_off should be asserted during PWR_SWITCH_OPEN too,
  // since the power switch is open (core unpowered) in that state.
  assign pd_core_off = (pwr_state == PWR_SWITCH_OPEN) || (pwr_state == PWR_CORE_OFF);

endmodule : i3c_power_controller

