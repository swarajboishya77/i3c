// =============================================================================
// i3c_daa.sv
// DAA sequencer: ENTDAA + SETDASA per MIPI I3C Basic
// =============================================================================

import i3c_pkg::*;

module i3c_daa (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        start_entdaa,
    input  logic        start_setdasa,
    input  logic [6:0]  setdasa_static_addr,
    input  logic        tgt_table_full,     // all 16 slots valid
    input  logic [3:0]  tgt_table_count,    // current valid slot count (TB hook; not used internally)
    output logic        req_start,
    output logic        req_repeat_start,
    output logic        req_stop,
    output logic        req_send_byte,
    output logic [7:0]  req_send_byte_val,
    output logic        req_recv_byte,
    output logic        req_send_ack,
    output logic        req_send_nack,
    output logic        req_send_addr_w,
    output logic        req_send_addr_r,
    output logic [6:0]  req_addr_val,
    input  logic        prim_done,
    input  logic        prim_ack_recv,
    input  logic [7:0]  prim_byte_recv,
    output logic        daa_done,
    output logic        daa_target_found,
    output logic [47:0] daa_pid,
    output logic [7:0]  daa_bcr,
    output logic [7:0]  daa_dcr,
    output logic [6:0]  daa_dyn_addr_assigned,
    output logic        daa_recv_last_byte
);

  localparam int TARGET_TABLE_DEPTH = 16;

  // -------------------------------------------------------------------------
  // Function: next_reserved_skip
  // Returns the next valid I3C dynamic address after `da`, skipping all
  // reserved/restricted addresses per MIPI I3C Basic v1.2 Table 10.
  // Reserved: 0x00-0x07, 0x3E, 0x5E, 0x6E, 0x76, 0x7A, 0x7C, 0x7E, 0x7F.
  // Available: 0x08-0x3D, 0x3F-0x5D, 0x5F-0x6D, 0x6F-0x75, 0x77, 0x7D.
  // Wraps from 0x7D back to 0x08.
  // -------------------------------------------------------------------------
  function automatic logic [6:0] next_reserved_skip(input logic [6:0] da);
    logic [6:0] nxt;
    nxt = da + 7'd1;
    // Wrap from 0x7D (or anything >= 0x7D) back to 0x08
    if (nxt >= 7'h7E) nxt = 7'h08;
    // Skip 6 single-bit-error-detect addresses around the broadcast 0x7E
    if (nxt == 7'h3E) nxt = 7'h3F;
    if (nxt == 7'h5E) nxt = 7'h5F;
    if (nxt == 7'h6E) nxt = 7'h6F;
    if (nxt == 7'h76) nxt = 7'h77;
    if (nxt == 7'h7A) nxt = 7'h7B;
    if (nxt == 7'h7C) nxt = 7'h7D;
    return nxt;
  endfunction

  typedef enum logic [4:0] {
    D_IDLE,
    D_E_START, D_E_ADDR7E_W, D_E_ADDR7E_ACK,
    D_E_TX_OPCODE,
    // D_E_REPSTART removed — the DAA handler skips Repeated START and goes
    // directly from D_E_TX_OPCODE to D_E_ADDR7E_R (the controller FSM issues
    // a Repeated START as part of the addr_r request).
    D_E_ADDR7E_R, D_E_ADDR7E_R_ACK,
    D_E_RX_PID_BCR_DCR, D_E_TX_DYN_ADDR, D_E_TX_DYN_ADDR_ACK,
    D_E_FIRST_BIT_STALL, D_E_STOP,
    D_S_START, D_S_ADDR, D_S_ADDR_ACK, D_S_TX_OPCODE, D_S_TX_OPCODE_ACK,
    D_S_TX_DA, D_S_TX_DA_ACK, D_S_STOP,
    D_COLLISION_DETECT, D_DONE, D_ERROR
  } daa_state_e;

  daa_state_e state, next_state;
  logic [3:0]  byte_cnt;
  logic [47:0] pid_reg;
  logic [7:0]  bcr_reg, dcr_reg;
  logic [6:0]  next_da;
  logic [7:0]  pid_byte [0:5];
  logic [15:0] stall_cnt, pid_timeout_cnt;

  logic [6:0]  setdasa_addr_q;
  logic [6:0]  assigned_da_r;  // capture DA before increment
  // BUGFIX: latch start_entdaa/start_setdasa to avoid 1-cycle pulse races.
  // In Vivado, the TB's 1-cycle start pulse can be missed if the FSM is
  // transitioning states. These latches hold the start request until the
  // FSM actually begins the requested flow.
  logic start_entdaa_lat, start_setdasa_lat;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      start_entdaa_lat <= 1'b0;
      start_setdasa_lat <= 1'b0;
    end else begin
      if (start_entdaa) start_entdaa_lat <= 1'b1;
      else if (state == D_E_START) start_entdaa_lat <= 1'b0;
      if (start_setdasa) start_setdasa_lat <= 1'b1;
      else if (state == D_S_START) start_setdasa_lat <= 1'b0;
    end
  end

  localparam int STALL_CYCLES = 2;  // short stall for sim (was 100)
  localparam int PID_TIMEOUT_CYCLES = 10000;  // 100us

  // PID byte order was reversed. pid_byte[0] is the first byte
  // received (MSB of PID), so pid_reg should be {pid_byte[0], pid_byte[1], ...}.
  assign daa_pid = {pid_byte[0], pid_byte[1], pid_byte[2], pid_byte[3], pid_byte[4], pid_byte[5]};
  assign daa_bcr = bcr_reg;
  assign daa_dcr = dcr_reg;
  assign daa_dyn_addr_assigned = assigned_da_r;  // use captured DA
  assign daa_recv_last_byte = (byte_cnt == 4'd6) && (state == D_E_RX_PID_BCR_DCR);

  always_comb begin
    pid_reg = {pid_byte[5], pid_byte[4], pid_byte[3], pid_byte[2], pid_byte[1], pid_byte[0]};
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= D_IDLE; byte_cnt <= '0;
      pid_byte[0] <= '0; pid_byte[1] <= '0; pid_byte[2] <= '0;
      pid_byte[3] <= '0; pid_byte[4] <= '0; pid_byte[5] <= '0;
      bcr_reg <= '0; dcr_reg <= '0;
      next_da <= 7'h08; assigned_da_r <= 7'h00; stall_cnt <= '0; pid_timeout_cnt <= '0;
      setdasa_addr_q <= '0;
    end else begin
      state <= next_state;

      // --- byte_cnt: single-driver (reset on 7E/R-ACK, increment on RX byte) ---
      if (state == D_E_ADDR7E_R_ACK && prim_done && prim_ack_recv) begin
        byte_cnt <= '0;
      end else if (state == D_E_RX_PID_BCR_DCR && prim_done) begin
        byte_cnt <= byte_cnt + 1'b1;
      end

      // --- PID/BCR/DCR capture (same state as byte_cnt increment) ---
      if (state == D_E_RX_PID_BCR_DCR && prim_done) begin
        if (byte_cnt < 6) pid_byte[byte_cnt] <= prim_byte_recv;
        else if (byte_cnt == 6) bcr_reg <= prim_byte_recv;
        else if (byte_cnt == 7) dcr_reg <= prim_byte_recv;
      end

      // --- assigned_da_r: single-driver (ENTDAA or SETDASA path) ---
      if (state == D_E_TX_DYN_ADDR_ACK && prim_done && prim_ack_recv) begin
        assigned_da_r <= next_da;
      end else if (state == D_S_TX_DA_ACK && prim_done && prim_ack_recv) begin
        assigned_da_r <= setdasa_addr_q;
      end

      // --- next_da: single-driver (ENTDAA start or post-assign increment) ---
      // BUGFIX: use latched start_entdaa_lat and also capture in D_DONE
      if ((state == D_IDLE || state == D_DONE) && (start_entdaa || start_entdaa_lat)) begin
        next_da <= 7'h08;
      end else if (state == D_E_TX_DYN_ADDR_ACK && prim_done && prim_ack_recv) begin
        // Per MIPI I3C Basic v1.2 Table 10 — skip reserved/restricted addresses
        next_da <= next_reserved_skip(next_da);
      end

      // --- setdasa_addr_q: single-driver ---
      // BUGFIX: use latched start_setdasa_lat
      if ((state == D_IDLE || state == D_DONE) && (start_setdasa || start_setdasa_lat)) begin
        setdasa_addr_q <= setdasa_static_addr;
      end

      // --- stall_cnt: single-driver ---
      if (state == D_E_FIRST_BIT_STALL) begin
        stall_cnt <= stall_cnt + 1'b1;
      end else begin
        stall_cnt <= '0;
      end

      // --- pid_timeout_cnt: single-driver ---
      if (state == D_E_RX_PID_BCR_DCR) begin
        pid_timeout_cnt <= pid_timeout_cnt + 1'b1;
      end else begin
        pid_timeout_cnt <= '0;
      end
    end
  end

  always_comb begin
    next_state       = state;
    req_start        = 1'b0;
    req_repeat_start = 1'b0;
    req_stop         = 1'b0;
    req_send_byte    = 1'b0;
    req_send_byte_val = 8'h00;
    req_recv_byte    = 1'b0;
    req_send_ack     = 1'b0;
    req_send_nack    = 1'b0;
    req_send_addr_w  = 1'b0;
    req_send_addr_r  = 1'b0;
    req_addr_val     = 7'h00;
    daa_done         = 1'b0;
    daa_target_found = 1'b0;

    unique case (state)
      D_IDLE: begin
        // BUGFIX: use latched start signals to avoid 1-cycle pulse races
        if (start_entdaa || start_entdaa_lat) next_state = D_E_START;
        else if (start_setdasa || start_setdasa_lat) next_state = D_S_START;
      end
      D_E_START: begin req_start = 1'b1; if (prim_done) next_state = D_E_ADDR7E_W; end
      D_E_ADDR7E_W: begin req_send_byte = 1'b1; req_send_byte_val = {7'h7E, 1'b0}; if (prim_done) next_state = D_E_ADDR7E_ACK; end
      D_E_ADDR7E_ACK: if (prim_done) begin if (prim_ack_recv) next_state = D_E_TX_OPCODE; else next_state = D_ERROR; end
      D_E_TX_OPCODE: begin req_send_byte = 1'b1; req_send_byte_val = 8'h07; if (prim_done) next_state = D_E_ADDR7E_R; end  // skip REPSTART
      D_E_ADDR7E_R: begin req_send_byte = 1'b1; req_send_byte_val = {7'h7E, 1'b1}; if (prim_done) next_state = D_E_ADDR7E_R_ACK; end
      D_E_ADDR7E_R_ACK: if (prim_done) begin if (prim_ack_recv) next_state = D_E_RX_PID_BCR_DCR; else next_state = D_E_STOP; end  // wrap in begin-end
      D_E_RX_PID_BCR_DCR: begin
        req_recv_byte = 1'b1;
        // ACK every byte except the last (DCR, byte_cnt==7).
        if (byte_cnt < 4'd7) req_send_ack = 1'b1;
        else                 req_send_nack = 1'b1;
        if (prim_done) begin if (byte_cnt == 7) next_state = D_E_TX_DYN_ADDR; else next_state = D_E_RX_PID_BCR_DCR; end
        else if (pid_timeout_cnt >= PID_TIMEOUT_CYCLES) next_state = D_ERROR;
      end
      D_E_TX_DYN_ADDR: begin
        // Per MIPI I3C Basic v1.2 §4.3.4.2 step 9: drive 7-bit DA + odd parity bit (PAR).
        // PAR = ~XOR(DA[6:0]), placed in bit[0].
        req_send_byte = 1'b1;
        req_send_byte_val = {next_da, ~(^next_da)};
        if (prim_done) next_state = D_E_TX_DYN_ADDR_ACK;
      end
      D_E_TX_DYN_ADDR_ACK: if (prim_done) begin if (prim_ack_recv) next_state = D_E_FIRST_BIT_STALL; else next_state = D_ERROR; end
      D_E_FIRST_BIT_STALL: if (stall_cnt >= STALL_CYCLES) begin
        daa_target_found = 1'b1;
        // Check if target table is full before looping back
        // tgt_count overflows to 0 when all 16 slots are valid.
        // Also check tgt_table_full flag.
        if (tgt_table_full)
          next_state = D_E_STOP;  // table full — issue STOP and finish
        else
          next_state = D_E_ADDR7E_R;  // loop directly to 7E-R (skip REPSTART)
      end
      D_E_STOP: begin req_stop = 1'b1; if (prim_done) next_state = D_DONE; end  // wait for prim_done
      D_S_START: begin req_start = 1'b1; req_addr_val = setdasa_addr_q; if (prim_done) next_state = D_S_ADDR; end
      D_S_ADDR: begin req_send_addr_w = 1'b1; req_addr_val = setdasa_addr_q; if (prim_done) next_state = D_S_ADDR_ACK; end
      D_S_ADDR_ACK: if (prim_done) begin if (prim_ack_recv) next_state = D_S_TX_OPCODE; else next_state = D_ERROR; end
      // SETDASA is a Direct CCC: START → StaticAddr+W → 0x87 → NewDynAddr+W → STOP.
      D_S_TX_OPCODE: begin req_send_byte = 1'b1; req_send_byte_val = CCC_SETDASA_D; if (prim_done) next_state = D_S_TX_OPCODE_ACK; end
      D_S_TX_OPCODE_ACK: if (prim_done) begin if (prim_ack_recv) next_state = D_S_TX_DA; else next_state = D_ERROR; end
      D_S_TX_DA: begin req_send_byte = 1'b1; req_send_byte_val = {setdasa_addr_q, ~(^setdasa_addr_q)}; if (prim_done) next_state = D_S_TX_DA_ACK; end  // BUGFIX: I3C parity bit, not W=0
      // only claim success if the device ACKed the dynamic address
      D_S_TX_DA_ACK: if (prim_done) begin if (prim_ack_recv) daa_target_found = 1'b1; next_state = D_S_STOP; end
      D_S_STOP: begin req_stop = 1'b1; if (prim_done) next_state = D_DONE; end
      D_COLLISION_DETECT: next_state = D_E_STOP;
      // BUGFIX: accept start_entdaa/start_setdasa in D_DONE (back-to-back race)
      D_DONE: begin daa_done = 1'b1;
                   // BUGFIX: use latched start signals
                   if (start_entdaa || start_entdaa_lat) next_state = D_E_START;
                   else if (start_setdasa || start_setdasa_lat) next_state = D_S_START;
                   else next_state = D_IDLE; end
      D_ERROR: begin daa_done = 1'b1; next_state = D_IDLE; end
      default: next_state = D_IDLE;
    endcase
  end

endmodule : i3c_daa

