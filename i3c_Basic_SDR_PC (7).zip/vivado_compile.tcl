# =============================================================================
# vivado_compile.tcl
# -----------------------------------------------------------------------------
# Vivado VRFC-compatible compile script for I3C Basic v1.2 SDR Controller.
# Compiles i3c_pkg.sv FIRST (required by VRFC 10-2989), then all other files.
#
# NOTE: This is a TCL script — do NOT run with bash 'source'.
#       Use ONE of these methods:
#
# Method 1 — Vivado GUI TCL Console:
#   cd <path_to>/i3c_controller_rtl
#   source vivado_compile.tcl
#
# Method 2 — Vivado batch mode (bash):
#   vivado -mode batch -source vivado_compile.tcl
#
# Method 3 — For XSIM simulation, use the bash script instead:
#   bash vivado_compile.sh --sim
# =============================================================================

set RTL_DIR [file dirname [info script]]
if {$RTL_DIR eq ""} {set RTL_DIR "."}

puts "================================================================"
puts "Vivado VRFC Compile — I3C Basic v1.2 SDR Controller"
puts "RTL_DIR: $RTL_DIR"
puts "================================================================"

# -----------------------------------------------------------------------------
# Step 1: Compile the SV package FIRST (required by VRFC 10-2989)
# -----------------------------------------------------------------------------
puts "\n--- Step 1: Compiling i3c_pkg.sv (MUST be first) ---"
read_verilog -sv [glob ${RTL_DIR}/rtl/include/i3c_pkg.sv]

# -----------------------------------------------------------------------------
# Step 2: Compile all leaf modules (no dependencies on other local modules)
# -----------------------------------------------------------------------------
puts "\n--- Step 2: Compiling leaf modules ---"
read_verilog -sv [glob ${RTL_DIR}/rtl/io_pad/io_buf.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/dnf/i3c_dnf.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/pec/i3c_pec.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/digital_phy/i3c_timing_control.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/digital_phy/i3c_start_stop_gen.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/digital_phy/i3c_phy_fsm.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/digital_phy/i3c_phy_mux.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/ccc/i3c_ccc_handler.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/daa/i3c_daa.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/ibi/i3c_ibi_handler.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/hj/i3c_hotjoin_handler.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/group/i3c_group_addr.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/wake/i3c_wake_detector.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/target/i3c_target_engine.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/target/i3c_ccc_event_decoder.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/target/i3c_target_table.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/role/i3c_role_manager.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/clock/i3c_clock_gate.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/clock/i3c_async_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/power/i3c_power_controller.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/controller/byte_serdes_i3c.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/controller/byte_serdes_i2c.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/controller/i2c_controller_fsm.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/controller/i2c_prescaler.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/fifo/i3c_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/fifo/i3c_cmd_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/fifo/i3c_wr_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/fifo/i3c_rd_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/fifo/i3c_resp_fifo.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/axi/axi4_lite_slave.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/register_map/i3c_register_file.sv]
read_verilog -sv [glob ${RTL_DIR}/rtl/register_map/i2c_register_file.sv]

# -----------------------------------------------------------------------------
# Step 3: Compile top-level controller LAST (instantiates all above)
# -----------------------------------------------------------------------------
puts "\n--- Step 3: Compiling top-level controller ---"
read_verilog -sv [glob ${RTL_DIR}/rtl/controller/i3c_primary_controller_sdr.sv]

puts "\n================================================================"
puts "Vivado VRFC Compile COMPLETE"
puts "================================================================"
