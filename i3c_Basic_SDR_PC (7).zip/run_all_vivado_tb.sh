#!/bin/bash
# =============================================================================
# run_all_vivado_tb.sh — Run ALL testbenches in Vivado XSIM batch mode
# -----------------------------------------------------------------------------
# Compiles all RTL + TBs, then elaborates and simulates each testbench.
# Collects pass/fail results for all testbenches.
#
# LOGGING:
#   Full XSIM output for FAILED testbenches is saved to:
#       xsim_logs/<tb_name>.log
#   If a previously-failed testbench PASSES on a later run, its old failure
#   log is automatically deleted. After every run, xsim_logs/ contains logs
#   for ONLY the testbenches that failed in that run.
#   NO regression_summary.txt is generated.
#
# CLEANUP:
#   Vivado junk files (.wbd, .jou, .pb, backup.log, webtalk*, etc.) are
#   deleted after every xvlog/xelab/xsim invocation and at script end.
#
# Usage:
#   bash run_all_vivado_tb.sh
# =============================================================================

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

# --- Per-testbench XSIM log directory (fail-only) ---
LOG_DIR="$PROJECT_ROOT/xsim_logs"
mkdir -p "$LOG_DIR"
# Sweep any orphaned .tmp_* files from a previously-interrupted run
rm -f "$LOG_DIR"/.tmp_*.log

# --- Per-test wall-clock timeout for xsim (seconds) ---
# If a TB has an infinite loop or a 2-billion-timeunit watchdog, xsim would
# otherwise block the whole regression. 300s = 5 min per test is plenty.
XSIM_TIMEOUT=300

# --- Helper: remove Vivado junk files ---
# Vivado creates .wbd (waveform database) during xelab, and backup.log/.jou/.pb
# during xvlog/xelab/xsim. These are written ASYNCHRONOUSLY by Vivado background
# processes AFTER the main tool exits. We use find (more reliable than rm -f
# with globs) and poll for up to 10 seconds to catch them.
cleanup_vivado_junk() {
    local i remaining
    for i in $(seq 1 10); do
        # Delete all junk patterns using find (handles no-match gracefully)
        find "$PROJECT_ROOT" -maxdepth 1 -name "*.wbd" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "backup.log*" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "*.jou" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "*.pb" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "*.str" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "xvlog.log" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "xelab.log" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "xsim.log" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "webtalk*.log" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name "webtalk*.zip" -delete 2>/dev/null
        find "$PROJECT_ROOT" -maxdepth 1 -name ".Xil" -delete 2>/dev/null
        # Check if any junk files remain using find (reliable, no glob issues)
        remaining=$(find "$PROJECT_ROOT" -maxdepth 1 \( -name "*.wbd" -o -name "backup.log*" -o -name "*.jou" -o -name "*.pb" \) 2>/dev/null | wc -l)
        if [ "$remaining" -eq 0 ]; then
            break
        fi
        sleep 1
    done
}
trap cleanup_vivado_junk EXIT
cleanup_vivado_junk

echo "================================================================"
echo "Vivado XSIM — Run ALL Testbenches"
echo "Project: $PROJECT_ROOT"
echo "================================================================"

# --- Step 1: Compile all RTL + TBs ---
echo ""
echo "=== STEP 1: COMPILE ALL ==="
# BUGFIX: delete cached compiled library to force full recompile.
# xvlog uses incremental compilation — if source files have the same or older
# timestamps as the cached objects in xsim.dir/work, Vivado skips recompilation.
# Deleting xsim.dir forces a clean recompile so the latest RTL fixes take effect.
echo "  Deleting cached xsim.dir/work for clean recompile..."
rm -rf "$PROJECT_ROOT/xsim.dir"
bash 1_vivado_xvlog_compile.sh
cleanup_vivado_junk

# Also compile UVM package and testbenches
echo ""
echo "=== Compiling UVM-style testbenches ==="
xvlog -sv tb_uvm/i3c_uvm_pkg.sv 2>&1 | tail -1
for tb_file in tb_uvm/tb_uvm_*.sv; do
    [ -f "$tb_file" ] || continue
    tb_name=$(basename "$tb_file")
    output=$(xvlog -sv "$tb_file" 2>&1) || true
    if echo "$output" | grep -qiE "ERROR"; then
        echo "  FAIL: $tb_name"
        echo "$output" | grep -E "ERROR" | head -3 | sed 's/^/        /'
    else
        echo "  OK: $tb_name"
    fi
done
cleanup_vivado_junk

# --- List of testbenches to run (ALL tb_*.sv files) ---
TBS=(
    # Original SV testbenches
    tb_axi_corner_cases
    tb_cdc_reset_corner_cases
    tb_fifo_corner_cases
    tb_i2c_transaction_e2e
    tb_i3c_all_features
    tb_i3c_getaccr_deep_audit
    tb_i3c_getaccr_e2e
    tb_i3c_mipi_mixedbus_timing
    tb_i3c_protocol_corner_cases
    tb_i3c_register_bitfield
    tb_i3c_role_manager
    tb_i3c_round3_corner_cases
    tb_i3c_submodule_audit
    tb_i3c_submodule_audit_v2
    tb_i3c_target_engine
    tb_i3c_timing_guard
    tb_i3c_transaction_e2e
    tb_i3c_primary_controller_sdr
    tb_sva_formal
    # New SV testbenches (converted from cocotb)
    tb_i3c_pec
    tb_i3c_dnf
    tb_i3c_clock_gate_sv
    tb_i3c_group_addr_sv
    tb_i3c_hotjoin_sv
    tb_i3c_wake_sv
    tb_i3c_start_stop_sv
    tb_i3c_phy_mux_sv
    tb_i3c_power_sv
    tb_i3c_fifo_sv
    tb_i3c_async_fifo_sv
    tb_i2c_prescaler_sv
    tb_i3c_ibi_sv
    tb_i3c_target_table_sv
    tb_byte_serdes_i3c_sv
    tb_byte_serdes_i2c_sv
    tb_i2c_controller_fsm_sv
    tb_i3c_timing_control_sv
    # UVM-style testbenches (from tb_uvm/)
    tb_uvm_axi4_lite
    tb_uvm_ccc
    tb_uvm_daa
)

echo ""
echo "================================================================"
echo "STEP 2+3: ELABORATE + SIMULATE EACH TESTBENCH"
echo "================================================================"

PASS_COUNT=0
FAIL_COUNT=0
RESULTS=""

for tb in "${TBS[@]}"; do
    echo ""
    echo "--- $tb ---"

    # Elaborate
    echo "  Elaborating..."
    xelab -L work -debug typical $tb -s "sim_${tb}" 2>&1 | tail -2

    # Check if elaborate succeeded
    if [ ! -d "xsim.dir/sim_${tb}" ]; then
        echo "  RESULT: ELABORATE FAILED"
        RESULTS="${RESULTS}\n  FAIL: $tb (elaborate failed)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        cleanup_vivado_junk
        continue
    fi

    # Simulate in batch mode
    echo "  Simulating..."
    output=$(timeout "$XSIM_TIMEOUT" xsim "sim_${tb}" -tclbatch run_sim.tcl 2>&1)
    xsim_exit=$?
    if [ "$xsim_exit" -eq 124 ]; then
        output="RESULT: TIMEOUT — xsim exceeded ${XSIM_TIMEOUT}s wall clock
${output}"
    fi

    # Show ALL summary/result/overall lines (broader grep)
    summary_lines=$(echo "$output" | grep -iE "SUMMARY:|RESULT:|OVERALL:|Passed:|Failed:|PASS:|FAIL:|TOTAL:" | tail -5)
    if [ -n "$summary_lines" ]; then
        echo "$summary_lines" | sed 's/^/    /'
    else
        # Show last 3 lines of output as fallback
        echo "$output" | tail -3 | sed 's/^/    /'
    fi

    # Determine pass/fail and manage log file accordingly
    if echo "$output" | grep -qiE "0 FAIL|ALL PASS|ALL TESTS PASS|OVERALL: PASS|RESULT: ALL PASS"; then
        # PASS — delete any old failure log from a previous run
        rm -f "$LOG_DIR/${tb}.log" 2>/dev/null
        RESULTS="${RESULTS}\n  PASS: $tb"
        PASS_COUNT=$((PASS_COUNT + 1))
    elif echo "$output" | grep -qiE "FAIL|ERROR|TIMEOUT"; then
        # FAIL — write the full xsim output to the failure log
        echo "$output" > "$LOG_DIR/${tb}.log"
        RESULTS="${RESULTS}\n  FAIL: $tb"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    elif echo "$output" | grep -qiE "PASS"; then
        # Has PASS lines but no explicit summary
        pass_count=$(echo "$output" | grep -ciE "\[PASS\]")
        rm -f "$LOG_DIR/${tb}.log" 2>/dev/null
        RESULTS="${RESULTS}\n  PASS: $tb ($pass_count tests, no summary)"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        # UNKNOWN — treat as fail, keep the log for inspection
        echo "$output" > "$LOG_DIR/${tb}.log"
        RESULTS="${RESULTS}\n  UNKNOWN: $tb (no test output)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi

    # Clean up snapshot to save disk space
    rm -rf "xsim.dir/sim_${tb}"
    cleanup_vivado_junk
done

echo ""
echo "================================================================"
echo "ALL TESTBENCH RESULTS"
echo "================================================================"
echo -e "$RESULTS"
echo ""
echo "  Total PASS: $PASS_COUNT"
echo "  Total FAIL: $FAIL_COUNT"
echo "================================================================"

# Final sweep — wait 3 seconds for Vivado background processes to finish
# writing async files, then delete all junk. Do NOT delete xsim.dir — it
# contains the compiled work library and is needed for re-runs.
sleep 3
cleanup_vivado_junk
