#!/bin/bash
# =============================================================================
# run_all_vivado_tb.sh — Run ALL testbenches in Vivado XSIM batch mode
# -----------------------------------------------------------------------------
# Compiles all RTL + TBs, then elaborates and simulates each testbench.
# Collects pass/fail results for all testbenches.
#
# LOGGING:
#   Full XSIM output for FAILED testbenches is saved to:
#       xsim_logs/<tb_name>.log
#   If a previously-failed testbench PASSES on a later run, its old failure
#   log is automatically deleted. After every run, xsim_logs/ contains logs
#   for ONLY the testbenches that failed in that run.
#   NO regression_summary.txt is generated.
#
# CLEANUP:
#   Vivado junk files (.wbd, .jou, .pb, backup.log, webtalk*, etc.) are
#   deleted after every xvlog/xelab/xsim invocation and at script end.
#
# Usage:
#   bash run_all_vivado_tb.sh
# =============================================================================

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

# --- Per-testbench XSIM log directory (fail-only) ---
LOG_DIR="$PROJECT_ROOT/xsim_logs"
mkdir -p "$LOG_DIR"
# Sweep any orphaned .tmp_* files from a previously-interrupted run
rm -f "$LOG_DIR"/.tmp_*.log

# --- Per-test wall-clock timeout for xsim (seconds) ---
# If a TB has an infinite loop or a 2-billion-timeunit watchdog, xsim would
# otherwise block the whole regression. 300s = 5 min per test is plenty.
XSIM_TIMEOUT=300

# --- Helper: remove Vivado junk files ---
# Vivado creates .wbd (waveform database) during xelab, and backup.log/.jou/.pb
# during xvlog/xelab/xsim. These are written ASYNCHRONOUSLY by Vivado background
# processes AFTER the main tool exits. We use find (more reliable than rm -f
# with globs) and poll for up to 10 seconds to catch them.
cleanup_vivado_junk() {
    local i remaining
    for i in $(seq 1 10); do
        # Delete all junk patterns using find (handles no-match gracefully)
        find "$PROJECT_ROOT"  -name "*.wbd" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "backup.log*" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "*.jou" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "*.pb" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "*.str" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "xvlog.log" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "xelab.log" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "xsim.log" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "webtalk*.log" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name "webtalk*.zip" -delete 2>/dev/null
        find "$PROJECT_ROOT"  -name ".Xil" -delete 2>/dev/null
        # Check if any junk files remain using find (reliable, no glob issues)
        remaining=$(find "$PROJECT_ROOT"  \( -name "*.wbd" -o -name "backup.log*" -o -name "*.jou" -o -name "*.pb" \) 2>/dev/null | wc -l)
        if [ "$remaining" -eq 0 ]; then
            break
        fi
        sleep 1
    done
}
trap cleanup_vivado_junk EXIT
cleanup_vivado_junk

echo "================================================================"
echo "Vivado XSIM — Run ALL Testbenches"
echo "Project: $PROJECT_ROOT"
echo "================================================================"

# --- Step 1: Compile all RTL + TBs ---
echo ""
echo "=== STEP 1: COMPILE ALL ==="
# BUGFIX: delete cached compiled library to force full recompile.
# xvlog uses incremental compilation — if source files have the same or older
# timestamps as the cached objects in xsim.dir/work, Vivado skips recompilation.
# Deleting xsim.dir forces a clean recompile so the latest RTL fixes take effect.
echo "  Deleting cached xsim.dir/work for clean recompile..."
rm -rf "$PROJECT_ROOT/xsim.dir"
bash 1_vivado_xvlog_compile.sh
cleanup_vivado_junk



# --- List of testbenches to run (automatically discovered) ---
echo "  Discovering testbenches in tb/ and tb_uvm/..."
TBS=( $(
    (
        # Handle cases where the directory might not exist or be empty
        [ -d "tb" ] && cd tb && \
        for f in tb_*.sv; do
            [ -f "$f" ] && basename "$f" .sv
        done && \
        cd ..
    )
    (
        [ -d "tb_uvm" ] && cd tb_uvm && \
        for f in tb_uvm_*.sv; do
            [ -f "$f" ] && basename "$f" .sv
        done && \
        cd ..
    )
) )
echo "  Found ${#TBS[@]} valid top-level testbenches to run."

echo ""
echo "================================================================"
echo "STEP 2+3: ELABORATE + SIMULATE EACH TESTBENCH"
echo "================================================================"

PASS_COUNT=0
FAIL_COUNT=0
RESULTS=""

for tb in "${TBS[@]}"; do
    echo ""
    echo "--- $tb ---"

    # Elaborate
    echo "  Elaborating..."
    xelab_log="${LOG_DIR}/${tb}_elab.log"
    xelab -L work -debug typical $tb -s "sim_${tb}" > "$xelab_log" 2>&1

    # Check if elaborate succeeded
    if [ ! -d "xsim.dir/sim_${tb}" ]; then
        echo "  RESULT: ELABORATE FAILED (see ${xelab_log})"
        RESULTS="${RESULTS}\n  FAIL: $tb (elaborate failed)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
        cleanup_vivado_junk
        continue
    else
        # Elaboration succeeded, remove the log
        rm -f "$xelab_log"
    fi

    # Simulate in batch mode
    echo "  Simulating..."
    output=$(timeout "$XSIM_TIMEOUT" xsim "sim_${tb}" -tclbatch run_sim.tcl 2>&1)
    xsim_exit=$?
    if [ "$xsim_exit" -eq 124 ]; then
        output="RESULT: TIMEOUT — xsim exceeded ${XSIM_TIMEOUT}s wall clock
${output}"
    fi

    # Show ALL summary/result/overall lines (broader grep)
    summary_lines=$(echo "$output" | grep -iE "SUMMARY:|RESULT:|OVERALL:|Passed:|Failed:|PASS:|FAIL:|TOTAL:" | tail -5)
    if [ -n "$summary_lines" ]; then
        echo "$summary_lines" | sed 's/^/    /'
    else
        # Show last 3 lines of output as fallback
        echo "$output" | tail -3 | sed 's/^/    /'
    fi

    # Determine pass/fail and manage log file accordingly
    if echo "$output" | grep -qiE "0 FAIL|ALL PASS|ALL TESTS PASS|OVERALL: PASS|RESULT: ALL PASS"; then
        # PASS — delete any old failure log from a previous run
        rm -f "$LOG_DIR/${tb}.log" 2>/dev/null
        RESULTS="${RESULTS}\n  PASS: $tb"
        PASS_COUNT=$((PASS_COUNT + 1))
    elif echo "$output" | grep -qiE "FAIL|ERROR|TIMEOUT"; then
        # FAIL — write the full xsim output to the failure log
        echo "$output" > "$LOG_DIR/${tb}.log"
        RESULTS="${RESULTS}\n  FAIL: $tb"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    elif echo "$output" | grep -qiE "PASS"; then
        # Has PASS lines but no explicit summary
        pass_count=$(echo "$output" | grep -ciE "\[PASS\]")
        rm -f "$LOG_DIR/${tb}.log" 2>/dev/null
        RESULTS="${RESULTS}\n  PASS: $tb ($pass_count tests, no summary)"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        # UNKNOWN — treat as fail, keep the log for inspection
        echo "$output" > "$LOG_DIR/${tb}.log"
        RESULTS="${RESULTS}\n  UNKNOWN: $tb (no test output)"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi

    # Clean up snapshot to save disk space
    rm -rf "xsim.dir/sim_${tb}"
    cleanup_vivado_junk
done

echo ""
echo "================================================================"
echo "ALL TESTBENCH RESULTS"
echo "================================================================"
echo -e "$RESULTS"
echo ""
echo "  Total PASS: $PASS_COUNT"
echo "  Total FAIL: $FAIL_COUNT"
echo "================================================================"

# Final sweep — wait 3 seconds for Vivado background processes to finish
# writing async files, then delete all junk. Do NOT delete xsim.dir — it
# contains the compiled work library and is needed for re-runs.
sleep 3
cleanup_vivado_junk
