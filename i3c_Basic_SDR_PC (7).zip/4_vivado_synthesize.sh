#!/bin/bash
# =============================================================================
# 4_vivado_synthesize.sh  —  STEP 4: SYNTHESIZE
# -----------------------------------------------------------------------------
# Runs Vivado synthesis on the RTL using the provided SDC and TCL scripts.
#
# Usage:
#   bash 4_vivado_synthesize.sh                              # Default SDC
#   bash 4_vivado_synthesize.sh syn/i3c_controller.sdc       # Custom SDC
#
# Prerequisite: RTL files must be present (no compile needed — Vivado
# synthesis reads RTL directly, not the xsim.dir/ compiled library).
# =============================================================================

set -e

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

SDC_FILE="${1:-syn/i3c_controller.sdc}"
TCL_FILE="syn/syn_i3c_controller.tcl"

echo "================================================================"
echo "STEP 4: SYNTHESIZE (Vivado synthesis)"
echo "Project:  $PROJECT_ROOT"
echo "SDC:      $SDC_FILE"
echo "TCL:      $TCL_FILE"
echo "================================================================"

# --- Check files exist ---
if [ ! -f "$SDC_FILE" ]; then
    echo "ERROR: SDC file not found: $SDC_FILE"
    exit 1
fi
if [ ! -f "$TCL_FILE" ]; then
    echo "ERROR: Synthesis TCL file not found: $TCL_FILE"
    exit 1
fi

# --- Run synthesis ---
echo ""
echo "--- Running Vivado synthesis (batch mode) ---"
echo "--- This may take several minutes ---"
vivado -mode batch -source "$TCL_FILE"

echo ""
echo "================================================================"
echo "STEP 4 COMPLETE: Synthesis done."
echo "Output: syn/ directory with netlist and reports"
echo "================================================================"
