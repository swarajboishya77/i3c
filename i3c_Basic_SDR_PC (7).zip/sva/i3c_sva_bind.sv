// =============================================================================
// i3c_sva_bind.sv
// Bind assertion module to RTL instances
// =============================================================================

bind i3c_primary_controller_sdr i3c_controller_sva u_sva (
    .s_axi_aclk      (s_axi_aclk),
    .s_axi_aresetn   (s_axi_aresetn),
    .ctrl_state      (ctrl_state),
    .scl_out         (scl_out),
    .sda_out         (sda_out),
    .scl_oe          (scl_oe),
    .sda_oe          (sda_oe),
    .start_req       (fsm_req_start),
    .stop_req        (fsm_req_stop),
    .bit_done        (bit_done),
    .cfg_scl_high_time (cfg_scl_high_time),
    .cfg_scl_low_time  (cfg_scl_low_time),
    .cfg_bus_free_time (cfg_bus_free_time),
    .timing_guard_en   (timing_guard_en),
    .ccc_done          (ccc_done),
    .daa_done          (daa_done),
    .ibi_done          (ibi_done),
    .resp_code         (resp_code)
);

