// =============================================================================
// i3c_controller_sva.sv
// SystemVerilog Assertions for I3C Controller Formal Verification
// Bind to i3c_primary_controller_sdr for formal/simulation
// =============================================================================

module i3c_controller_sva (
    input logic s_axi_aclk,
    input logic s_axi_aresetn,
    input logic [5:0] ctrl_state,
    input logic scl_out,
    input logic sda_out,
    input logic scl_oe,
    input logic sda_oe,
    input logic start_req,
    input logic stop_req,
    input logic bit_done,
    input logic [17:0] cfg_scl_high_time,
    input logic [17:0] cfg_scl_low_time,
    input logic [17:0] cfg_bus_free_time,
    input logic timing_guard_en,
    input logic ccc_done,
    input logic daa_done,
    input logic ibi_done,
    input logic [3:0] resp_code
);

  import i3c_pkg::*;

  // 1. FSM Reset Properties
  property p_fsm_reset;
    @(posedge s_axi_aclk) !s_axi_aresetn |-> ##1 (ctrl_state == CTRL_IDLE);
  endproperty
  a_fsm_reset: assert property (p_fsm_reset);

  // 2. SCL/SDA Never Both Driven in Push-Pull Data Phase
  property p_no_scl_sda_clash;
    @(posedge s_axi_aclk)
    (ctrl_state == CTRL_DATA_TX || ctrl_state == CTRL_DATA_RX) |->
      !(scl_oe && sda_oe && scl_out && !sda_out);
  endproperty
  a_no_clash: assert property (p_no_scl_sda_clash);

  // 3. tBUF Minimum Compliance
  property p_tbuf_min_pure;
    @(posedge s_axi_aclk)
    disable iff (!s_axi_aresetn)
    (stop_req && timing_guard_en) |-> ##[250:$] (ctrl_state == CTRL_START_GEN);
  endproperty
  a_tbuf_min: assert property (p_tbuf_min_pure);

  // 4. CCC/DAA Response Codes Valid
  property p_resp_code_valid;
    @(posedge s_axi_aclk)
    (ccc_done || daa_done) |-> (resp_code inside {RESP_OK, RESP_NACK_ADDR, RESP_NACK_DATA,
                                                   RESP_TIMEOUT, RESP_BUS_ERR, RESP_DAA_COLLISION});
  endproperty
  a_resp_valid: assert property (p_resp_code_valid);

  // 5. No Infinite PHY Wait
  property p_phy_timeout;
    @(posedge s_axi_aclk)
    disable iff (!s_axi_aresetn)
    (ctrl_state != CTRL_IDLE) |-> ##[1000:$] (ctrl_state == CTRL_IDLE || ctrl_state == CTRL_DONE);
  endproperty
  a_phy_timeout: assert property (p_phy_timeout);

  // 6. Clock Gating Safety
  property p_clk_gate_idle_only;
    @(posedge s_axi_aclk)
    (clk_gate_en) |-> (ctrl_state == CTRL_IDLE);
  endproperty
  a_clk_gate_safe: assert property (p_clk_gate_idle_only);

  // 7. IBI Priority Ordering
  property p_ibi_priority;
    @(posedge s_axi_aclk)
    (ibi_done) |-> (resp_code == RESP_OK || resp_code == RESP_IBI_NACK);
  endproperty
  a_ibi_priority: assert property (p_ibi_priority);

  // 8. Reset Synchronization
  property p_reset_sync;
    @(posedge s_axi_aclk)
    $fell(s_axi_aresetn) |-> ##[1:3] (ctrl_state == CTRL_IDLE);
  endproperty
  a_reset_sync: assert property (p_reset_sync);

endmodule : i3c_controller_sva
