// =============================================================================
// tb_uvm_ibi_full.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for i3c_ibi_handler.sv
// Icarus Verilog 12.0 compatible.
// =============================================================================

import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_ibi_full;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  // IBI Handler Interface
  logic        ibi_enable = 1;
  logic        bus_idle = 1;
  logic        controller_idle = 1;
  logic        sda_i = 1;
  logic        scl_i = 1;
  logic        ibi_req_bus;
  logic        ibi_req_start;
  logic        ibi_req_recv_byte;
  logic        ibi_req_nack;
  logic        ibi_req_stop;
  logic        bus_done = 0;
  logic        bus_ack_recv = 0;
  logic [7:0]  bus_byte_rx = 0;
  logic        ibi_fifo_push;
  logic [31:0] ibi_fifo_push_data;
  logic        ibi_irq;
  logic        ibi_active;
  logic        crr_received;
  logic [6:0]  crr_dev_addr;
  logic [6:0]  ibi_detected_addr;
  logic        hj_received;
  logic [6:0]  ibi_lookup_da;
  logic [3:0]  ibi_lookup_idx = 0;
  logic        ibi_lookup_valid = 0;
  logic [15:0] ibi_lookup_mrl = 0;
  logic [7:0]  ibi_lookup_ibi_max = 0;
  logic [7:0]  ibi_lookup_bcr = 0;

  i3c_ibi_handler u_ibi (
      .clk(clk),
      .rst_n(rst_n),
      .ibi_enable(ibi_enable),
      .bus_idle(bus_idle),
      .controller_idle(controller_idle),
      .sda_i(sda_i),
      .scl_i(scl_i),
      .ibi_req_bus(ibi_req_bus),
      .ibi_req_start(ibi_req_start),
      .ibi_req_recv_byte(ibi_req_recv_byte),
      .ibi_req_nack(ibi_req_nack),
      .ibi_req_stop(ibi_req_stop),
      .bus_done(bus_done),
      .bus_ack_recv(bus_ack_recv),
      .bus_byte_rx(bus_byte_rx),
      .ibi_fifo_push(ibi_fifo_push),
      .ibi_fifo_push_data(ibi_fifo_push_data),
      .ibi_irq(ibi_irq),
      .ibi_active(ibi_active),
      .crr_received(crr_received),
      .crr_dev_addr(crr_dev_addr),
      .ibi_detected_addr(ibi_detected_addr),
      .hj_received(hj_received),
      .ibi_lookup_da(ibi_lookup_da),
      .ibi_lookup_idx(ibi_lookup_idx),
      .ibi_lookup_valid(ibi_lookup_valid),
      .ibi_lookup_mrl(ibi_lookup_mrl),
      .ibi_lookup_ibi_max(ibi_lookup_ibi_max),
      .ibi_lookup_bcr(ibi_lookup_bcr)
  );

  int sb_pass = 0, sb_fail = 0, sb_cov = 0;

  // Mock Target Table lookup
  always_comb begin
      if (ibi_lookup_da == 7'h5A) begin
          ibi_lookup_valid = 1;
          ibi_lookup_idx = 4'd1;
          ibi_lookup_mrl = 16'd10;
          ibi_lookup_ibi_max = 8'd4;
          ibi_lookup_bcr = 8'h06; // BCR[1] = 1 (IBI), BCR[2] = 1 (Payload)
      end else if (ibi_lookup_da == 7'h6B) begin
          ibi_lookup_valid = 1;
          ibi_lookup_idx = 4'd2;
          ibi_lookup_mrl = 16'd5;
          ibi_lookup_ibi_max = 8'd0;
          ibi_lookup_bcr = 8'h40; // BCR[6] = 1 (Controller capable)
      end else begin
          ibi_lookup_valid = 0;
          ibi_lookup_idx = 0;
          ibi_lookup_mrl = 0;
          ibi_lookup_ibi_max = 0;
          ibi_lookup_bcr = 0;
      end
  end

  // Bus tasks
  task trigger_start();
      sda_i = 1; scl_i = 1;
      #20000;
      sda_i = 0; // START
      #20000;
      scl_i = 0;
      #20000;
  endtask

  task trigger_stop();
      sda_i = 0; scl_i = 0;
      #20000;
      scl_i = 1;
      #20000;
      sda_i = 1; // STOP
      #20000;
  endtask

  task send_bit(input logic b);
      sda_i = b;
      #10000;
      scl_i = 1;
      #20000;
      scl_i = 0;
      #10000;
  endtask

  task send_byte(input logic [7:0] data);
      int i;
      for (i = 7; i >= 0; i--) begin
          send_bit(data[i]);
      end
  endtask

  always @(u_ibi.state) begin
      $display("[%0t] u_ibi state changed to: %0d", $time, u_ibi.state);
  end

  always @(u_ibi.payload_cnt) begin
      if (u_ibi.state == 6) // IBI_RECV_PAYLOAD
          $display("[%0t] payload_cnt = %0d", $time, u_ibi.payload_cnt);
  end

  // Helper to wait for a request and acknowledge it
  task ack_req_bus();
      $display("[%0t] ack_req_bus: waiting for ibi_req_bus...", $time);
      while (!ibi_req_bus) @(posedge clk);
      $display("[%0t] ack_req_bus: received ibi_req_bus, acknowledging...", $time);
      @(posedge clk);
      bus_done <= 1'b1;
      @(posedge clk);
      bus_done <= 1'b0;
  endtask

  task ack_req_recv_byte(input logic [7:0] data, input logic last_byte);
      $display("[%0t] ack_req_recv_byte: waiting for ibi_req_recv_byte...", $time);
      while (!ibi_req_recv_byte) @(posedge clk);
      $display("[%0t] ack_req_recv_byte: received request, driving bus...", $time);
      // Drive the byte on the bus so the handler can sample it
      send_byte(data);
      send_bit(1'b1); // T-bit (dummy)
      @(posedge clk);
      bus_ack_recv <= ~last_byte; // If last_byte, simulate NACK/end
      bus_done <= 1'b1;
      @(posedge clk);
      bus_done <= 1'b0;
  endtask

  task ack_req_stop();
      $display("[%0t] ack_req_stop: waiting for ibi_req_stop...", $time);
      while (!ibi_req_stop) @(posedge clk);
      $display("[%0t] ack_req_stop: received request, driving STOP...", $time);
      trigger_stop();
      @(posedge clk);
      bus_done <= 1'b1;
      @(posedge clk);
      bus_done <= 1'b0;
  endtask

  initial begin
      $dumpfile("/tmp/uvm_ibi_full.vcd");
      $dumpvars(0, tb_uvm_ibi_full);

      // Timeout
      fork
          begin
              #5000000;
              $display("[%0t] TIMEOUT REACHED!", $time);
              $finish;
          end
      join_none

      // Reset
      rst_n = 0;
      #20000;
      rst_n = 1;
      #20000;

      // ------------------------------------------------------------------
      // T1: Normal IBI (Target Interrupt) with MDB and Payload
      // ------------------------------------------------------------------
      $display("[%0t] === T1: Target Interrupt (SIR) ===", $time);
      trigger_start();
      
      // Target sends address 0x5A + Read (1)
      send_byte({7'h5A, 1'b1});
      
      // 9th bit (ACK = 0)
      send_bit(1'b0);

      // Handler should request bus
      ack_req_bus();

      // Handler requests MDB
      ack_req_recv_byte(8'hDE, 0); // MDB = DE
      
      // Handler requests Payload (because BCR[2]=1)
      ack_req_recv_byte(8'hAD, 0); // Payload 1
      ack_req_recv_byte(8'hBE, 1); // Payload 2 (last byte)
      
      // Handler requests STOP
      ack_req_stop();

      // Check FIFO
      if (ibi_fifo_push === 1'b1 && ibi_fifo_push_data[7:0] === 8'hDE) begin
          $display("[%0t] T1 PASS: MDB correctly pushed", $time);
          sb_pass++;
      end else begin
          $display("[%0t] T1 FAIL: Expected MDB 0xDE, got %h", $time, ibi_fifo_push_data[7:0]);
          sb_fail++;
      end
      sb_cov++;
      
      #100000;

      // ------------------------------------------------------------------
      // T2: Controller Role Request (CRR)
      // ------------------------------------------------------------------
      $display("[%0t] === T2: Controller Role Request (CRR) ===", $time);
      trigger_start();
      
      // Target sends address 0x6B + Write (0)
      send_byte({7'h6B, 1'b0});
      
      // 9th bit (ACK)
      send_bit(1'b0); 

      ack_req_bus(); // Grants bus, CRR completes immediately without MDB
      
      ack_req_stop();

      if (crr_received && crr_dev_addr === 7'h6B) begin
          $display("[%0t] T2 PASS: CRR received from 6B", $time);
          sb_pass++;
      end else begin
          $display("[%0t] T2 FAIL: CRR dev addr %h", $time, crr_dev_addr);
          sb_fail++;
      end
      sb_cov++;
      
      #100000;
      
      // ------------------------------------------------------------------
      // T3: Hot-Join Request
      // ------------------------------------------------------------------
      $display("[%0t] === T3: Hot-Join (HJ) ===", $time);
      trigger_start();
      
      // Target sends address 0x02 + Write (0)
      send_byte({7'h02, 1'b0});
      
      // 9th bit (ACK)
      send_bit(1'b0); 

      ack_req_bus();
      ack_req_stop();

      if (hj_received) begin
          $display("[%0t] T3 PASS: HJ received", $time);
          sb_pass++;
      end else begin
          $display("[%0t] T3 FAIL: HJ not received", $time);
          sb_fail++;
      end
      sb_cov++;

      #100000;

      // Finish
      $display("\n============================================================");
      $display("SCOREBOARD REPORT");
      $display("  Pass: %0d", sb_pass);
      $display("  Fail: %0d", sb_fail);
      $display("  Cov samples: %0d", sb_cov);
      $display("============================================================\n");
      
      if (sb_fail == 0) begin
          $display("UVM IBI TEST SUMMARY");
          $display("  RESULT: ALL TESTS PASS");
      end else begin
          $display("UVM IBI TEST SUMMARY");
          $display("  RESULT: %0d FAILURES", sb_fail);
      end
      $display("============================================================\n");
      $finish;
  end

endmodule
