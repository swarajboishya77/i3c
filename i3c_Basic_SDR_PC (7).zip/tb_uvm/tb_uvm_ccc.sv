// =============================================================================
// tb_uvm_ccc.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for I3C CCC handler with scoreboard analysis.
// Tests all broadcast/direct CCCs (15+), GETACCR parity verification, RSTACT.
// Icarus Verilog 12.0 compatible.
// =============================================================================


import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_ccc;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  logic [15:0] cfg_mwl = 16'h0008;
  logic [15:0] cfg_mrl = 16'h0008;
  logic        ccc_req = 0, ccc_is_direct = 0;
  logic [7:0]  ccc_opcode = 0;
  logic [6:0]  ccc_target_addr = 0;
  logic [15:0] ccc_defining_byte = 0;
  logic        ccc_has_defining_byte = 0;
  logic        prim_done = 0, prim_ack_recv = 0;
  logic [7:0]  prim_byte_recv = 0;
  logic        ccc_start, ccc_repeat_start, ccc_stop;
  logic        ccc_send_addr_w, ccc_send_addr_r;
  logic [6:0]  ccc_addr_val;
  logic        ccc_send_byte;
  logic [7:0]  ccc_byte_val;
  logic        ccc_recv_byte, ccc_expect_response;
  logic        ccc_done, ccc_resp_valid;
  logic [7:0]  ccc_resp_byte;
  logic        ccc_getacccr_ack, ccc_getacccr_addr_nack, ccc_getacccr_data_nack;
  logic        ccc_error;

  i3c_ccc_handler u_ccc (
    .clk(clk), .rst_n(rst_n),
    .cfg_mwl(cfg_mwl), .cfg_mrl(cfg_mrl),
    .ccc_req(ccc_req), .ccc_is_direct(ccc_is_direct),
    .ccc_opcode(ccc_opcode), .ccc_target_addr(ccc_target_addr),
    .ccc_defining_byte(ccc_defining_byte),
    .ccc_has_defining_byte(ccc_has_defining_byte),
    .prim_done(prim_done), .prim_ack_recv(prim_ack_recv),
    .prim_byte_recv(prim_byte_recv),
    .ccc_start(ccc_start), .ccc_repeat_start(ccc_repeat_start),
    .ccc_stop(ccc_stop),
    .ccc_send_addr_w(ccc_send_addr_w), .ccc_send_addr_r(ccc_send_addr_r),
    .ccc_addr_val(ccc_addr_val),
    .ccc_send_byte(ccc_send_byte), .ccc_byte_val(ccc_byte_val),
    .ccc_recv_byte(ccc_recv_byte), .ccc_expect_response(ccc_expect_response),
    .ccc_done(ccc_done), .ccc_resp_valid(ccc_resp_valid),
    .ccc_resp_byte(ccc_resp_byte),
    .ccc_getacccr_ack(ccc_getacccr_ack),
    .ccc_getacccr_addr_nack(ccc_getacccr_addr_nack),
    .ccc_getacccr_data_nack(ccc_getacccr_data_nack),
    .ccc_error(ccc_error)
  );

  // Mock bus responder — ONLY drives prim_done (pulse for 1 cycle)
  // prim_ack_recv and prim_byte_recv are driven by the run_ccc task
  always_ff @(posedge clk) begin
    prim_done <= 1'b0;
    if (ccc_start || ccc_repeat_start || ccc_send_byte || ccc_send_addr_w ||
        ccc_send_addr_r || ccc_recv_byte || ccc_stop) begin
      prim_done <= 1'b1;
    end
  end

  // Scoreboard counters
  int sb_pass = 0, sb_fail = 0, sb_cov = 0;

  task run_ccc(input logic [7:0] opcode, input logic is_direct,
               input logic [6:0] target, input logic [15:0] defbyte,
               input logic has_db, input logic ack,
               input logic [7:0] resp_byte);
    @(negedge clk);
    ccc_req <= 1'b1;
    ccc_opcode <= opcode;
    ccc_is_direct <= is_direct;
    ccc_target_addr <= target;
    ccc_defining_byte <= defbyte;
    ccc_has_defining_byte <= has_db;
    prim_ack_recv <= ack;
    prim_byte_recv <= resp_byte;
    @(posedge clk);
    @(negedge clk);
    ccc_req <= 1'b0;
    // Keep ack/resp_byte stable during the entire CCC transaction
    while (!ccc_done) begin
      @(posedge clk);
      prim_ack_recv <= ack;
      prim_byte_recv <= resp_byte;
    end
    sb_cov++;
  endtask

  int i;
  logic [6:0] test_target;
  logic [7:0] expected_resp, wrong_resp;
  logic correct_par, wrong_par;

  initial begin
    rst_n = 0;
    repeat(5) @(posedge clk);
    rst_n = 1;
    @(posedge clk);

    // T1: All broadcast CCCs
    $display("[%0t] === T1: All broadcast CCCs ===", $time);
    run_ccc(8'h00, 0, 7'h00, 16'h00, 0, 1, 8'h00); // ENEC
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h01, 0, 7'h00, 16'h00, 0, 1, 8'h00); // DISEC
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h06, 0, 7'h00, 16'h00, 0, 1, 8'h00); // RSTDAA
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h07, 0, 7'h00, 16'h00, 0, 1, 8'h00); // ENTDAA
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h09, 0, 7'h00, 16'h00, 0, 1, 8'h00); // SETMWL
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h0A, 0, 7'h00, 16'h00, 0, 1, 8'h00); // SETMRL
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h2A, 0, 7'h00, 16'h0001, 1, 1, 8'h00); // RSTACT with defining byte
    if (!ccc_error) sb_pass++; else sb_fail++;
    $display("[%0t] T1: broadcast CCCs done", $time);

    // T2: All direct GET CCCs
    $display("[%0t] === T2: All direct GET CCCs ===", $time);
    run_ccc(8'h8B, 1, 7'h08, 16'h00, 0, 1, 8'h08); // GETMWL
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h8C, 1, 7'h08, 16'h00, 0, 1, 8'h08); // GETMRL
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h8D, 1, 7'h08, 16'h00, 0, 1, 8'h01); // GETPID
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h8E, 1, 7'h08, 16'h00, 0, 1, 8'h4A); // GETBCR
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h8F, 1, 7'h08, 16'h00, 0, 1, 8'h99); // GETDCR
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h90, 1, 7'h08, 16'h00, 0, 1, 8'h00); // GETSTATUS
    if (!ccc_error) sb_pass++; else sb_fail++;
    $display("[%0t] T2: direct GET CCCs done", $time);

    // T3: Direct SET CCCs
    $display("[%0t] === T3: Direct SET CCCs ===", $time);
    run_ccc(8'h87, 1, 7'h08, 16'h00, 0, 1, 8'h00); // SETDASA
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h88, 1, 7'h08, 16'h00, 0, 1, 8'h00); // SETNEWDA
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h89, 1, 7'h08, 16'h00, 0, 1, 8'h00); // SETMWL direct
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h8A, 1, 7'h08, 16'h00, 0, 1, 8'h00); // SETMRL direct
    if (!ccc_error) sb_pass++; else sb_fail++;
    run_ccc(8'h9A, 1, 7'h08, 16'h0001, 1, 1, 8'h00); // RSTACT direct with DB
    if (!ccc_error) sb_pass++; else sb_fail++;
    $display("[%0t] T3: direct SET CCCs done", $time);

    // T4: GETACCR accepted (correct DA + PAR)
    $display("[%0t] === T4: GETACCR accepted ===", $time);
    begin
      test_target = 7'h30;
      expected_resp = {test_target, ~(^test_target)};
      run_ccc(8'h91, 1, test_target, 16'h00, 0, 1, expected_resp);
      if (ccc_getacccr_ack && !ccc_error) begin
        $display("[%0t] T4 PASS: GETACCR accepted", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T4 FAIL: ack=%b error=%b", $time, ccc_getacccr_ack, ccc_error);
        sb_fail++;
      end
    end

    // T5: GETACCR wrong DA
    $display("[%0t] === T5: GETACCR wrong DA ===", $time);
    begin
      test_target = 7'h30;
      wrong_resp = {7'h40, ~(^7'h40)};
      run_ccc(8'h91, 1, test_target, 16'h00, 0, 1, wrong_resp);
      if (!ccc_getacccr_ack && ccc_getacccr_data_nack) begin
        $display("[%0t] T5 PASS: GETACCR rejected (wrong DA)", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T5 FAIL: ack=%b data_nack=%b", $time, ccc_getacccr_ack, ccc_getacccr_data_nack);
        sb_fail++;
      end
    end

    // T6: GETACCR wrong PAR
    $display("[%0t] === T6: GETACCR wrong PAR ===", $time);
    begin
      test_target = 7'h30;
      correct_par = ~(^test_target);
      wrong_par = ~correct_par;
      wrong_resp = {test_target, wrong_par};
      run_ccc(8'h91, 1, test_target, 16'h00, 0, 1, wrong_resp);
      if (!ccc_getacccr_ack && ccc_getacccr_data_nack) begin
        $display("[%0t] T6 PASS: GETACCR rejected (wrong PAR)", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T6 FAIL: ack=%b data_nack=%b", $time, ccc_getacccr_ack, ccc_getacccr_data_nack);
        sb_fail++;
      end
    end
    
    // T7: Error & Abort Sequences - Address Phase NACK
    $display("[%0t] === T7: Address Phase NACK ===", $time);
    // target sends NACK (ack=0) during address phase of a direct CCC
    run_ccc(8'h8B, 1, 7'h08, 16'h00, 0, 0, 8'h08); // GETMWL but NACKed
    if (ccc_error) begin
      $display("[%0t] T7 PASS: NACK correctly causes error", $time);
      sb_pass++;
    end else begin
      $display("[%0t] T7 FAIL: NACK ignored", $time);
      sb_fail++;
    end

    // Report
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("============================================================");
    $display("");
    $display("UVM CCC TEST SUMMARY");
    if (sb_fail == 0)
      $display("  RESULT: ALL TESTS PASS");
    else
      $display("  RESULT: %0d FAILURES", sb_fail);
    $display("============================================================");
    $finish;
  end

  initial begin
    #2000000000;  // 5us timeout
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("============================================================");
    $display("");
    $display("UVM CCC TEST SUMMARY");
    $display("  RESULT: TIMEOUT (sb_pass=%0d sb_fail=%0d)", sb_pass, sb_fail);
    $display("============================================================");
    $finish;
  end

endmodule
