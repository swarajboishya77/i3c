// =============================================================================
// tb_uvm_axi4_lite.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for AXI4-Lite slave with scoreboard analysis.
// Icarus Verilog 12.0 compatible.
// =============================================================================


import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_axi4_lite;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  logic        s_axi_awvalid = 0, s_axi_awready;
  logic [31:0] s_axi_awaddr = 0;
  logic [2:0]  s_axi_awprot = 0;
  logic        s_axi_wvalid = 0, s_axi_wready;
  logic [31:0] s_axi_wdata = 0;
  logic [3:0]  s_axi_wstrb = 4'hF;
  logic        s_axi_bvalid, s_axi_bready = 1;
  logic [1:0]  s_axi_bresp;
  logic        s_axi_arvalid = 0, s_axi_arready;
  logic [31:0] s_axi_araddr = 0;
  logic [2:0]  s_axi_arprot = 0;
  logic        s_axi_rvalid, s_axi_rready = 1;
  logic [31:0] s_axi_rdata;
  logic [1:0]  s_axi_rresp;

  logic        reg_wr, reg_rd;
  logic [31:0] reg_wr_addr, reg_rd_addr;
  logic [31:0] reg_wr_data, reg_rd_data;
  logic [3:0]  reg_wr_strb;
  logic        reg_wr_ack, reg_rd_ack;

  logic [31:0] mock_regs [0:15];

  axi4_lite_slave #(.ADDR_W(32), .DATA_W(32)) u_axi (
    .clk(clk), .rst_n(rst_n),
    .s_axi_awvalid(s_axi_awvalid), .s_axi_awready(s_axi_awready), .s_axi_awaddr(s_axi_awaddr),
    .s_axi_awprot(s_axi_awprot),
    .s_axi_wvalid(s_axi_wvalid), .s_axi_wready(s_axi_wready), .s_axi_wdata(s_axi_wdata),
    .s_axi_wstrb(s_axi_wstrb),
    .s_axi_bvalid(s_axi_bvalid), .s_axi_bready(s_axi_bready), .s_axi_bresp(s_axi_bresp),
    .s_axi_arvalid(s_axi_arvalid), .s_axi_arready(s_axi_arready), .s_axi_araddr(s_axi_araddr),
    .s_axi_arprot(s_axi_arprot),
    .s_axi_rvalid(s_axi_rvalid), .s_axi_rready(s_axi_rready), .s_axi_rdata(s_axi_rdata),
    .s_axi_rresp(s_axi_rresp),
    .reg_wr(reg_wr), .reg_wr_addr(reg_wr_addr), .reg_wr_data(reg_wr_data),
    .reg_wr_strb(reg_wr_strb), .reg_wr_ack(reg_wr_ack),
    .reg_rd(reg_rd), .reg_rd_addr(reg_rd_addr), .reg_rd_data(reg_rd_data),
    .reg_rd_ack(reg_rd_ack)
  );

  // Mock RF: 16 registers at 0x00-0x3C. Addresses outside this range → NACK (SLVERR)
  // Storage is registered (always_ff); ack/data are combinational.
  // The AXI slave latches reg_wr_addr in W_IDLE, then asserts reg_wr in
  // W_ADDR_DATA (one cycle later). At that point reg_wr_addr is stable
  // (flop output), so the combinational ack is correct.
  // NOTE: reg_wr_ack is gated by reg_wr to ensure it only reflects the address
  // check during the actual write cycle. When reg_wr=0, ack defaults to 1
  // (OKAY) which is harmless because the AXI slave only samples it when
  // w_state == W_ADDR_DATA (which is when reg_wr=1).
  always_ff @(posedge clk) begin
    if (reg_wr) begin
      if (reg_wr_addr[31:0] <= 32'h3C)
        mock_regs[reg_wr_addr[5:2]] <= reg_wr_data;
    end
  end
  // When reg_wr is asserted, check the address. Otherwise, return OKAY (default).
  // The AXI slave's b_ack_lat only samples when w_state == W_ADDR_DATA,
  // which is exactly when reg_wr=1, so the address check is active.
  // BUGFIX: reg_wr_ack should NOT be gated by reg_wr. The AXI slave captures
  // b_ack_lat in W_ADDR_DATA (when reg_wr=1), but if reg_wr_ack depends on
  // reg_wr (combinational), there's a race in Vivado where reg_wr_ack may
  // evaluate before reg_wr settles. Instead, always check the address — when
  // reg_wr=0, the AXI slave doesn't sample reg_wr_ack anyway.
  assign reg_wr_ack  = (reg_wr_addr[31:0] <= 32'h3C) ? 1'b1 : 1'b0;
  assign reg_rd_ack  = (reg_rd_addr[31:0] <= 32'h3C) ? 1'b1 : 1'b0;
  assign reg_rd_data = (reg_rd_addr[31:0] <= 32'h3C) ? mock_regs[reg_rd_addr[5:2]] : 32'hFFFF_FFFF;

  // UVM scoreboard (simple counters — Icarus-compatible)
  int sb_pass = 0;
  int sb_fail = 0;
  int sb_mismatch = 0;
  int sb_cov_samples = 0;
  bit test_done = 1'b0;  // set when test completes normally

  task axi_write(input logic [31:0] addr, input logic [31:0] data,
                 output logic [1:0] bresp);
    logic aw_done = 0, w_done = 0;
    @(negedge clk);
    s_axi_awvalid = 1; s_axi_awaddr = addr;
    s_axi_wvalid  = 1; s_axi_wdata  = data; s_axi_wstrb = 4'hF;
    s_axi_bready  = 1;
    while (!aw_done || !w_done) begin
      @(posedge clk);
      if (s_axi_awvalid && s_axi_awready) aw_done = 1;
      if (s_axi_wvalid  && s_axi_wready)  w_done  = 1;
      @(negedge clk);
      if (aw_done) s_axi_awvalid = 0;
      if (w_done)  s_axi_wvalid  = 0;
    end
    while (!s_axi_bvalid) @(posedge clk);
    bresp = s_axi_bresp;
    @(negedge clk);
    s_axi_bready = 0;
    sb_cov_samples++;
  endtask

  task axi_read(input logic [31:0] addr,
                output logic [31:0] rdata, output logic [1:0] rresp);
    @(negedge clk);
    s_axi_arvalid = 1; s_axi_araddr = addr;
    s_axi_rready  = 1;
    while (!(s_axi_arvalid && s_axi_arready)) @(posedge clk);
    @(negedge clk);
    s_axi_arvalid = 0;
    while (!s_axi_rvalid) @(posedge clk);
    rdata = s_axi_rdata;
    rresp = s_axi_rresp;
    @(negedge clk);
    s_axi_rready = 0;
    sb_cov_samples++;
  endtask

  int i;
  logic [31:0] rdata;
  logic [1:0]  resp;

  initial begin : sim
    for (i = 0; i < 16; i++) mock_regs[i] = 0;
    

    rst_n = 0;
    repeat(5) @(posedge clk);
    rst_n = 1;
    @(posedge clk);

    // T1: Single write + readback
    $display("[%0t] === T1: Single write + readback ===", $time);
    axi_write(32'h0000_0010, 32'hDEAD_BEEF, resp);
    axi_read(32'h0000_0010, rdata, resp);
    if (rdata === 32'hDEAD_BEEF) begin
      $display("[%0t] T1 PASS: readback 0x%08x", $time, rdata);
      sb_pass++;
    end else begin
      $display("[%0t] T1 FAIL: got 0x%08x", $time, rdata);
      sb_fail++;
    end

    // T2: Back-to-back writes
    $display("[%0t] === T2: Back-to-back writes ===", $time);
    for (i = 0; i < 10; i++) begin
      axi_write(32'h0000_0000 + i*4, 32'hA000_0000 + i, resp);
      if (resp == 2'b00) sb_pass++; else sb_fail++;
    end

    // T3: Back-to-back reads
    $display("[%0t] === T3: Back-to-back reads ===", $time);
    for (i = 0; i < 10; i++) begin
      axi_read(32'h0000_0000 + i*4, rdata, resp);
      if (rdata === 32'hA000_0000 + i) sb_pass++;
      else begin
        $display("[%0t] T3[%0d] FAIL: got 0x%08x, exp 0x%08x", $time, i, rdata, 32'hA000_0000 + i);
        sb_fail++;
      end
    end

    // T4: Write to invalid address (SLVERR)
    $display("[%0t] === T4: Write to invalid address ===", $time);
    axi_write(32'h0000_0100, 32'hCAFE_BABE, resp);
    if (resp == 2'b10) begin
      $display("[%0t] T4 PASS: SLVERR", $time);
      sb_pass++;
    end else begin
      $display("[%0t] T4 FAIL: expected SLVERR, got %b", $time, resp);
      sb_fail++;
    end

    // T5: Read from invalid address (SLVERR)
    $display("[%0t] === T5: Read from invalid address ===", $time);
    axi_read(32'h0000_0100, rdata, resp);
    if (resp == 2'b10) begin
      $display("[%0t] T5 PASS: SLVERR", $time);
      sb_pass++;
    end else begin
      $display("[%0t] T5 FAIL: expected SLVERR, got %b", $time, resp);
      sb_fail++;
    end

    // T6: Random transactions
    $display("[%0t] === T6: Random transactions ===", $time);
    for (i = 0; i < 20; i++) begin
      if (i % 2 == 0)
        axi_write($random, $random, resp);
      else
        axi_read($random, rdata, resp);
      if (resp == 2'b00 || resp == 2'b10) sb_pass++;
      else sb_fail++;
    end

    // Report — ONE summary only
    $display("");
    $display("============================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", sb_pass, (sb_fail + sb_mismatch));
    if ((sb_fail + sb_mismatch) == 0)
      $display("OVERALL: PASS");
    else
      $display("OVERALL: FAIL");
    $display("============================================================");
    test_done = 1'b1;
    $finish;
  end

  // Watchdog — only fires if test didn't complete
  initial begin
    #2000000000;
    if (test_done) $finish;
    $display("");
    $display("============================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", sb_pass, (sb_fail + sb_mismatch));
    $display("OVERALL: FAIL (watchdog timeout)");
    $display("============================================================");
    $finish;
  end

endmodule
