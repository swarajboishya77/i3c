// =============================================================================
// tb_uvm_multi_target.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for DAA and Target Table with 16 targets.
// Tests: ENTDAA for 16 active targets, verifying address assignment, collision,
// and target table storage logic.
// =============================================================================


import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_multi_target;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  logic        start_entdaa = 0, start_setdasa = 0;
  logic [6:0]  setdasa_static_addr = 0;
  logic        tgt_table_full;
  logic [3:0]  tgt_table_count;
  logic        req_start, req_repeat_start, req_stop;
  logic        req_send_byte, req_recv_byte;
  logic        req_send_ack, req_send_nack;
  logic        req_send_addr_w, req_send_addr_r;
  logic [6:0]  req_addr_val;
  logic [7:0]  req_send_byte_val;
  logic        prim_done = 0, prim_ack_recv = 0;
  logic [7:0]  prim_byte_recv = 0;
  logic        daa_done, daa_target_found;
  logic [47:0] daa_pid;
  logic [7:0]  daa_bcr, daa_dcr;
  logic [6:0]  daa_dyn_addr_assigned;
  logic        daa_recv_last_byte;

  i3c_daa u_daa (
    .clk(clk), .rst_n(rst_n),
    .start_entdaa(start_entdaa), .start_setdasa(start_setdasa),
    .setdasa_static_addr(setdasa_static_addr),
    .tgt_table_full(tgt_table_full), .tgt_table_count(tgt_table_count),
    .req_start(req_start), .req_repeat_start(req_repeat_start),
    .req_stop(req_stop),
    .req_send_byte(req_send_byte), .req_send_byte_val(req_send_byte_val),
    .req_recv_byte(req_recv_byte),
    .req_send_ack(req_send_ack), .req_send_nack(req_send_nack),
    .req_send_addr_w(req_send_addr_w), .req_send_addr_r(req_send_addr_r),
    .req_addr_val(req_addr_val),
    .prim_done(prim_done), .prim_ack_recv(prim_ack_recv),
    .prim_byte_recv(prim_byte_recv),
    .daa_done(daa_done), .daa_target_found(daa_target_found),
    .daa_pid(daa_pid), .daa_bcr(daa_bcr), .daa_dcr(daa_dcr),
    .daa_dyn_addr_assigned(daa_dyn_addr_assigned),
    .daa_recv_last_byte(daa_recv_last_byte)
  );

  // Target Table
  logic        ccc_wr_en = 0, ccc_wr_mrl = 0, ccc_wr_mwl = 0, ccc_wr_ibi_max = 0;
  logic [3:0]  ccc_wr_idx = 0;
  logic [15:0] ccc_wr_mrl_val = 0, ccc_wr_mwl_val = 0;
  logic [7:0]  ccc_wr_ibi_val = 0;
  logic [6:0]  ibi_lookup_da = 0;
  logic [3:0]  ibi_lookup_idx;
  logic        ibi_lookup_valid;
  logic [15:0] ibi_lookup_mrl;
  logic [7:0]  ibi_lookup_ibi_max, ibi_lookup_bcr;
  logic [3:0]  reg_addr = 0;
  logic        reg_wr_en = 0;
  logic [127:0] reg_wr_data = 0, reg_rd_data;
  logic [15:0] tgt_valid;

  i3c_target_table u_tgt_table (
    .clk(clk), .rst_n(rst_n),
    .daa_wr_en(daa_target_found), // Written when DAA finishes a target
    .daa_wr_idx(tgt_table_count),
    .daa_wr_da(daa_dyn_addr_assigned),
    .daa_wr_bcr(daa_bcr), .daa_wr_dcr(daa_dcr), .daa_wr_pid(daa_pid),
    .ccc_wr_en(ccc_wr_en), .ccc_wr_idx(ccc_wr_idx),
    .ccc_wr_mrl(ccc_wr_mrl), .ccc_wr_mwl(ccc_wr_mwl),
    .ccc_wr_ibi_max(ccc_wr_ibi_max),
    .ccc_wr_mrl_val(ccc_wr_mrl_val), .ccc_wr_mwl_val(ccc_wr_mwl_val),
    .ccc_wr_ibi_val(ccc_wr_ibi_val),
    .ibi_lookup_da(ibi_lookup_da),
    .ibi_lookup_idx(ibi_lookup_idx), .ibi_lookup_valid(ibi_lookup_valid),
    .ibi_lookup_mrl(ibi_lookup_mrl), .ibi_lookup_ibi_max(ibi_lookup_ibi_max),
    .ibi_lookup_bcr(ibi_lookup_bcr),
    .reg_addr(reg_addr), .reg_wr_en(reg_wr_en),
    .reg_wr_data(reg_wr_data), .reg_rd_data(reg_rd_data),
    .tgt_count(tgt_table_count), .tgt_valid(tgt_valid),
    .tgt_table_full(tgt_table_full)
  );

  // Mock bus responder
  integer byte_idx = 0;
  logic [7:0] pid_bytes [0:5];
  // Track how many targets we've "found" — NACK the 7E/R to end DAA
  logic [4:0] targets_found = 0;
  logic [4:0] max_targets_to_find = 0;
  logic       mock_reset = 0;

  // Timeout-safe wait helper: avoid infinite hang if DAA FSM stalls
  task wait_daa_target_found;
    integer timeout_cnt;
    begin
      timeout_cnt = 0;
      while (!daa_target_found && timeout_cnt < 5000) begin
        @(posedge clk);
        timeout_cnt = timeout_cnt + 1;
      end
    end
  endtask

  task wait_daa_done;
    integer timeout_cnt;
    begin
      timeout_cnt = 0;
      while (!daa_done && timeout_cnt < 5000) begin
        @(posedge clk);
        timeout_cnt = timeout_cnt + 1;
      end
    end
  endtask

  always_ff @(posedge clk) begin
    prim_done <= 1'b0;
    if (mock_reset) begin
      targets_found <= 0;
    end else if (daa_done) begin
      // Release DAA FSM from D_DONE/D_ERROR states (no req asserted there)
      prim_done <= 1'b1;
    end else if (req_start || req_repeat_start || req_stop || req_send_addr_w) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
      byte_idx <= 0;
    end else if (req_send_addr_r) begin
      // 7E/R: ACK first time (target present), NACK second time (no more targets)
      prim_done <= 1'b1;
      if (targets_found < max_targets_to_find) begin
        prim_ack_recv <= 1'b1;  // ACK — target is present
        byte_idx <= 0;
      end else begin
        prim_ack_recv <= 1'b0;  // NACK — no more targets, DAA ends
      end
    end else if (req_send_byte) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
    end else if (req_recv_byte) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
      if (byte_idx < 6) begin
        prim_byte_recv <= pid_bytes[byte_idx];
        byte_idx <= byte_idx + 1;
      end else if (byte_idx == 6) begin
        prim_byte_recv <= 8'h4A;  // BCR
        byte_idx <= byte_idx + 1;
      end else if (byte_idx == 7) begin
        prim_byte_recv <= 8'h99;  // DCR
        byte_idx <= 0;
        targets_found <= targets_found + 1;  // target complete
        pid_bytes[0] <= pid_bytes[0] + 1;    // change PID for next target!
      end
    end
  end

  // Scoreboard
  int sb_pass = 0, sb_fail = 0, sb_cov = 0;
  int reserved_count = 0;

  // Reserved address checker
  function automatic logic is_reserved(input logic [6:0] da);
    if (da <= 7'h07) return 1'b1;
    if (da == 7'h3E || da == 7'h5E || da == 7'h6E ||
        da == 7'h76 || da == 7'h7A || da == 7'h7C ||
        da == 7'h7E || da == 7'h7F) return 1'b1;
    return 1'b0;
  endfunction

  int i;
  logic [47:0] expected_pid;

  initial begin
    rst_n = 0;
    mock_reset = 1;
    max_targets_to_find = 16;
    repeat(5) @(posedge clk);
    rst_n = 1;
    mock_reset = 0;
    @(posedge clk);

    // T1: ENTDAA for 16 targets
    $display("[%0t] === T1: ENTDAA 16 targets ===", $time);
    pid_bytes[0] = 8'h11; pid_bytes[1] = 8'h22; pid_bytes[2] = 8'h33;
    pid_bytes[3] = 8'h44; pid_bytes[4] = 8'h55; pid_bytes[5] = 8'h66;
    
    start_entdaa = 1;
    @(posedge clk);
    start_entdaa = 0;

    for (i = 0; i < 16; i++) begin
      wait_daa_target_found;
      sb_cov++;
      if (!is_reserved(daa_dyn_addr_assigned)) begin
        $display("[%0t] T1[%0d] PASS: DA=0x%02x valid", $time, i, daa_dyn_addr_assigned);
        sb_pass++;
      end else begin
        $display("[%0t] T1[%0d] FAIL: DA=0x%02x reserved!", $time, i, daa_dyn_addr_assigned);
        sb_fail++;
      end
      @(posedge clk);
    end

    wait_daa_done;
    
    if (tgt_table_full) begin
      $display("[%0t] T1 PASS: Target table full flag set", $time);
      sb_pass++;
    end else begin
      $display("[%0t] T1 FAIL: Target table full flag NOT set", $time);
      sb_fail++;
    end

    // T2: Verify target table via Register Read
    $display("[%0t] === T2: Verify Target Table ===", $time);
    for (i = 0; i < 16; i++) begin
      reg_addr = i[3:0];
      @(posedge clk);
      @(posedge clk); // let data settle
      // reg_rd_data = {16'h0, Valid[111], IBI_MAX[110:103], MWL[102:87], MRL[86:71], PID[70:23], DCR[22:15], BCR[14:7], DA[6:0]}
      if (reg_rd_data[111] === 1'b1) begin
         $display("[%0t] T2[%0d] PASS: Valid bit set", $time, i);
         sb_pass++;
      end else begin
         $display("[%0t] T2[%0d] FAIL: Valid bit NOT set", $time, i);
         sb_fail++;
      end
      
      expected_pid = {8'h11 + i[7:0], 8'h22, 8'h33, 8'h44, 8'h55, 8'h66};
      
      if (reg_rd_data[70:23] === expected_pid) begin
         $display("[%0t] T2[%0d] PASS: PID match", $time, i);
         sb_pass++;
      end else begin
         $display("[%0t] T2[%0d] FAIL: PID mismatch %h (expected %h)", $time, i, reg_rd_data[70:23], expected_pid);
         sb_fail++;
      end
    end

    // Report
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("  Reserved DAs assigned: %0d", reserved_count);
    $display("============================================================");
    $display("");
    $display("UVM DAA TEST SUMMARY");
    if (sb_fail == 0)
      $display("  RESULT: ALL TESTS PASS");
    else
      $display("  RESULT: %0d FAILURES", sb_fail);
    $display("============================================================");
    $finish;
  end

  initial begin
    #2000000000;
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("  Reserved DAs assigned: %0d", reserved_count);
    $display("============================================================");
    $display("");
    $display("UVM DAA TEST SUMMARY");
    $display("  RESULT: TIMEOUT (sb_pass=%0d sb_fail=%0d)", sb_pass, sb_fail);
    $display("============================================================");
    $finish;
  end

endmodule
