// =============================================================================
// tb_uvm_pec_e2e.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for end-to-end PEC (CRC-8) generation and checking.
// Integrates byte_serdes_i3c with mock PHY and mock controller FSM.
// Icarus Verilog 12.0 compatible.
// =============================================================================

import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_pec_e2e;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  // SERDES Interface
  logic req_start = 0, req_repeat_start = 0, req_stop = 0;
  logic req_send_addr_w = 0, req_send_addr_r = 0;
  logic [6:0] addr_val = 0;
  logic req_send_byte = 0;
  logic [7:0] byte_tx = 0;
  logic req_recv_byte = 0, recv_last_byte = 0;
  logic i2c_mode = 0;

  logic done, ack_recv, busy, idle;
  logic [7:0] byte_rx;

  logic tcmd_start, tcmd_repeat_start, tcmd_stop;
  logic tcmd_drive_scl_low, tcmd_release_bus;
  logic tcmd_bit_xfer, tcmd_bit_xfer_od, sda_drive_val, mode_pushpull;
  logic tcmd_done = 0;
  logic sda_sampled = 0;

  logic pec_en = 0, pec_append_req = 0, pec_rx_check = 0;
  logic pec_error;
  logic [7:0] pec_crc_out;
  logic pec_tx_byte_valid;
  logic [7:0] pec_tx_byte_value;

  byte_serdes_i3c u_serdes (
      .clk(clk), .rst_n(rst_n),
      .req_start(req_start), .req_repeat_start(req_repeat_start), .req_stop(req_stop),
      .req_send_addr_w(req_send_addr_w), .req_send_addr_r(req_send_addr_r),
      .addr_val(addr_val), .req_send_byte(req_send_byte), .byte_tx(byte_tx),
      .req_recv_byte(req_recv_byte), .recv_last_byte(recv_last_byte),
      .i2c_mode(i2c_mode),
      .done(done), .ack_recv(ack_recv), .byte_rx(byte_rx), .busy(busy), .idle(idle),
      .tcmd_start(tcmd_start), .tcmd_repeat_start(tcmd_repeat_start),
      .tcmd_stop(tcmd_stop), .tcmd_drive_scl_low(tcmd_drive_scl_low),
      .tcmd_release_bus(tcmd_release_bus), .tcmd_bit_xfer(tcmd_bit_xfer),
      .tcmd_bit_xfer_od(tcmd_bit_xfer_od), .sda_drive_val(sda_drive_val),
      .mode_pushpull(mode_pushpull), .tcmd_done(tcmd_done), .sda_sampled(sda_sampled),
      .pec_en(pec_en), .pec_append_req(pec_append_req), .pec_rx_check(pec_rx_check),
      .pec_error(pec_error), .pec_crc_out(pec_crc_out),
      .pec_tx_byte_valid(pec_tx_byte_valid), .pec_tx_byte_value(pec_tx_byte_value)
  );

  // Mock PHY
  logic [7:0] mock_phy_rx_byte;
  int mock_bit_idx = 7;
  logic mock_is_tx = 0;
  logic [7:0] mock_phy_tx_byte;

  always_ff @(posedge clk) begin
      tcmd_done <= 1'b0;
      
      if ((tcmd_start || tcmd_repeat_start || tcmd_stop || tcmd_drive_scl_low || tcmd_release_bus || tcmd_bit_xfer || tcmd_bit_xfer_od) && !tcmd_done) begin
          tcmd_done <= 1'b1;
          if (tcmd_bit_xfer || tcmd_bit_xfer_od) begin
              if (mock_is_tx) begin
                 // Capture MSB first
                 if (mock_bit_idx >= 0 && mock_bit_idx <= 7) begin
                     mock_phy_tx_byte[mock_bit_idx] <= sda_drive_val;
                 end
              end else begin
                 if (mock_bit_idx >= 0 && mock_bit_idx <= 7) begin
                     sda_sampled <= mock_phy_rx_byte[mock_bit_idx];
                 end else begin
                     sda_sampled <= 1'b1; // T-bit high
                 end
              end
              if (mock_bit_idx == -1) mock_bit_idx <= 7; // -1 handles the 9th bit (T-bit/ACK)
              else mock_bit_idx <= mock_bit_idx - 1;
          end
      end
  end

  int sb_pass = 0, sb_fail = 0, sb_cov = 0;

  // CRC-8 calculation helper (software reference model)
  function automatic logic [7:0] calc_crc8(logic [7:0] data, logic [7:0] crc_in);
      logic [7:0] c;
      int i;
      c = crc_in ^ data;
      for (i = 0; i < 8; i++) begin
          if (c[7]) begin
              c = (c << 1) ^ 8'h07;
          end else begin
              c = (c << 1);
          end
      end
      return c;
  endfunction

  // Send byte task
  task send_byte(input logic [7:0] b);
      mock_is_tx = 1;
      mock_bit_idx = 7;
      @(negedge clk);
      req_send_byte <= 1'b1;
      byte_tx <= b;
      @(posedge clk);
      @(negedge clk);
      req_send_byte <= 1'b0;
      while (!done) @(posedge clk);
      $display("[%0t] TX BYTE MOCK CAPTURED: %h (expected %h)", $time, mock_phy_tx_byte, b);
  endtask
  
  task send_addr(input logic [6:0] addr, input logic is_read);
      mock_is_tx = 1;
      mock_bit_idx = 7;
      @(negedge clk);
      if (is_read) req_send_addr_r <= 1'b1;
      else req_send_addr_w <= 1'b1;
      addr_val <= addr;
      @(posedge clk);
      @(negedge clk);
      req_send_addr_r <= 1'b0;
      req_send_addr_w <= 1'b0;
      while (!done) @(posedge clk);
      $display("[%0t] TX ADDR MOCK CAPTURED: %h", $time, mock_phy_tx_byte);
  endtask

  // Send PEC task
  task send_pec_byte();
      mock_is_tx = 1;
      mock_bit_idx = 7;
      @(negedge clk);
      pec_append_req <= 1'b1;
      @(posedge clk);
      @(negedge clk);
      pec_append_req <= 1'b0;
      
      // Wait for PEC byte to become valid
      while (!pec_tx_byte_valid) @(posedge clk);
      
      @(negedge clk);
      req_send_byte <= 1'b1;
      byte_tx <= pec_tx_byte_value;
      @(posedge clk);
      @(negedge clk);
      req_send_byte <= 1'b0;
      
      while (!done) @(posedge clk);
  endtask

  // Recv byte task
  task recv_byte(input logic [7:0] b, input logic last);
      mock_is_tx = 0;
      mock_bit_idx = 7;
      mock_phy_rx_byte = b;
      @(negedge clk);
      req_recv_byte <= 1'b1;
      recv_last_byte <= last;
      @(posedge clk);
      @(negedge clk);
      req_recv_byte <= 1'b0;
      while (!done) @(posedge clk);
  endtask
  
  // Recv PEC task
  task recv_pec_byte(input logic [7:0] b);
      mock_is_tx = 0;
      mock_bit_idx = 7;
      mock_phy_rx_byte = b;
      @(negedge clk);
      req_recv_byte <= 1'b1;
      recv_last_byte <= 1'b1;
      pec_rx_check <= 1'b1;
      @(posedge clk);
      @(negedge clk);
      req_recv_byte <= 1'b0;
      while (!done) @(posedge clk);
      @(negedge clk);
      pec_rx_check <= 1'b0;
  endtask

  initial begin
    rst_n = 0;
    repeat(5) @(posedge clk);
    rst_n = 1;
    pec_en = 1'b1;
    i2c_mode = 1'b0; // I3C mode
    @(posedge clk);

    // -------------------------------------------------------------
    // T1: TX PEC Append (Controller to Target)
    // Send addr write, then 2 bytes, then append PEC.
    // -------------------------------------------------------------
    $display("[%0t] === T1: TX PEC Append ===", $time);
    send_addr(7'h5A, 0);
    send_byte(8'h12);
    send_byte(8'h34);
    send_pec_byte();
    
    begin
      logic [7:0] expected_crc;
      expected_crc = 8'h00;
      expected_crc = calc_crc8({7'h5A, 1'b0}, expected_crc);
      expected_crc = calc_crc8(8'h12, expected_crc);
      expected_crc = calc_crc8(8'h34, expected_crc);
      
      $display("[%0t] T1: Expected CRC = %h, Captured on bus = %h", $time, expected_crc, mock_phy_tx_byte);
      if (mock_phy_tx_byte === expected_crc) begin
        $display("[%0t] T1 PASS", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T1 FAIL", $time);
        sb_fail++;
      end
      sb_cov++;
    end

    // -------------------------------------------------------------
    // T2: RX PEC Check (Target to Controller)
    // Send addr read, then receive 2 bytes, then check PEC.
    // -------------------------------------------------------------
    $display("[%0t] === T2: RX PEC Check ===", $time);
    // Pulse start to reset PEC state machine (serdes automatically pulses internal start)
    @(negedge clk); req_start = 1; @(posedge clk); req_start = 0; while(!done) @(posedge clk);
    
    send_addr(7'h5A, 1);
    recv_byte(8'hAB, 0);
    recv_byte(8'hCD, 0);
    begin
      logic [7:0] expected_crc;
      expected_crc = 8'h00;
      expected_crc = calc_crc8({7'h5A, 1'b1}, expected_crc);
      expected_crc = calc_crc8(8'hAB, expected_crc);
      expected_crc = calc_crc8(8'hCD, expected_crc);
      
      $display("[%0t] T2: Expected CRC = %h, RTL CRC = %h, Injecting it for check", $time, expected_crc, pec_crc_out);
      recv_pec_byte(expected_crc);
      
      if (pec_error === 1'b0) begin
        $display("[%0t] T2 PASS: PEC error is 0", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T2 FAIL: PEC error is 1", $time);
        sb_fail++;
      end
      sb_cov++;
    end

    // -------------------------------------------------------------
    // T3: RX PEC Error (Target to Controller)
    // Send addr read, receive 1 byte, check INCORRECT PEC.
    // -------------------------------------------------------------
    $display("[%0t] === T3: RX PEC Error Injection ===", $time);
    @(negedge clk); req_start = 1; @(posedge clk); req_start = 0; while(!done) @(posedge clk);
    
    send_addr(7'h33, 1);
    recv_byte(8'hFF, 0);
    begin
      automatic logic [7:0] wrong_crc = 8'hDE; // arbitrary wrong CRC
      
      $display("[%0t] T3: Injecting wrong CRC = %h", $time, wrong_crc);
      recv_pec_byte(wrong_crc);
      
      if (pec_error === 1'b1) begin
        $display("[%0t] T3 PASS: PEC error is 1", $time);
        sb_pass++;
      end else begin
        $display("[%0t] T3 FAIL: PEC error is 0", $time);
        sb_fail++;
      end
      sb_cov++;
    end

    // Report
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("============================================================");
    $display("");
    $display("UVM PEC TEST SUMMARY");
    if (sb_fail == 0)
      $display("  RESULT: ALL TESTS PASS");
    else
      $display("  RESULT: %0d FAILURES", sb_fail);
    $display("============================================================");
    $finish;
  end

  initial begin
    #2000000000;  // 5us timeout
    $display("");
    $display("============================================================");
    $display("UVM PEC TEST SUMMARY");
    $display("  RESULT: TIMEOUT (sb_pass=%0d sb_fail=%0d)", sb_pass, sb_fail);
    $display("============================================================");
    $finish;
  end

endmodule
