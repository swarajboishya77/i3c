#!/bin/bash
# run_uvm_tests.sh - Run all UVM-style SV testbenches
set +e
IV=/home/z/my-project/tools/iverilog/usr/bin/iverilog
VVP=/home/z/my-project/tools/iverilog/usr/bin/vvp
RTL_DIR=/home/z/my-project/download/i3c_controller_rtl
cd "$RTL_DIR"

echo "============================================================"
echo "UVM-STYLE SV TESTBENCH REGRESSION"
echo "============================================================"
echo ""

TOTAL_PASS=0
TOTAL_FAIL=0
FAILED_TBS=()

run_uvm() {
  local name=$1
  local rtl_files=$2
  local tb_file=$3
  echo "--- $name ---"
  $IV -g2012 -o /tmp/uvm_${name}.vvp -y rtl -I rtl/include \
    rtl/include/i3c_pkg.sv $rtl_files \
    tb_uvm/i3c_uvm_pkg.sv $tb_file 2>&1 | grep -iE "error" | head -3
  if [ ! -f /tmp/uvm_${name}.vvp ]; then
    echo "  COMPILE FAILED"
    FAILED_TBS+=("$name (compile)")
    return
  fi
  out=$(timeout 30 $VVP /tmp/uvm_${name}.vvp 2>&1)
  echo "$out" | grep -E "Pass:|Fail:|RESULT:|SUMMARY" | tail -5
  rm -f /tmp/uvm_${name}.vvp
  echo ""
}

run_uvm "axi" "rtl/axi/axi4_lite_slave.sv" "tb_uvm/tb_uvm_axi4_lite.sv"
run_uvm "ccc" "rtl/ccc/i3c_ccc_handler.sv" "tb_uvm/tb_uvm_ccc.sv"
run_uvm "daa" "rtl/daa/i3c_daa.sv" "tb_uvm/tb_uvm_daa.sv"

echo "============================================================"
echo "UVM REGRESSION COMPLETE"
echo "============================================================"
