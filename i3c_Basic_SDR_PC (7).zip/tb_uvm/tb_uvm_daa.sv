// =============================================================================
// tb_uvm_daa.sv
// -----------------------------------------------------------------------------
// UVM-style SV testbench for DAA with scoreboard analysis.
// Tests: ENTDAA single/multi-target, SETDASA, reserved address skip, parity.
// Icarus Verilog 12.0 compatible.
// =============================================================================


import i3c_pkg::*;
import i3c_uvm_pkg::*;

module tb_uvm_daa;

  logic clk = 0;
  logic rst_n = 0;
  always #5000 clk = ~clk;

  logic        start_entdaa = 0, start_setdasa = 0;
  logic [6:0]  setdasa_static_addr = 0;
  logic        tgt_table_full = 0;
  logic [3:0]  tgt_table_count = 0;
  logic        req_start, req_repeat_start, req_stop;
  logic        req_send_byte, req_recv_byte;
  logic        req_send_ack, req_send_nack;
  logic        req_send_addr_w, req_send_addr_r;
  logic [6:0]  req_addr_val;
  logic [7:0]  req_send_byte_val;
  logic        prim_done = 0, prim_ack_recv = 0;
  logic [7:0]  prim_byte_recv = 0;
  logic        daa_done, daa_target_found;
  logic [47:0] daa_pid;
  logic [7:0]  daa_bcr, daa_dcr;
  logic [6:0]  daa_dyn_addr_assigned;
  logic        daa_recv_last_byte;

  i3c_daa u_daa (
    .clk(clk), .rst_n(rst_n),
    .start_entdaa(start_entdaa), .start_setdasa(start_setdasa),
    .setdasa_static_addr(setdasa_static_addr),
    .tgt_table_full(tgt_table_full), .tgt_table_count(tgt_table_count),
    .req_start(req_start), .req_repeat_start(req_repeat_start),
    .req_stop(req_stop),
    .req_send_byte(req_send_byte), .req_send_byte_val(req_send_byte_val),
    .req_recv_byte(req_recv_byte),
    .req_send_ack(req_send_ack), .req_send_nack(req_send_nack),
    .req_send_addr_w(req_send_addr_w), .req_send_addr_r(req_send_addr_r),
    .req_addr_val(req_addr_val),
    .prim_done(prim_done), .prim_ack_recv(prim_ack_recv),
    .prim_byte_recv(prim_byte_recv),
    .daa_done(daa_done), .daa_target_found(daa_target_found),
    .daa_pid(daa_pid), .daa_bcr(daa_bcr), .daa_dcr(daa_dcr),
    .daa_dyn_addr_assigned(daa_dyn_addr_assigned),
    .daa_recv_last_byte(daa_recv_last_byte)
  );

  // Mock bus responder
  integer byte_idx = 0;
  logic [7:0] pid_bytes [0:5];
  // Track how many targets we've "found" — NACK the 2nd 7E/R to end DAA
  logic [3:0] targets_found = 0;
  logic       mock_reset = 0;  // pulse high to reset targets_found

  // Timeout-safe wait helper: avoid infinite hang if DAA FSM stalls
  task wait_daa_target_found;
    integer timeout_cnt;
    begin
      timeout_cnt = 0;
      while (!daa_target_found && timeout_cnt < 5000) begin
        @(posedge clk);
        timeout_cnt = timeout_cnt + 1;
      end
    end
  endtask

  task wait_daa_done;
    integer timeout_cnt;
    begin
      timeout_cnt = 0;
      while (!daa_done && timeout_cnt < 5000) begin
        @(posedge clk);
        timeout_cnt = timeout_cnt + 1;
      end
    end
  endtask

  always_ff @(posedge clk) begin
    prim_done <= 1'b0;
    if (mock_reset) begin
      targets_found <= 0;
    end else if (daa_done) begin
      // Release DAA FSM from D_DONE/D_ERROR states (no req asserted there)
      prim_done <= 1'b1;
    end else if (req_start || req_repeat_start || req_stop || req_send_addr_w) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
      byte_idx <= 0;
    end else if (req_send_addr_r) begin
      // 7E/R: ACK first time (target present), NACK second time (no more targets)
      prim_done <= 1'b1;
      if (targets_found == 0) begin
        prim_ack_recv <= 1'b1;  // ACK — target is present
        byte_idx <= 0;
      end else begin
        prim_ack_recv <= 1'b0;  // NACK — no more targets, DAA ends
      end
    end else if (req_send_byte) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
    end else if (req_recv_byte) begin
      prim_done <= 1'b1;
      prim_ack_recv <= 1'b1;
      if (byte_idx < 6) begin
        prim_byte_recv <= pid_bytes[byte_idx];
        byte_idx <= byte_idx + 1;
      end else if (byte_idx == 6) begin
        prim_byte_recv <= 8'h4A;  // BCR
        byte_idx <= byte_idx + 1;
      end else if (byte_idx == 7) begin
        prim_byte_recv <= 8'h99;  // DCR
        byte_idx <= 0;
        targets_found <= targets_found + 1;  // target complete
      end
    end
  end

  // Scoreboard
  int sb_pass = 0, sb_fail = 0, sb_cov = 0;
  int reserved_count = 0;

  // Reserved address checker
  function automatic logic is_reserved(input logic [6:0] da);
    if (da <= 7'h07) return 1'b1;
    if (da == 7'h3E || da == 7'h5E || da == 7'h6E ||
        da == 7'h76 || da == 7'h7A || da == 7'h7C ||
        da == 7'h7E || da == 7'h7F) return 1'b1;
    return 1'b0;
  endfunction

  int i;

  initial begin
    rst_n = 0;
    repeat(5) @(posedge clk);
    rst_n = 1;
    @(posedge clk);

    // T1: ENTDAA single target
    $display("[%0t] === T1: ENTDAA single target ===", $time);
    pid_bytes[0] = 8'h11; pid_bytes[1] = 8'h22; pid_bytes[2] = 8'h33;
    pid_bytes[3] = 8'h44; pid_bytes[4] = 8'h55; pid_bytes[5] = 8'h66;
    start_entdaa = 1;
    @(posedge clk);
    start_entdaa = 0;
    wait_daa_target_found;
    sb_cov++;
    if (!is_reserved(daa_dyn_addr_assigned)) begin
      $display("[%0t] T1 PASS: DA=0x%02x valid", $time, daa_dyn_addr_assigned);
      sb_pass++;
    end else begin
      $display("[%0t] T1 FAIL: DA=0x%02x reserved!", $time, daa_dyn_addr_assigned);
      sb_fail++;
      reserved_count++;
    end
    wait_daa_done;

    // T2: SETDASA
    $display("[%0t] === T2: SETDASA ===", $time);
    // BUGFIX: wait 2 cycles after daa_done to let FSM settle in D_IDLE
    // before pulsing start_setdasa. Without this, Vivado's NBA timing causes
    // start_setdasa to arrive while the FSM is still transitioning D_DONE→D_IDLE,
    // and the SETDASA capture misses, causing ENTDAA path to run instead.
    @(posedge clk);
    @(posedge clk);
    setdasa_static_addr = 7'h50;
    start_setdasa = 1;
    @(posedge clk);
    @(posedge clk);  // BUGFIX: hold 2 cycles to avoid race
    start_setdasa = 0;
    wait_daa_done;
    sb_cov++;
    if (daa_dyn_addr_assigned == 7'h50) begin
      $display("[%0t] T2 PASS: SETDASA assigned 0x%02x", $time, daa_dyn_addr_assigned);
      sb_pass++;
    end else begin
      $display("[%0t] T2 FAIL: expected 0x50, got 0x%02x", $time, daa_dyn_addr_assigned);
      sb_fail++;
    end

    // T3: ENTDAA multi-target (verify reserved skip)
    $display("[%0t] === T3: ENTDAA multi-target + reserved skip ===", $time);
    for (i = 0; i < 8; i++) begin
      pid_bytes[0] = 8'h10 + i;
      pid_bytes[1] = 8'h20;
      pid_bytes[2] = 8'h30;
      pid_bytes[3] = 8'h40;
      pid_bytes[4] = 8'h50;
      pid_bytes[5] = 8'h60;
      mock_reset = 1;  // Reset mock: allow 1 target per ENTDAA cycle
      @(posedge clk);
      @(posedge clk);  // BUGFIX: hold 2 cycles to avoid always_ff race
      mock_reset = 0;
      start_entdaa = 1;
      @(posedge clk);
      start_entdaa = 0;
      wait_daa_target_found;
      sb_cov++;
      if (is_reserved(daa_dyn_addr_assigned)) begin
        $display("[%0t] T3[%0d] FAIL: DA=0x%02x reserved!", $time, i, daa_dyn_addr_assigned);
        sb_fail++;
        reserved_count++;
      end else begin
        $display("[%0t] T3[%0d] PASS: DA=0x%02x", $time, i, daa_dyn_addr_assigned);
        sb_pass++;
      end
      // Wait for DAA to complete (NACK on 2nd 7E/R ends it)
      wait_daa_done;
      repeat(10) @(posedge clk);
    end

    // Report
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("  Reserved DAs assigned: %0d", reserved_count);
    $display("============================================================");
    $display("");
    $display("UVM DAA TEST SUMMARY");
    if (sb_fail == 0)
      $display("  RESULT: ALL TESTS PASS");
    else
      $display("  RESULT: %0d FAILURES", sb_fail);
    $display("============================================================");
    $finish;
  end

  initial begin
    #2000000000;
    $display("");
    $display("============================================================");
    $display("SCOREBOARD REPORT");
    $display("  Pass: %0d", sb_pass);
    $display("  Fail: %0d", sb_fail);
    $display("  Cov samples: %0d", sb_cov);
    $display("  Reserved DAs assigned: %0d", reserved_count);
    $display("============================================================");
    $display("");
    $display("UVM DAA TEST SUMMARY");
    $display("  RESULT: TIMEOUT (sb_pass=%0d sb_fail=%0d)", sb_pass, sb_fail);
    $display("============================================================");
    $finish;
  end

endmodule
