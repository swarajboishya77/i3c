// =============================================================================
// i3c_uvm_pkg.sv
// -----------------------------------------------------------------------------
// Lightweight UVM-style SystemVerilog package for I3C Controller verification.
// Icarus Verilog 12.0 compatible — uses only enums and functions (no classes,
// no structs, no constraints).
// =============================================================================

package i3c_uvm_pkg;

  typedef enum logic [3:0] {
    TXN_AXI_WRITE   = 4'h1,
    TXN_AXI_READ    = 4'h2,
    TXN_I3C_WRITE   = 4'h3,
    TXN_I3C_READ    = 4'h4,
    TXN_CCC_BCAST   = 4'h5,
    TXN_CCC_DIRECT  = 4'h6,
    TXN_DAA         = 4'h7,
    TXN_I2C_WRITE   = 4'h8,
    TXN_I2C_READ    = 4'h9
  } txn_type_e;

  typedef enum logic [2:0] {
    RESP_OKAY    = 3'b000,
    RESP_SLVERR  = 3'b010,
    RESP_ABORTED = 3'b011,
    RESP_NACK    = 3'b100,
    RESP_TIMEOUT = 3'b101
  } resp_code_e;

  // Response code name (for display)
  function automatic string resp_name(input resp_code_e r);
    case (r)
      RESP_OKAY:    return "OKAY";
      RESP_SLVERR:  return "SLVERR";
      RESP_ABORTED: return "ABORTED";
      RESP_NACK:    return "NACK";
      RESP_TIMEOUT: return "TIMEOUT";
      default:      return "UNKNOWN";
    endcase
  endfunction

  // Odd parity helper (for DAA / GETACCR verification)
  function automatic logic odd_parity_7bit(input logic [6:0] da);
    return ~(^da);
  endfunction

  // Reserved address checker (per MIPI I3C Basic v1.2 Table 10)
  function automatic logic is_reserved_addr(input logic [6:0] da);
    if (da <= 7'h07) return 1'b1;
    if (da == 7'h3E) return 1'b1;
    if (da == 7'h5E) return 1'b1;
    if (da == 7'h6E) return 1'b1;
    if (da == 7'h76) return 1'b1;
    if (da == 7'h7A) return 1'b1;
    if (da == 7'h7C) return 1'b1;
    if (da == 7'h7E) return 1'b1;
    if (da == 7'h7F) return 1'b1;
    return 1'b0;
  endfunction

endpackage : i3c_uvm_pkg
