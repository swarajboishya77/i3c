#!/bin/bash
# =============================================================================
# vivado_compile.sh  —  COMPILE ONLY (xvlog)
# -----------------------------------------------------------------------------
# Compiles all RTL files with xvlog (Vivado XSIM compiler).
# i3c_pkg.sv is compiled FIRST (required by VRFC 10-2989).
#
# This is the same as 1_vivado_compile.sh — kept for backward compat.
#
# Usage:
#   bash vivado_compile.sh
#
# For the full step-by-step flow, use:
#   bash 1_vivado_xvlog_compile.sh      # Step 1: Compile
#   bash 2_vivado_xelab_elaborate.sh    # Step 2: Elaborate
#   bash 3_vivado_xsim_simulate.sh     # Step 3: Simulate
#   bash 4_vivado_synthesize.sh   # Step 4: Synthesize
# =============================================================================

set -e

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

echo "================================================================"
echo "COMPILE (xvlog) — I3C Basic v1.2 SDR Controller"
echo "Project: $PROJECT_ROOT"
echo "================================================================"

# --- Compile SV package FIRST ---
echo ""
echo "--- Compiling i3c_pkg.sv (MUST be first) ---"
xvlog -sv rtl/include/i3c_pkg.sv

# --- Compile all leaf modules ---
echo ""
echo "--- Compiling RTL modules ---"
xvlog -sv \
  rtl/io_pad/io_buf.sv \
  rtl/dnf/i3c_dnf.sv \
  rtl/pec/i3c_pec.sv \
  rtl/digital_phy/i3c_timing_control.sv \
  rtl/digital_phy/i3c_start_stop_gen.sv \
  rtl/digital_phy/i3c_phy_fsm.sv \
  rtl/digital_phy/i3c_phy_mux.sv \
  rtl/ccc/i3c_ccc_handler.sv \
  rtl/daa/i3c_daa.sv \
  rtl/ibi/i3c_ibi_handler.sv \
  rtl/hj/i3c_hotjoin_handler.sv \
  rtl/group/i3c_group_addr.sv \
  rtl/wake/i3c_wake_detector.sv \
  rtl/target/i3c_target_engine.sv \
  rtl/target/i3c_ccc_event_decoder.sv \
  rtl/target/i3c_target_table.sv \
  rtl/role/i3c_role_manager.sv \
  rtl/clock/i3c_clock_gate.sv \
  rtl/clock/i3c_async_fifo.sv \
  rtl/power/i3c_power_controller.sv \
  rtl/controller/byte_serdes_i3c.sv \
  rtl/controller/byte_serdes_i2c.sv \
  rtl/controller/i2c_controller_fsm.sv \
  rtl/controller/i2c_prescaler.sv \
  rtl/fifo/i3c_fifo.sv \
  rtl/fifo/i3c_cmd_fifo.sv \
  rtl/fifo/i3c_wr_fifo.sv \
  rtl/fifo/i3c_rd_fifo.sv \
  rtl/fifo/i3c_resp_fifo.sv \
  rtl/axi/axi4_lite_slave.sv \
  rtl/register_map/i3c_register_file.sv \
  rtl/register_map/i2c_register_file.sv

# --- Compile top-level controller LAST ---
echo ""
echo "--- Compiling top-level controller ---"
xvlog -sv rtl/controller/i3c_primary_controller_sdr.sv

echo ""
echo "================================================================"
echo "COMPILE COMPLETE."
echo ""
echo "Next steps:"
echo "  bash 2_vivado_xelab_elaborate.sh    # Elaborate"
echo "  bash 3_vivado_xsim_simulate.sh     # Simulate"
echo "  bash 4_vivado_synthesize.sh   # Synthesize"
echo "================================================================"
