# =============================================================================
# i3c_controller_top.f
# Filelist for I3C Basic v1.2 SDR Primary Controller IP
# =============================================================================
# Features: IBI, Hot-Join, Group Addressing, Digital Noise Filter, PEC,
#           Wake-Up, Target Engine, Power Domain Control
# Folder structure:
#   rtl/include/      - SV package + defines
#   rtl/axi/          - AXI4-Lite slave
#   rtl/register_map/ - Register file
#   rtl/fifo/         - 4 FIFOs + generic template
#   rtl/io_pad/       - SDA/SCL tri-state I/O buffer (analog frontend)
#   rtl/digital_phy/  - Digital PHY (start_stop_gen, phy_fsm, phy_mux,
#                                    timing_control)
#   rtl/dnf/          - Digital Noise Filter
#   rtl/pec/          - Packet Error Code (CRC-8)
#   rtl/ccc/          - CCC handler
#   rtl/daa/          - DAA sequencer
#   rtl/ibi/          - In-Band Interrupt handler
#   rtl/hj/           - Hot-Join handler
#   rtl/group/        - Group addressing
#   rtl/wake/         - Wake detector (PD_AON)
#   rtl/target/       - Target engine
#   rtl/role/         - Role manager
#   rtl/clock/        - Clock gate + async FIFO (CDC)
#   rtl/power/        - Power domain controller
#   rtl/controller/   - Top-level controller (FSM + integration)
# =============================================================================

+incdir+rtl/include

# Package (must compile first)
rtl/include/i3c_pkg.sv

# I/O pad buffer
rtl/io_pad/io_buf.sv

# Digital Noise Filter
rtl/dnf/i3c_dnf.sv

# Packet Error Code (CRC-8)
rtl/pec/i3c_pec.sv

# Digital PHY
rtl/digital_phy/i3c_timing_control.sv
rtl/digital_phy/i3c_start_stop_gen.sv
rtl/digital_phy/i3c_phy_fsm.sv
rtl/digital_phy/i3c_phy_mux.sv

# CCC handler
rtl/ccc/i3c_ccc_handler.sv

# DAA sequencer
rtl/daa/i3c_daa.sv

# IBI handler (In-Band Interrupt)
rtl/ibi/i3c_ibi_handler.sv

# Hot-Join handler
rtl/hj/i3c_hotjoin_handler.sv

# Group addressing
rtl/group/i3c_group_addr.sv

# Wake detector (PD_AON)
rtl/wake/i3c_wake_detector.sv

# Target engine
rtl/target/i3c_target_engine.sv
rtl/target/i3c_ccc_event_decoder.sv
rtl/target/i3c_target_table.sv

# Role manager
rtl/role/i3c_role_manager.sv

# Clock gate + async FIFO (CDC)
rtl/clock/i3c_clock_gate.sv
rtl/clock/i3c_async_fifo.sv

# Power domain controller
rtl/power/i3c_power_controller.sv

# Top-level controller (FSM + integration)
rtl/controller/byte_serdes_i3c.sv
rtl/controller/byte_serdes_i2c.sv
rtl/controller/i3c_primary_controller_sdr.sv
rtl/controller/i2c_controller_fsm.sv
rtl/controller/i2c_prescaler.sv

# FIFOs
rtl/fifo/i3c_fifo.sv
rtl/fifo/i3c_cmd_fifo.sv
rtl/fifo/i3c_wr_fifo.sv
rtl/fifo/i3c_rd_fifo.sv
rtl/fifo/i3c_resp_fifo.sv

# AXI4-Lite slave
rtl/axi/axi4_lite_slave.sv

# Register map
rtl/register_map/i3c_register_file.sv
rtl/register_map/i2c_register_file.sv
