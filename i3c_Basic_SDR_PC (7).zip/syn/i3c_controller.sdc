# =============================================================================
# i3c_controller.sdc — Synopsys Design Constraints
# -----------------------------------------------------------------------------
# I3C Basic v1.2 SDR Primary Controller IP
# Target: 5nm ASIC, 100 MHz PCLK, 12.5 MHz SCL, 32 kHz clk_aon
# =============================================================================

# =============================================================================
# 1. Clock Definitions
# =============================================================================

# Primary clock: AXI4-Lite clock (100 MHz = 10 ns period)
create_clock -name PCLK -period 10.0 [get_ports s_axi_aclk]

# Always-on clock: 32 kHz RTC (31.25 µs period)
create_clock -name CLK_AON -period 31250 [get_ports clk_aon]

# I3C SCL clock is generated internally by phy_fsm when this IP is the
# Active Controller. Max SCL = 12.5 MHz (80 ns period).
# Generated clock on the internal sda_i/scl_i filtered signals:
# create_generated_clock -name SCL_INT -source [get_ports s_axi_aclk] \
#     -divide_by 8 [get_pins u_phy_fsm/scl_o]

# External SCL clock (when this IP is a Target, SCL comes from another
# controller). This is a virtual clock for IO timing:
create_clock -name SCL_EXT -period 80 [get_ports scl]

# =============================================================================
# 2. Clock Uncertainty (5nm margin: 5% + 50ps jitter)
# =============================================================================

set_clock_uncertainty -hold  0.050 [all_clocks]
set_clock_uncertainty -setup 0.100 [all_clocks]

# =============================================================================
# 3. Clock Groups (for CDC analysis)
# =============================================================================

# PCLK and CLK_AON are asynchronous — no timing paths between them
set_clock_groups -asynchronous \
    -group {PCLK} \
    -group {CLK_AON} \
    -group {SCL_EXT}

# SCL_EXT (target mode) is async to PCLK — target engine uses async FIFO CDC
set_clock_groups -asynchronous \
    -group {PCLK} \
    -group {SCL_EXT}

# =============================================================================
# 4. Input/Output Delays
# =============================================================================

# AXI4-Lite interface (PCLK domain)
set_input_delay  -max 2.0 -clock PCLK [get_ports {s_axi_awvalid s_axi_awaddr[*] s_axi_wvalid s_axi_wdata[*] s_axi_wstrb[*] s_axi_arvalid s_axi_araddr[*] s_axi_bready s_axi_rready s_axi_aresetn}]
set_input_delay  -min 0.1 -clock PCLK [get_ports {s_axi_awvalid s_axi_awaddr[*] s_axi_wvalid s_axi_wdata[*] s_axi_wstrb[*] s_axi_arvalid s_axi_araddr[*] s_axi_bready s_axi_rready s_axi_aresetn}]
set_output_delay -max 2.0 -clock PCLK [get_ports {s_axi_awready s_axi_wready s_axi_bvalid s_axi_bresp[*] s_axi_arready s_axi_rvalid s_axi_rdata[*] s_axi_rresp[*]}]
set_output_delay -min 0.1 -clock PCLK [get_ports {s_axi_awready s_axi_wready s_axi_bvalid s_axi_bresp[*] s_axi_arready s_axi_rvalid s_axi_rdata[*] s_axi_rresp[*]}]

# I3C SDA/SCL pads (SCL_EXT domain — open-drain, slow)
set_input_delay  -max 10.0 -clock SCL_EXT [get_ports {sda scl}]
set_input_delay  -min  1.0 -clock SCL_EXT [get_ports {sda scl}]
set_output_delay -max 10.0 -clock SCL_EXT [get_ports {sda scl}]
set_output_delay -min  1.0 -clock SCL_EXT [get_ports {sda scl}]

# Always-on domain signals
set_input_delay  -max 5000 -clock CLK_AON [get_ports {rst_aon_n pd_core_req pd_core_ack}]
set_input_delay  -min  100 -clock CLK_AON [get_ports {rst_aon_n pd_core_req pd_core_ack}]
set_output_delay -max 5000 -clock CLK_AON [get_ports {wake_irq wake_to_host pd_core_off pd_core_sw_en pd_core_iso_en pd_core_rst}]
set_output_delay -min  100 -clock CLK_AON [get_ports {wake_irq wake_to_host pd_core_off pd_core_sw_en pd_core_iso_en pd_core_rst}]

# =============================================================================
# 5. False Paths (CDC — handled by synchronizers)
# =============================================================================

# Reset is async-assert, sync-deassert — no timing path on async assert
set_false_path -from [get_ports s_axi_aresetn]
set_false_path -from [get_ports rst_aon_n]

# CDC: PCLK → CLK_AON (wake_irq, interrupt flags)
# These cross through 2-flop synchronizers in the RTL
set_false_path -from [get_clocks PCLK] -to [get_clocks CLK_AON]
set_false_path -from [get_clocks CLK_AON] -to [get_clocks PCLK]

# CDC: SCL_EXT → PCLK (target engine RX data)
# Crosses through async FIFO (Gray-code pointer CDC)
set_false_path -from [get_clocks SCL_EXT] -to [get_clocks PCLK]
set_false_path -from [get_clocks PCLK] -to [get_clocks SCL_EXT]

# Target engine TX/RX FIFO cross-domain paths
set_false_path -from [get_pins u_target_engine/rx_fifo/wr_ptr_gray_reg*/Q] \
               -to   [get_pins u_target_engine/rx_fifo/rd_ptr_gray_sync2_reg*/D]
set_false_path -from [get_pins u_target_engine/tx_fifo/rd_ptr_gray_reg*/Q] \
               -to   [get_pins u_target_engine/tx_fifo/wr_ptr_gray_sync2_reg*/D]

# Power controller outputs are in CLK_AON — no timing to PCLK
set_false_path -from [get_pins u_power_controller/*/Q] \
               -to   [get_pins u_*/D]

# =============================================================================
# 6. Multi-Cycle Paths
# =============================================================================

# AXI4-Lite write response can take multiple cycles (AW → W → B)
set_multicycle_path 2 -setup -from [get_ports {s_axi_awvalid s_axi_wvalid}] \
                         -to   [get_ports s_axi_bvalid]

# =============================================================================
# 7. Max Fanout / Max Transition (5nm-specific)
# =============================================================================

# 5nm: max transition 80ps for standard cells, max fanout 20 for timing
set_max_transition 0.080 [current_design]
set_max_fanout 20 [current_design]
set_max_capacitance 0.040 [current_design]

# High-fanout nets: clock reset
set_max_fanout 100 [get_ports s_axi_aresetn]
set_max_fanout 100 [get_ports rst_aon_n]

# =============================================================================
# 8. Clock Gating Checks
# =============================================================================

# Enable clock gating checks on all ICG cells
set_clock_gating_check -setup  0.150 [all_clocks]
set_clock_gating_check -hold  -0.050 [all_clocks]

# =============================================================================
# 9. Design Rule Constraints
# =============================================================================

set_max_area 0
set_max_leakage 0
set_max_dynamic_power 0

# Don't touch the ICG cells (RTL-defined pattern — don't let synthesis optimize away)
set_dont_touch [get_cells u_clk_gate_ctrl/*]
set_dont_touch [get_cells u_clk_gate_fifo/*]

# Don't touch the reset synchronizers (CDC-critical)
set_dont_touch [get_cells rst_sync_meta_reg*]
set_dont_touch [get_cells rst_sync_n_reg*]

# =============================================================================
# 10. IO Pad Constraints (for 5nm pad ring integration)
# =============================================================================

# SDA/SCL are open-drain bidirectional pads
set_drive 1000 [get_ports {sda scl}]
set_driving_cell -lib_cell INVX2 -pin Z [get_ports {sda scl}]
set_load 5.0 [get_ports {sda scl}]

# AXI4-Lite inputs: standard CMOS drive
set_driving_cell -lib_cell INVX2 -pin Z [get_ports {s_axi_*}]
set_load 2.0 [get_ports {s_axi_*}]
