# =============================================================================
# syn_i3c_controller.tcl — Synopsys Design Compiler Synthesis Script
# -----------------------------------------------------------------------------
# I3C Basic v1.2 SDR Primary Controller IP
# Target: 5nm ASIC (TSMC N5 / Samsung 5LPE / Intel 18A — generic)
# Tool: Design Compiler 2023.12+ with UPF power intent
# =============================================================================
# =============================================================================
# 1. Library Setup
# =============================================================================

# --- Target foundry libraries (replace with actual PDK paths) ---
# Example: TSMC N5 0.8V/0.72V/0.65V standard cell library
set search_path [list . \
    /home/pdk/tsmc5nm/N5/stdcell/HVT/db \
    /home/pdk/tsmc5nm/N5/stdcell/RVT/db \
    /home/pdk/tsmc5nm/N5/stdcell/LVT/db \
    /home/pdk/tsmc5nm/N5/stdcell/sram/db \
    /home/pdk/tsmc5nm/N5/io/db \
    ./upf ./syn ./rtl]

# --- Link libraries (multi-Vt for leakage optimization) ---
# HVT = high-Vt (low leakage), RVT = regular-Vt (balanced), LVT = low-Vt (fast)
set link_library [list * \
    NLLV120HDHVT_tt0p8v25c.db \
    NLLV120HDRVT_tt0p8v25c.db \
    NLLV120HDLVT_tt0p8v25c.db \
    NLLV120HDHVT_ss0p72v125c.db \
    NLLV120HDRVT_ss0p72v125c.db \
    NLLV120HDLVT_ss0p72v125c.db]

set target_library [list \
    NLLV120HDHVT_tt0p8v25c.db \
    NLLV120HDRVT_tt0p8v25c.db \
    NLLV120HDLVT_tt0p8v25c.db]

set symbol_library [list NLLV120HDHVT.sdb]

# =============================================================================
# 2. Read RTL
# =============================================================================

# Analyze all RTL files (in dependency order)
analyze -format sverilog [list \
    rtl/include/i3c_pkg.sv \
    rtl/io_pad/io_buf.sv \
    rtl/digital_phy/i3c_timing_control.sv \
    rtl/digital_phy/i3c_dnf.sv \
    rtl/digital_phy/i3c_pec.sv \
    rtl/digital_phy/i3c_start_stop_gen.sv \
    rtl/digital_phy/i3c_phy_fsm.sv \
    rtl/digital_phy/i3c_phy_mux.sv \
    rtl/ccc/i3c_ccc_handler.sv \
    rtl/daa/i3c_daa.sv \
    rtl/ibi/i3c_ibi_handler.sv \
    rtl/hj/i3c_hotjoin_handler.sv \
    rtl/group/i3c_group_addr.sv \
    rtl/wake/i3c_wake_detector.sv \
    rtl/target/i3c_target_engine.sv \
    rtl/role/i3c_role_manager.sv \
    rtl/clock/i3c_clock_gate.sv \
    rtl/clock/i3c_async_fifo.sv \
    rtl/power/i3c_power_controller.sv \
    rtl/controller/byte_serdes_i3c.sv \
    rtl/controller/byte_serdes_i2c.sv \
    rtl/controller/i3c_primary_controller_sdr.sv \
    rtl/controller/i2c_controller_fsm.sv \
    rtl/controller/i2c_prescaler.sv \
    rtl/fifo/i3c_fifo.sv \
    rtl/fifo/i3c_cmd_fifo.sv \
    rtl/fifo/i3c_wr_fifo.sv \
    rtl/fifo/i3c_rd_fifo.sv \
    rtl/fifo/i3c_resp_fifo.sv \
    rtl/axi/axi4_lite_slave.sv \
    rtl/register_map/i3c_register_file.sv \
    rtl/register_map/i2c_register_file.sv]

# Elaborate top module
elaborate i3c_primary_controller_sdr

# =============================================================================
# 3. Apply Constraints
# =============================================================================

# Source SDC constraints
source syn/i3c_controller.sdc

# Source UPF power intent
load_upf upf/i3c_controller.upf

# =============================================================================
# 4. Compile (synthesis)
# =============================================================================

# First pass: map to gates, no optimization
compile_ultra -no_autoungroup -no_boundary_optimization

# Insert clock gating cells (auto-detect ICG patterns)
# The RTL already uses i3c_clock_gate, but this catches any additional
# enable signals on flip-flops that could benefit from gating.
insert_clock_gating -no_hierarchy

# Second pass: optimize with clock gating awareness
compile_ultra -no_autoungroup -no_boundary_optimization -incremental

# =============================================================================
# 5. Multi-Vt Optimization (5nm leakage reduction)
# =============================================================================

# Swap LVT cells to HVT where timing slack permits (reduces leakage)
set_attribute -port leage_optimization_mode coarse [current_design]
 Leakage_optimization

# =============================================================================
# 6. Power Optimization
# =============================================================================

# Enable power-aware synthesis (uses UPF power domains)
set_attribute -port power_mode aware [current_design]

# Optimize for dynamic power (clock gating + operand isolation)
optimize_power

# =============================================================================
# 7. Generate Reports
# =============================================================================

# Timing report
report_timing -max_paths 50 -nworst 10 > reports/timing_report.txt
report_timing -max_paths 20 -nworst 5 -delay min > reports/timing_min_report.txt

# Area report (cell count by Vt)
report_area -hierarchy > reports/area_report.txt
report_area -physical -hierarchy > reports/area_physical_report.txt

# Power report (leakage + dynamic, by power domain)
report_power -analysis_effort high > reports/power_report.txt
report_power -hierarchy > reports/power_hierarchy_report.txt

# Clock gating report
report_clock_gating > reports/clock_gating_report.txt

# Constraint violations
report_constraint -all_violations > reports/constraint_violations.txt

# UPF / power domain report
report_power_domain > reports/power_domain_report.txt
report_isolation_cell > reports/isolation_cell_report.txt
report_retention_cell > reports/retention_cell_report.txt
report_level_shifter > reports/level_shifter_report.txt

# =============================================================================
# 8. Write Netlist
# =============================================================================

# Remove unmapped cells and write structural Verilog netlist
change_names -hierarchy -rules verilog
write -format verilog -hierarchy -output outputs/i3c_controller_syn.v

# Write SDC for P&R (post-synthesis timing)
write_sdc outputs/i3c_controller_postsyn.sdc

# Write UPF for P&R (power intent preserved)
save_upf outputs/i3c_controller_postsyn.upf

# Write SPEF for P&R (parasitics — placeholder, P&R tool generates actual)
# write_parasitics -format spef -output outputs/i3c_controller.spef

# Write DEF for P&R (floorplan seed)
# write_def -output outputs/i3c_controller.def

# =============================================================================
# 9. DFT (Design for Test) — optional, for production ASIC
# =============================================================================

# Insert scan chains (manufacturing test)
# set_scan_configuration -chain_count 4 -max_length 1000
# create_scan_chain
# compile_ultra -incremental -scan

# =============================================================================
# 10. Final Check
# =============================================================================

# Check for unconstrained paths
report_timing -max_paths 10 -nworst 5 -slack_lesser_than 0 > reports/negative_slack.txt

# Check for multi-driver nets
report_net -connections > reports/net_connections.txt

# Check for latch inference
report_latches > reports/latch_report.txt

# Check for design rule violations
report_design_rule > reports/drc_report.txt

echo "============================================"
echo "Synthesis complete. Reports in reports/"
echo "Netlist: outputs/i3c_controller_syn.v"
echo "============================================"
