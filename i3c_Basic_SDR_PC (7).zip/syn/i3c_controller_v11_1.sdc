# SDC for I3C Controller v11.1
set s_axi_aclk_period 10.0
set scl_filt_period 80.0
create_clock -name s_axi_aclk -period $s_axi_aclk_period [get_ports s_axi_aclk]
create_clock -name scl_filt -period $scl_filt_period [get_ports scl_filt]
set_clock_groups -async -group [get_clocks s_axi_aclk] -group [get_clocks scl_filt]
set_input_delay -clock s_axi_aclk -max 2.0 [get_ports s_axi_aw*]
set_input_delay -clock s_axi_aclk -max 2.0 [get_ports s_axi_ar*]
set_input_delay -clock s_axi_aclk -max 2.0 [get_ports s_axi_w*]
set_output_delay -clock s_axi_aclk -max 2.0 [get_ports s_axi_r*]
set_output_delay -clock s_axi_aclk -max 2.0 [get_ports s_axi_b*]
set_input_delay -clock scl_filt -max 5.0 [get_ports sda]
set_input_delay -clock scl_filt -max 5.0 [get_ports scl]
set_output_delay -clock scl_filt -max 5.0 [get_ports sda]
set_output_delay -clock scl_filt -max 5.0 [get_ports scl]
set_false_path -from [get_cells -hier wr_ptr_gray_reg*] -to [get_cells -hier wr_ptr_gray_sync*]
set_false_path -from [get_cells -hier rd_ptr_gray_reg*] -to [get_cells -hier rd_ptr_gray_sync*]
set_multicycle_path -setup 2 -from [get_cells timer_reg*] -to [get_cells state_reg*]
set_multicycle_path -hold 1 -from [get_cells timer_reg*] -to [get_cells state_reg*]
