# =============================================================================
# syn_i3c_controller_v11_1.tcl
# Synthesis script for fixed I3C Controller v11.1
# =============================================================================
set DESIGN i3c_controller_top

# Suppress 'no load/unconnected' warnings for standard unused ports
set_msg_config -id {Synth 8-7129} -suppress

set VERILOG_FILES {
    rtl/include/i3c_pkg.sv
    rtl/include/i3c_defines.svh
    rtl/axi/axi4_lite_slave.sv
    rtl/register_map/i3c_register_file.sv
    rtl/register_map/i2c_register_file.sv
    rtl/controller/i3c_primary_controller_sdr.sv
    rtl/controller/byte_serdes_i3c.sv
    rtl/controller/byte_serdes_i2c.sv
    rtl/controller/i2c_controller_fsm.sv
    rtl/controller/i2c_prescaler.sv
    rtl/digital_phy/i3c_timing_control.sv
    rtl/digital_phy/i3c_phy_fsm.sv
    rtl/digital_phy/i3c_start_stop_gen.sv
    rtl/digital_phy/i3c_dnf.sv
    rtl/digital_phy/i3c_pec.sv
    rtl/digital_phy/i3c_phy_mux.sv
    rtl/ccc/i3c_ccc_handler.sv
    rtl/daa/i3c_daa.sv
    rtl/ibi/i3c_ibi_handler.sv
    rtl/hj/i3c_hotjoin_handler.sv
    rtl/target/i3c_target_engine.sv
    rtl/target/i3c_ccc_event_decoder.sv
    rtl/role/i3c_role_manager.sv
    rtl/group/i3c_group_addr.sv
    rtl/wake/i3c_wake_detector.sv
    rtl/power/i3c_power_controller.sv
    rtl/clock/i3c_clock_gate.sv
    rtl/clock/i3c_async_fifo.sv
    rtl/fifo/i3c_fifo.sv
    rtl/fifo/i3c_cmd_fifo.sv
    rtl/fifo/i3c_rd_fifo.sv
    rtl/fifo/i3c_wr_fifo.sv
    rtl/fifo/i3c_resp_fifo.sv
    rtl/io_pad/io_buf.sv
    rtl/future_wrappers/i3c_hci_wrapper.sv
    rtl/future_wrappers/i3c_tcri_wrapper.sv
}

read_verilog -sv $VERILOG_FILES
set_top $DESIGN
set_clock -name s_axi_aclk -period 10.0
set_clock -name scl_filt -period 80.0
set_false_path -from [get_clocks s_axi_aclk] -to [get_clocks scl_filt]
set_false_path -from [get_clocks scl_filt] -to [get_clocks s_axi_aclk]
set_dont_touch [get_cells -hier *gray*]
set_dont_touch [get_cells -hier *sync*]
compile_ultra -no_autoungroup
report_timing -max_paths 10 > reports/timing.rpt
report_area > reports/area.rpt
report_power > reports/power.rpt
report_qor > reports/qor.rpt
write -format ddc -output outputs/${DESIGN}.ddc
write -format verilog -output outputs/${DESIGN}_gate.v
