"""
test_i3c_group_addr.py — Cocotb testbench for i3c_group_addr
Tests: disabled, match entries 0-7, wrong addr, group_count limits, GETRTGL response.
Table format: [31:25]=addr(7bit), [24:9]=targets(16bit), [8:0]=reserved
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def make_entry(addr, targets):
    """Build a 32-bit group table entry: [31:25]=addr, [24:9]=targets, [8:0]=reserved."""
    return ((addr & 0x7F) << 25) | ((targets & 0xFFFF) << 9)


def match_cov(m):
    pass
CoverPoint("group.match", bins=[0, 1])(match_cov)


def set_table(dut, entries):
    """Set the 8 group_table_* inputs from a list of 8 entries."""
    for i in range(8):
        getattr(dut, f'group_table_{i}').value = entries[i]


async def test_disabled(dut, sb, cov, assert_chk):
    """T1: Group addressing disabled — no match."""
    dut._log.info("T1: Disabled")
    dut.group_enable.value = 0
    dut.group_count.value = 8
    set_table(dut, [make_entry(0x10, 0x0001)] + [0]*7)
    dut.addr_val.value = 0x10
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    match_cov(m)
    assert_chk.check("disabled_no_match", m == 0, f"disabled: match={m} (expected 0)")
    sb.add_expected(0); sb.add_actual(m)


async def test_match_each_entry(dut, sb, cov, assert_chk):
    """T2: Match entries 0 through 7."""
    dut._log.info("T2: Match entries 0-7")
    dut.group_enable.value = 1
    dut.group_count.value = 8
    # Build a table with 8 unique group addresses
    addrs = [0x10 + i for i in range(8)]
    targets = [0x0001 << i for i in range(8)]
    entries = [make_entry(addrs[i], targets[i]) for i in range(8)]
    set_table(dut, entries)
    for i in range(8):
        dut.addr_val.value = addrs[i]
        await RisingEdge(dut.clk)
        await RisingEdge(dut.clk)
        m = int(dut.group_match.value)
        idx = int(dut.group_idx.value)
        tgt = int(dut.group_targets.value)
        match_cov(m)
        assert_chk.check(f"match_idx_{i}",
                         m == 1 and idx == i and tgt == targets[i],
                         f"addr={addrs[i]:#x} match={m} idx={idx} targets={tgt:#x} (expected match=1 idx={i} targets={targets[i]:#x})")
        sb.add_expected(1); sb.add_actual(m)


async def test_wrong_addr(dut, sb, cov, assert_chk):
    """T3: Address that doesn't match any entry."""
    dut._log.info("T3: Wrong address")
    dut.group_enable.value = 1
    dut.group_count.value = 8
    addrs = [0x10 + i for i in range(8)]
    entries = [make_entry(addrs[i], 0x0001 << i) for i in range(8)]
    set_table(dut, entries)
    # Address that's not in the table
    dut.addr_val.value = 0x55
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    match_cov(m)
    assert_chk.check("wrong_addr_no_match", m == 0, f"wrong addr: match={m} (expected 0)")
    sb.add_expected(0); sb.add_actual(m)


async def test_group_count_limits(dut, sb, cov, assert_chk):
    """T4: group_count limits which entries are checked."""
    dut._log.info("T4: group_count limits")
    dut.group_enable.value = 1
    addrs = [0x10 + i for i in range(8)]
    entries = [make_entry(addrs[i], 0x0001 << i) for i in range(8)]
    set_table(dut, entries)
    # group_count=3: only entries 0,1,2 are checked
    dut.group_count.value = 3
    # addr in entry 0 (should match)
    dut.addr_val.value = addrs[0]
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    match_cov(m)
    assert_chk.check("count3_match_entry0", m == 1, f"count=3, entry 0: match={m} (expected 1)")
    sb.add_expected(1); sb.add_actual(m)
    # addr in entry 3 (should NOT match because group_count=3)
    dut.addr_val.value = addrs[3]
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    match_cov(m)
    assert_chk.check("count3_no_match_entry3", m == 0, f"count=3, entry 3: match={m} (expected 0)")
    sb.add_expected(0); sb.add_actual(m)
    # addr in entry 7 (should NOT match)
    dut.addr_val.value = addrs[7]
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    assert_chk.check("count3_no_match_entry7", m == 0, f"count=3, entry 7: match={m} (expected 0)")
    # group_count=0: no entries checked
    dut.group_count.value = 0
    dut.addr_val.value = addrs[0]
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    assert_chk.check("count0_no_match", m == 0, f"count=0: match={m} (expected 0)")


async def test_getrtgl_response(dut, sb, cov, assert_chk):
    """T5: GETRTGL CCC response."""
    dut._log.info("T5: GETRTGL response")
    dut.group_enable.value = 1
    dut.group_count.value = 8
    # Set table with known low-byte values: entry[i] low byte = 0xA0+i
    entries = []
    for i in range(8):
        # [7:0] is reserved field — set to known pattern
        e = make_entry(0x10 + i, 0x0001 << i) | (0xA0 + i)
        entries.append(e)
    set_table(dut, entries)
    # Pulse ccc_getrtgl 8 times; each pulse returns entry[getrtgl_idx][7:0] and increments idx
    for i in range(8):
        dut.ccc_getrtgl.value = 1
        await RisingEdge(dut.clk)
        dut.ccc_getrtgl.value = 0
        await RisingEdge(dut.clk)
        valid = int(dut.ccc_response_valid.value)
        resp = int(dut.ccc_response_byte.value)
        expected = 0xA0 + i
        assert_chk.check(f"getrtgl_{i}",
                         valid == 1 and resp == expected,
                         f"getrtgl[{i}]: valid={valid} resp={resp:#x} (expected valid=1 resp={expected:#x})")
        sb.add_expected(expected); sb.add_actual(resp)


async def test_setrtgl_ack(dut, sb, cov, assert_chk):
    """T6: SETRTGL just acknowledges (table is set via register map inputs)."""
    dut._log.info("T6: SETRTGL ack")
    dut.group_enable.value = 1
    dut.group_count.value = 4
    set_table(dut, [make_entry(0x20, 0x00FF)] + [0]*7)
    dut.addr_val.value = 0x20
    dut.ccc_setrtgl.value = 1
    await RisingEdge(dut.clk)
    dut.ccc_setrtgl.value = 0
    await RisingEdge(dut.clk)
    # Match should still work after SETRTGL (table is set via inputs)
    m = int(dut.group_match.value)
    match_cov(m)
    assert_chk.check("setrtgl_then_match", m == 1, f"after SETRTGL: match={m} (expected 1)")
    sb.add_expected(1); sb.add_actual(m)


async def test_random(dut, gen, sb, cov, assert_chk, num=20):
    """Randomized tests."""
    dut._log.info(f"T7: Random tests ({num} iterations)")
    for i in range(num):
        enable = gen.rng.randint(0, 1)
        count = gen.rng.randint(0, 8)
        # Random table
        addrs = [gen.rng.randint(0, 0x7F) for _ in range(8)]
        targets = [gen.rng.randint(0, 0xFFFF) for _ in range(8)]
        entries = [make_entry(addrs[j], targets[j]) for j in range(8)]
        dut.group_enable.value = enable
        dut.group_count.value = count
        set_table(dut, entries)
        # Pick a random addr — 50% from active entries, 50% random
        if enable and count > 0 and gen.rng.random() < 0.5:
            pick = gen.rng.randint(0, count - 1)
            dut.addr_val.value = addrs[pick]
            expected_match = 1
            # Note: there might be a duplicate addr earlier — but for simplicity assume unique
            # Compute expected idx/targets as the LAST match (RTL loops and overwrites)
            exp_idx = pick
            exp_tgt = targets[pick]
            for j in range(count):
                if addrs[j] == addrs[pick]:
                    exp_idx = j
                    exp_tgt = targets[j]
        else:
            dut.addr_val.value = gen.rng.randint(0, 0x7F)
            expected_match = 0
            exp_idx = 0
            exp_tgt = 0
            # Could match by chance — check
            if enable:
                for j in range(count):
                    if addrs[j] == int(dut.addr_val.value):
                        expected_match = 1
                        exp_idx = j
                        exp_tgt = targets[j]
        await RisingEdge(dut.clk)
        await RisingEdge(dut.clk)
        m = int(dut.group_match.value)
        match_cov(m)
        ok = (m == expected_match)
        assert_chk.check(f"rand_{i}", ok,
                         f"rand_{i}: enable={enable} count={count} addr={int(dut.addr_val.value):#x} match={m} (expected {expected_match})")
        sb.add_expected(expected_match); sb.add_actual(m)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main group address test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.group_enable.value = 0
    dut.group_count.value = 0
    for i in range(8):
        getattr(dut, f'group_table_{i}').value = 0
    dut.addr_val.value = 0
    dut.ccc_setrtgl.value = 0
    dut.ccc_getrtgl.value = 0
    dut.ccc_payload_byte.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('group')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('group')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Group Address Testbench")
    dut._log.info("=" * 60)

    await test_disabled(dut, sb, cov, assert_chk)
    await test_match_each_entry(dut, sb, cov, assert_chk)
    await test_wrong_addr(dut, sb, cov, assert_chk)
    await test_group_count_limits(dut, sb, cov, assert_chk)
    await test_getrtgl_response(dut, sb, cov, assert_chk)
    await test_setrtgl_ack(dut, sb, cov, assert_chk)
    await test_random(dut, gen, sb, cov, assert_chk, 20)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
