"""
test_w1c_race_v2.py — W1C (write-1-to-clear) race condition test.

Regression test for Bug 6.1 (SW clear overrides HW set in same cycle).
Tests:
  T1. Hardware sets interrupt, then SW clears — normal sequence
  T2. Hardware set + SW clear in SAME cycle — HW must win (event not lost)
  T3. All 15 sticky interrupt bits — set/clear each independently
  T4. W1C clear with reg_wr_data=0 — no clear (must write 1)
  T5. Rapid set/clear/set sequence
  T6. DATA_LOST [18] W1C clears FIFO_OVERFLOW [3] and DATA_NACK [1]
  T7. IBI_STATUS W1C bits
  T8. HJ_STATUS W1C bits

Top module: i3c_register_file (standalone)
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from cocotb_agents import AssertionChecker

# Register addresses
INTERRUPT_STATUS_ADDR      = 0x14
INTERRUPT_ENABLE_CTRL_ADDR = 0x10
IBI_STATUS_ADDR            = 0x1C
HJ_STATUS_ADDR             = 0x28

sb = AssertionChecker("w1c_race")


async def reg_write(dut, addr, data):
    """Direct regfile write (reg_wr interface)."""
    dut.reg_wr.value = 0
    dut.reg_wr_addr.value = addr
    dut.reg_wr_data.value = data
    dut.reg_wr_strb.value = 0xF
    await RisingEdge(dut.clk)
    dut.reg_wr.value = 1
    await RisingEdge(dut.clk)
    dut.reg_wr.value = 0
    await RisingEdge(dut.clk)


async def reg_read(dut, addr):
    """Direct regfile read."""
    dut.reg_rd.value = 0
    dut.reg_rd_addr.value = addr
    await RisingEdge(dut.clk)
    dut.reg_rd.value = 1
    await RisingEdge(dut.clk)
    dut.reg_rd.value = 0
    await RisingEdge(dut.clk)
    return int(dut.reg_rd_data.value)


@cocotb.test()
async def main_test(dut):
    """W1C race condition and interrupt stress test."""
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset
    dut.rst_n.value = 0
    dut.reg_wr.value = 0
    dut.reg_rd.value = 0
    dut.reg_wr_addr.value = 0
    dut.reg_wr_data.value = 0
    dut.reg_wr_strb.value = 0
    dut.reg_rd_addr.value = 0

    # Stub all hw_* inputs
    for attr in dir(dut):
        if attr.startswith('hw_'):
            try:
                getattr(dut, attr).value = 0
            except:
                pass

    await Timer(100, unit="ns")
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # T1: Normal set then clear sequence
    # Set hw_err_timeout, read it, then clear via W1C
    dut.hw_err_timeout.value = 1
    await RisingEdge(dut.clk)
    dut.hw_err_timeout.value = 0
    await RisingEdge(dut.clk)
    val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
    sb.check("T1a: hw_err_timeout sets bit [2]", (val & (1 << 2)) != 0)

    await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << 2)  # clear bit 2
    val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
    sb.check("T1b: W1C clear of bit [2]", (val & (1 << 2)) == 0)

    # T2: CRITICAL — HW set + SW clear in SAME cycle
    # First set the bit
    dut.hw_err_timeout.value = 1
    await RisingEdge(dut.clk)
    dut.hw_err_timeout.value = 0
    await RisingEdge(dut.clk)

    # Now simultaneously set HW and clear SW in the same cycle
    dut.hw_err_timeout.value = 1
    await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << 2)
    dut.hw_err_timeout.value = 0
    await RisingEdge(dut.clk)
    val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
    # HW set must win — the event should NOT be lost
    sb.check("T2: HW set + SW clear same cycle — HW wins (bit [2] still set)",
             (val & (1 << 2)) != 0)

    # Clear it properly for next test
    await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << 2)

    # T3: Set and clear each sticky bit independently
    test_bits = [
        (0, 'hw_err_nack_addr', 'ADDR_NACK'),
        (1, 'hw_err_nack_data', 'DATA_NACK'),
        (3, 'hw_err_fifo_overflow', 'FIFO_OVF'),
        (4, 'hw_err_fifo_underflow', 'FIFO_UNF'),
        (10, 'hw_xfer_done', 'XFER_DONE'),
        (12, 'hw_hj_received', 'HJ_RECV'),
        (14, 'hw_wake_event', 'WAKE'),
    ]
    for bit, hw_sig, name in test_bits:
        # Set
        if hasattr(dut, hw_sig):
            getattr(dut, hw_sig).value = 1
            await RisingEdge(dut.clk)
            getattr(dut, hw_sig).value = 0
            await RisingEdge(dut.clk)
            val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
            sb.check(f"T3: Set {name} bit [{bit}]", (val & (1 << bit)) != 0)
            # Clear
            await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << bit)
            val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
            sb.check(f"T3: Clear {name} bit [{bit}]", (val & (1 << bit)) == 0)

    # T4: W1C with data=0 — no clear
    dut.hw_err_timeout.value = 1
    await RisingEdge(dut.clk)
    dut.hw_err_timeout.value = 0
    await RisingEdge(dut.clk)
    await reg_write(dut, INTERRUPT_STATUS_ADDR, 0x0000)  # write 0 — no clear
    val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
    sb.check("T4: W1C with data=0 — no clear", (val & (1 << 2)) != 0)
    await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << 2)  # proper clear

    # T5: Rapid set/clear/set
    for _ in range(5):
        dut.hw_err_timeout.value = 1
        await RisingEdge(dut.clk)
        dut.hw_err_timeout.value = 0
        await reg_write(dut, INTERRUPT_STATUS_ADDR, 1 << 2)
    val = await reg_read(dut, INTERRUPT_STATUS_ADDR)
    sb.check("T5: Rapid set/clear — no stuck bits", (val & (1 << 2)) == 0)

    sb.report()
    assert sb.fail_count == 0, f"{sb.fail_count} failures detected"
