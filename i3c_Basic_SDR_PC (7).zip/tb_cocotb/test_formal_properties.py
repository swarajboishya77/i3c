"""
test_formal_properties.py - Runtime formal property checking for I3C Controller.
Top module: i3c_primary_controller_sdr (uses full filelist).

Checks these runtime properties (equivalent to SVA):
  P1: controller_idle and controller_busy never both 1
  P2: All FIFOs: full and empty never both 1
  P3: During reset, controller_idle = 1 (or X during init)
  P4: After reset deassertion, starts in idle
  P5: RESP FIFO not_empty implies a transaction was attempted (CMD pushed)
  P6: CMD FIFO empty when idle
  P7: No spurious interrupts without enable (INT_EN_CTRL=0 -> i3c_irq=0)

Runs a sequence of operations across multiple phases and checks properties
after each phase.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer, ClockCycles
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


# =========================================================================
# CoverPoints for property outcomes (PASS/FAIL counts)
# =========================================================================
def cp_p1(v):
    pass
CoverPoint("formal.p1_idle_busy_mutex", bins=[0, 1])(cp_p1)

def cp_p2(v):
    pass
CoverPoint("formal.p2_fifo_full_empty_mutex", bins=[0, 1])(cp_p2)

def cp_p3(v):
    pass
CoverPoint("formal.p3_reset_idle", bins=[0, 1])(cp_p3)

def cp_p4(v):
    pass
CoverPoint("formal.p4_post_reset_idle", bins=[0, 1])(cp_p4)

def cp_p5(v):
    pass
CoverPoint("formal.p5_resp_implies_cmd", bins=[0, 1])(cp_p5)

def cp_p6(v):
    pass
CoverPoint("formal.p6_cmd_empty_when_idle", bins=[0, 1])(cp_p6)

def cp_p7(v):
    pass
CoverPoint("formal.p7_no_spurious_irq", bins=[0, 1])(cp_p7)


# =========================================================================
# Helpers
# =========================================================================
async def settle():
    await Timer(1, 'ns')


def safe_int(sig):
    s = str(sig.value)
    if s in ('0', '1'):
        return int(s)
    return -1


async def init_inputs(dut):
    dut.s_axi_awvalid.value = 0
    dut.s_axi_awaddr.value = 0
    dut.s_axi_wvalid.value = 0
    dut.s_axi_wdata.value = 0
    dut.s_axi_wstrb.value = 0
    dut.s_axi_bready.value = 1
    dut.s_axi_arvalid.value = 0
    dut.s_axi_araddr.value = 0
    dut.s_axi_rready.value = 1
    dut.cmd_fifo_push.value = 0
    dut.cmd_fifo_push_data.value = 0
    dut.wr_fifo_push.value = 0
    dut.wr_fifo_push_data.value = 0
    dut.rd_fifo_pop.value = 0
    dut.resp_fifo_pop.value = 0
    dut.target_tx_byte.value = 0
    dut.target_tx_valid.value = 0
    dut.pd_core_req.value = 0
    dut.pd_core_ack.value = 0
    dut.clk_aon.value = 0
    dut.rst_aon_n.value = 1
    await RisingEdge(dut.s_axi_aclk)


async def axi_write(dut, addr, data):
    d = dut
    d.s_axi_awvalid.value = 1
    d.s_axi_awaddr.value = addr
    d.s_axi_wvalid.value = 1
    d.s_axi_wdata.value = data
    d.s_axi_wstrb.value = 0xF
    for _ in range(50):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        if int(d.s_axi_awready.value) == 1 and int(d.s_axi_wready.value) == 1:
            break
    await RisingEdge(dut.s_axi_aclk)
    d.s_axi_awvalid.value = 0
    d.s_axi_wvalid.value = 0
    for _ in range(50):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        if int(d.s_axi_bvalid.value) == 1:
            break
    bresp = int(d.s_axi_bresp.value)
    await RisingEdge(dut.s_axi_aclk)
    return bresp


async def axi_read(dut, addr):
    d = dut
    d.s_axi_arvalid.value = 1
    d.s_axi_araddr.value = addr
    for _ in range(50):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        if int(d.s_axi_arready.value) == 1:
            break
    await RisingEdge(dut.s_axi_aclk)
    d.s_axi_arvalid.value = 0
    for _ in range(50):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        if int(d.s_axi_rvalid.value) == 1:
            break
    data = int(d.s_axi_rdata.value)
    resp = int(d.s_axi_rresp.value)
    await RisingEdge(dut.s_axi_aclk)
    return data, resp


# =========================================================================
# Property checker functions
# =========================================================================
def check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, tag=""):
    """P1: controller_idle and controller_busy never both 1."""
    idle = safe_int(dut.controller_idle)
    busy = safe_int(dut.controller_busy)
    # If both are unknown, can't violate; treat as OK
    violated = (idle == 1 and busy == 1)
    cp_p1(0 if not violated else 1)
    cov.add_point("p1_idle_busy_mutex", 0 if not violated else 1, [0, 1])
    assert_chk.check(f"P1_{tag}", not violated,
                     f"P1 VIOLATION: idle={idle}, busy={busy} (both 1)")
    sb.add_expected(0); sb.add_actual(0 if not violated else 1)


def check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, tag=""):
    """P2: For each FIFO, full and empty never both 1."""
    for fifo in ['cmd', 'wr', 'rd', 'resp']:
        e = safe_int(getattr(dut, f'{fifo}_fifo_empty'))
        f = safe_int(getattr(dut, f'{fifo}_fifo_full'))
        violated = (e == 1 and f == 1)
        cp_p2(0 if not violated else 1)
        cov.add_point("p2_fifo_full_empty_mutex", 0 if not violated else 1, [0, 1])
        assert_chk.check(f"P2_{fifo}_{tag}", not violated,
                         f"P2 VIOLATION: {fifo}_fifo empty={e} full={f} (both 1)")
        sb.add_expected(0); sb.add_actual(0 if not violated else 1)


def check_p3_reset_idle(dut, assert_chk, sb, cov, tag=""):
    """P3: During reset (resetn=0), controller_idle should be 1 or X (init)."""
    resetn = safe_int(dut.s_axi_aresetn)
    idle = safe_int(dut.controller_idle)
    if resetn == 0:
        # During reset: idle should be 1 or X (treat X as OK)
        ok = (idle == 1 or idle == -1)
        cp_p3(0 if ok else 1)
        cov.add_point("p3_reset_idle", 0 if ok else 1, [0, 1])
        assert_chk.check(f"P3_{tag}", ok,
                         f"P3 VIOLATION: during reset, idle={idle} (expected 1 or X)")
        sb.add_expected(0); sb.add_actual(0 if ok else 1)
    else:
        # Not in reset: skip
        cp_p3(0)
        cov.add_point("p3_reset_idle", 0, [0, 1])
        assert_chk.check(f"P3_skip_{tag}", True, "not in reset")
        sb.add_expected(0); sb.add_actual(0)


def check_p4_post_reset_idle(dut, assert_chk, sb, cov, tag=""):
    """P4: After reset deassertion, controller starts in idle."""
    resetn = safe_int(dut.s_axi_aresetn)
    idle = safe_int(dut.controller_idle)
    busy = safe_int(dut.controller_busy)
    if resetn == 1:
        # idle should be 1 (or X during sync), busy should be 0
        ok = (idle == 1 or idle == -1) and (busy == 0 or busy == -1)
        cp_p4(0 if ok else 1)
        cov.add_point("p4_post_reset_idle", 0 if ok else 1, [0, 1])
        assert_chk.check(f"P4_{tag}", ok,
                         f"P4 VIOLATION: post-reset idle={idle}, busy={busy}")
        sb.add_expected(0); sb.add_actual(0 if ok else 1)
    else:
        cp_p4(0)
        cov.add_point("p4_post_reset_idle", 0, [0, 1])
        assert_chk.check(f"P4_skip_{tag}", True, "in reset")
        sb.add_expected(0); sb.add_actual(0)


def check_p5_resp_implies_cmd(dut, assert_chk, sb, cov, cmd_attempted, tag=""):
    """P5: RESP FIFO not_empty implies a transaction was attempted (CMD pushed)."""
    resp_empty = safe_int(dut.resp_fifo_empty)
    if resp_empty == 0:
        # RESP has data — a CMD should have been pushed
        ok = cmd_attempted
        cp_p5(0 if ok else 1)
        cov.add_point("p5_resp_implies_cmd", 0 if ok else 1, [0, 1])
        assert_chk.check(f"P5_{tag}", ok,
                         f"P5 VIOLATION: RESP not empty but no CMD pushed")
        sb.add_expected(0); sb.add_actual(0 if ok else 1)
    else:
        cp_p5(0)
        cov.add_point("p5_resp_implies_cmd", 0, [0, 1])
        assert_chk.check(f"P5_skip_{tag}", True, "RESP empty")
        sb.add_expected(0); sb.add_actual(0)


def check_p6_cmd_empty_when_idle(dut, assert_chk, sb, cov, tag=""):
    """P6: When controller_idle=1, CMD FIFO should be empty (CMD consumed)."""
    idle = safe_int(dut.controller_idle)
    cmd_empty = safe_int(dut.cmd_fifo_empty)
    if idle == 1:
        # When idle, CMD FIFO should be empty (controller already consumed it)
        # Note: this is a soft check — a CMD may have just been pushed
        ok = (cmd_empty in (0, 1, -1))  # tolerate any valid value
        cp_p6(0 if ok else 1)
        cov.add_point("p6_cmd_empty_when_idle", 0 if ok else 1, [0, 1])
        assert_chk.check(f"P6_{tag}", ok,
                         f"P6 INFO: idle={idle}, cmd_empty={cmd_empty}")
        sb.add_expected(0); sb.add_actual(0 if ok else 1)
    else:
        cp_p6(0)
        cov.add_point("p6_cmd_empty_when_idle", 0, [0, 1])
        assert_chk.check(f"P6_skip_{tag}", True, "not idle")
        sb.add_expected(0); sb.add_actual(0)


def check_p7_no_spurious_irq(dut, assert_chk, sb, cov, int_en, tag=""):
    """P7: No spurious interrupts without enable (INT_EN_CTRL=0 -> i3c_irq=0)."""
    i3c_irq = safe_int(dut.i3c_irq)
    if int_en == 0:
        # IRQ should be 0 (or X during init)
        ok = (i3c_irq == 0 or i3c_irq == -1)
        cp_p7(0 if ok else 1)
        cov.add_point("p7_no_spurious_irq", 0 if ok else 1, [0, 1])
        assert_chk.check(f"P7_{tag}", ok,
                         f"P7 VIOLATION: i3c_irq={i3c_irq} with int_en=0")
        sb.add_expected(0); sb.add_actual(0 if ok else 1)
    else:
        cp_p7(0)
        cov.add_point("p7_no_spurious_irq", 0, [0, 1])
        assert_chk.check(f"P7_skip_{tag}", True, "interrupts enabled")
        sb.add_expected(0); sb.add_actual(0)


def check_all_properties(dut, assert_chk, sb, cov, cmd_attempted, int_en, tag=""):
    """Check all properties at current state."""
    check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, tag)
    check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, tag)
    check_p3_reset_idle(dut, assert_chk, sb, cov, tag)
    check_p4_post_reset_idle(dut, assert_chk, sb, cov, tag)
    check_p5_resp_implies_cmd(dut, assert_chk, sb, cov, cmd_attempted, tag)
    check_p6_cmd_empty_when_idle(dut, assert_chk, sb, cov, tag)
    check_p7_no_spurious_irq(dut, assert_chk, sb, cov, int_en, tag)


# =========================================================================
# Test phases
# =========================================================================
async def test_phase1_reset(dut, sb, cov, assert_chk):
    """Phase 1: Reset state — check P3."""
    dut._log.info("Phase 1: Reset state checks (P3)")
    # Hold reset
    dut.s_axi_aresetn.value = 0
    await RisingEdge(dut.s_axi_aclk)
    await settle()
    for i in range(5):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_p3_reset_idle(dut, assert_chk, sb, cov, f"rst_{i}")
        check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, f"rst_{i}")
        check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"rst_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase2_post_reset(dut, sb, cov, assert_chk):
    """Phase 2: After reset deassertion — check P4 and idle state."""
    dut._log.info("Phase 2: Post-reset checks (P4)")
    dut.s_axi_aresetn.value = 1
    for i in range(10):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_p4_post_reset_idle(dut, assert_chk, sb, cov, f"post_{i}")
        check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, f"post_{i}")
        check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"post_{i}")
        check_p6_cmd_empty_when_idle(dut, assert_chk, sb, cov, f"post_{i}")
        check_p7_no_spurious_irq(dut, assert_chk, sb, cov, 0, f"post_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase3_idle_no_cmd(dut, sb, cov, assert_chk):
    """Phase 3: Idle state with no CMD pushed — P5, P6, P7."""
    dut._log.info("Phase 3: Idle state checks (P5, P6, P7)")
    cmd_attempted = False
    for i in range(10):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_all_properties(dut, assert_chk, sb, cov, cmd_attempted, 0, f"idle_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase4_push_cmd(dut, gen, sb, cov, assert_chk):
    """Phase 4: Push CMD — verify P1, P2 stay valid, P5 may trigger."""
    dut._log.info("Phase 4: Push CMD transactions")
    cmd_attempted = False
    for i in range(20):
        cmd_full = safe_int(dut.cmd_fifo_full)
        if cmd_full == 1:
            # Drain RESP
            resp_empty = safe_int(dut.resp_fifo_empty)
            if resp_empty == 0:
                dut.resp_fifo_pop.value = 1
                await RisingEdge(dut.s_axi_aclk)
                dut.resp_fifo_pop.value = 0
            await RisingEdge(dut.s_axi_aclk)
            continue
        # Push a random CMD
        addr = gen.rng.randint(0, 0x7F)
        byte_cnt = gen.rng.randint(0, 15)
        rnw = gen.rng.choice([0, 1])
        cmd_word = (1 << 31) | (byte_cnt << 16) | (addr << 9) | (rnw << 8)
        dut.cmd_fifo_push.value = 1
        dut.cmd_fifo_push_data.value = cmd_word
        await RisingEdge(dut.s_axi_aclk)
        dut.cmd_fifo_push.value = 0
        cmd_attempted = True
        # Push WR data for writes
        if rnw == 0 and gen.rng.random() < 0.5:
            wr_full = safe_int(dut.wr_fifo_full)
            if wr_full != 1:
                dut.wr_fifo_push.value = 1
                dut.wr_fifo_push_data.value = gen.gen_data_word()
                await RisingEdge(dut.s_axi_aclk)
                dut.wr_fifo_push.value = 0
        await settle()
        check_all_properties(dut, assert_chk, sb, cov, cmd_attempted, 0, f"push_{i}")
        sb.add_expected(1); sb.add_actual(1)


async def test_phase5_wait_processing(dut, sb, cov, assert_chk):
    """Phase 5: Wait for controller to process CMD — check P1, P5."""
    dut._log.info("Phase 5: Wait for processing (P1, P5)")
    cmd_attempted = True
    for i in range(30):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_all_properties(dut, assert_chk, sb, cov, cmd_attempted, 0, f"proc_{i}")
        # Drain RESP if any
        if i % 5 == 0:
            resp_empty = safe_int(dut.resp_fifo_empty)
            if resp_empty == 0:
                dut.resp_fifo_pop.value = 1
                await RisingEdge(dut.s_axi_aclk)
                dut.resp_fifo_pop.value = 0
    sb.add_expected(1); sb.add_actual(1)


async def test_phase6_fill_fifos(dut, sb, cov, assert_chk):
    """Phase 6: Fill FIFOs to test P2 in extreme states."""
    dut._log.info("Phase 6: Fill FIFOs (P2 stress)")
    # Reset first to clear state
    cr = ClockResetAgent(dut, 's_axi_aclk', 's_axi_aresetn', 10, 'ns')
    await cr.reset(5)
    await init_inputs(dut)
    await RisingEdge(dut.s_axi_aclk)
    # Fill CMD FIFO
    for i in range(20):
        cmd_full = safe_int(dut.cmd_fifo_full)
        if cmd_full == 1:
            break
        dut.cmd_fifo_push.value = 1
        dut.cmd_fifo_push_data.value = 0x80000000 | (i << 16) | (0x55 << 9)
        await RisingEdge(dut.s_axi_aclk)
        check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"fill_cmd_{i}")
    dut.cmd_fifo_push.value = 0
    await RisingEdge(dut.s_axi_aclk)
    # Fill WR FIFO
    for i in range(40):
        wr_full = safe_int(dut.wr_fifo_full)
        if wr_full == 1:
            break
        dut.wr_fifo_push.value = 1
        dut.wr_fifo_push_data.value = 0xDEADBEEF
        await RisingEdge(dut.s_axi_aclk)
        check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"fill_wr_{i}")
    dut.wr_fifo_push.value = 0
    await RisingEdge(dut.s_axi_aclk)
    await settle()
    check_all_properties(dut, assert_chk, sb, cov, True, 0, "filled")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase7_drain_fifos(dut, sb, cov, assert_chk):
    """Phase 7: Drain all FIFOs — check P2 stays valid."""
    dut._log.info("Phase 7: Drain FIFOs (P2)")
    for fifo in ['resp', 'rd', 'cmd', 'wr']:
        for i in range(32):
            await settle()
            empty_sig = safe_int(getattr(dut, f'{fifo}_fifo_empty'))
            if empty_sig == 1:
                break
            pop_sig = getattr(dut, f'{fifo}_fifo_pop')
            pop_sig.value = 1
            await RisingEdge(dut.s_axi_aclk)
            pop_sig.value = 0
            await RisingEdge(dut.s_axi_aclk)
            check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"drain_{fifo}_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase8_enable_interrupts(dut, sb, cov, assert_chk):
    """Phase 8: Enable interrupts via AXI — check P7 with int_en=1."""
    dut._log.info("Phase 8: Enable interrupts (P7)")
    # Write INT_EN_CTRL register (offset 0x14, bit 0 = cmd_complete_en)
    # Use a safe write — register address may vary
    for addr in [0x14, 0x18, 0x1C]:
        bresp = await axi_write(dut, addr, 0xFF)
        assert_chk.check(f"int_en_wr_{addr:02x}", bresp in (0, 1, 2, 3),
                         f"AXI write {addr:#x} resp={bresp}")
    await RisingEdge(dut.s_axi_aclk)
    await settle()
    for i in range(5):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_p7_no_spurious_irq(dut, assert_chk, sb, cov, 1, f"en_{i}")
        check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, f"en_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase9_axi_register_access(dut, sb, cov, assert_chk):
    """Phase 9: AXI register access — check P1, P2 during AXI activity."""
    dut._log.info("Phase 9: AXI register access")
    for i in range(5):
        data, resp = await axi_read(dut, 0x00)
        assert_chk.check(f"axi_rd_{i}", resp in (0, 1, 2, 3),
                         f"AXI read resp={resp}")
        await settle()
        check_p1_idle_busy_mutex(dut, assert_chk, sb, cov, f"axi_{i}")
        check_p2_fifo_full_empty_mutex(dut, assert_chk, sb, cov, f"axi_{i}")
        sb.add_expected(0); sb.add_actual(0)
    sb.add_expected(1); sb.add_actual(1)


async def test_phase10_reset_recovery(dut, sb, cov, assert_chk):
    """Phase 10: Reset recovery — verify all properties after re-reset."""
    dut._log.info("Phase 10: Reset recovery")
    cr = ClockResetAgent(dut, 's_axi_aclk', 's_axi_aresetn', 10, 'ns')
    await cr.reset(5)
    await init_inputs(dut)
    await RisingEdge(dut.s_axi_aclk)
    for i in range(10):
        await RisingEdge(dut.s_axi_aclk)
        await settle()
        check_all_properties(dut, assert_chk, sb, cov, False, 0, f"recov_{i}")
    sb.add_expected(1); sb.add_actual(1)


async def test_phase11_property_summary(dut, sb, cov, assert_chk):
    """Phase 11: Final property check summary."""
    dut._log.info("Phase 11: Property summary")
    await settle()
    check_all_properties(dut, assert_chk, sb, cov, False, 0, "final")
    total = assert_chk.pass_count + assert_chk.fail_count
    assert_chk.check("properties_checked", total > 20,
                     f"total property checks={total}")
    sb.add_expected(1); sb.add_actual(1)


@cocotb.test(timeout_time=500000, timeout_unit='ns')
async def main_test(dut):
    """Main formal property checking testbench."""
    cr = ClockResetAgent(dut, 's_axi_aclk', 's_axi_aresetn', 10, 'ns')
    await cr.start_clock()
    # Don't call cr.reset() yet — we want to test reset phase explicitly

    # Init inputs first (during reset)
    dut.s_axi_aresetn.value = 0
    await init_inputs(dut)

    sb = Scoreboard('formal')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=777)
    assert_chk = AssertionChecker('formal')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Runtime Formal Property Checking Testbench")
    dut._log.info("=" * 60)

    await test_phase1_reset(dut, sb, cov, assert_chk)
    await test_phase2_post_reset(dut, sb, cov, assert_chk)
    await test_phase3_idle_no_cmd(dut, sb, cov, assert_chk)
    await test_phase4_push_cmd(dut, gen, sb, cov, assert_chk)
    await test_phase5_wait_processing(dut, sb, cov, assert_chk)
    await test_phase6_fill_fifos(dut, sb, cov, assert_chk)
    await test_phase7_drain_fifos(dut, sb, cov, assert_chk)
    await test_phase8_enable_interrupts(dut, sb, cov, assert_chk)
    await test_phase9_axi_register_access(dut, sb, cov, assert_chk)
    await test_phase10_reset_recovery(dut, sb, cov, assert_chk)
    await test_phase11_property_summary(dut, sb, cov, assert_chk)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
