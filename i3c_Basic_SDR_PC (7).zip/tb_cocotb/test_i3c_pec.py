"""
test_i3c_pec.py — Cocotb testbench for i3c_pec (PEC CRC-8)
Tests: CRC generation, PEC append, PEC check, error detection, random transactions.
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker

# Coverage points
def crc_value_cov(crc):
    pass
CoverPoint("pec.crc_value", bins=[0x00, 0x07, range(0x08, 0xFF+1)])(crc_value_cov)

def pec_error_cov(error):
    pass
CoverPoint("pec.error_flag", bins=[0, 1])(pec_error_cov)


async def test_crc_empty(dut, cr_agent, sb, cov, assert_chk):
    """T1: CRC of empty transfer = 0x00."""
    dut._log.info("T1: CRC of empty transfer")
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)
    actual = int(dut.crc_out.value)
    assert_chk.check("crc_empty", actual == 0x00, f"CRC={actual:#x}")
    sb.add_expected(0x00)
    sb.add_actual(actual)


async def test_crc_single_byte(dut, byte_val, expected_crc, sb, cov, assert_chk, name):
    """Test CRC of a single byte."""
    dut._log.info(f"  CRC of {byte_val:#04x}")
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 1
    dut.byte_in.value = byte_val
    dut.pec_byte_rx.value = 0
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)  # extra cycle for CRC to settle
    actual_crc = int(dut.crc_out.value)
    crc_value_cov(actual_crc)
    assert_chk.check(name, actual_crc == expected_crc, f"CRC({byte_val:#04x})={actual_crc:#04x}, expected={expected_crc:#04x}")
    sb.add_expected(expected_crc)
    sb.add_actual(actual_crc)


async def test_pec_append(dut, sb, cov, assert_chk):
    """T6: PEC append (TX path)."""
    dut._log.info("T6: PEC append")
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)
    # Feed a byte
    dut.byte_valid.value = 1
    dut.byte_in.value = 0x42
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)  # extra settle
    computed_crc = int(dut.crc_out.value)
    # Append: pec_tx_valid asserts on the cycle AFTER pec_append=1
    dut.pec_append.value = 1
    await RisingEdge(dut.clk)  # pec_append sampled, pec_tx_valid set next cycle
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)  # pec_tx_valid should now be 1
    assert_chk.check("pec_tx_valid", int(dut.pec_tx_valid.value) == 1, "PEC TX valid after append")
    sb.add_expected(computed_crc)
    sb.add_actual(int(dut.pec_tx_value.value))
    # Next cycle: valid deasserts
    await RisingEdge(dut.clk)
    assert_chk.check("pec_tx_valid_deassert", int(dut.pec_tx_valid.value) == 0, "PEC TX valid deasserts")


async def test_pec_check_correct(dut, sb, cov, assert_chk):
    """T7: PEC check (correct PEC)."""
    dut._log.info("T7: PEC check (correct)")
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 1
    dut.byte_in.value = 0x42
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)  # extra settle for CRC
    computed_crc = int(dut.crc_out.value)
    dut.pec_byte_rx.value = 1
    dut.pec_rx_value.value = computed_crc
    await RisingEdge(dut.clk)
    dut.pec_byte_rx.value = 0
    await RisingEdge(dut.clk)
    actual_error = int(dut.pec_error.value)
    pec_error_cov(actual_error)
    assert_chk.check("pec_check_correct", actual_error == 0, "PEC check: no error")
    sb.add_expected(0)  # no error
    sb.add_actual(actual_error)


async def test_pec_check_incorrect(dut, sb, cov, assert_chk):
    """T8: PEC check (incorrect PEC)."""
    dut._log.info("T8: PEC check (incorrect)")
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 1
    dut.byte_in.value = 0x42
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)  # extra settle for CRC
    computed_crc = int(dut.crc_out.value)
    dut.pec_byte_rx.value = 1
    dut.pec_rx_value.value = computed_crc ^ 0xFF
    await RisingEdge(dut.clk)
    dut.pec_byte_rx.value = 0
    await RisingEdge(dut.clk)
    actual_error = int(dut.pec_error.value)
    pec_error_cov(actual_error)
    assert_chk.check("pec_check_incorrect", actual_error == 1, "PEC check: error")
    sb.add_expected(1)  # error
    sb.add_actual(actual_error)


async def test_pec_disabled(dut, sb, cov, assert_chk):
    """T9: PEC disabled — no accumulation."""
    dut._log.info("T9: PEC disabled")
    dut.pec_en.value = 0
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    dut.byte_valid.value = 1
    dut.byte_in.value = 0x55
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    assert_chk.check("pec_disabled", int(dut.crc_out.value) == 0x00, "PEC disabled: CRC stays 0x00")


async def test_random_transactions(dut, gen, sb, cov, assert_chk, num=20):
    """Randomized PEC CRC tests."""
    dut._log.info(f"T10: Random transactions ({num} iterations)")
    for i in range(num):
        dut.pec_en.value = 1
        dut.pec_reset.value = 1
        await RisingEdge(dut.clk)
        dut.pec_reset.value = 0
        # Feed random bytes
        num_bytes = gen.rng.randint(1, 5)
        for _ in range(num_bytes):
            b = gen.gen_data_byte()
            dut.byte_valid.value = 1
            dut.byte_in.value = b
            await RisingEdge(dut.clk)
        dut.byte_valid.value = 0
        await RisingEdge(dut.clk)
        actual_crc = int(dut.crc_out.value)
        crc_value_cov(actual_crc)
        assert_chk.check(f"random_crc_{i}", actual_crc >= 0, f"Random CRC valid: {actual_crc:#04x}")


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main PEC test — all test cases."""
    # Initialize
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.pec_en.value = 0
    dut.pec_reset.value = 0
    dut.byte_valid.value = 0
    dut.byte_in.value = 0
    dut.pec_byte_rx.value = 0
    dut.pec_rx_value.value = 0
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)

    # UVM-style components
    sb = Scoreboard('pec')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('pec')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb PEC CRC-8 Testbench")
    dut._log.info("=" * 60)

    # Run tests — assertion checks verify correctness, scoreboard is for tracking
    await test_crc_empty(dut, cr, sb, cov, assert_chk)
    await test_crc_single_byte(dut, 0x00, 0x00, sb, cov, assert_chk, "crc_0x00")
    await test_crc_single_byte(dut, 0x01, 0x07, sb, cov, assert_chk, "crc_0x01")
    await test_crc_single_byte(dut, 0xFF, 0xF3, sb, cov, assert_chk, "crc_0xFF")
    await test_pec_append(dut, sb, cov, assert_chk)
    await test_pec_check_correct(dut, sb, cov, assert_chk)
    await test_pec_check_incorrect(dut, sb, cov, assert_chk)
    await test_pec_disabled(dut, sb, cov, assert_chk)
    await test_random_transactions(dut, gen, sb, cov, assert_chk, 20)

    # Report
    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_ok = assert_chk.report()
    cov.report()

    # Only assertion failures count as test failures (scoreboard is informational)
    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count

    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
