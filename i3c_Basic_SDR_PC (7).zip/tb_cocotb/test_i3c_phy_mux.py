"""
test_i3c_phy_mux.py — Cocotb testbench for i3c_phy_mux
Tests: sel=00 controller, sel=01 target, sel=10 bootstrap, sel=11 reserved,
       readback broadcast, all combinations, SDA/SCL drive selection, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

The mux is purely combinational — no clock, no reset, no state.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def sel_cov(s):
    pass
CoverPoint("mux.sel", bins=[0, 1, 2, 3])(sel_cov)


async def settle():
    await Timer(1, 'ns')


async def check_mux(dut, sel, dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe,
                    tgt_sda_o, tgt_sda_oe,
                    boot_sda_o, boot_sda_oe, boot_scl_o, boot_scl_oe,
                    pad_sda_i, pad_scl_i,
                    sb, cov, assert_chk, name):
    """Set inputs, check outputs."""
    dut.phy_mux_sel.value = sel
    dut.dphy_sda_o.value = dphy_sda_o
    dut.dphy_sda_oe.value = dphy_sda_oe
    dut.dphy_scl_o.value = dphy_scl_o
    dut.dphy_scl_oe.value = dphy_scl_oe
    dut.tgt_sda_o.value = tgt_sda_o
    dut.tgt_sda_oe.value = tgt_sda_oe
    dut.boot_sda_o.value = boot_sda_o
    dut.boot_sda_oe.value = boot_sda_oe
    dut.boot_scl_o.value = boot_scl_o
    dut.boot_scl_oe.value = boot_scl_oe
    dut.pad_sda_i.value = pad_sda_i
    dut.pad_scl_i.value = pad_scl_i
    await settle()
    sel_cov(sel)

    # Determine expected SDA output
    if sel == 0:
        exp_sda_o = dphy_sda_o
        exp_sda_oe = dphy_sda_oe
        exp_scl_o = dphy_scl_o
        exp_scl_oe = dphy_scl_oe
    elif sel == 1:
        exp_sda_o = tgt_sda_o
        exp_sda_oe = tgt_sda_oe
        exp_scl_o = 1  # target never drives SCL
        exp_scl_oe = 0
    elif sel == 2:
        exp_sda_o = boot_sda_o
        exp_sda_oe = boot_sda_oe
        exp_scl_o = boot_scl_o
        exp_scl_oe = boot_scl_oe
    else:  # sel == 3 (reserved)
        exp_sda_o = 1
        exp_sda_oe = 0
        exp_scl_o = 1
        exp_scl_oe = 0

    a_sda_o = int(dut.pad_sda_o.value)
    a_sda_oe = int(dut.pad_sda_oe.value)
    a_scl_o = int(dut.pad_scl_o.value)
    a_scl_oe = int(dut.pad_scl_oe.value)

    assert_chk.check(f"{name}_sda_o", a_sda_o == exp_sda_o,
                     f"sel={sel} pad_sda_o={a_sda_o} (expected {exp_sda_o})")
    assert_chk.check(f"{name}_sda_oe", a_sda_oe == exp_sda_oe,
                     f"sel={sel} pad_sda_oe={a_sda_oe} (expected {exp_sda_oe})")
    assert_chk.check(f"{name}_scl_o", a_scl_o == exp_scl_o,
                     f"sel={sel} pad_scl_o={a_scl_o} (expected {exp_scl_o})")
    assert_chk.check(f"{name}_scl_oe", a_scl_oe == exp_scl_oe,
                     f"sel={sel} pad_scl_oe={a_scl_oe} (expected {exp_scl_oe})")
    sb.add_expected(exp_sda_o); sb.add_actual(a_sda_o)
    sb.add_expected(exp_sda_oe); sb.add_actual(a_sda_oe)
    sb.add_expected(exp_scl_o); sb.add_actual(a_scl_o)
    sb.add_expected(exp_scl_oe); sb.add_actual(a_scl_oe)

    # Check readback broadcast
    assert_chk.check(f"{name}_dphy_sda_i", int(dut.dphy_sda_i.value) == pad_sda_i,
                     f"dphy_sda_i={int(dut.dphy_sda_i.value)} expected={pad_sda_i}")
    assert_chk.check(f"{name}_dphy_scl_i", int(dut.dphy_scl_i.value) == pad_scl_i,
                     f"dphy_scl_i={int(dut.dphy_scl_i.value)} expected={pad_scl_i}")
    assert_chk.check(f"{name}_tgt_sda_i", int(dut.tgt_sda_i.value) == pad_sda_i,
                     f"tgt_sda_i={int(dut.tgt_sda_i.value)} expected={pad_sda_i}")
    assert_chk.check(f"{name}_tgt_scl_i", int(dut.tgt_scl_i.value) == pad_scl_i,
                     f"tgt_scl_i={int(dut.tgt_scl_i.value)} expected={pad_scl_i}")
    assert_chk.check(f"{name}_boot_sda_i", int(dut.boot_sda_i.value) == pad_sda_i,
                     f"boot_sda_i={int(dut.boot_sda_i.value)} expected={pad_sda_i}")
    assert_chk.check(f"{name}_boot_scl_i", int(dut.boot_scl_i.value) == pad_scl_i,
                     f"boot_scl_i={int(dut.boot_scl_i.value)} expected={pad_scl_i}")


async def test_sel0_controller(dut, sb, cov, assert_chk):
    """T1: sel=00 — Digital PHY (Active Controller) drives SDA and SCL."""
    dut._log.info("T1: sel=00 (Controller)")
    await check_mux(dut, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0,
                    sb, cov, assert_chk, "sel0_a")
    await check_mux(dut, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1,
                    sb, cov, assert_chk, "sel0_b")


async def test_sel1_target(dut, sb, cov, assert_chk):
    """T2: sel=01 — Target Engine drives SDA only, never SCL."""
    dut._log.info("T2: sel=01 (Target)")
    await check_mux(dut, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0,
                    sb, cov, assert_chk, "sel1_a")
    await check_mux(dut, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1,
                    sb, cov, assert_chk, "sel1_b")
    # Verify SCL is never driven by target
    dut.phy_mux_sel.value = 1
    dut.tgt_sda_o.value = 0
    dut.tgt_sda_oe.value = 1
    await settle()
    assert_chk.check("sel1_scl_oe_zero", int(dut.pad_scl_oe.value) == 0,
                     f"target scl_oe={int(dut.pad_scl_oe.value)} (expected 0)")
    assert_chk.check("sel1_scl_o_one", int(dut.pad_scl_o.value) == 1,
                     f"target scl_o={int(dut.pad_scl_o.value)} (expected 1 — released)")


async def test_sel2_bootstrap(dut, sb, cov, assert_chk):
    """T3: sel=10 — Bootstrap drives both SDA and SCL."""
    dut._log.info("T3: sel=10 (Bootstrap)")
    await check_mux(dut, 2, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0,
                    sb, cov, assert_chk, "sel2_a")
    await check_mux(dut, 2, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1,
                    sb, cov, assert_chk, "sel2_b")


async def test_sel3_reserved(dut, sb, cov, assert_chk):
    """T4: sel=11 — Reserved, bus released (high-Z)."""
    dut._log.info("T4: sel=11 (Reserved)")
    await check_mux(dut, 3, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1,
                    sb, cov, assert_chk, "sel3_a")
    await check_mux(dut, 3, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0,
                    sb, cov, assert_chk, "sel3_b")


async def test_readback_broadcast(dut, sb, cov, assert_chk):
    """T5: Pad readback broadcast to all three blocks regardless of sel."""
    dut._log.info("T5: Readback broadcast")
    for sel in range(4):
        for pad_sda, pad_scl in [(0, 0), (0, 1), (1, 0), (1, 1)]:
            dut.phy_mux_sel.value = sel
            dut.pad_sda_i.value = pad_sda
            dut.pad_scl_i.value = pad_scl
            # Set all driver inputs to 0 to avoid bus contention
            dut.dphy_sda_o.value = 0; dut.dphy_sda_oe.value = 0
            dut.dphy_scl_o.value = 0; dut.dphy_scl_oe.value = 0
            dut.tgt_sda_o.value = 0; dut.tgt_sda_oe.value = 0
            dut.boot_sda_o.value = 0; dut.boot_sda_oe.value = 0
            dut.boot_scl_o.value = 0; dut.boot_scl_oe.value = 0
            await settle()
            ds = int(dut.dphy_sda_i.value)
            dc = int(dut.dphy_scl_i.value)
            ts = int(dut.tgt_sda_i.value)
            tc = int(dut.tgt_scl_i.value)
            bs = int(dut.boot_sda_i.value)
            bc = int(dut.boot_scl_i.value)
            assert_chk.check(f"rb_sel{sel}_sda{pad_sda}scl{pad_scl}_dphy",
                             ds == pad_sda and dc == pad_scl,
                             f"sel={sel} dphy: sda={ds} scl={dc}")
            assert_chk.check(f"rb_sel{sel}_sda{pad_sda}scl{pad_scl}_tgt",
                             ts == pad_sda and tc == pad_scl,
                             f"sel={sel} tgt: sda={ts} scl={tc}")
            assert_chk.check(f"rb_sel{sel}_sda{pad_sda}scl{pad_scl}_boot",
                             bs == pad_sda and bc == pad_scl,
                             f"sel={sel} boot: sda={bs} scl={bc}")
            sb.add_expected(pad_sda); sb.add_actual(ds)


async def test_all_combinations(dut, sb, cov, assert_chk):
    """T6: All 4 sel values with various input combinations."""
    dut._log.info("T6: All combinations")
    test_vectors = [
        # (dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe,
        #  tgt_sda_o, tgt_sda_oe, boot_sda_o, boot_sda_oe, boot_scl_o, boot_scl_oe)
        (1, 1, 1, 1, 0, 1, 1, 0, 0, 1),
        (0, 0, 0, 0, 1, 0, 0, 1, 1, 0),
        (1, 0, 0, 1, 1, 1, 0, 0, 1, 1),
        (0, 1, 1, 0, 0, 0, 1, 1, 0, 0),
    ]
    for sel in range(4):
        for i, v in enumerate(test_vectors):
            await check_mux(dut, sel, v[0], v[1], v[2], v[3], v[4], v[5],
                            v[6], v[7], v[8], v[9], 1, 1,
                            sb, cov, assert_chk, f"all_sel{sel}_v{i}")


async def test_random_selections(dut, gen, sb, cov, assert_chk, num=20):
    """T7: Randomized sel and input combinations."""
    dut._log.info(f"T7: Random selections ({num})")
    for i in range(num):
        sel = gen.rng.randint(0, 3)
        dphy_sda_o = gen.rng.randint(0, 1)
        dphy_sda_oe = gen.rng.randint(0, 1)
        dphy_scl_o = gen.rng.randint(0, 1)
        dphy_scl_oe = gen.rng.randint(0, 1)
        tgt_sda_o = gen.rng.randint(0, 1)
        tgt_sda_oe = gen.rng.randint(0, 1)
        boot_sda_o = gen.rng.randint(0, 1)
        boot_sda_oe = gen.rng.randint(0, 1)
        boot_scl_o = gen.rng.randint(0, 1)
        boot_scl_oe = gen.rng.randint(0, 1)
        pad_sda_i = gen.rng.randint(0, 1)
        pad_scl_i = gen.rng.randint(0, 1)
        await check_mux(dut, sel, dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe,
                        tgt_sda_o, tgt_sda_oe,
                        boot_sda_o, boot_sda_oe, boot_scl_o, boot_scl_oe,
                        pad_sda_i, pad_scl_i,
                        sb, cov, assert_chk, f"rand_{i}")


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main PHY mux test — all test cases."""
    # The mux is purely combinational — no clock, no reset. Use Timer for delays.
    # Initialize all inputs
    dut.phy_mux_sel.value = 0
    dut.dphy_sda_o.value = 0
    dut.dphy_sda_oe.value = 0
    dut.dphy_scl_o.value = 0
    dut.dphy_scl_oe.value = 0
    dut.tgt_sda_o.value = 0
    dut.tgt_sda_oe.value = 0
    dut.boot_sda_o.value = 0
    dut.boot_sda_oe.value = 0
    dut.boot_scl_o.value = 0
    dut.boot_scl_oe.value = 0
    dut.pad_sda_i.value = 0
    dut.pad_scl_i.value = 0
    await settle()

    sb = Scoreboard('phy_mux')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('phy_mux')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb PHY Mux Testbench")
    dut._log.info("=" * 60)

    await test_sel0_controller(dut, sb, cov, assert_chk)
    await test_sel1_target(dut, sb, cov, assert_chk)
    await test_sel2_bootstrap(dut, sb, cov, assert_chk)
    await test_sel3_reserved(dut, sb, cov, assert_chk)
    await test_readback_broadcast(dut, sb, cov, assert_chk)
    await test_all_combinations(dut, sb, cov, assert_chk)
    await test_random_selections(dut, gen, sb, cov, assert_chk, 20)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
