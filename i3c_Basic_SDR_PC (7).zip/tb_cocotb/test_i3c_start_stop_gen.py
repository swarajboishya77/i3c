"""
test_i3c_start_stop_gen.py — Cocotb testbench for i3c_start_stop_gen
Tests: idle, START, STOP, Repeated START, Release, multiple cycles, larger timing,
       no spurious done.
Uses small config values (2-4) for fast simulation.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def done_cov(d):
    pass
CoverPoint("ss.done", bins=[0, 1])(done_cov)


def set_config(dut, tsu_start=3, thd_start=2, tsu_stop=3, bus_free=4):
    dut.cfg_tsu_start.value = tsu_start
    dut.cfg_thd_start.value = thd_start
    dut.cfg_tsu_stop.value = tsu_stop
    dut.cfg_bus_free_time.value = bus_free


async def wait_for_done(dut, timeout=200):
    """Wait for done=1 pulse. Returns number of cycles waited, or -1 on timeout."""
    for i in range(timeout):
        await RisingEdge(dut.clk)
        if int(dut.done.value) == 1:
            return i + 1
    return -1


async def test_idle(dut, sb, cov, assert_chk):
    """T1: Idle state — no commands, busy=0, done=0, outputs high-Z."""
    dut._log.info("T1: Idle state")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_start.value = 0
    dut.cmd_repeat_start.value = 0
    dut.cmd_stop.value = 0
    dut.cmd_release.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    done = int(dut.done.value)
    sda_oe = int(dut.sda_oe.value)
    scl_oe = int(dut.scl_oe.value)
    done_cov(done)
    assert_chk.check("idle_busy", busy == 0, f"idle: busy={busy} (expected 0)")
    assert_chk.check("idle_done", done == 0, f"idle: done={done} (expected 0)")
    assert_chk.check("idle_highz", sda_oe == 0 and scl_oe == 0,
                     f"idle: sda_oe={sda_oe} scl_oe={scl_oe} (expected 0,0 — high-Z)")
    sb.add_expected(0); sb.add_actual(done)


async def test_start(dut, sb, cov, assert_chk):
    """T2: START condition generation."""
    dut._log.info("T2: START")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_start.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    # Issue cmd_start
    dut.cmd_start.value = 1
    await RisingEdge(dut.clk)
    dut.cmd_start.value = 0
    # Check busy asserts
    await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    assert_chk.check("start_busy", busy == 1, f"START: busy={busy} (expected 1)")
    # Wait for done
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("start_done", cycles > 0, f"START: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
        # After done, busy should de-assert
        await RisingEdge(dut.clk)
        busy = int(dut.busy.value)
        assert_chk.check("start_done_busy_clear", busy == 0,
                         f"START: after done, busy={busy} (expected 0)")


async def test_stop(dut, sb, cov, assert_chk):
    """T3: STOP condition generation."""
    dut._log.info("T3: STOP")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_stop.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.cmd_stop.value = 1
    await RisingEdge(dut.clk)
    dut.cmd_stop.value = 0
    await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    assert_chk.check("stop_busy", busy == 1, f"STOP: busy={busy} (expected 1)")
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("stop_done", cycles > 0, f"STOP: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
        await RisingEdge(dut.clk)
        busy = int(dut.busy.value)
        assert_chk.check("stop_done_busy_clear", busy == 0,
                         f"STOP: after done, busy={busy} (expected 0)")


async def test_repeat_start(dut, sb, cov, assert_chk):
    """T4: Repeated START condition generation."""
    dut._log.info("T4: Repeated START")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_repeat_start.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.cmd_repeat_start.value = 1
    await RisingEdge(dut.clk)
    dut.cmd_repeat_start.value = 0
    await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    assert_chk.check("rstart_busy", busy == 1, f"Repeated START: busy={busy} (expected 1)")
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("rstart_done", cycles > 0, f"Repeated START: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
        await RisingEdge(dut.clk)
        busy = int(dut.busy.value)
        assert_chk.check("rstart_done_busy_clear", busy == 0,
                         f"Repeated START: after done, busy={busy} (expected 0)")


async def test_release(dut, sb, cov, assert_chk):
    """T5: Release bus (high-Z)."""
    dut._log.info("T5: Release")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_release.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.cmd_release.value = 1
    await RisingEdge(dut.clk)
    dut.cmd_release.value = 0
    # Release should be quick — done in 1-2 cycles
    cycles = await wait_for_done(dut, 20)
    done_cov(1)
    assert_chk.check("release_done", cycles > 0, f"Release: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
        await RisingEdge(dut.clk)
        sda_oe = int(dut.sda_oe.value)
        scl_oe = int(dut.scl_oe.value)
        assert_chk.check("release_highz",
                         sda_oe == 0 and scl_oe == 0,
                         f"after release: sda_oe={sda_oe} scl_oe={scl_oe} (expected 0,0)")
        busy = int(dut.busy.value)
        assert_chk.check("release_busy_clear", busy == 0, f"after release: busy={busy} (expected 0)")


async def test_multiple_cycles(dut, sb, cov, assert_chk):
    """T6: Multiple START/STOP cycles back-to-back."""
    dut._log.info("T6: Multiple cycles")
    set_config(dut, 2, 2, 2, 2)
    for op in ['start', 'stop', 'start', 'release', 'stop']:
        for _ in range(2):
            await RisingEdge(dut.clk)
        if op == 'start':
            dut.cmd_start.value = 1
        elif op == 'stop':
            dut.cmd_stop.value = 1
        elif op == 'release':
            dut.cmd_release.value = 1
        await RisingEdge(dut.clk)
        # Clear command
        dut.cmd_start.value = 0
        dut.cmd_stop.value = 0
        dut.cmd_release.value = 0
        dut.cmd_repeat_start.value = 0
        cycles = await wait_for_done(dut, 100)
        assert_chk.check(f"multi_{op}_done", cycles > 0,
                         f"multi: op={op} done never pulsed (waited {cycles} cycles)")
        if cycles > 0:
            sb.add_expected(1); sb.add_actual(1)
        # Wait for busy to clear
        for _ in range(3):
            await RisingEdge(dut.clk)


async def test_larger_timing(dut, sb, cov, assert_chk):
    """T7: Larger timing values."""
    dut._log.info("T7: Larger timing")
    set_config(dut, 10, 8, 10, 12)
    dut.cmd_start.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.cmd_start.value = 1
    await RisingEdge(dut.clk)
    dut.cmd_start.value = 0
    cycles = await wait_for_done(dut, 200)
    done_cov(1)
    assert_chk.check("larger_timing_start_done", cycles > 0,
                     f"larger timing START: done pulsed after {cycles} cycles")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
        # Total cycles should be at least tsu_start + tsu_start + thd_start = 10+10+8 = 28
        assert_chk.check("larger_timing_min_cycles", cycles >= 28,
                         f"larger timing: cycles={cycles} (expected >= 28)")


async def test_no_spurious_done(dut, sb, cov, assert_chk):
    """T8: No spurious done pulses in idle."""
    dut._log.info("T8: No spurious done")
    set_config(dut, 3, 2, 3, 4)
    dut.cmd_start.value = 0
    dut.cmd_stop.value = 0
    dut.cmd_repeat_start.value = 0
    dut.cmd_release.value = 0
    done_count = 0
    for _ in range(20):
        await RisingEdge(dut.clk)
        if int(dut.done.value) == 1:
            done_count += 1
    done_cov(0)
    assert_chk.check("no_spurious_done", done_count == 0,
                     f"idle for 20 cycles: done pulsed {done_count} times (expected 0)")
    sb.add_expected(0); sb.add_actual(done_count)


async def test_random(dut, gen, sb, cov, assert_chk, num=10):
    """Randomized tests."""
    dut._log.info(f"T9: Random tests ({num} iterations)")
    for i in range(num):
        tsu = gen.rng.randint(1, 5)
        thd = gen.rng.randint(1, 5)
        tsus = gen.rng.randint(1, 5)
        bft = gen.rng.randint(1, 5)
        set_config(dut, tsu, thd, tsus, bft)
        op = gen.rng.choice(['start', 'stop', 'rstart', 'release'])
        for _ in range(2):
            await RisingEdge(dut.clk)
        if op == 'start':
            dut.cmd_start.value = 1
        elif op == 'stop':
            dut.cmd_stop.value = 1
        elif op == 'rstart':
            dut.cmd_repeat_start.value = 1
        else:
            dut.cmd_release.value = 1
        await RisingEdge(dut.clk)
        dut.cmd_start.value = 0
        dut.cmd_stop.value = 0
        dut.cmd_repeat_start.value = 0
        dut.cmd_release.value = 0
        cycles = await wait_for_done(dut, 100)
        assert_chk.check(f"rand_{i}_{op}_done", cycles > 0,
                         f"rand_{i}: op={op} tsu={tsu} thd={thd} done after {cycles} cycles")
        if cycles > 0:
            sb.add_expected(1); sb.add_actual(1)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main start/stop generator test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    set_config(dut, 3, 2, 3, 4)
    dut.cmd_start.value = 0
    dut.cmd_repeat_start.value = 0
    dut.cmd_stop.value = 0
    dut.cmd_release.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('ss')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('ss')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Start/Stop Generator Testbench")
    dut._log.info("=" * 60)

    await test_idle(dut, sb, cov, assert_chk)
    await test_start(dut, sb, cov, assert_chk)
    await test_stop(dut, sb, cov, assert_chk)
    await test_repeat_start(dut, sb, cov, assert_chk)
    await test_release(dut, sb, cov, assert_chk)
    await test_multiple_cycles(dut, sb, cov, assert_chk)
    await test_larger_timing(dut, sb, cov, assert_chk)
    await test_no_spurious_done(dut, sb, cov, assert_chk)
    await test_random(dut, gen, sb, cov, assert_chk, 10)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
