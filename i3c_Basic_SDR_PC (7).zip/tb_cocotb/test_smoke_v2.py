"""
test_smoke_v2.py — Cocotb smoke test for the full I3C Primary Controller.

Cocotb equivalent of tb/tb_primary_controller_sdr.sv. Tests:
  T1. VERSION register reads 0x0001_0002
  T2. PID0 register reads 0x0000_0001 (default CTRL_PID parameter)
  T3. SCL_HIGH_TIME_CFG write/read back (AXI write test — NOT skipped)
  T4. controller_idle asserted after reset
  T5. CMD FIFO empty after reset
  T6. RESP FIFO empty after reset
  T7. No X propagation on key outputs
  T8. TRANSACTION_CTRL.EN write/read back
  T9. DNF_CTRL write/read back

AXI4-Lite compliance (per AMBA AXI Protocol Spec IHI0022H):
  - VALID must remain asserted until the handshake (VALID & READY at rising edge)
  - Master must NOT wait for READY before asserting VALID
  - BVALID must remain asserted until BREADY handshake
  - No combinatorial paths between input and output (slave side)

Top module: i3c_primary_controller_sdr (uses full filelist)
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import AssertionChecker


# Register addresses (from i3c_pkg.sv)
VERSION_ADDR            = 0x00
PID0_STATUS_ADDR        = 0x9C
SCL_HIGH_TIME_CFG_ADDR  = 0x4C
TRANSACTION_CTRL_ADDR   = 0x0C  # BUG-R3-001c fix: was 0x08 (SPEED_MODE_CFG)
DNF_CTRL_ADDR           = 0x74

EXPECTED_VERSION = 0x0001_0002  # v1.2
EXPECTED_PID0 = 0x0000_0001     # default CTRL_PID parameter low 32 bits

sb = AssertionChecker("test")


async def axi_write(dut, addr, data):
    """
    AXI4-Lite single write per AMBA AXI Protocol Spec IHI0022H.

    Per spec A3.2.1:
      - AWVALID must remain asserted until AWREADY handshake at rising edge
      - WVALID must remain asserted until WREADY handshake at rising edge
      - BVALID remains asserted until BREADY handshake

    Per spec A3.3.1 (AXI4 write dependencies):
      - Slave must wait for both AW+W handshakes before asserting BVALID
      - Master must NOT wait for AWREADY/WREADY before asserting AWVALID/WVALID
    """
    # 1. Assert AWVALID, AWADDR, WVALID, WDATA, WSTRB simultaneously
    #    (AXI4-Lite allows AW and W in any order; asserting both is fine)
    dut.s_axi_awvalid.value = 1
    dut.s_axi_awaddr.value = addr
    dut.s_axi_wvalid.value = 1
    dut.s_axi_wdata.value = data
    dut.s_axi_wstrb.value = 0xF
    dut.s_axi_bready.value = 1  # ready to accept B response

    # 2. Wait for AW handshake at a rising clock edge
    #    Per spec: "When VALID is asserted, it must remain asserted until
    #    the handshake occurs, at a rising clock edge when VALID and READY
    #    are both asserted."
    aw_handshake = False
    w_handshake = False
    timeout = 0
    while not (aw_handshake and w_handshake):
        await RisingEdge(dut.s_axi_aclk)
        # Check at the rising edge: if AWREADY was high and AWVALID is high,
        # the AW handshake occurred at THIS edge
        if int(dut.s_axi_awready.value) and int(dut.s_axi_awvalid.value):
            aw_handshake = True
        if int(dut.s_axi_wready.value) and int(dut.s_axi_wvalid.value):
            w_handshake = True
        # Deassert AWVALID after AW handshake (but keep WVALID if W not done)
        if aw_handshake:
            dut.s_axi_awvalid.value = 0
        if w_handshake:
            dut.s_axi_wvalid.value = 0
        timeout += 1
        if timeout > 100:
            raise AssertionError(
                f"AXI write timeout (AW={aw_handshake}, W={w_handshake})")

    # 3. Wait for BVALID (slave asserts after both AW+W handshakes)
    #    Per spec: "BVALID must remain asserted until the rising clock edge
    #    after the master asserts BREADY."
    timeout = 0
    while not int(dut.s_axi_bvalid.value):
        await RisingEdge(dut.s_axi_aclk)
        timeout += 1
        if timeout > 100:
            raise AssertionError("AXI write timeout (BVALID)")

    # 4. BREADY is already high, so B handshake occurs at this edge
    #    Deassert BREADY after the B handshake
    dut.s_axi_bready.value = 0
    await RisingEdge(dut.s_axi_aclk)


async def axi_read(dut, addr):
    """
    AXI4-Lite single read per AMBA AXI Protocol Spec IHI0022H.

    Per spec A3.2.1:
      - ARVALID must remain asserted until ARREADY handshake at rising edge
      - RVALID remains asserted until RREADY handshake

    Per spec A3.3.1 (read dependencies):
      - Slave must wait for AR handshake before asserting RVALID
      - Slave must NOT wait for RREADY before asserting RVALID
    """
    # 1. Assert ARVALID and ARADDR
    dut.s_axi_arvalid.value = 1
    dut.s_axi_araddr.value = addr
    dut.s_axi_rready.value = 1  # ready to accept R data

    # 2. Wait for AR handshake at a rising clock edge
    timeout = 0
    while not (int(dut.s_axi_arready.value) and int(dut.s_axi_arvalid.value)):
        await RisingEdge(dut.s_axi_aclk)
        timeout += 1
        if timeout > 100:
            raise AssertionError("AXI read timeout (AR handshake)")

    # 3. Deassert ARVALID after the AR handshake
    dut.s_axi_arvalid.value = 0

    # 4. Wait for RVALID (slave asserts after AR handshake)
    timeout = 0
    while not int(dut.s_axi_rvalid.value):
        await RisingEdge(dut.s_axi_aclk)
        timeout += 1
        if timeout > 100:
            raise AssertionError("AXI read timeout (RVALID)")

    # 5. Sample RDATA at the rising edge where RVALID & RREADY are both high
    #    RREADY is already high, so the R handshake occurs at this edge
    data = int(dut.s_axi_rdata.value)
    dut.s_axi_rready.value = 0
    await RisingEdge(dut.s_axi_aclk)
    return data


@cocotb.test()
async def main_test(dut):
    """Smoke test: verify basic register access, writes, and reset state."""
    clock = Clock(dut.s_axi_aclk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset (per spec: ARESETn must be low for at least 1 cycle, and master
    # must not assert VALID until after reset deassertion)
    dut.s_axi_aresetn.value = 0
    dut.s_axi_awvalid.value = 0
    dut.s_axi_wvalid.value = 0
    dut.s_axi_arvalid.value = 0
    dut.s_axi_bready.value = 0
    dut.s_axi_rready.value = 0

    # Stub FIFO inputs (host-side)
    if hasattr(dut, 'cmd_fifo_push'):
        dut.cmd_fifo_push.value = 0
    if hasattr(dut, 'wr_fifo_push'):
        dut.wr_fifo_push.value = 0
    if hasattr(dut, 'rd_fifo_pop'):
        dut.rd_fifo_pop.value = 0
    if hasattr(dut, 'resp_fifo_pop'):
        dut.resp_fifo_pop.value = 0
    if hasattr(dut, 'cmd_fifo_push_data'):
        dut.cmd_fifo_push_data.value = 0
    if hasattr(dut, 'wr_fifo_push_data'):
        dut.wr_fifo_push_data.value = 0

    await Timer(100, unit="ns")
    dut.s_axi_aresetn.value = 1
    # Per spec A3.2.1: "The earliest point after reset that a master is
    # permitted to begin driving ARVALID, AWVALID, or WVALID HIGH" — wait
    # for at least 1 clock after reset deassertion
    await RisingEdge(dut.s_axi_aclk)
    for _ in range(4):
        await RisingEdge(dut.s_axi_aclk)

    # T1: Read VERSION (RO register, should be 0x0001_0002)
    val = await axi_read(dut, VERSION_ADDR)
    cocotb.log.info(f"VERSION = 0x{val:08X} (expected 0x{EXPECTED_VERSION:08X})")
    sb.check("T1: VERSION = 0x0001_0002", val == EXPECTED_VERSION)

    # T2: Read PID0 (RO register, default CTRL_PID = 0x0000_0000_0001)
    val = await axi_read(dut, PID0_STATUS_ADDR)
    cocotb.log.info(f"PID0 = 0x{val:08X} (expected 0x{EXPECTED_PID0:08X})")
    sb.check("T2: PID0 = 0x0000_0001 (default)", val == EXPECTED_PID0)

    # T3: AXI WRITE test — SCL_HIGH_TIME_CFG (R/W register at 0x50)
    # Write 5 cycles (50 ns, above 32 ns Fm+ minimum — no clamping)
    # This tests the full AXI write path: AW → W → B handshake
    write_val = 5
    await axi_write(dut, SCL_HIGH_TIME_CFG_ADDR, write_val)
    val = await axi_read(dut, SCL_HIGH_TIME_CFG_ADDR)
    cocotb.log.info(f"SCL_HIGH_TIME: wrote={write_val}, read={val & 0x3FFFF}")
    sb.check("T3: SCL_HIGH_TIME write/read back = 5", (val & 0x3FFFF) == write_val)

    # T4: AXI WRITE test — TRANSACTION_CTRL.EN (R/W register at 0x0C)
    # Write EN=1 (bit 0) to enable the controller
    await axi_write(dut, TRANSACTION_CTRL_ADDR, 0x0000_0001)
    val = await axi_read(dut, TRANSACTION_CTRL_ADDR)
    cocotb.log.info(f"TRANSACTION_CTRL: wrote=0x1, read=0x{val:08X}")
    sb.check("T4: TRANSACTION_CTRL.EN write/read back = 1", (val & 0x1) == 1)

    # T5: AXI WRITE test — DNF_CTRL (R/W register at 0x48)
    # Write DNF threshold=3, enable=1 (bits [4:1]=threshold, bit 0=enable)
    dnf_val = 0x0000_0007  # enable=1, threshold=3
    await axi_write(dut, DNF_CTRL_ADDR, dnf_val)
    val = await axi_read(dut, DNF_CTRL_ADDR)
    cocotb.log.info(f"DNF_CTRL: wrote=0x{dnf_val:08X}, read=0x{val:08X}")
    sb.check("T5: DNF_CTRL write/read back = 0x07", val == dnf_val)

    # T6: controller_idle asserted after reset (no commands pending)
    idle_val = int(dut.controller_idle.value)
    sb.check("T6: controller_idle = 1 after reset", idle_val == 1)

    # T7: CMD FIFO empty after reset
    if hasattr(dut, 'cmd_fifo_empty'):
        empty = int(dut.cmd_fifo_empty.value)
        sb.check("T7: CMD FIFO empty after reset", empty == 1)

    # T8: RESP FIFO empty after reset
    if hasattr(dut, 'resp_fifo_empty'):
        empty = int(dut.resp_fifo_empty.value)
        sb.check("T8: RESP FIFO empty after reset", empty == 1)

    # T9: No X propagation on key outputs
    busy_val = str(dut.controller_busy.value)
    sb.check("T9a: controller_busy is not X", busy_val != 'x')

    if hasattr(dut, 'i3c_irq'):
        irq_val = str(dut.i3c_irq.value)
        sb.check("T9b: i3c_irq is not X", irq_val != 'x')

    if hasattr(dut, 'wake_irq'):
        wake_val = str(dut.wake_irq.value)
        sb.check("T9c: wake_irq is not X", wake_val != 'x')

    sb.report()
    assert sb.fail_count == 0, f"{sb.fail_count} failures detected"
