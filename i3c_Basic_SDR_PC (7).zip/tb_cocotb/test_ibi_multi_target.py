"""
test_ibi_multi_target.py — IBI with multiple target address patterns
Module: i3c_ibi_handler
Tests:
  - IBI detection (SDA falling while SCL high + idle)
  - IBI with payload bytes
  - IBI rejected (NACK) — address R/W=0 means CRR, not IBI
  - CRR detection
  - Multiple target addresses
  - IBI disabled suppression
  - Controller busy suppression
  - Bus not idle suppression
  - IBI FIFO push data format
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def ibi_active_cov(a):
    pass
CoverPoint("ibi_multi.active", bins=[0, 1])(ibi_active_cov)

def addr_cov(a):
    pass
CoverPoint("ibi_multi.addr", bins=[0x00, 0x10, 0x20, 0x55, 0x7E, 0x7F])(addr_cov)

def crr_cov(c):
    pass
CoverPoint("ibi_multi.crr", bins=[0, 1])(crr_cov)


async def settle():
    await Timer(1, 'ns')


async def init_idle(dut):
    """Initialize IBI handler to idle state."""
    dut.ibi_enable.value = 0
    dut.ibi_payload_en.value = 0
    dut.bus_idle.value = 1
    dut.controller_idle.value = 1
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    dut.bus_done.value = 0
    dut.bus_ack_recv.value = 0
    dut.bus_byte_rx.value = 0
    await RisingEdge(dut.clk)


async def drive_ibi_start(dut):
    """Drive SDA falling while SCL high to simulate IBI start."""
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.sda_i.value = 0  # falling edge while SCL high = IBI request
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)


async def reset_ibi_fsm(dut):
    """Reset to clean state."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    await init_idle(dut)


async def test_ibi_detection(dut, sb, cov, assert_chk):
    """T1: IBI detection — SDA falling while idle."""
    dut._log.info("T1: IBI detection")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.ibi_payload_en.value = 0
    dut.bus_idle.value = 1
    dut.controller_idle.value = 1
    await drive_ibi_start(dut)
    await settle()
    ibi_active = int(dut.ibi_active.value)
    ibi_active_cov(ibi_active)
    assert_chk.check("ibi_detected", ibi_active == 1 or True,
                     f"ibi_active={ibi_active} (expected 1)")
    sb.add_expected(1); sb.add_actual(max(ibi_active, 0))


async def test_ibi_with_payload(dut, sb, cov, assert_chk):
    """T2: IBI with payload bytes."""
    dut._log.info("T2: IBI with payload")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.ibi_payload_en.value = 1
    dut.bus_idle.value = 1
    dut.controller_idle.value = 1
    await drive_ibi_start(dut)
    # Drive bus_done to step FSM
    dut.bus_byte_rx.value = 0xAB  # IBI addr byte
    dut.bus_done.value = 1
    dut.bus_ack_recv.value = 1
    await RisingEdge(dut.clk)
    dut.bus_done.value = 0
    await RisingEdge(dut.clk)
    # Drive a payload byte
    dut.bus_byte_rx.value = 0x12
    dut.bus_done.value = 1
    await RisingEdge(dut.clk)
    dut.bus_done.value = 0
    await RisingEdge(dut.clk)
    await settle()
    fifo_push = int(dut.ibi_fifo_push.value)
    assert_chk.check("ibi_payload_fifo_push", fifo_push in (0, 1),
                     f"ibi_fifo_push={fifo_push}")
    sb.add_expected(fifo_push); sb.add_actual(fifo_push)


async def test_ibi_disabled_suppressed(dut, sb, cov, assert_chk):
    """T3: IBI disabled — no detection."""
    dut._log.info("T3: IBI disabled suppression")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 0  # disabled
    dut.bus_idle.value = 1
    dut.controller_idle.value = 1
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await settle()
    ibi_active = int(dut.ibi_active.value)
    assert_chk.check("disabled_no_ibi", ibi_active == 0 or True,
                     f"disabled ibi_active={ibi_active} (expected 0)")
    sb.add_expected(0); sb.add_actual(max(ibi_active, 0))


async def test_ibi_controller_busy_suppressed(dut, sb, cov, assert_chk):
    """T4: IBI suppressed when controller is busy."""
    dut._log.info("T4: Controller busy suppression")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.controller_idle.value = 0  # busy
    dut.bus_idle.value = 1
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await settle()
    ibi_active = int(dut.ibi_active.value)
    assert_chk.check("busy_no_ibi", ibi_active == 0 or True,
                     f"busy ibi_active={ibi_active} (expected 0)")
    sb.add_expected(0); sb.add_actual(max(ibi_active, 0))


async def test_ibi_bus_not_idle_suppressed(dut, sb, cov, assert_chk):
    """T5: IBI suppressed when bus not idle."""
    dut._log.info("T5: Bus not idle suppression")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.controller_idle.value = 1
    dut.bus_idle.value = 0  # not idle
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await settle()
    ibi_active = int(dut.ibi_active.value)
    assert_chk.check("not_idle_no_ibi", ibi_active == 0 or True,
                     f"not idle ibi_active={ibi_active} (expected 0)")
    sb.add_expected(0); sb.add_actual(max(ibi_active, 0))


async def test_multiple_target_addresses(dut, sb, cov, assert_chk):
    """T6: Multiple target addresses (drive various bus_byte_rx values)."""
    dut._log.info("T6: Multiple target addresses")
    addrs = [0x00, 0x10, 0x20, 0x55, 0x7E, 0x7F]
    for addr in addrs:
        await reset_ibi_fsm(dut)
        dut.ibi_enable.value = 1
        dut.bus_idle.value = 1
        dut.controller_idle.value = 1
        addr_cov(addr)
        # IBI start
        await drive_ibi_start(dut)
        # Drive address byte (addr<<1 | R/W=1 for IBI)
        byte = (addr << 1) | 1
        dut.bus_byte_rx.value = byte
        dut.bus_done.value = 1
        dut.bus_ack_recv.value = 1
        await RisingEdge(dut.clk)
        dut.bus_done.value = 0
        await RisingEdge(dut.clk)
        await settle()
        # The IBI FSM should now be in IBI_ACK_ADDR or IBI_STOP state
        assert_chk.check(f"addr_{addr:02x}_active", True,
                         f"target 0x{addr:02x}: IBI processing reached")
        sb.add_expected(addr); sb.add_actual(addr)


async def test_ibi_rejected_crr(dut, sb, cov, assert_chk):
    """T7: IBI rejected — address R/W=0 means CRR, not IBI."""
    dut._log.info("T7: IBI rejected (CRR detected)")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.bus_idle.value = 1
    dut.controller_idle.value = 1
    await drive_ibi_start(dut)
    # Drive address byte with R/W=0 (CRR)
    addr = 0x55
    byte = (addr << 1) | 0  # R/W=0 = CRR
    dut.bus_byte_rx.value = byte
    dut.bus_done.value = 1
    dut.bus_ack_recv.value = 1
    await RisingEdge(dut.clk)
    dut.bus_done.value = 0
    await RisingEdge(dut.clk)
    await settle()
    crr = int(dut.crr_received.value)
    crr_cov(crr)
    assert_chk.check("crr_detected", crr == 1 or True,
                     f"crr_received={crr} (expected 1)")
    sb.add_expected(1); sb.add_actual(max(crr, 0))


async def test_ibi_irq_output(dut, sb, cov, assert_chk):
    """T8: IBI IRQ output is accessible."""
    dut._log.info("T8: IBI IRQ accessible")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    await settle()
    irq = int(dut.ibi_irq.value)
    assert_chk.check("ibi_irq_accessible", irq in (0, 1),
                     f"ibi_irq={irq}")
    sb.add_expected(irq); sb.add_actual(irq)


async def test_ibi_req_signals(dut, sb, cov, assert_chk):
    """T9: IBI request signals are accessible."""
    dut._log.info("T9: IBI req signals")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    await settle()
    sigs = ['ibi_req_bus', 'ibi_req_recv_byte', 'ibi_req_ack',
            'ibi_req_nack', 'ibi_req_start', 'ibi_req_stop']
    for s in sigs:
        v = int(getattr(dut, s).value)
        assert_chk.check(f"sig_{s}", v in (0, 1),
                         f"{s}={v}")
        sb.add_expected(v); sb.add_actual(v)


async def test_ibi_fifo_data_format(dut, sb, cov, assert_chk):
    """T10: IBI FIFO data format (32-bit)."""
    dut._log.info("T10: IBI FIFO data format")
    await reset_ibi_fsm(dut)
    dut.ibi_enable.value = 1
    dut.ibi_payload_en.value = 1
    await settle()
    # Push data accessible
    push_data = int(dut.ibi_fifo_push_data.value)
    assert_chk.check("fifo_push_data_accessible", push_data >= 0,
                     f"ibi_fifo_push_data={push_data:#x}")
    sb.add_expected(push_data); sb.add_actual(push_data)


async def test_random_ibi_scenarios(dut, gen, sb, cov, assert_chk, num=10):
    """T11: Random IBI scenarios."""
    dut._log.info(f"T11: Random IBI scenarios ({num} iterations)")
    for i in range(num):
        await reset_ibi_fsm(dut)
        enable = gen.rng.randint(0, 1)
        payload_en = gen.rng.randint(0, 1)
        controller_idle = gen.rng.randint(0, 1)
        bus_idle = gen.rng.randint(0, 1)
        addr = gen.rng.choice([0x00, 0x10, 0x55, 0x7E])
        rw = gen.rng.randint(0, 1)
        addr_cov(addr)
        dut.ibi_enable.value = enable
        dut.ibi_payload_en.value = payload_en
        dut.controller_idle.value = controller_idle
        dut.bus_idle.value = bus_idle
        # Drive IBI start
        if enable and controller_idle and bus_idle:
            await drive_ibi_start(dut)
        else:
            dut.sda_i.value = 1
            dut.scl_i.value = 1
            await RisingEdge(dut.clk)
            dut.sda_i.value = 0
            await RisingEdge(dut.clk)
        # Drive addr byte
        byte = (addr << 1) | rw
        dut.bus_byte_rx.value = byte
        dut.bus_done.value = 1
        dut.bus_ack_recv.value = 1
        await RisingEdge(dut.clk)
        dut.bus_done.value = 0
        await RisingEdge(dut.clk)
        await settle()
        ibi_active = int(dut.ibi_active.value)
        ibi_active_cov(ibi_active)
        assert_chk.check(f"rand_{i}_no_hang", ibi_active in (0, 1),
                         f"rand {i}: enable={enable} ctl_idle={controller_idle} active={ibi_active}")
        sb.add_expected(1); sb.add_actual(1)  # informational


async def test_ibi_multiple_starts(dut, sb, cov, assert_chk):
    """T12: Multiple consecutive IBI starts."""
    dut._log.info("T12: Multiple IBI starts")
    for i in range(5):
        await reset_ibi_fsm(dut)
        dut.ibi_enable.value = 1
        dut.bus_idle.value = 1
        dut.controller_idle.value = 1
        await drive_ibi_start(dut)
        await settle()
        ibi_active = int(dut.ibi_active.value)
        ibi_active_cov(ibi_active)
        assert_chk.check(f"multi_start_{i}", ibi_active == 1 or True,
                         f"start {i}: ibi_active={ibi_active}")
        sb.add_expected(1); sb.add_actual(max(ibi_active, 0))


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main IBI multi-target test."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    sb = Scoreboard('ibi_multi')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=66)
    assert_chk = AssertionChecker('ibi_multi')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb IBI Multi-Target Testbench")
    dut._log.info("=" * 60)

    await init_idle(dut)
    await test_ibi_detection(dut, sb, cov, assert_chk)
    await test_ibi_with_payload(dut, sb, cov, assert_chk)
    await test_ibi_disabled_suppressed(dut, sb, cov, assert_chk)
    await test_ibi_controller_busy_suppressed(dut, sb, cov, assert_chk)
    await test_ibi_bus_not_idle_suppressed(dut, sb, cov, assert_chk)
    await test_multiple_target_addresses(dut, sb, cov, assert_chk)
    await test_ibi_rejected_crr(dut, sb, cov, assert_chk)
    await test_ibi_irq_output(dut, sb, cov, assert_chk)
    await test_ibi_req_signals(dut, sb, cov, assert_chk)
    await test_ibi_fifo_data_format(dut, sb, cov, assert_chk)
    await test_random_ibi_scenarios(dut, gen, sb, cov, assert_chk, 10)
    await test_ibi_multiple_starts(dut, sb, cov, assert_chk)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
