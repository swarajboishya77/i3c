"""
test_axi4_lite_slave.py — Cocotb testbench for axi4_lite_slave
Tests: back-to-back writes, back-to-back reads, interleaved, AW/W ordering
       (AW-first, W-first, simultaneous), error response (SLVERR), bvalid stays
       until bready, rvalid stays until rready, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

The AXI slave requires an external register file. We provide a minimal mock:
  - reg_wr_ack: always 1 by default (OKAY), can force to 0 for SLVERR test
  - reg_rd_data: driven from a Python dict keyed by address (lower 8 bits)
  - reg_rd_ack: always 1 by default (OKAY), can force to 0 for SLVERR test
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


# Coverage points
def bresp_cov(r):
    pass
CoverPoint("axi.bresp", bins=[0, 2])(bresp_cov)  # OKAY=0, SLVERR=2 (AMBA IHI 0022H §R3.1)

def rresp_cov(r):
    pass
CoverPoint("axi.rresp", bins=[0, 2])(rresp_cov)  # OKAY=0, SLVERR=2 (AMBA IHI 0022H §R3.1)


# Simple mock register file (Python dict)
REG_FILE = {}

def reg_read(addr):
    return REG_FILE.get(addr & 0xFF, 0xDEAD0000 | (addr & 0xFFFF))

def reg_write(addr, data):
    REG_FILE[addr & 0xFF] = data


async def settle():
    await Timer(1, 'ns')


async def axi_write(dut, addr, data, wr_ack=1, bready_delay=0):
    """Single AXI4-Lite write with simultaneous AW+W. Returns bresp.

    Asserts AW and W valid for exactly one cycle (both accepted in W_IDLE),
    then waits for bvalid. bready can be delayed.
    """
    dut.s_axi_bready.value = 0
    dut.reg_wr_ack.value = wr_ack
    dut.s_axi_awvalid.value = 1
    dut.s_axi_awaddr.value = addr
    dut.s_axi_wvalid.value = 1
    dut.s_axi_wdata.value = data
    dut.s_axi_wstrb.value = 0xF
    # One rising edge accepts both AW and W (W_IDLE state)
    await RisingEdge(dut.clk)
    dut.s_axi_awvalid.value = 0
    dut.s_axi_wvalid.value = 0
    reg_write(addr, data)
    # FSM: W_ADDR_DATA (1 cycle) → W_RESP (bvalid=1)
    # Wait for bvalid (max 10 cycles)
    for _ in range(10):
        await RisingEdge(dut.clk)
        await settle()
        if int(dut.s_axi_bvalid.value) == 1:
            break
    # Optional bready delay
    for _ in range(bready_delay):
        await RisingEdge(dut.clk)
        await settle()
    # Assert bready, capture bresp
    dut.s_axi_bready.value = 1
    await RisingEdge(dut.clk)
    await settle()
    bresp = int(dut.s_axi_bresp.value)
    dut.s_axi_bready.value = 0
    await RisingEdge(dut.clk)
    await settle()
    bresp_cov(bresp)
    return bresp


async def axi_write_aw_first(dut, addr, data, wr_ack=1):
    """Write with AW presented before W."""
    dut.s_axi_bready.value = 0
    dut.reg_wr_ack.value = wr_ack
    # AW first
    dut.s_axi_awvalid.value = 1
    dut.s_axi_awaddr.value = addr
    dut.s_axi_wvalid.value = 0
    await RisingEdge(dut.clk)
    # AW accepted (aw_done=1 now, awready=0); deassert AW
    dut.s_axi_awvalid.value = 0
    # Now present W
    dut.s_axi_wvalid.value = 1
    dut.s_axi_wdata.value = data
    dut.s_axi_wstrb.value = 0xF
    await RisingEdge(dut.clk)
    # W accepted; FSM → W_ADDR_DATA
    dut.s_axi_wvalid.value = 0
    reg_write(addr, data)
    # Wait for bvalid
    for _ in range(10):
        await RisingEdge(dut.clk)
        await settle()
        if int(dut.s_axi_bvalid.value) == 1:
            break
    dut.s_axi_bready.value = 1
    await RisingEdge(dut.clk)
    await settle()
    bresp = int(dut.s_axi_bresp.value)
    dut.s_axi_bready.value = 0
    await RisingEdge(dut.clk)
    await settle()
    bresp_cov(bresp)
    return bresp


async def axi_write_w_first(dut, addr, data, wr_ack=1):
    """Write with W presented before AW."""
    dut.s_axi_bready.value = 0
    dut.reg_wr_ack.value = wr_ack
    # W first
    dut.s_axi_wvalid.value = 1
    dut.s_axi_wdata.value = data
    dut.s_axi_wstrb.value = 0xF
    dut.s_axi_awvalid.value = 0
    await RisingEdge(dut.clk)
    # W accepted (w_done=1 now); deassert W
    dut.s_axi_wvalid.value = 0
    # Now present AW
    dut.s_axi_awvalid.value = 1
    dut.s_axi_awaddr.value = addr
    await RisingEdge(dut.clk)
    # AW accepted; FSM → W_ADDR_DATA
    dut.s_axi_awvalid.value = 0
    reg_write(addr, data)
    # Wait for bvalid
    for _ in range(10):
        await RisingEdge(dut.clk)
        await settle()
        if int(dut.s_axi_bvalid.value) == 1:
            break
    dut.s_axi_bready.value = 1
    await RisingEdge(dut.clk)
    await settle()
    bresp = int(dut.s_axi_bresp.value)
    dut.s_axi_bready.value = 0
    await RisingEdge(dut.clk)
    await settle()
    bresp_cov(bresp)
    return bresp


async def axi_read(dut, addr, rd_ack=1, rready_delay=0):
    """Single AXI4-Lite read. Returns (rdata, rresp).

    reg_rd_data is driven combinationally based on addr. The slave latches
    it on the rising edge where AR is accepted (RD_IDLE → RD_DATA).
    """
    dut.s_axi_rready.value = 0
    dut.reg_rd_ack.value = rd_ack
    # Drive reg_rd_data based on addr (mock register file)
    dut.reg_rd_data.value = reg_read(addr)
    # Present AR
    dut.s_axi_arvalid.value = 1
    dut.s_axi_araddr.value = addr
    await RisingEdge(dut.clk)
    # AR accepted; FSM → RD_DATA
    dut.s_axi_arvalid.value = 0
    # Wait for rvalid (max 5 cycles)
    for _ in range(5):
        await RisingEdge(dut.clk)
        await settle()
        if int(dut.s_axi_rvalid.value) == 1:
            break
    # Optional rready delay
    for _ in range(rready_delay):
        await RisingEdge(dut.clk)
        await settle()
    # Assert rready, capture rdata/rresp
    dut.s_axi_rready.value = 1
    await RisingEdge(dut.clk)
    await settle()
    rdata = int(dut.s_axi_rdata.value)
    rresp = int(dut.s_axi_rresp.value)
    dut.s_axi_rready.value = 0
    await RisingEdge(dut.clk)
    await settle()
    rresp_cov(rresp)
    return rdata, rresp


async def test_single_write(dut, sb, cov, assert_chk):
    """T1: Single write — bresp=OKAY, register updated."""
    dut._log.info("T1: Single write")
    bresp = await axi_write(dut, 0x10, 0xCAFEBABE)
    assert_chk.check("write_okay", bresp == 0, f"bresp={bresp} (expected 0=OKAY)")
    sb.add_expected(0); sb.add_actual(bresp)
    assert_chk.check("write_reg_updated", REG_FILE.get(0x10, 0) == 0xCAFEBABE,
                     f"reg[0x10]={REG_FILE.get(0x10, 0):#010x}")


async def test_single_read(dut, sb, cov, assert_chk):
    """T2: Single read — rdata matches written value, rresp=OKAY."""
    dut._log.info("T2: Single read")
    await axi_write(dut, 0x20, 0x12345678)
    rdata, rresp = await axi_read(dut, 0x20)
    assert_chk.check("read_okay", rresp == 0, f"rresp={rresp} (expected 0)")
    assert_chk.check("read_data", rdata == 0x12345678,
                     f"rdata={rdata:#010x} (expected 0x12345678)")
    sb.add_expected(0x12345678); sb.add_actual(rdata)
    sb.add_expected(0); sb.add_actual(rresp)


async def test_back_to_back_writes(dut, sb, cov, assert_chk):
    """T3: Back-to-back writes — multiple writes in sequence."""
    dut._log.info("T3: Back-to-back writes")
    addrs = [0x30, 0x34, 0x38, 0x3C]
    datas = [0xAABBCCDD, 0x11223344, 0x55667788, 0x99AABBCD]
    for a, d in zip(addrs, datas):
        bresp = await axi_write(dut, a, d)
        assert_chk.check(f"bb_write_{a:#x}", bresp == 0, f"addr={a:#x} bresp={bresp}")
        sb.add_expected(0); sb.add_actual(bresp)
    for a, d in zip(addrs, datas):
        rdata, _ = await axi_read(dut, a)
        assert_chk.check(f"bb_read_{a:#x}", rdata == d,
                         f"addr={a:#x} rdata={rdata:#010x} expected={d:#010x}")
        sb.add_expected(d); sb.add_actual(rdata)


async def test_back_to_back_reads(dut, sb, cov, assert_chk):
    """T4: Back-to-back reads."""
    dut._log.info("T4: Back-to-back reads")
    addrs = [0x40, 0x44, 0x48]
    datas = [0x11111111, 0x22222222, 0x33333333]
    for a, d in zip(addrs, datas):
        await axi_write(dut, a, d)
    for a, d in zip(addrs, datas):
        rdata, rresp = await axi_read(dut, a)
        assert_chk.check(f"bb_rd_{a:#x}_data", rdata == d,
                         f"addr={a:#x} rdata={rdata:#010x} expected={d:#010x}")
        assert_chk.check(f"bb_rd_{a:#x}_resp", rresp == 0, f"rresp={rresp}")
        sb.add_expected(d); sb.add_actual(rdata)


async def test_aw_first(dut, sb, cov, assert_chk):
    """T5: AW presented before W — write still completes."""
    dut._log.info("T5: AW-first ordering")
    bresp = await axi_write_aw_first(dut, 0x50, 0xDEADBEEF)
    assert_chk.check("aw_first_okay", bresp == 0, f"bresp={bresp}")
    rdata, _ = await axi_read(dut, 0x50)
    assert_chk.check("aw_first_data", rdata == 0xDEADBEEF,
                     f"rdata={rdata:#010x}")
    sb.add_expected(0xDEADBEEF); sb.add_actual(rdata)


async def test_w_first(dut, sb, cov, assert_chk):
    """T6: W presented before AW — write still completes."""
    dut._log.info("T6: W-first ordering")
    bresp = await axi_write_w_first(dut, 0x60, 0xFEEDFACE)
    assert_chk.check("w_first_okay", bresp == 0, f"bresp={bresp}")
    rdata, _ = await axi_read(dut, 0x60)
    assert_chk.check("w_first_data", rdata == 0xFEEDFACE,
                     f"rdata={rdata:#010x}")
    sb.add_expected(0xFEEDFACE); sb.add_actual(rdata)


async def test_simultaneous_aw_w(dut, sb, cov, assert_chk):
    """T7: AW and W simultaneous — verify explicit simultaneous case."""
    dut._log.info("T7: Simultaneous AW+W")
    bresp = await axi_write(dut, 0x70, 0x0BADF00D)
    assert_chk.check("sim_aw_w_okay", bresp == 0, f"bresp={bresp}")
    rdata, _ = await axi_read(dut, 0x70)
    assert_chk.check("sim_aw_w_data", rdata == 0x0BADF00D,
                     f"rdata={rdata:#010x}")
    sb.add_expected(0x0BADF00D); sb.add_actual(rdata)


async def test_write_slverr(dut, sb, cov, assert_chk):
    """T8: Write with reg_wr_ack=0 — bresp=SLVERR (2'b10)."""
    dut._log.info("T8: Write SLVERR")
    bresp = await axi_write(dut, 0x80, 0xAAAA5555, wr_ack=0)
    assert_chk.check("write_slverr", bresp == 2, f"bresp={bresp} (expected 2=SLVERR)")
    sb.add_expected(2); sb.add_actual(bresp)


async def test_read_slverr(dut, sb, cov, assert_chk):
    """T9: Read with reg_rd_ack=0 — rresp=SLVERR."""
    dut._log.info("T9: Read SLVERR")
    rdata, rresp = await axi_read(dut, 0x90, rd_ack=0)
    assert_chk.check("read_slverr", rresp == 2, f"rresp={rresp} (expected 2)")
    sb.add_expected(2); sb.add_actual(rresp)


async def test_bvalid_holds(dut, sb, cov, assert_chk):
    """T10: bvalid stays asserted until bready — delay bready by 3 cycles."""
    dut._log.info("T10: bvalid holds until bready")
    bresp = await axi_write(dut, 0xA0, 0x1234ABCD, bready_delay=3)
    assert_chk.check("bvalid_hold_okay", bresp == 0, f"bresp={bresp}")
    sb.add_expected(0); sb.add_actual(bresp)


async def test_rvalid_holds(dut, sb, cov, assert_chk):
    """T11: rvalid stays asserted until rready — delay rready by 3 cycles."""
    dut._log.info("T11: rvalid holds until rready")
    await axi_write(dut, 0xB0, 0xFEDCBA98)
    rdata, rresp = await axi_read(dut, 0xB0, rready_delay=3)
    assert_chk.check("rvalid_hold_data", rdata == 0xFEDCBA98,
                     f"rdata={rdata:#010x}")
    assert_chk.check("rvalid_hold_resp", rresp == 0, f"rresp={rresp}")
    sb.add_expected(0xFEDCBA98); sb.add_actual(rdata)


async def test_interleaved_rw(dut, sb, cov, assert_chk):
    """T12: Interleaved reads and writes."""
    dut._log.info("T12: Interleaved R/W")
    for i in range(4):
        await axi_write(dut, 0xC0 + i*4, 0xC000 + i)
        rdata, _ = await axi_read(dut, 0xC0 + i*4)
        assert_chk.check(f"interleave_{i}", rdata == 0xC000 + i,
                         f"iter={i} rdata={rdata:#x} expected={0xC000+i:#x}")
        sb.add_expected(0xC000 + i); sb.add_actual(rdata)


async def test_random_transactions(dut, gen, sb, cov, assert_chk, num=15):
    """T13: Randomized R/W with integrity check."""
    dut._log.info(f"T13: Random transactions ({num})")
    for i in range(num):
        op = gen.rng.choice(['write', 'read'])
        addr = gen.rng.randint(0, 0xFF) & 0xFC
        if op == 'write':
            data = gen.gen_data_word()
            bresp = await axi_write(dut, addr, data)
            assert_chk.check(f"rand_{i}_write", bresp == 0, f"bresp={bresp}")
            sb.add_expected(0); sb.add_actual(bresp)
        else:
            expected = REG_FILE.get(addr, 0xDEAD0000 | (addr & 0xFFFF))
            rdata, rresp = await axi_read(dut, addr)
            assert_chk.check(f"rand_{i}_read", rdata == expected,
                             f"addr={addr:#x} rdata={rdata:#010x} expected={expected:#010x}")
            sb.add_expected(expected); sb.add_actual(rdata)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main AXI4-Lite slave test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.s_axi_awvalid.value = 0
    dut.s_axi_awaddr.value = 0
    dut.s_axi_awprot.value = 0
    dut.s_axi_wvalid.value = 0
    dut.s_axi_wdata.value = 0
    dut.s_axi_wstrb.value = 0
    dut.s_axi_bready.value = 0
    dut.s_axi_arvalid.value = 0
    dut.s_axi_araddr.value = 0
    dut.s_axi_arprot.value = 0
    dut.s_axi_rready.value = 0
    dut.reg_wr_ack.value = 1
    dut.reg_rd_data.value = 0
    dut.reg_rd_ack.value = 1
    await RisingEdge(dut.clk)

    sb = Scoreboard('axi')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('axi')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb AXI4-Lite Slave Testbench")
    dut._log.info("=" * 60)

    await test_single_write(dut, sb, cov, assert_chk)
    await test_single_read(dut, sb, cov, assert_chk)
    await test_back_to_back_writes(dut, sb, cov, assert_chk)
    await test_back_to_back_reads(dut, sb, cov, assert_chk)
    await test_aw_first(dut, sb, cov, assert_chk)
    await test_w_first(dut, sb, cov, assert_chk)
    await test_simultaneous_aw_w(dut, sb, cov, assert_chk)
    await test_write_slverr(dut, sb, cov, assert_chk)
    await test_read_slverr(dut, sb, cov, assert_chk)
    await test_bvalid_holds(dut, sb, cov, assert_chk)
    await test_rvalid_holds(dut, sb, cov, assert_chk)
    await test_interleaved_rw(dut, sb, cov, assert_chk)
    await test_random_transactions(dut, gen, sb, cov, assert_chk, 15)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
