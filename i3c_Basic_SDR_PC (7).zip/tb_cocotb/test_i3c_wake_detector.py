"""
test_i3c_wake_detector.py — Cocotb testbench for i3c_wake_detector
Tests: disabled, wake via START, wake clear, wake via SCL edge, SCL low = no START
       wake, both sources.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def wake_cov(w):
    pass
CoverPoint("wake.irq", bins=[0, 1])(wake_cov)


async def sync_settle(dut, n=5):
    """Wait n clk_aon cycles for synchronizers to settle (3-stage sync)."""
    for _ in range(n):
        await RisingEdge(dut.clk_aon)


async def test_disabled(dut, sb, cov, assert_chk):
    """T1: wake_en=0 — no wake even with START condition."""
    dut._log.info("T1: Disabled")
    # Clear any prior wake
    dut.wake_clear.value = 1
    dut.wake_en.value = 0
    dut.wake_start_en.value = 1
    dut.wake_scl_en.value = 1
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await sync_settle(dut, 5)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    # Now drive SDA falling while SCL high
    dut.sda_raw.value = 0
    dut.scl_raw.value = 1
    await sync_settle(dut, 6)
    irq = int(dut.wake_irq.value)
    wake_cov(irq)
    assert_chk.check("disabled_no_wake", irq == 0, f"disabled: irq={irq} (expected 0)")
    sb.add_expected(0); sb.add_actual(irq)


async def test_wake_via_start(dut, sb, cov, assert_chk):
    """T2: Wake via START condition (SDA falls while SCL high)."""
    dut._log.info("T2: Wake via START")
    # Clear any prior wake
    dut.wake_clear.value = 1
    dut.wake_en.value = 1
    dut.wake_start_en.value = 1
    dut.wake_scl_en.value = 0
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await sync_settle(dut, 5)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    assert_chk.check("pre_start_no_irq",
                     int(dut.wake_irq.value) == 0,
                     f"pre-start: irq={int(dut.wake_irq.value)} (expected 0)")
    # Drive SDA falling while SCL high
    dut.sda_raw.value = 0
    dut.scl_raw.value = 1
    await sync_settle(dut, 6)
    irq = int(dut.wake_irq.value)
    src_start = int(dut.wake_src_start.value)
    src_scl = int(dut.wake_src_scl.value)
    wake_cov(irq)
    assert_chk.check("start_wakes",
                     irq == 1 and src_start == 1,
                     f"after START: irq={irq} src_start={src_start} (expected 1,1)")
    assert_chk.check("start_no_scl_src",
                     src_scl == 0,
                     f"after START: src_scl={src_scl} (expected 0 — wake_scl_en disabled)")
    sb.add_expected(1); sb.add_actual(irq)


async def test_wake_clear(dut, sb, cov, assert_chk):
    """T3: wake_clear clears wake status."""
    dut._log.info("T3: Wake clear")
    # At this point, wake_irq should be set from T2
    pre_irq = int(dut.wake_irq.value)
    assert_chk.check("pre_clear_irq_set", pre_irq == 1, f"pre-clear: irq={pre_irq} (expected 1)")
    # Assert wake_clear
    dut.wake_clear.value = 1
    await RisingEdge(dut.clk_aon)
    await RisingEdge(dut.clk_aon)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    irq = int(dut.wake_irq.value)
    src_start = int(dut.wake_src_start.value)
    src_scl = int(dut.wake_src_scl.value)
    assert_chk.check("cleared_irq",
                     irq == 0 and src_start == 0 and src_scl == 0,
                     f"after clear: irq={irq} src_start={src_start} src_scl={src_scl} (expected all 0)")
    sb.add_expected(0); sb.add_actual(irq)


async def test_wake_via_scl_edge(dut, sb, cov, assert_chk):
    """T4: Wake via SCL edge (SCL transitions)."""
    dut._log.info("T4: Wake via SCL edge")
    # Clear any prior wake
    dut.wake_clear.value = 1
    dut.wake_en.value = 1
    dut.wake_start_en.value = 0
    dut.wake_scl_en.value = 1
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await sync_settle(dut, 5)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    # Toggle SCL (rising edge first since SCL=1 already — let's go SCL=0 then SCL=1)
    dut.scl_raw.value = 0
    await sync_settle(dut, 5)
    irq_after_fall = int(dut.wake_irq.value)
    # SCL falling edge should trigger wake
    assert_chk.check("scl_edge_wake",
                     irq_after_fall == 1,
                     f"after SCL fall: irq={irq_after_fall} (expected 1)")
    src_scl = int(dut.wake_src_scl.value)
    src_start = int(dut.wake_src_start.value)
    assert_chk.check("scl_edge_src",
                     src_scl == 1 and src_start == 0,
                     f"after SCL fall: src_scl={src_scl} src_start={src_start} (expected 1,0)")
    sb.add_expected(1); sb.add_actual(irq_after_fall)


async def test_scl_low_no_start_wake(dut, sb, cov, assert_chk):
    """T5: SDA falling while SCL low — no START wake (but may trigger SCL edge)."""
    dut._log.info("T5: SCL low = no START wake")
    # Clear any prior wake
    dut.wake_clear.value = 1
    dut.wake_en.value = 1
    dut.wake_start_en.value = 1
    dut.wake_scl_en.value = 0  # Disable SCL edge detection to isolate START
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await sync_settle(dut, 5)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    # First drive SCL low (with sda high)
    dut.scl_raw.value = 0
    dut.sda_raw.value = 1
    await sync_settle(dut, 5)
    # Now drive SDA falling while SCL low
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    await sync_settle(dut, 6)
    irq = int(dut.wake_irq.value)
    src_start = int(dut.wake_src_start.value)
    assert_chk.check("scl_low_no_start_wake",
                     irq == 0 and src_start == 0,
                     f"SCL low + SDA fall: irq={irq} src_start={src_start} (expected 0,0)")
    sb.add_expected(0); sb.add_actual(irq)


async def test_both_sources(dut, sb, cov, assert_chk):
    """T6: Both START and SCL edge wake sources enabled."""
    dut._log.info("T6: Both sources")
    # Clear any prior wake
    dut.wake_clear.value = 1
    dut.wake_en.value = 1
    dut.wake_start_en.value = 1
    dut.wake_scl_en.value = 1
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await sync_settle(dut, 5)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    # Trigger START (SDA falls while SCL high)
    dut.sda_raw.value = 0
    dut.scl_raw.value = 1
    await sync_settle(dut, 6)
    irq1 = int(dut.wake_irq.value)
    src_start1 = int(dut.wake_src_start.value)
    assert_chk.check("both_start_triggered",
                     irq1 == 1 and src_start1 == 1,
                     f"after START: irq={irq1} src_start={src_start1} (expected 1,1)")
    # Clear
    dut.wake_clear.value = 1
    await sync_settle(dut, 3)
    dut.wake_clear.value = 0
    await sync_settle(dut, 2)
    assert_chk.check("both_clear",
                     int(dut.wake_irq.value) == 0,
                     f"after clear: irq={int(dut.wake_irq.value)} (expected 0)")
    # Now trigger SCL edge
    dut.scl_raw.value = 0
    await sync_settle(dut, 5)
    irq2 = int(dut.wake_irq.value)
    src_scl2 = int(dut.wake_src_scl.value)
    assert_chk.check("both_scl_triggered",
                     irq2 == 1 and src_scl2 == 1,
                     f"after SCL edge: irq={irq2} src_scl={src_scl2} (expected 1,1)")
    sb.add_expected(1); sb.add_actual(irq2)


async def test_random(dut, gen, sb, cov, assert_chk, num=12):
    """Randomized tests."""
    dut._log.info(f"T7: Random tests ({num} iterations)")
    for i in range(num):
        # Clear prior wake
        dut.wake_clear.value = 1
        en = gen.rng.randint(0, 1)
        start_en = gen.rng.randint(0, 1)
        scl_en = gen.rng.randint(0, 1)
        dut.wake_en.value = en
        dut.wake_start_en.value = start_en
        dut.wake_scl_en.value = scl_en
        dut.sda_raw.value = 1
        dut.scl_raw.value = 1
        await sync_settle(dut, 5)
        dut.wake_clear.value = 0
        await sync_settle(dut, 2)
        # Random event: SDA fall, SCL toggle, or both
        event = gen.rng.choice(['sda_fall_scl_high', 'sda_fall_scl_low', 'scl_toggle', 'none'])
        if event == 'sda_fall_scl_high':
            dut.sda_raw.value = 0
            dut.scl_raw.value = 1
        elif event == 'sda_fall_scl_low':
            dut.sda_raw.value = 0
            dut.scl_raw.value = 0
        elif event == 'scl_toggle':
            dut.scl_raw.value = 0
            dut.sda_raw.value = 1
        else:
            pass
        await sync_settle(dut, 6)
        irq = int(dut.wake_irq.value)
        wake_cov(irq)
        # Compute expected
        expect_wake = 0
        if en:
            if event == 'sda_fall_scl_high' and start_en:
                expect_wake = 1
            elif event == 'scl_toggle' and scl_en:
                expect_wake = 1
        assert_chk.check(f"rand_{i}",
                         irq == expect_wake,
                         f"rand_{i}: en={en} start_en={start_en} scl_en={scl_en} event={event} irq={irq} (expected {expect_wake})")
        sb.add_expected(expect_wake); sb.add_actual(irq)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main wake detector test — all test cases."""
    cr = ClockResetAgent(dut, 'clk_aon', 'rst_aon_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.wake_en.value = 0
    dut.wake_start_en.value = 0
    dut.wake_scl_en.value = 0
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    dut.wake_clear.value = 0
    await RisingEdge(dut.clk_aon)

    sb = Scoreboard('wake')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('wake')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Wake Detector Testbench")
    dut._log.info("=" * 60)

    await test_disabled(dut, sb, cov, assert_chk)
    await test_wake_via_start(dut, sb, cov, assert_chk)
    await test_wake_clear(dut, sb, cov, assert_chk)
    await test_wake_via_scl_edge(dut, sb, cov, assert_chk)
    await test_scl_low_no_start_wake(dut, sb, cov, assert_chk)
    await test_both_sources(dut, sb, cov, assert_chk)
    await test_random(dut, gen, sb, cov, assert_chk, 12)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
