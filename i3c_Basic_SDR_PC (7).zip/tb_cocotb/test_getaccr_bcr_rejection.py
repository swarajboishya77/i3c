"""
test_getaccr_bcr_rejection.py
Tests that the target engine correctly rejects GETACCR when BCR[5]=0 and BCR[3]=0.
Requires modified i3c_target_engine with target_bcr port.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer, FallingEdge
from cocotb.clock import Clock

@cocotb.test()
async def test_getaccr_accept_when_capable(dut):
    """Target with BCR[5]=1 accepts GETACCR."""
    clock = Clock(dut.clk_sys, 10, units="ns")
    cocotb.start_soon(clock.start())

    dut.rst_sys_n.value = 0
    dut.target_en.value = 0
    dut.target_dyn_addr.value = 0x5A
    dut.target_bcr.value = 0x20  # BCR[5]=1 (ACT Controller Role)
    dut.reclaim_test_active.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.scl_filt_rst_n.value = 0
    dut.ccc_getrtgl_byte.value = 0
    dut.ccc_getrtgl_valid.value = 0
    await Timer(100, units="ns")
    dut.rst_sys_n.value = 1
    dut.scl_filt_rst_n.value = 1
    dut.target_en.value = 1
    await RisingEdge(dut.clk_sys)

    # Simulate bus sequence: START + 0x7E + W + ACK
    # Then CCC opcode 0x91 + ACK
    # Then RepSTART + 0x5A + R + ACK
    # Force internal state progression for unit test

    # Step 1: Force to TGT_GETACCR_CCC state
    dut.tgt_state.value = 0xA  # TGT_GETACCR_CCC
    await Timer(50, units="ns")

    # Step 2: Force to TGT_GETACCR_ADDR with our address
    dut.tgt_state.value = 0xB  # TGT_GETACCR_ADDR
    dut.rx_shift.value = 0xB5  # 0x5A << 1 | 1 (read)
    dut.bit_cnt.value = 0x7
    await Timer(50, units="ns")

    # Step 3: Force to TGT_GETACCR_ACK and let it evaluate
    dut.tgt_state.value = 0xC  # TGT_GETACCR_ACK
    await Timer(50, units="ns")

    # Trigger on falling SCL edge
    dut.scl_filt.value = 0
    await Timer(20, units="ns")
    dut.scl_filt.value = 1
    await Timer(20, units="ns")

    # Check that next state is TGT_GETACCR_RESP
    assert int(dut.tgt_state.value) == 0xD, f"Expected TGT_GETACCR_RESP(13), got {int(dut.tgt_state.value)}"
    # Check response byte is 0x00 (Accepted)
    assert int(dut.tx_shift.value) == 0x00, f"Expected 0x00, got {int(dut.tx_shift.value)}"

@cocotb.test()
async def test_getaccr_reject_when_not_capable(dut):
    """Target with BCR[5]=0, BCR[3]=0 rejects GETACCR with 0x01."""
    clock = Clock(dut.clk_sys, 10, units="ns")
    cocotb.start_soon(clock.start())

    dut.rst_sys_n.value = 0
    dut.target_en.value = 0
    dut.target_dyn_addr.value = 0x5A
    dut.target_bcr.value = 0x00  # Not capable
    dut.reclaim_test_active.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.scl_filt_rst_n.value = 0
    dut.ccc_getrtgl_byte.value = 0
    dut.ccc_getrtgl_valid.value = 0
    await Timer(100, units="ns")
    dut.rst_sys_n.value = 1
    dut.scl_filt_rst_n.value = 1
    dut.target_en.value = 1
    await RisingEdge(dut.clk_sys)

    # Same sequence but with BCR=0x00
    dut.tgt_state.value = 0xA
    await Timer(50, units="ns")
    dut.tgt_state.value = 0xB
    dut.rx_shift.value = 0xB5
    dut.bit_cnt.value = 0x7
    await Timer(50, units="ns")
    dut.tgt_state.value = 0xC
    await Timer(50, units="ns")

    dut.scl_filt.value = 0
    await Timer(20, units="ns")
    dut.scl_filt.value = 1
    await Timer(20, units="ns")

    # Check response byte is 0x01 (Not Accepted)
    assert int(dut.tx_shift.value) == 0x01, f"Expected 0x01, got {int(dut.tx_shift.value)}"

    # Continue to TGT_GETACCR_RESP and verify role_return does NOT pulse
    dut.tgt_state.value = 0xD  # TGT_GETACCR_RESP
    dut.bit_cnt.value = 0x7
    await Timer(50, units="ns")

    dut.scl_filt.value = 0
    await Timer(20, units="ns")
    dut.scl_filt.value = 1
    await Timer(20, units="ns")

    assert int(dut.role_return.value) == 0, "role_return should NOT pulse on rejection"

@cocotb.test()
async def test_getaccr_ignore_wrong_address(dut):
    """Target ignores GETACCR addressed to different device."""
    clock = Clock(dut.clk_sys, 10, units="ns")
    cocotb.start_soon(clock.start())

    dut.rst_sys_n.value = 0
    dut.target_en.value = 0
    dut.target_dyn_addr.value = 0x5A
    dut.target_bcr.value = 0x20
    dut.reclaim_test_active.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.scl_filt_rst_n.value = 0
    await Timer(100, units="ns")
    dut.rst_sys_n.value = 1
    dut.scl_filt_rst_n.value = 1
    dut.target_en.value = 1
    await RisingEdge(dut.clk_sys)

    # Force wrong address
    dut.tgt_state.value = 0xC
    dut.rx_shift.value = 0xB7  # 0x5B << 1 | 1 (wrong address)
    await Timer(50, units="ns")

    dut.scl_filt.value = 0
    await Timer(20, units="ns")
    dut.scl_filt.value = 1
    await Timer(20, units="ns")

    # Should return to IDLE, not TGT_GETACCR_RESP
    assert int(dut.tgt_state.value) == 0, f"Expected IDLE(0), got {int(dut.tgt_state.value)}"
