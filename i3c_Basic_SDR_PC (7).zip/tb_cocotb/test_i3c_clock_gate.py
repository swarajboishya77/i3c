"""
test_i3c_clock_gate.py — Cocotb testbench for i3c_clock_gate
NOTE: AUTO_GATE=0 by default, so auto_gate_en/activity have NO effect.
Only manual_gate_en matters:
  manual_gate_en=0 -> gated=0 (clock on), clk_out follows clk_in
  manual_gate_en=1 -> gated=1 (clock off), clk_out=0
Tests: manual enable/disable, clk_out follows clk_in, gated output, toggle.
Uses: Scoreboard, Coverage, Random generator, Assertions.

IMPORTANT: iverilog's VPI fires RisingEdge before combinational logic settles,
so we add a small `await Timer(1, 'ns')` after each edge before reading clk_out.
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def gate_cov(g):
    pass
CoverPoint("clk_gate.gated", bins=[0, 1])(gate_cov)


async def read_settled(sig):
    """Read signal after a tiny delay to allow combinational logic to settle."""
    await Timer(1, 'ns')
    return int(sig.value)


async def sample_clk_out_high_count(dut, cycles=8):
    """Sample clk_out at rising edges of clk_in for `cycles` cycles."""
    high_count = 0
    for _ in range(cycles):
        await RisingEdge(dut.clk_in)
        co = await read_settled(dut.clk_out)
        if co == 1:
            high_count += 1
    return high_count


async def test_clock_on(dut, sb, cov, assert_chk):
    """T1: manual_gate_en=0 -> clock on, clk_out follows clk_in, gated=0."""
    dut._log.info("T1: Clock on (manual_gate_en=0)")
    dut.manual_gate_en.value = 0
    dut.auto_gate_en.value = 0
    dut.activity.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_in)
    g = await read_settled(dut.gated)
    gate_cov(g)
    assert_chk.check("gated_zero_when_enabled",
                     g == 0,
                     f"gated={g} (expected 0)")
    hi = await sample_clk_out_high_count(dut, 8)
    assert_chk.check("clk_out_follows_clk_in",
                     hi == 8,
                     f"clk_out high count={hi}/8 (expected 8)")
    sb.add_expected(8); sb.add_actual(hi)


async def test_clock_off(dut, sb, cov, assert_chk):
    """T2: manual_gate_en=1 -> clock off, clk_out=0, gated=1."""
    dut._log.info("T2: Clock off (manual_gate_en=1)")
    dut.manual_gate_en.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk_in)
    g = await read_settled(dut.gated)
    gate_cov(g)
    assert_chk.check("gated_one_when_disabled",
                     g == 1,
                     f"gated={g} (expected 1)")
    hi = await sample_clk_out_high_count(dut, 8)
    assert_chk.check("clk_out_zero_when_gated",
                     hi == 0,
                     f"clk_out high count={hi}/8 (expected 0)")
    sb.add_expected(0); sb.add_actual(hi)


async def test_toggle(dut, sb, cov, assert_chk):
    """T3: Toggle manual_gate_en multiple times."""
    dut._log.info("T3: Toggle manual_gate_en")
    for i in range(4):
        en = i % 2
        dut.manual_gate_en.value = en
        for _ in range(5):
            await RisingEdge(dut.clk_in)
        g = await read_settled(dut.gated)
        gate_cov(g)
        assert_chk.check(f"toggle_{i}_gated",
                         g == en,
                         f"iter={i} en={en} gated={g} (expected {en})")
        hi = await sample_clk_out_high_count(dut, 4)
        expected_hi = 4 if en == 0 else 0
        assert_chk.check(f"toggle_{i}_clk_out",
                         hi == expected_hi,
                         f"iter={i} en={en} clk_out hi={hi}/4 (expected {expected_hi})")
        sb.add_expected(expected_hi); sb.add_actual(hi)


async def test_auto_gate_no_effect(dut, sb, cov, assert_chk):
    """T4: auto_gate_en and activity have NO effect (AUTO_GATE=0)."""
    dut._log.info("T4: auto_gate_en/activity no effect")
    dut.manual_gate_en.value = 0
    for ag, act in [(1, 0), (0, 1), (1, 1), (0, 0)]:
        dut.auto_gate_en.value = ag
        dut.activity.value = act
        for _ in range(5):
            await RisingEdge(dut.clk_in)
        g = await read_settled(dut.gated)
        assert_chk.check(f"auto_no_effect_ag{ag}_act{act}",
                         g == 0,
                         f"auto_gate_en={ag} activity={act} gated={g} (expected 0 — auto disabled)")
        sb.add_expected(0); sb.add_actual(g)


async def test_clk_out_latch_behavior(dut, sb, cov, assert_chk):
    """T5: Verify latch updates on falling edge — change manual_gate_en mid-cycle."""
    dut._log.info("T5: Latch behavior on falling edge")
    dut.manual_gate_en.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_in)
    # Now gate off
    dut.manual_gate_en.value = 1
    await RisingEdge(dut.clk_in)
    g = await read_settled(dut.gated)
    assert_chk.check("gated_combinational", g == 1, f"gated={g} (expected 1)")
    # Wait for falling edge then rising edge so latch updates
    await FallingEdge(dut.clk_in)
    await RisingEdge(dut.clk_in)
    co = await read_settled(dut.clk_out)
    assert_chk.check("clk_out_gated_after_fall",
                     co == 0,
                     f"clk_out={co} (expected 0 after falling-edge latch update)")
    sb.add_expected(0); sb.add_actual(co)
    # Now re-enable
    dut.manual_gate_en.value = 0
    await FallingEdge(dut.clk_in)
    await RisingEdge(dut.clk_in)
    co = await read_settled(dut.clk_out)
    assert_chk.check("clk_out_passthrough_after_fall",
                     co == 1,
                     f"clk_out={co} (expected 1 after re-enable)")
    sb.add_expected(1); sb.add_actual(co)


async def test_random(dut, gen, sb, cov, assert_chk, num=20):
    """Randomized tests."""
    dut._log.info(f"T6: Random tests ({num} iterations)")
    for i in range(num):
        en = gen.rng.randint(0, 1)
        ag = gen.rng.randint(0, 1)
        act = gen.rng.randint(0, 1)
        dut.manual_gate_en.value = en
        dut.auto_gate_en.value = ag
        dut.activity.value = act
        for _ in range(4):
            await RisingEdge(dut.clk_in)
        g = await read_settled(dut.gated)
        gate_cov(g)
        assert_chk.check(f"rand_{i}_gated",
                         g == en,
                         f"rand_{i}: en={en} ag={ag} act={act} gated={g} (expected {en})")
        sb.add_expected(en); sb.add_actual(g)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main clock gate test — all test cases."""
    cr = ClockResetAgent(dut, 'clk_in', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.manual_gate_en.value = 0
    dut.auto_gate_en.value = 0
    dut.activity.value = 0
    await RisingEdge(dut.clk_in)

    sb = Scoreboard('clk_gate')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('clk_gate')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Clock Gate Testbench")
    dut._log.info("=" * 60)

    await test_clock_on(dut, sb, cov, assert_chk)
    await test_clock_off(dut, sb, cov, assert_chk)
    await test_toggle(dut, sb, cov, assert_chk)
    await test_auto_gate_no_effect(dut, sb, cov, assert_chk)
    await test_clk_out_latch_behavior(dut, sb, cov, assert_chk)
    await test_random(dut, gen, sb, cov, assert_chk, 20)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
