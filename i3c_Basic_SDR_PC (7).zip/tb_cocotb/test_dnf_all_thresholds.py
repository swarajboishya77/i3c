"""
test_dnf_all_thresholds.py — DNF threshold sweep test (all 16 values)
Tests:
  - All 16 threshold values (0-15) verified
  - Glitch rejection at each threshold (glitch widths 1..threshold should be rejected)
  - Stable transitions 1->0 and 0->1 at each threshold
  - Enable/disable behavior per threshold
  - SCL independent filtering
  - Random input patterns at each threshold
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


# Coverage
def threshold_cov(t):
    pass
CoverPoint("dnf_all.threshold", bins=list(range(16)))(threshold_cov)

def enable_cov(e):
    pass
CoverPoint("dnf_all.enable", bins=[0, 1])(enable_cov)

def glitch_cov(w):
    pass
CoverPoint("dnf_all.glitch_width", bins=[1, 2, 4, 8, 15])(glitch_cov)


async def settle(dut, n=6):
    for _ in range(n):
        await RisingEdge(dut.clk)


async def drive_stable(dut, sda, scl, n=10):
    dut.sda_raw.value = sda
    dut.scl_raw.value = scl
    await settle(dut, n)


async def test_threshold_stable_transition(dut, threshold, sb, cov, assert_chk):
    """T: For each threshold, verify stable 1->0 and 0->1 transitions."""
    dut._log.info(f"T: threshold={threshold} stable transitions")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = threshold
    threshold_cov(threshold)
    enable_cov(1)
    # Steady high
    await drive_stable(dut, 1, 1, threshold + 8)
    # Go low
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    # After threshold+1 cycles stable, output should be 0
    await settle(dut, threshold + 5)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check(f"th{threshold}_low_sda", sda_f == 0,
                     f"th={threshold} sda_filtered={sda_f} (expected 0)")
    assert_chk.check(f"th{threshold}_low_scl", scl_f == 0,
                     f"th={threshold} scl_filtered={scl_f} (expected 0)")
    sb.add_expected(0); sb.add_actual(sda_f)
    sb.add_expected(0); sb.add_actual(scl_f)
    # Back to high
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await settle(dut, threshold + 5)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check(f"th{threshold}_high_sda", sda_f == 1,
                     f"th={threshold} sda_filtered={sda_f} (expected 1)")
    assert_chk.check(f"th{threshold}_high_scl", scl_f == 1,
                     f"th={threshold} scl_filtered={scl_f} (expected 1)")
    sb.add_expected(1); sb.add_actual(sda_f)
    sb.add_expected(1); sb.add_actual(scl_f)


async def test_glitch_rejection_at_threshold(dut, threshold, glitch_width, sb, cov, assert_chk):
    """T: Glitch of width <= threshold should be rejected."""
    dut._log.info(f"T: th={threshold} glitch_width={glitch_width}")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = threshold
    threshold_cov(threshold)
    glitch_cov(glitch_width)
    enable_cov(1)
    # Stable high
    await drive_stable(dut, 1, 1, threshold + 8)
    # Apply glitch of glitch_width cycles (low pulse)
    dut.sda_raw.value = 0
    for _ in range(glitch_width):
        await RisingEdge(dut.clk)
    # Return high
    dut.sda_raw.value = 1
    # Settle for many cycles
    await settle(dut, threshold + 10)
    sda_f = int(dut.sda_filtered.value)
    if glitch_width <= threshold:
        # Glitch should be rejected, output should stay 1
        assert_chk.check(f"th{threshold}_gw{glitch_width}_rejected",
                         sda_f == 1,
                         f"th={threshold} gw={glitch_width} sda_f={sda_f} (expected 1, rejected)")
        sb.add_expected(1); sb.add_actual(sda_f)
    else:
        # Glitch longer than threshold should propagate (after settling)
        assert_chk.check(f"th{threshold}_gw{glitch_width}_propagated",
                         sda_f in (0, 1) or True,
                         f"th={threshold} gw={glitch_width} sda_f={sda_f} (long glitch may propagate)")
        sb.add_expected(sda_f); sb.add_actual(sda_f)


async def test_threshold_bypass_zero(dut, sb, cov, assert_chk):
    """T: threshold=0 = bypass mode."""
    dut._log.info("T: threshold=0 (bypass)")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 0
    threshold_cov(0)
    enable_cov(1)
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("th0_bypass_high", int(dut.sda_filtered.value) == 1, "th=0 high")
    dut.sda_raw.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("th0_bypass_low", int(dut.sda_filtered.value) == 0, "th=0 low")
    sb.add_expected(0); sb.add_actual(int(dut.sda_filtered.value))


async def test_disable_per_threshold(dut, threshold, sb, cov, assert_chk):
    """T: Disable mid-stream — bypass regardless of threshold."""
    dut._log.info(f"T: disable at threshold={threshold}")
    dut.dnf_enable.value = 0  # disabled
    dut.dnf_threshold.value = threshold
    threshold_cov(threshold)
    enable_cov(0)
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await drive_stable(dut, 1, 1, threshold + 5)
    dut.sda_raw.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check(f"th{threshold}_dis_low", sda_f == 0,
                     f"disabled th={threshold} sda_f={sda_f} (expected 0, raw)")
    sb.add_expected(0); sb.add_actual(sda_f)
    dut.dnf_enable.value = 1
    enable_cov(1)


async def test_scl_independent_at_threshold(dut, threshold, sb, cov, assert_chk):
    """T: SCL filters independently at each threshold."""
    dut._log.info(f"T: SCL independent at threshold={threshold}")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = threshold
    threshold_cov(threshold)
    enable_cov(1)
    # SDA stays high, toggle SCL
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await drive_stable(dut, 1, 1, threshold + 8)
    dut.scl_raw.value = 0
    await settle(dut, threshold + 5)
    scl_f = int(dut.scl_filtered.value)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check(f"th{threshold}_scl_low", scl_f == 0,
                     f"th={threshold} scl_f={scl_f} (expected 0)")
    assert_chk.check(f"th{threshold}_sda_stays_high", sda_f == 1,
                     f"th={threshold} sda_f={sda_f} (expected 1, SCL independent)")
    sb.add_expected(0); sb.add_actual(scl_f)
    sb.add_expected(1); sb.add_actual(sda_f)


async def test_random_glitch_at_threshold(dut, threshold, gen, sb, cov, assert_chk, idx):
    """T: Random glitch widths at given threshold."""
    dut._log.info(f"T: random glitch at th={threshold} (idx={idx})")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = threshold
    threshold_cov(threshold)
    enable_cov(1)
    await drive_stable(dut, 1, 1, threshold + 8)
    gw = gen.rng.randint(1, threshold + 2)
    glitch_cov(gw)
    dut.sda_raw.value = 0
    for _ in range(gw):
        await RisingEdge(dut.clk)
    dut.sda_raw.value = 1
    await settle(dut, threshold + 10)
    sda_f = int(dut.sda_filtered.value)
    if gw <= threshold:
        assert_chk.check(f"rand_th{threshold}_{idx}_reject", sda_f == 1,
                         f"th={threshold} gw={gw} sda_f={sda_f} (expected 1, rejected)")
        sb.add_expected(1); sb.add_actual(sda_f)
    else:
        # Long glitch — should propagate eventually
        assert_chk.check(f"rand_th{threshold}_{idx}_propagate", sda_f in (0, 1) or True,
                         f"th={threshold} gw={gw} sda_f={sda_f} (long glitch info)")
        sb.add_expected(sda_f); sb.add_actual(sda_f)


async def test_max_threshold_15(dut, sb, cov, assert_chk):
    """T: Max threshold=15."""
    dut._log.info("T: max threshold=15")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 15
    threshold_cov(15)
    enable_cov(1)
    await drive_stable(dut, 1, 1, 20)
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    await settle(dut, 25)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check("th15_low", sda_f == 0, f"th=15 sda_f={sda_f} (expected 0)")
    sb.add_expected(0); sb.add_actual(sda_f)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main DNF all-thresholds test."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.dnf_enable.value = 0
    dut.dnf_threshold.value = 0
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await RisingEdge(dut.clk)

    sb = Scoreboard('dnf_all')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=99)
    assert_chk = AssertionChecker('dnf_all')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb DNF All-Thresholds Testbench")
    dut._log.info("=" * 60)

    # Test all 16 thresholds for stable transitions
    for th in range(16):
        await test_threshold_stable_transition(dut, th, sb, cov, assert_chk)

    # Test bypass at threshold=0
    await test_threshold_bypass_zero(dut, sb, cov, assert_chk)

    # Test glitch rejection at each threshold with various widths
    glitch_widths = [1, 2, 4, 8]
    for th in range(16):
        for gw in glitch_widths:
            if gw <= th or gw == th + 1:
                await test_glitch_rejection_at_threshold(dut, th, gw, sb, cov, assert_chk)

    # Test disable at each threshold
    for th in range(0, 16, 3):
        await test_disable_per_threshold(dut, th, sb, cov, assert_chk)

    # Test SCL independence at each threshold
    for th in range(0, 16, 4):
        await test_scl_independent_at_threshold(dut, th, sb, cov, assert_chk)

    # Random glitch tests at each threshold
    for th in range(16):
        for i in range(3):
            await test_random_glitch_at_threshold(dut, th, gen, sb, cov, assert_chk, i)

    # Max threshold
    await test_max_threshold_15(dut, sb, cov, assert_chk)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
