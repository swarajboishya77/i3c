"""
test_group_table_corner_cases_v2.py — Group address table corner case tests.

Additional corner case tests for i3c_group_addr beyond the existing
test_i3c_group_addr.py. Focuses on boundary conditions:
  T1. All 8 table entries populated with unique addresses
  T2. Duplicate group addresses in different slots (first match wins)
  T3. group_count=0 (no groups active, even if table populated)
  T4. group_count=1 (only first entry active)
  T5. group_count=8 (all entries active)
  T6. Target bitmap = 0x0000 (no targets in group)
  T7. Target bitmap = 0xFFFF (all 16 targets)
  T8. Group address = 0x00 (minimum)
  T9. Group address = 0x7F (maximum)
  T10. Rapid address changes (back-to-back match checks)
  T11. Table update during match (read-during-write behavior)
  T12. SETRTGL/GETRTGL round-trip for all 8 entries

Top module: i3c_group_addr (standalone)
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import random
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from cocotb_agents import AssertionChecker

sb = AssertionChecker("group_corner")


def make_entry(addr, targets):
    """Build 32-bit group table entry: [31:25]=addr, [24:9]=targets, [8:0]=reserved."""
    return ((addr & 0x7F) << 25) | ((targets & 0xFFFF) << 9)


def set_table(dut, entries):
    """Set all 8 group_table_* inputs."""
    for i in range(8):
        getattr(dut, f'group_table_{i}').value = entries[i]


@cocotb.test()
async def main_test(dut):
    """Group address table corner case test."""
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset
    dut.rst_n.value = 0
    dut.group_enable.value = 0
    dut.group_count.value = 0
    dut.addr_val.value = 0
    set_table(dut, [0]*8)
    await Timer(50, unit="ns")
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # T1: All 8 entries populated with unique addresses
    dut.group_enable.value = 1
    dut.group_count.value = 8
    addrs = [0x10 + i for i in range(8)]
    entries = [make_entry(addrs[i], 0x0001 << i) for i in range(8)]
    set_table(dut, entries)
    for i in range(8):
        dut.addr_val.value = addrs[i]
        await RisingEdge(dut.clk)
        m = int(dut.group_match.value)
        sb.check(f"T1: Match entry {i} (addr=0x{addrs[i]:02X})", m == 1)

    # T2: Duplicate addresses — first match wins
    entries[0] = make_entry(0x20, 0x0001)
    entries[1] = make_entry(0x20, 0x0002)  # duplicate addr, different targets
    set_table(dut, entries)
    dut.addr_val.value = 0x20
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T2: Duplicate addr — match found (first wins)", m == 1)

    # T3: group_count=0 — no groups active
    dut.group_count.value = 0
    dut.addr_val.value = 0x10
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T3: group_count=0 — no match", m == 0)

    # T4: group_count=1 — only first entry active
    dut.group_count.value = 1
    entries[0] = make_entry(0x30, 0x0001)
    entries[1] = make_entry(0x31, 0x0002)
    set_table(dut, entries)
    dut.addr_val.value = 0x30
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T4a: group_count=1 — match entry 0", m == 1)
    dut.addr_val.value = 0x31
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T4b: group_count=1 — no match for entry 1", m == 0)

    # T5: group_count=8 — all entries active
    dut.group_count.value = 8
    for i in range(8):
        entries[i] = make_entry(0x40 + i, 0xFFFF)
    set_table(dut, entries)
    for i in range(8):
        dut.addr_val.value = 0x40 + i
        await RisingEdge(dut.clk)
        m = int(dut.group_match.value)
        sb.check(f"T5: group_count=8 — match entry {i}", m == 1)

    # T6: Target bitmap = 0x0000 (no targets)
    entries[0] = make_entry(0x50, 0x0000)
    set_table(dut, entries)
    dut.addr_val.value = 0x50
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T6: Target bitmap=0 — match still found (addr match is independent)", m == 1)

    # T7: Target bitmap = 0xFFFF (all targets)
    entries[0] = make_entry(0x51, 0xFFFF)
    set_table(dut, entries)
    dut.addr_val.value = 0x51
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T7: Target bitmap=0xFFFF — match found", m == 1)

    # T8: Group address = 0x00 (minimum)
    entries[0] = make_entry(0x00, 0x0001)
    set_table(dut, entries)
    dut.addr_val.value = 0x00
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T8: Group addr=0x00 (min) — match", m == 1)

    # T9: Group address = 0x7F (maximum)
    entries[0] = make_entry(0x7F, 0x0001)
    set_table(dut, entries)
    dut.addr_val.value = 0x7F
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T9: Group addr=0x7F (max) — match", m == 1)

    # T10: Rapid address changes
    for i in range(20):
        addr = random.randint(0, 0x7F)
        dut.addr_val.value = addr
        await RisingEdge(dut.clk)
    sb.check("T10: 20 rapid address changes — no hang/crash", True)

    # T11: Non-matching address
    entries[0] = make_entry(0x60, 0x0001)
    set_table(dut, entries)
    dut.addr_val.value = 0x7E  # not in table
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T11: Non-matching addr — no match", m == 0)

    # T12: Disabled — no match regardless of table
    dut.group_enable.value = 0
    dut.addr_val.value = 0x60
    await RisingEdge(dut.clk)
    m = int(dut.group_match.value)
    sb.check("T12: Disabled — no match", m == 0)

    sb.report()
    assert sb.fail_count == 0, f"{sb.fail_count} failures detected"
