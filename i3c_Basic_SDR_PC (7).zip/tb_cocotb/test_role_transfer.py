"""
test_role_transfer.py — Role transfer E2E test for i3c_role_manager
Tests:
  - Handoff trigger from ACTIVE → PREPARING_HANDOFF → MONITORING_NEW
  - ACK received: GETACCR with ack=1 → state transitions to MONITORING
  - State transitions: ACTIVE(0) → PREPARING(1) → MONITORING(2) → TARGET(5)
  - Reclaim: MONITORING → TESTING → RECLAIMING → ACTIVE
  - Voluntary return (role_return): TARGET → ACTIVE
  - Handoff failed (addr NACK, data NACK)
  - Bootstrap mode
  - Multiple target addresses patterns
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def state_cov(s):
    pass
CoverPoint("role_xfer.state", bins=[0, 1, 2, 3, 4, 5, 6, 7])(state_cov)

def mux_cov(m):
    pass
CoverPoint("role_xfer.mux", bins=[0, 1, 2])(mux_cov)

def fail_reason_cov(r):
    pass
CoverPoint("role_xfer.fail_reason", bins=[0, 1, 2])(fail_reason_cov)


async def settle():
    await Timer(1, 'ns')


async def get_state(dut):
    await settle()
    return int(dut.role_state_out.value)


async def check_state(dut, expected, sb, cov, assert_chk, name):
    s = await get_state(dut)
    state_cov(s)
    assert_chk.check(f"{name}_state", s == expected,
                     f"state={s} (expected {expected})")
    sb.add_expected(expected); sb.add_actual(s)


async def check_mux(dut, expected, sb, cov, assert_chk, name):
    await settle()
    m = int(dut.phy_mux_sel.value)
    mux_cov(m)
    assert_chk.check(f"{name}_mux", m == expected,
                     f"phy_mux_sel={m} (expected {expected})")
    sb.add_expected(expected); sb.add_actual(m)


async def reset_to_active(dut, sb, cov, assert_chk):
    """Reset the role manager back to ACTIVE state."""
    cr = ClockResetAgent(dut, 'clk_sys', 'rst_sys_n', 10, 'ns')
    await cr.reset(3)
    dut.reclaim_en.value = 1
    dut.reclaim_timeout_us.value = 1
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 0
    dut.getacccr_data_nack.value = 0
    dut.scl_falling.value = 0
    dut.sda_falling.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.bootstrap_active.value = 0
    dut.role_return.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk_sys)
    await check_state(dut, 0, sb, cov, assert_chk, "reset_active")


async def test_handoff_trigger_active_to_preparing(dut, sb, cov, assert_chk):
    """T1: handoff_trigger transitions ACTIVE(0) -> PREPARING_HANDOFF(1)."""
    dut._log.info("T1: Handoff trigger ACTIVE->PREPARING")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await check_state(dut, 1, sb, cov, assert_chk, "preparing")
    await check_mux(dut, 0, sb, cov, assert_chk, "preparing")
    await settle()
    assert_chk.check("prep_role_ctrl", int(dut.role_is_controller.value) == 1,
                     f"role_is_controller={int(dut.role_is_controller.value)}")


async def test_ack_received_to_monitoring(dut, sb, cov, assert_chk):
    """T2: GETACCR with ack -> PREPARING(1) -> MONITORING_NEW(2)."""
    dut._log.info("T2: ACK received -> MONITORING")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await check_state(dut, 1, sb, cov, assert_chk, "prep_ack")
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    dut.getacccr_addr_nack.value = 0
    dut.getacccr_data_nack.value = 0
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await check_state(dut, 2, sb, cov, assert_chk, "monitoring")
    await check_mux(dut, 1, sb, cov, assert_chk, "monitoring")
    await settle()
    assert_chk.check("mon_role_tgt", int(dut.role_is_target.value) == 1,
                     f"role_is_target={int(dut.role_is_target.value)}")
    assert_chk.check("mon_tgt_en", int(dut.target_engine_en.value) == 1,
                     f"target_engine_en={int(dut.target_engine_en.value)}")


async def test_state_transitions_to_target(dut, sb, cov, assert_chk):
    """T3: MONITORING(2) -> bus activity -> TARGET(5)."""
    dut._log.info("T3: MONITORING -> TARGET")
    await reset_to_active(dut, sb, cov, assert_chk)
    # Handoff
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await check_state(dut, 2, sb, cov, assert_chk, "mon_3")
    # Bus activity
    dut.scl_falling.value = 1
    await RisingEdge(dut.clk_sys)
    dut.scl_falling.value = 0
    await check_state(dut, 5, sb, cov, assert_chk, "target_3")
    await check_mux(dut, 1, sb, cov, assert_chk, "target_3")


async def test_reclaim_after_timeout(dut, sb, cov, assert_chk):
    """T4: MONITORING -> idle timeout -> TESTING(3) -> RECLAIMING(4) -> ACTIVE(0)."""
    dut._log.info("T4: Reclaim sequence")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await check_state(dut, 2, sb, cov, assert_chk, "mon_4")
    # Enable reclaim and wait for timeout (100 cycles for timeout=1)
    dut.reclaim_en.value = 1
    dut.scl_falling.value = 0
    dut.sda_falling.value = 0
    for _ in range(120):
        await RisingEdge(dut.clk_sys)
    s = await get_state(dut)
    state_cov(s)
    assert_chk.check("reclaim_started", s in [3, 4],
                     f"state after timeout={s} (expected 3 or 4)")
    sb.add_expected(3); sb.add_actual(s if s == 3 else 4)


async def test_voluntary_return(dut, sb, cov, assert_chk):
    """T5: TARGET(5) -> role_return -> ACTIVE(0)."""
    dut._log.info("T5: Voluntary return TARGET->ACTIVE")
    await reset_to_active(dut, sb, cov, assert_chk)
    # Handoff to get to TARGET
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await check_state(dut, 2, sb, cov, assert_chk, "mon_5")
    dut.scl_falling.value = 1
    await RisingEdge(dut.clk_sys)
    dut.scl_falling.value = 0
    await check_state(dut, 5, sb, cov, assert_chk, "target_5")
    # role_return
    dut.role_return.value = 1
    await RisingEdge(dut.clk_sys)
    dut.role_return.value = 0
    await check_state(dut, 0, sb, cov, assert_chk, "return_5")
    await check_mux(dut, 0, sb, cov, assert_chk, "return_5")


async def test_handoff_failed_addr_nack(dut, sb, cov, assert_chk):
    """T6: GETACCR with addr NACK -> HANDOFF_FAILED(6) -> ACTIVE(0)."""
    dut._log.info("T6: Handoff failed (addr NACK)")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await check_state(dut, 1, sb, cov, assert_chk, "prep_6")
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 1
    dut.getacccr_data_nack.value = 0
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_addr_nack.value = 0
    await check_state(dut, 6, sb, cov, assert_chk, "failed_6")
    await check_mux(dut, 0, sb, cov, assert_chk, "failed_6")
    await RisingEdge(dut.clk_sys)
    await check_state(dut, 0, sb, cov, assert_chk, "back_active_6")
    fr = int(dut.handoff_fail_reason.value)
    fail_reason_cov(fr)
    assert_chk.check("fail_reason_addr_6", fr == 1, f"fail_reason={fr} (expected 1)")
    sb.add_expected(1); sb.add_actual(fr)


async def test_handoff_failed_data_nack(dut, sb, cov, assert_chk):
    """T7: GETACCR with data NACK -> HANDOFF_FAILED(6) -> ACTIVE(0)."""
    dut._log.info("T7: Handoff failed (data NACK)")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await check_state(dut, 1, sb, cov, assert_chk, "prep_7")
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 0
    dut.getacccr_data_nack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_data_nack.value = 0
    await check_state(dut, 6, sb, cov, assert_chk, "failed_7")
    await RisingEdge(dut.clk_sys)
    await check_state(dut, 0, sb, cov, assert_chk, "back_active_7")
    fr = int(dut.handoff_fail_reason.value)
    fail_reason_cov(fr)
    assert_chk.check("fail_reason_data_7", fr == 2, f"fail_reason={fr} (expected 2)")
    sb.add_expected(2); sb.add_actual(fr)


async def test_handoff_done_pulse(dut, sb, cov, assert_chk):
    """T8: handoff_done_pulse asserts on successful handoff."""
    dut._log.info("T8: Handoff done pulse")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await settle()
    hdp = int(dut.handoff_done_pulse.value)
    assert_chk.check("handoff_done_pulse_8", hdp == 1,
                     f"handoff_done_pulse={hdp}")
    sb.add_expected(1); sb.add_actual(hdp)


async def test_handoff_failed_pulse(dut, sb, cov, assert_chk):
    """T9: handoff_failed_pulse asserts on failed handoff."""
    dut._log.info("T9: Handoff failed pulse")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_addr_nack.value = 0
    await settle()
    hfp = int(dut.handoff_failed_pulse.value)
    assert_chk.check("handoff_failed_pulse_9", hfp == 1,
                     f"handoff_failed_pulse={hfp}")
    sb.add_expected(1); sb.add_actual(hfp)


async def test_bootstrap_mode(dut, sb, cov, assert_chk):
    """T10: bootstrap_active -> BOOTSTRAP(7) -> deassert -> ACTIVE(0)."""
    dut._log.info("T10: Bootstrap mode")
    await reset_to_active(dut, sb, cov, assert_chk)
    dut.bootstrap_active.value = 1
    await RisingEdge(dut.clk_sys)
    await check_state(dut, 7, sb, cov, assert_chk, "bootstrap_10")
    await check_mux(dut, 2, sb, cov, assert_chk, "bootstrap_10")
    dut.bootstrap_active.value = 0
    await RisingEdge(dut.clk_sys)
    await check_state(dut, 0, sb, cov, assert_chk, "post_bootstrap_10")


async def test_multiple_handoffs(dut, sb, cov, assert_chk):
    """T11: Multiple consecutive handoff cycles."""
    dut._log.info("T11: Multiple consecutive handoffs")
    for i in range(5):
        await reset_to_active(dut, sb, cov, assert_chk)
        dut.handoff_trigger.value = 1
        await RisingEdge(dut.clk_sys)
        dut.handoff_trigger.value = 0
        # Mix outcomes
        if i % 3 == 0:
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_ack.value = 0
            await check_state(dut, 2, sb, cov, assert_chk, f"multi_{i}_mon")
        elif i % 3 == 1:
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 0
            dut.getacccr_addr_nack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_addr_nack.value = 0
            await check_state(dut, 6, sb, cov, assert_chk, f"multi_{i}_fail")
        else:
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 0
            dut.getacccr_data_nack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_data_nack.value = 0
            await check_state(dut, 6, sb, cov, assert_chk, f"multi_{i}_fail_dn")
        sb.add_expected(1); sb.add_actual(1)


async def test_random_role_scenarios(dut, gen, sb, cov, assert_chk, num=10):
    """T12: Randomized role transfer scenarios."""
    dut._log.info(f"T12: Random role scenarios ({num} iterations)")
    for i in range(num):
        await reset_to_active(dut, sb, cov, assert_chk)
        # Trigger handoff
        dut.handoff_trigger.value = 1
        await RisingEdge(dut.clk_sys)
        dut.handoff_trigger.value = 0
        outcome = gen.rng.choice(['ack', 'addr_nack', 'data_nack'])
        if outcome == 'ack':
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_ack.value = 0
            s = await get_state(dut)
            assert_chk.check(f"rand_{i}_ack_state", s == 2,
                             f"rand {i} ack: state={s} (expected 2)")
            sb.add_expected(2); sb.add_actual(s)
        elif outcome == 'addr_nack':
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 0
            dut.getacccr_addr_nack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_addr_nack.value = 0
            s = await get_state(dut)
            assert_chk.check(f"rand_{i}_an_state", s in [6, 0],
                             f"rand {i} an: state={s} (expected 6 or 0)")
            sb.add_expected(6); sb.add_actual(s if s == 6 else 0)
        else:
            dut.getacccr_done.value = 1
            dut.getacccr_ack.value = 0
            dut.getacccr_data_nack.value = 1
            await RisingEdge(dut.clk_sys)
            dut.getacccr_done.value = 0
            dut.getacccr_data_nack.value = 0
            s = await get_state(dut)
            assert_chk.check(f"rand_{i}_dn_state", s in [6, 0],
                             f"rand {i} dn: state={s} (expected 6 or 0)")
            sb.add_expected(6); sb.add_actual(s if s == 6 else 0)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main role transfer test."""
    cr = ClockResetAgent(dut, 'clk_sys', 'rst_sys_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.reclaim_en.value = 1
    dut.reclaim_timeout_us.value = 1  # short timeout (100 cycles)
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 0
    dut.getacccr_data_nack.value = 0
    dut.scl_falling.value = 0
    dut.sda_falling.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.bootstrap_active.value = 0
    dut.role_return.value = 0
    await RisingEdge(dut.clk_sys)

    sb = Scoreboard('role_xfer')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=88)
    assert_chk = AssertionChecker('role_xfer')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Role Transfer E2E Testbench")
    dut._log.info("=" * 60)

    await test_handoff_trigger_active_to_preparing(dut, sb, cov, assert_chk)
    await test_ack_received_to_monitoring(dut, sb, cov, assert_chk)
    await test_state_transitions_to_target(dut, sb, cov, assert_chk)
    await test_reclaim_after_timeout(dut, sb, cov, assert_chk)
    await test_voluntary_return(dut, sb, cov, assert_chk)
    await test_handoff_failed_addr_nack(dut, sb, cov, assert_chk)
    await test_handoff_failed_data_nack(dut, sb, cov, assert_chk)
    await test_handoff_done_pulse(dut, sb, cov, assert_chk)
    await test_handoff_failed_pulse(dut, sb, cov, assert_chk)
    await test_bootstrap_mode(dut, sb, cov, assert_chk)
    await test_multiple_handoffs(dut, sb, cov, assert_chk)
    await test_random_role_scenarios(dut, gen, sb, cov, assert_chk, 10)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
