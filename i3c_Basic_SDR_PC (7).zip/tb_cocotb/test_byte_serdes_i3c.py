"""
test_byte_serdes_i3c.py — Cocotb testbench for byte_serdes_i3c (I3C Byte SerDes + PEC)
PHY simulation: when tcmd_bit_xfer or tcmd_start etc. is high, provide tcmd_done=1
                on the next cycle (background coroutine).
Tests: idle, START, send addr, send data byte, receive data byte, STOP, NACK, I2C mode.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def done_cov(d):
    pass
CoverPoint("serdes_i3c.done", bins=[0, 1])(done_cov)


class I3CPhyModel:
    """Simple PHY model that responds to tcmd_* with tcmd_done=1 next cycle.
    Also drives sda_sampled for receive operations."""
    def __init__(self, dut):
        self.dut = dut
        self.sda_sampled_value = 0  # default: ACK / 0 bit
        self.running = False
        self.task = None

    def set_sda_sampled(self, val):
        """Set the sda_sampled value to drive."""
        self.sda_sampled_value = val

    async def run(self):
        """Background coroutine: respond to tcmd_* with tcmd_done=1 next cycle."""
        d = self.dut
        d.tcmd_done.value = 0
        d.tcmd_busy.value = 0
        d.sda_sampled.value = 0
        self.running = True
        while self.running:
            await RisingEdge(d.clk)
            # Read tcmd_* signals (set combinationally by FSM this cycle)
            any_tcmd = (int(d.tcmd_start.value) or int(d.tcmd_repeat_start.value) or
                        int(d.tcmd_stop.value) or int(d.tcmd_bit_xfer.value) or
                        int(d.tcmd_drive_scl_low.value) or int(d.tcmd_release_bus.value))
            # Respond next cycle with tcmd_done
            d.tcmd_done.value = 1 if any_tcmd else 0
            d.tcmd_busy.value = 1 if any_tcmd else 0
            d.sda_sampled.value = self.sda_sampled_value

    def stop(self):
        self.running = False


async def wait_for_done(dut, timeout=200):
    """Wait for done=1 pulse. Returns cycles waited, or -1 on timeout."""
    for i in range(timeout):
        await RisingEdge(dut.clk)
        if int(dut.done.value) == 1:
            return i + 1
    return -1


async def test_idle(dut, sb, cov, assert_chk):
    """T1: Idle state — no commands, busy=0, idle=1."""
    dut._log.info("T1: Idle")
    dut.req_start.value = 0
    dut.req_repeat_start.value = 0
    dut.req_stop.value = 0
    dut.req_send_addr_w.value = 0
    dut.req_send_addr_r.value = 0
    dut.req_send_byte.value = 0
    dut.req_recv_byte.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    idle = int(dut.idle.value)
    done = int(dut.done.value)
    assert_chk.check("idle_busy", busy == 0, f"idle: busy={busy} (expected 0)")
    assert_chk.check("idle_idle", idle == 1, f"idle: idle={idle} (expected 1)")
    assert_chk.check("idle_done", done == 0, f"idle: done={done} (expected 0)")
    sb.add_expected(0); sb.add_actual(done)


async def test_start(dut, sb, cov, assert_chk):
    """T2: START command."""
    dut._log.info("T2: START")
    dut.req_start.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.req_start.value = 1
    await RisingEdge(dut.clk)
    dut.req_start.value = 0
    cycles = await wait_for_done(dut, 50)
    done_cov(1)
    assert_chk.check("start_done", cycles > 0, f"START: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    await RisingEdge(dut.clk)
    idle = int(dut.idle.value)
    assert_chk.check("start_idle_after", idle == 1, f"START: after done, idle={idle} (expected 1)")


async def test_send_addr_w(dut, phy, sb, cov, assert_chk):
    """T3: Send address byte (write) — target ACKs."""
    dut._log.info("T3: Send addr (write, ACK)")
    addr = 0x55
    dut.req_send_addr_w.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    # Set sda_sampled=0 (ACK) for the 9th bit
    phy.set_sda_sampled(0)
    dut.addr_val.value = addr
    dut.req_send_addr_w.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_addr_w.value = 0
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("addr_w_done", cycles > 0, f"addr_w: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    # Check ack_recv=1 (target ACKed)
    ack = int(dut.ack_recv.value)
    assert_chk.check("addr_w_ack", ack == 1, f"addr_w: ack_recv={ack} (expected 1 — ACK)")
    await RisingEdge(dut.clk)


async def test_send_data_byte(dut, phy, sb, cov, assert_chk):
    """T4: Send data byte — controller drives T-bit (parity)."""
    dut._log.info("T4: Send data byte")
    byte_val = 0xAA
    dut.req_send_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.byte_tx.value = byte_val
    dut.req_send_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_byte.value = 0
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("send_byte_done", cycles > 0, f"send_byte: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    await RisingEdge(dut.clk)


async def test_recv_data_byte(dut, phy, sb, cov, assert_chk):
    """T5: Receive data byte — target drives T-bit."""
    dut._log.info("T5: Receive data byte")
    # Set sda_sampled=1 for all bits — byte_rx should be 0xFF
    dut.req_recv_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(1)
    dut.recv_last_byte.value = 0
    dut.req_recv_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_recv_byte.value = 0
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("recv_byte_done", cycles > 0, f"recv_byte: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    byte_rx = int(dut.byte_rx.value)
    # All bits = 1, so byte_rx should be 0xFF
    assert_chk.check("recv_byte_value", byte_rx == 0xFF,
                     f"recv_byte: byte_rx={byte_rx:#x} (expected 0xFF — all bits sampled 1)")
    phy.set_sda_sampled(0)
    await RisingEdge(dut.clk)


async def test_stop(dut, sb, cov, assert_chk):
    """T6: STOP command."""
    dut._log.info("T6: STOP")
    dut.req_stop.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.req_stop.value = 1
    await RisingEdge(dut.clk)
    dut.req_stop.value = 0
    cycles = await wait_for_done(dut, 50)
    done_cov(1)
    assert_chk.check("stop_done", cycles > 0, f"STOP: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    await RisingEdge(dut.clk)


async def test_nack(dut, phy, sb, cov, assert_chk):
    """T7: NACK on address byte."""
    dut._log.info("T7: NACK")
    addr = 0x33
    dut.req_send_addr_w.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    # Set sda_sampled=1 (NACK) for the 9th bit
    phy.set_sda_sampled(1)
    dut.addr_val.value = addr
    dut.req_send_addr_w.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_addr_w.value = 0
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("nack_done", cycles > 0, f"NACK: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    # Check ack_recv=0 (target NACKed)
    ack = int(dut.ack_recv.value)
    assert_chk.check("nack_ack_recv", ack == 0, f"NACK: ack_recv={ack} (expected 0 — NACK)")
    phy.set_sda_sampled(0)
    await RisingEdge(dut.clk)


async def test_i2c_mode(dut, phy, sb, cov, assert_chk):
    """T8: I2C mode — send byte with ACK/NACK."""
    dut._log.info("T8: I2C mode")
    dut.i2c_mode.value = 1
    dut.req_send_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(0)  # ACK
    dut.byte_tx.value = 0x5A
    dut.req_send_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_byte.value = 0
    cycles = await wait_for_done(dut, 100)
    done_cov(1)
    assert_chk.check("i2c_send_byte_done", cycles > 0,
                     f"I2C send_byte: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    ack = int(dut.ack_recv.value)
    assert_chk.check("i2c_send_byte_ack", ack == 1, f"I2C send_byte: ack_recv={ack} (expected 1 — ACK)")
    # Switch back to I3C mode
    dut.i2c_mode.value = 0
    await RisingEdge(dut.clk)


async def test_repeat_start(dut, sb, cov, assert_chk):
    """T9: Repeated START command."""
    dut._log.info("T9: Repeated START")
    dut.req_repeat_start.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.req_repeat_start.value = 1
    await RisingEdge(dut.clk)
    dut.req_repeat_start.value = 0
    cycles = await wait_for_done(dut, 50)
    done_cov(1)
    assert_chk.check("rstart_done", cycles > 0,
                     f"Repeated START: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    await RisingEdge(dut.clk)


async def test_random(dut, phy, gen, sb, cov, assert_chk, num=10):
    """Randomized tests."""
    dut._log.info(f"T10: Random tests ({num} iterations)")
    for i in range(num):
        op = gen.rng.choice(['start', 'rstart', 'stop', 'send_addr_w', 'send_byte', 'recv_byte'])
        for _ in range(2):
            await RisingEdge(dut.clk)
        if op == 'start':
            dut.req_start.value = 1
        elif op == 'rstart':
            dut.req_repeat_start.value = 1
        elif op == 'stop':
            dut.req_stop.value = 1
        elif op == 'send_addr_w':
            phy.set_sda_sampled(gen.rng.randint(0, 1))
            dut.addr_val.value = gen.rng.randint(0, 0x7F)
            dut.req_send_addr_w.value = 1
        elif op == 'send_byte':
            dut.byte_tx.value = gen.rng.randint(0, 0xFF)
            dut.req_send_byte.value = 1
        else:  # recv_byte
            phy.set_sda_sampled(gen.rng.randint(0, 1))
            dut.recv_last_byte.value = gen.rng.randint(0, 1)
            dut.req_recv_byte.value = 1
        await RisingEdge(dut.clk)
        dut.req_start.value = 0
        dut.req_repeat_start.value = 0
        dut.req_stop.value = 0
        dut.req_send_addr_w.value = 0
        dut.req_send_byte.value = 0
        dut.req_recv_byte.value = 0
        cycles = await wait_for_done(dut, 100)
        assert_chk.check(f"rand_{i}_{op}_done", cycles > 0,
                         f"rand_{i}: op={op} done after {cycles} cycles")
        if cycles > 0:
            sb.add_expected(1); sb.add_actual(1)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main I3C byte serdes test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.req_start.value = 0
    dut.req_repeat_start.value = 0
    dut.req_stop.value = 0
    dut.req_send_addr_w.value = 0
    dut.req_send_addr_r.value = 0
    dut.req_send_byte.value = 0
    dut.req_recv_byte.value = 0
    dut.recv_last_byte.value = 0
    dut.addr_val.value = 0
    dut.byte_tx.value = 0
    dut.i2c_mode.value = 0
    dut.pec_en.value = 0
    dut.pec_append_req.value = 0
    dut.pec_rx_check.value = 0
    dut.tcmd_done.value = 0
    dut.tcmd_busy.value = 0
    dut.sda_sampled.value = 0
    await RisingEdge(dut.clk)

    # Start PHY model in background
    phy = I3CPhyModel(dut)
    phy_task = cocotb.start_soon(phy.run())

    sb = Scoreboard('serdes_i3c')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('serdes_i3c')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb I3C Byte SerDes Testbench")
    dut._log.info("=" * 60)

    await test_idle(dut, sb, cov, assert_chk)
    await test_start(dut, sb, cov, assert_chk)
    await test_send_addr_w(dut, phy, sb, cov, assert_chk)
    await test_send_data_byte(dut, phy, sb, cov, assert_chk)
    await test_recv_data_byte(dut, phy, sb, cov, assert_chk)
    await test_stop(dut, sb, cov, assert_chk)
    await test_nack(dut, phy, sb, cov, assert_chk)
    await test_i2c_mode(dut, phy, sb, cov, assert_chk)
    await test_repeat_start(dut, sb, cov, assert_chk)
    await test_random(dut, phy, gen, sb, cov, assert_chk, 10)

    # Stop PHY model
    phy.stop()
    phy_task.kill()

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
