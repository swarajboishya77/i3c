"""
test_getaccr_e2e_v2.py — Cocotb testbench for GETACCR handoff flow.

Cocotb equivalent of tb/tb_i3c_getaccr_e2e.sv. Tests the role_manager
state transitions during GETACCR handoff:
  T1. Reset → ACTIVE_CONTROLLER
  T2. handoff_trigger → PREPARING_HANDOFF
  T3. getacccr_done + ack → MONITORING_NEW → TARGET
  T4. phy_mux_sel flips from DPHY to TARGET
  T5. target_engine_en asserted
  T6. getacccr_done + addr_nack → HANDOFF_FAILED → ACTIVE
  T7. getacccr_done + data_nack → HANDOFF_FAILED → ACTIVE
  T8. handoff_failed_pulse asserted on NACK
  T9. fail_reason encodes NACK type

Top module: i3c_role_manager (standalone)
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import AssertionChecker


# State encodings (from i3c_role_manager.sv)
ROLE_ACTIVE_CONTROLLER = 0
ROLE_PREPARING_HANDOFF = 1
ROLE_MONITORING_NEW    = 2
ROLE_TESTING_NEW       = 3
ROLE_RECLAIMING        = 4
ROLE_TARGET            = 5
ROLE_HANDOFF_FAILED    = 6
ROLE_BOOTSTRAP         = 7

# phy_mux_sel values
PHY_MUX_DPHY   = 0
PHY_MUX_TARGET = 1
PHY_MUX_BOOT   = 2

sb = AssertionChecker("test")


@cocotb.test()
async def main_test(dut):
    """GETACCR handoff flow test."""
    clock = Clock(dut.clk_sys, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset
    dut.rst_sys_n.value = 0
    dut.reclaim_en.value = 0
    dut.reclaim_timeout_us.value = 100
    dut.handoff_trigger.value = 0
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    dut.getacccr_addr_nack.value = 0
    dut.getacccr_data_nack.value = 0
    dut.scl_falling.value = 0
    dut.sda_falling.value = 0
    dut.scl_filt.value = 1
    dut.sda_filt.value = 1
    dut.bootstrap_active.value = 0
    dut.role_return.value = 0

    await Timer(100, unit="ns")
    dut.rst_sys_n.value = 1
    await RisingEdge(dut.clk_sys)
    await RisingEdge(dut.clk_sys)

    # T1: Reset → ACTIVE_CONTROLLER
    state = int(dut.role_state_out.value)
    sb.check("T1: Reset → ACTIVE_CONTROLLER", state == ROLE_ACTIVE_CONTROLLER)

    # T2: handoff_trigger → PREPARING_HANDOFF
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await RisingEdge(dut.clk_sys)
    state = int(dut.role_state_out.value)
    sb.check("T2: handoff_trigger → PREPARING_HANDOFF", state == ROLE_PREPARING_HANDOFF)

    # T3: getacccr_done + ack → MONITORING_NEW
    dut.getacccr_done.value = 1
    dut.getacccr_ack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_ack.value = 0
    await RisingEdge(dut.clk_sys)
    state = int(dut.role_state_out.value)
    sb.check("T3a: GETACCR ACK → MONITORING_NEW", state == ROLE_MONITORING_NEW)

    # Wait for the 100µs monitor timer to expire (simulated by waiting + SCL activity)
    # In the real FSM, MONITORING_NEW transitions to TARGET after scl_falling detected.
    # For this unit test, we pulse scl_falling directly (it's a direct input, not derived).
    for _ in range(3):
        dut.scl_falling.value = 1
        await RisingEdge(dut.clk_sys)
        dut.scl_falling.value = 0
        await RisingEdge(dut.clk_sys)

    state = int(dut.role_state_out.value)
    sb.check("T3b: After SCL activity → TARGET", state == ROLE_TARGET)

    # T4: phy_mux_sel = TARGET when in TARGET state
    mux = int(dut.phy_mux_sel.value)
    sb.check("T4: phy_mux_sel = TARGET", mux == PHY_MUX_TARGET)

    # T5: target_engine_en asserted
    ten = int(dut.target_engine_en.value)
    sb.check("T5: target_engine_en = 1", ten == 1)

    # T6: Reset back to ACTIVE, then test addr NACK
    dut.rst_sys_n.value = 0
    await RisingEdge(dut.clk_sys)
    dut.rst_sys_n.value = 1
    await RisingEdge(dut.clk_sys)

    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await RisingEdge(dut.clk_sys)

    # Addr NACK → HANDOFF_FAILED
    dut.getacccr_done.value = 1
    dut.getacccr_addr_nack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_addr_nack.value = 0
    await RisingEdge(dut.clk_sys)

    state = int(dut.role_state_out.value)
    sb.check("T6a: Addr NACK → HANDOFF_FAILED", state == ROLE_HANDOFF_FAILED)

    failed_pulse = int(dut.handoff_failed_pulse.value)
    sb.check("T6b: handoff_failed_pulse asserted", failed_pulse == 1)

    # HANDOFF_FAILED is transient → ACTIVE next cycle
    await RisingEdge(dut.clk_sys)
    state = int(dut.role_state_out.value)
    sb.check("T6c: HANDOFF_FAILED → ACTIVE_CONTROLLER", state == ROLE_ACTIVE_CONTROLLER)

    # T7: Data NACK → HANDOFF_FAILED
    dut.handoff_trigger.value = 1
    await RisingEdge(dut.clk_sys)
    dut.handoff_trigger.value = 0
    await RisingEdge(dut.clk_sys)

    dut.getacccr_done.value = 1
    dut.getacccr_data_nack.value = 1
    await RisingEdge(dut.clk_sys)
    dut.getacccr_done.value = 0
    dut.getacccr_data_nack.value = 0
    await RisingEdge(dut.clk_sys)

    state = int(dut.role_state_out.value)
    sb.check("T7a: Data NACK → HANDOFF_FAILED", state == ROLE_HANDOFF_FAILED)

    # fail_reason encoding
    reason = int(dut.handoff_fail_reason.value)
    sb.check("T7b: fail_reason != 0 (NACK type encoded)", reason != 0)

    await RisingEdge(dut.clk_sys)
    state = int(dut.role_state_out.value)
    sb.check("T7c: HANDOFF_FAILED → ACTIVE_CONTROLLER", state == ROLE_ACTIVE_CONTROLLER)

    # T8: role_is_controller and role_is_target are mutually exclusive
    ric = int(dut.role_is_controller.value)
    rit = int(dut.role_is_target.value)
    sb.check("T8: role_is_controller/target mutually exclusive", not (ric and rit))

    sb.report()
    assert sb.fail_count == 0, f"{sb.fail_count} failures detected"
