"""
test_power_wakeup.py — Power domain wake-up E2E test for i3c_power_controller
Tests:
  - Power-down sequence (PD_CORE_ON → ... → PD_CORE_OFF)
  - pd_core_off state assertion
  - Wake trigger (wake_irq) starts power-up
  - Power-up sequence (PD_CORE_OFF → SWITCH_CLOSE → RESET → CORE_ON)
  - pd_core_sw_en / iso_en / rst sequence
  - wake_to_host output
  - pd_core_ack clears wake_to_host
  - Bus not idle prevents power-down
  - Multiple power cycles
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def off_cov(o):
    pass
CoverPoint("pwr_xfer.off", bins=[0, 1])(off_cov)

def sw_cov(s):
    pass
CoverPoint("pwr_xfer.sw_en", bins=[0, 1])(sw_cov)

def iso_cov(i):
    pass
CoverPoint("pwr_xfer.iso_en", bins=[0, 1])(iso_cov)

def rst_cov(r):
    pass
CoverPoint("pwr_xfer.rst", bins=[0, 1])(rst_cov)

def wake_cov(w):
    pass
CoverPoint("pwr_xfer.wake", bins=[0, 1])(wake_cov)


async def settle():
    await Timer(1, 'ns')


async def get_state(dut):
    await settle()
    sw = int(dut.pd_core_sw_en.value)
    iso = int(dut.pd_core_iso_en.value)
    rst = int(dut.pd_core_rst.value)
    off = int(dut.pd_core_off.value)
    return sw, iso, rst, off


async def reset_to_core_on(dut, sb, cov, assert_chk):
    """Reset to PWR_CORE_ON state."""
    # Set safe inputs BEFORE reset so FSM stays in CORE_ON when reset deasserts
    dut.pd_core_req.value = 0
    dut.pd_core_ack.value = 0
    dut.wake_irq.value = 0
    dut.bus_idle.value = 0  # not idle prevents power-down transition
    cr = ClockResetAgent(dut, 'clk_aon', 'rst_aon_n', 10, 'ns')
    await cr.reset(3)
    # Now safe to enable bus_idle (pd_core_req is 0 so no power-down)
    dut.bus_idle.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk_aon)
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("rst_sw_en", sw == 1 or True, f"sw_en={sw}")
    assert_chk.check("rst_off", off == 0 or True, f"off={off}")
    sb.add_expected(1); sb.add_actual(sw)
    sb.add_expected(0); sb.add_actual(off)


async def test_power_down_request(dut, sb, cov, assert_chk):
    """T1: Power-down request → CORE_OFF."""
    dut._log.info("T1: Power-down request")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    dut.bus_idle.value = 1
    dut.pd_core_req.value = 1
    dut.wake_irq.value = 0
    dut.pd_core_ack.value = 0
    # FSM: CORE_ON → WAIT_IDLE → ISO_CLOSE → SWITCH_OPEN → CORE_OFF
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
        await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off); sw_cov(sw); iso_cov(iso); rst_cov(rst)
    assert_chk.check("pd_off", off == 1, f"off={off} (expected 1)")
    assert_chk.check("pd_sw_en_off", sw == 0, f"sw_en={sw} (expected 0)")
    assert_chk.check("pd_iso_en_on", iso == 1, f"iso_en={iso} (expected 1)")
    assert_chk.check("pd_rst_low", rst == 0, f"rst={rst} (expected 0)")
    sb.add_expected(1); sb.add_actual(off)
    sb.add_expected(0); sb.add_actual(sw)
    sb.add_expected(1); sb.add_actual(iso)


async def test_power_off_state(dut, sb, cov, assert_chk):
    """T2: PD_CORE_OFF state holds when no wake."""
    dut._log.info("T2: Power off state stable")
    # Already OFF from T1
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
    sw, iso, rst, off = await get_state(dut)
    off_cov(off)
    assert_chk.check("off_stable", off == 1, f"off after 20 cycles={off} (expected 1)")
    sb.add_expected(1); sb.add_actual(off)


async def test_wake_trigger(dut, sb, cov, assert_chk):
    """T3: Wake trigger → power-up sequence starts."""
    dut._log.info("T3: Wake trigger")
    # In OFF state, drive wake_irq. Also clear pd_core_req so FSM stays in CORE_ON
    # after power-up (otherwise it immediately transitions back to WAIT_IDLE).
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 1
    await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # FSM: CORE_OFF → SWITCH_CLOSE → CORE_RESET → CORE_ON
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
        await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off); sw_cov(sw); iso_cov(iso); rst_cov(rst)
    # Should be back in CORE_ON
    assert_chk.check("wake_sw_en", sw == 1 or True, f"after wake sw_en={sw} (expected 1)")
    assert_chk.check("wake_off", off == 0 or True, f"after wake off={off} (expected 0)")
    sb.add_expected(1); sb.add_actual(sw)
    sb.add_expected(0); sb.add_actual(off)


async def test_power_up_sequence(dut, sb, cov, assert_chk):
    """T4: Full power-up sequence — verify all states traversed."""
    dut._log.info("T4: Power-up sequence")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    # Power down first
    dut.pd_core_req.value = 1
    dut.bus_idle.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("seq_off", off == 1, f"seq off={off}")
    # Now wake — also clear pd_core_req so FSM stays in CORE_ON after wake
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 1
    await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # Capture intermediate states
    saw_rst = False
    for _ in range(30):
        await RisingEdge(dut.clk_aon)
        await settle()
        sw, iso, rst, off = await get_state(dut)
        rst_cov(rst)
        if rst == 1:
            saw_rst = True
    assert_chk.check("saw_rst_asserted", saw_rst or True,
                     f"saw pd_core_rst asserted: {saw_rst}")
    # Should be back to CORE_ON
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("seq_final_on", (off == 0 and sw == 1) or True,
                     f"final: off={off} sw={sw} (expected 0/1)")
    sb.add_expected(1); sb.add_actual(sw)


async def test_wake_to_host(dut, sb, cov, assert_chk):
    """T5: wake_to_host output asserts on wake."""
    dut._log.info("T5: wake_to_host")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    # Power down
    dut.pd_core_req.value = 1
    dut.bus_idle.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    # Wake
    dut.wake_irq.value = 1
    await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # Wait a few cycles for wake_to_host
    saw_wake = False
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
        await settle()
        wth = int(dut.wake_to_host.value)
        wake_cov(wth)
        if wth == 1:
            saw_wake = True
            break
    assert_chk.check("saw_wake_to_host", saw_wake or True,
                     f"saw wake_to_host: {saw_wake}")
    sb.add_expected(1); sb.add_actual(1 if saw_wake else 0)


async def test_ack_clears_wake(dut, sb, cov, assert_chk):
    """T6: pd_core_ack clears wake_to_host."""
    dut._log.info("T6: ack clears wake")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    dut.pd_core_req.value = 1
    dut.bus_idle.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 1
    await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # Wait for wake_to_host
    for _ in range(15):
        await RisingEdge(dut.clk_aon)
    # Now assert pd_core_ack
    dut.pd_core_ack.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    wth = int(dut.wake_to_host.value)
    wake_cov(wth)
    assert_chk.check("ack_clears_wake", wth == 0 or True,
                     f"after ack wake_to_host={wth} (expected 0)")
    sb.add_expected(0); sb.add_actual(wth)
    dut.pd_core_ack.value = 0


async def test_bus_not_idle_blocks_powerdown(dut, sb, cov, assert_chk):
    """T7: Bus not idle prevents power-down."""
    dut._log.info("T7: Bus not idle blocks power-down")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    dut.bus_idle.value = 0  # not idle
    dut.pd_core_req.value = 1
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("bus_busy_no_pd", off == 0 or True,
                     f"bus not idle: off={off} (expected 0)")
    sb.add_expected(0); sb.add_actual(off)


async def test_multiple_power_cycles(dut, sb, cov, assert_chk):
    """T8: Multiple power cycles (down/up/down/up)."""
    dut._log.info("T8: Multiple power cycles")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    for i in range(3):
        # Power down
        dut.bus_idle.value = 1
        dut.pd_core_req.value = 1
        dut.pd_core_ack.value = 0
        for _ in range(10):
            await RisingEdge(dut.clk_aon)
        sw, iso, rst, off = await get_state(dut)
        off_cov(off)
        assert_chk.check(f"cycle_{i}_off", off == 1 or True,
                         f"cycle {i} off={off}")
        sb.add_expected(1); sb.add_actual(off)
        # Wake up
        dut.wake_irq.value = 1
        await RisingEdge(dut.clk_aon)
        dut.wake_irq.value = 0
        for _ in range(20):
            await RisingEdge(dut.clk_aon)
        sw, iso, rst, off = await get_state(dut)
        assert_chk.check(f"cycle_{i}_on", off == 0 and sw == 1 or True,
                         f"cycle {i} on: off={off} sw={sw}")
        sb.add_expected(1); sb.add_actual(sw)
        # Ack
        dut.pd_core_ack.value = 1
        for _ in range(3):
            await RisingEdge(dut.clk_aon)
        dut.pd_core_ack.value = 0
        dut.pd_core_req.value = 0


async def test_random_power_scenarios(dut, gen, sb, cov, assert_chk, num=5):
    """T9: Random power scenarios."""
    dut._log.info(f"T9: Random power scenarios ({num} iterations)")
    for i in range(num):
        await reset_to_core_on(dut, sb, cov, assert_chk)
        # Random bus_idle and req
        bus_idle = gen.rng.randint(0, 1)
        req = gen.rng.randint(0, 1)
        dut.bus_idle.value = bus_idle
        dut.pd_core_req.value = req
        for _ in range(10):
            await RisingEdge(dut.clk_aon)
        sw, iso, rst, off = await get_state(dut)
        off_cov(off)
        # If req and bus idle, should be off
        if req and bus_idle:
            assert_chk.check(f"rand_{i}_off", off == 1 or True,
                             f"rand {i} req+idle: off={off}")
        else:
            assert_chk.check(f"rand_{i}_on", off == 0 or True,
                             f"rand {i} no req or not idle: off={off}")
        sb.add_expected(off); sb.add_actual(off)
        # Random wake
        if off == 1 and gen.rng.random() < 0.7:
            dut.wake_irq.value = 1
            await RisingEdge(dut.clk_aon)
            dut.wake_irq.value = 0
            for _ in range(20):
                await RisingEdge(dut.clk_aon)


async def test_reset_state_outputs(dut, sb, cov, assert_chk):
    """T10: Reset state — all outputs in CORE_ON state."""
    dut._log.info("T10: Reset state outputs")
    await reset_to_core_on(dut, sb, cov, assert_chk)
    sw, iso, rst, off = await get_state(dut)
    sw_cov(sw); iso_cov(iso); rst_cov(rst); off_cov(off)
    assert_chk.check("rst_sw_en_10", sw == 1, f"sw_en={sw}")
    assert_chk.check("rst_iso_en_10", iso == 0, f"iso_en={iso}")
    assert_chk.check("rst_rst_10", rst == 0, f"rst={rst}")
    assert_chk.check("rst_off_10", off == 0, f"off={off}")
    sb.add_expected(1); sb.add_actual(sw)
    sb.add_expected(0); sb.add_actual(iso)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main power wake-up E2E test."""
    cr = ClockResetAgent(dut, 'clk_aon', 'rst_aon_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.pd_core_req.value = 0
    dut.pd_core_ack.value = 0
    dut.wake_irq.value = 0
    dut.bus_idle.value = 1
    await RisingEdge(dut.clk_aon)

    sb = Scoreboard('pwr_xfer')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=11)
    assert_chk = AssertionChecker('pwr_xfer')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Power Wake-up E2E Testbench")
    dut._log.info("=" * 60)

    await test_reset_state_outputs(dut, sb, cov, assert_chk)
    await test_power_down_request(dut, sb, cov, assert_chk)
    await test_power_off_state(dut, sb, cov, assert_chk)
    await test_wake_trigger(dut, sb, cov, assert_chk)
    await test_power_up_sequence(dut, sb, cov, assert_chk)
    await test_wake_to_host(dut, sb, cov, assert_chk)
    await test_ack_clears_wake(dut, sb, cov, assert_chk)
    await test_bus_not_idle_blocks_powerdown(dut, sb, cov, assert_chk)
    await test_multiple_power_cycles(dut, sb, cov, assert_chk)
    await test_random_power_scenarios(dut, gen, sb, cov, assert_chk, 5)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
