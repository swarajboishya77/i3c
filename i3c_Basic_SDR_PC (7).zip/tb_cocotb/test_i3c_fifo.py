"""
test_i3c_fifo.py — Cocotb testbench for i3c_fifo (generic sync FIFO)
Tests: fill to depth, drain, overflow, underflow, simultaneous push+pop,
       wrap-around, flush, almost full/empty, reset clears sticky flags,
       data integrity, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

Default parameters: WIDTH=32, DEPTH=16, AFULL_TH=12, AEMPTY_TH=1, REG_OUT=1.
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker

DEPTH = 16   # matches default parameter
AFULL_TH = 12
AEMPTY_TH = 1


# Coverage points
def full_cov(v):
    pass
CoverPoint("fifo.full", bins=[0, 1])(full_cov)

def empty_cov(v):
    pass
CoverPoint("fifo.empty", bins=[0, 1])(empty_cov)

def ovf_cov(v):
    pass
CoverPoint("fifo.overflow", bins=[0, 1])(ovf_cov)

def unf_cov(v):
    pass
CoverPoint("fifo.underflow", bins=[0, 1])(unf_cov)


async def rd_after_edge(sig):
    """Read a registered signal after NBA has committed (post RisingEdge)."""
    await Timer(1, 'ns')
    return int(sig.value)


async def push_one(dut, data):
    """Push one word into the FIFO (assumes not full)."""
    dut.wr_en.value = 1
    dut.wr_data.value = data
    await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)


async def pop_one(dut):
    """Pop one word from the FIFO (assumes not empty). Returns rd_data."""
    dut.rd_en.value = 1
    await RisingEdge(dut.clk)
    dut.rd_en.value = 0
    val = await rd_after_edge(dut.rd_data)
    await RisingEdge(dut.clk)
    return val


async def drain_all(dut):
    """Drain all entries from FIFO."""
    for _ in range(DEPTH + 1):
        dut.rd_en.value = 1
        await RisingEdge(dut.clk)
        # Check empty flag (with NBA settle)
        await Timer(1, 'ns')
        if int(dut.empty.value) == 1:
            dut.rd_en.value = 0
            await RisingEdge(dut.clk)
            return
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)


async def test_reset_clears(dut, sb, cov, assert_chk):
    """T1: After reset, empty=1, full=0, overflow=0, underflow=0, data_count=0."""
    dut._log.info("T1: Reset clears sticky flags")
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    e = int(dut.empty.value)
    f = int(dut.full.value)
    ovf = int(dut.overflow.value)
    unf = int(dut.underflow.value)
    dc = int(dut.data_count.value)
    assert_chk.check("rst_empty", e == 1, f"empty={e}")
    assert_chk.check("rst_full", f == 0, f"full={f}")
    assert_chk.check("rst_ovf", ovf == 0, f"overflow={ovf}")
    assert_chk.check("rst_unf", unf == 0, f"underflow={unf}")
    assert_chk.check("rst_count", dc == 0, f"data_count={dc}")
    sb.add_expected(1); sb.add_actual(e)
    sb.add_expected(0); sb.add_actual(f)
    empty_cov(e); full_cov(f); ovf_cov(ovf); unf_cov(unf)


async def test_fill_to_depth(dut, sb, cov, assert_chk):
    """T2: Fill FIFO to DEPTH — full asserts, data_count=DEPTH."""
    dut._log.info("T2: Fill to depth")
    for i in range(DEPTH):
        dut.wr_en.value = 1
        dut.wr_data.value = (0xA000 + i) & 0xFFFFFFFF
        await RisingEdge(dut.clk)
        await Timer(1, 'ns')
        af = int(dut.almost_full.value)
        if af == 1:
            cov.add_point("fifo.almost_full_seen", 1, [1])
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    f = int(dut.full.value)
    e = int(dut.empty.value)
    dc = int(dut.data_count.value)
    full_cov(f); empty_cov(e)
    assert_chk.check("full_after_fill", f == 1, f"full={f} (expected 1)")
    assert_chk.check("not_empty_after_fill", e == 0, f"empty={e}")
    assert_chk.check("count_eq_depth", dc == DEPTH, f"data_count={dc} (expected {DEPTH})")
    sb.add_expected(1); sb.add_actual(f)


async def test_overflow(dut, sb, cov, assert_chk):
    """T3: Push when full — overflow flag sets, write dropped."""
    dut._log.info("T3: Overflow")
    # FIFO is already full from T2
    dut.wr_en.value = 1
    dut.wr_data.value = 0xDEADBEEF
    await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    ovf = int(dut.overflow.value)
    dc = int(dut.data_count.value)
    ovf_cov(ovf)
    assert_chk.check("overflow_flag", ovf == 1, f"overflow={ovf}")
    assert_chk.check("count_still_depth", dc == DEPTH, f"data_count={dc} (expected {DEPTH})")
    sb.add_expected(1); sb.add_actual(ovf)


async def test_drain_to_empty(dut, sb, cov, assert_chk):
    """T4: Drain FIFO — empty asserts, full deasserts, count=0."""
    dut._log.info("T4: Drain to empty")
    for i in range(DEPTH):
        dut.rd_en.value = 1
        await RisingEdge(dut.clk)
        await Timer(1, 'ns')
        ae = int(dut.almost_empty.value)
        if ae == 1:
            cov.add_point("fifo.almost_empty_seen", 1, [1])
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    e = int(dut.empty.value)
    f = int(dut.full.value)
    dc = int(dut.data_count.value)
    empty_cov(e); full_cov(f)
    assert_chk.check("empty_after_drain", e == 1, f"empty={e}")
    assert_chk.check("not_full_after_drain", f == 0, f"full={f}")
    assert_chk.check("count_zero_after_drain", dc == 0, f"data_count={dc}")
    sb.add_expected(1); sb.add_actual(e)
    sb.add_expected(0); sb.add_actual(f)


async def test_underflow(dut, sb, cov, assert_chk):
    """T5: Pop when empty — underflow flag sets."""
    dut._log.info("T5: Underflow")
    dut.rd_en.value = 1
    await RisingEdge(dut.clk)
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    unf = int(dut.underflow.value)
    unf_cov(unf)
    assert_chk.check("underflow_flag", unf == 1, f"underflow={unf}")
    sb.add_expected(1); sb.add_actual(unf)


async def test_data_integrity(dut, sb, cov, assert_chk):
    """T6: Push N words, pop them — verify order and value (FIFO)."""
    dut._log.info("T6: Data integrity")
    pattern = [0x12345678, 0xDEADBEEF, 0xCAFEBABE, 0x0BADF00D,
               0xFEEDFACE, 0xAAAA5555, 0x0000FFFF, 0x11112222]
    for v in pattern:
        dut.wr_en.value = 1
        dut.wr_data.value = v
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    # Pop and check — one at a time so we read after NBA settles
    for i, expected in enumerate(pattern):
        dut.rd_en.value = 1
        await RisingEdge(dut.clk)
        dut.rd_en.value = 0
        actual = await rd_after_edge(dut.rd_data)
        assert_chk.check(f"data_integrity_{i}", actual == expected,
                         f"idx={i} expected={expected:#010x} actual={actual:#010x}")
        sb.add_expected(expected); sb.add_actual(actual)
        await RisingEdge(dut.clk)


async def test_simultaneous_push_pop(dut, sb, cov, assert_chk):
    """T7: Simultaneous push+pop — count stays same (overflow/underflow from prior tests are sticky)."""
    dut._log.info("T7: Simultaneous push+pop")
    # Pre-fill with 4 entries (FIFO is currently empty after T6)
    for i in range(4):
        dut.wr_en.value = 1
        dut.wr_data.value = 0xB000 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    dc0 = int(dut.data_count.value)
    # Now do simultaneous push+pop for 8 cycles
    for i in range(8):
        dut.wr_en.value = 1
        dut.rd_en.value = 1
        dut.wr_data.value = 0xC000 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    dc_after = int(dut.data_count.value)
    # Started with 4, did 8 push+8 pop → still 4
    assert_chk.check("simul_count_stable", dc_after == 4,
                     f"data_count after simultaneous={dc_after} (expected 4, before={dc0})")
    sb.add_expected(4); sb.add_actual(dc_after)
    # Note: we don't check overflow/underflow here — they're sticky from T3/T5
    # Drain remaining
    await drain_all(dut)


async def test_wrap_around(dut, sb, cov, assert_chk):
    """T8: Wrap-around — push+pop DEPTH+4 times, verify pointers wrap."""
    dut._log.info("T8: Wrap-around")
    # FIFO should be empty after T7's drain
    # Run push+pop simultaneously to wrap the pointers
    for i in range(DEPTH + 8):
        dut.wr_en.value = 1
        dut.rd_en.value = 1
        dut.wr_data.value = 0xD000 + (i & 0xFF)
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    f = int(dut.full.value)
    dc = int(dut.data_count.value)
    assert_chk.check("wrap_no_full", f == 0, f"full={f} (expected 0)")
    # When starting empty, simultaneous push+pop: first pop is suppressed (empty),
    # so net +1 entry after first cycle. Then balanced. So dc should be 1.
    assert_chk.check("wrap_count_le_1", dc <= 1, f"data_count={dc} (expected 0 or 1)")
    sb.add_expected(0); sb.add_actual(f)


async def test_flush(dut, sb, cov, assert_chk):
    """T9: Flush — clears pointers and count, but NOT overflow/underflow."""
    dut._log.info("T9: Flush")
    # Drain first to ensure known state
    await drain_all(dut)
    # Pre-fill 8 entries
    for i in range(8):
        dut.wr_en.value = 1
        dut.wr_data.value = 0xE000 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    dc_before = int(dut.data_count.value)
    assert_chk.check("flush_pre_filled", dc_before == 8, f"before flush count={dc_before}")
    # Flush
    dut.flush.value = 1
    await RisingEdge(dut.clk)
    dut.flush.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    e = int(dut.empty.value)
    f = int(dut.full.value)
    dc = int(dut.data_count.value)
    assert_chk.check("flush_empty", e == 1, f"after flush empty={e}")
    assert_chk.check("flush_not_full", f == 0, f"after flush full={f}")
    assert_chk.check("flush_count_zero", dc == 0, f"after flush count={dc}")
    sb.add_expected(0); sb.add_actual(dc)


async def test_almost_full(dut, sb, cov, assert_chk):
    """T10: Almost-full threshold (AFULL_TH=12)."""
    dut._log.info("T10: Almost-full threshold")
    # Fill up to AFULL_TH-1 = 11, almost_full should be 0
    for i in range(AFULL_TH - 1):
        dut.wr_en.value = 1
        dut.wr_data.value = 0xF000 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    af = int(dut.almost_full.value)
    assert_chk.check("almost_full_below_th", af == 0,
                     f"count={AFULL_TH-1} almost_full={af} (expected 0)")
    # Push one more → count = AFULL_TH → almost_full=1
    dut.wr_en.value = 1
    dut.wr_data.value = 0xF100
    await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    af = int(dut.almost_full.value)
    assert_chk.check("almost_full_at_th", af == 1,
                     f"count={AFULL_TH} almost_full={af} (expected 1)")
    sb.add_expected(1); sb.add_actual(af)
    await drain_all(dut)


async def test_almost_empty(dut, sb, cov, assert_chk):
    """T11: Almost-empty threshold (AEMPTY_TH=1)."""
    dut._log.info("T11: Almost-empty threshold")
    await Timer(1, 'ns')
    ae = int(dut.almost_empty.value)
    assert_chk.check("almost_empty_at_0", ae == 1,
                     f"count=0 almost_empty={ae} (expected 1)")
    # Push 2 entries → count=2 → almost_empty=0
    for i in range(2):
        dut.wr_en.value = 1
        dut.wr_data.value = 0xF200 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    ae = int(dut.almost_empty.value)
    assert_chk.check("almost_empty_at_2", ae == 0,
                     f"count=2 almost_empty={ae} (expected 0)")
    # Pop one → count=1 → almost_empty=1
    dut.rd_en.value = 1
    await RisingEdge(dut.clk)
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    ae = int(dut.almost_empty.value)
    assert_chk.check("almost_empty_at_1", ae == 1,
                     f"count=1 almost_empty={ae} (expected 1)")
    sb.add_expected(1); sb.add_actual(ae)
    # Drain remaining
    await drain_all(dut)


async def test_reset_clears_sticky(dut, sb, cov, assert_chk):
    """T12: Reset clears sticky overflow/underflow flags."""
    dut._log.info("T12: Reset clears sticky flags")
    # Trigger overflow
    for i in range(DEPTH + 2):
        dut.wr_en.value = 1
        dut.wr_data.value = 0xAA00 + i
        await RisingEdge(dut.clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    ovf = int(dut.overflow.value)
    assert_chk.check("sticky_overflow_set", ovf == 1, f"overflow={ovf}")
    # Reset
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.wr_en.value = 0
    dut.rd_en.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, 'ns')
    ovf = int(dut.overflow.value)
    unf = int(dut.underflow.value)
    dc = int(dut.data_count.value)
    assert_chk.check("reset_clears_overflow", ovf == 0, f"after reset overflow={ovf}")
    assert_chk.check("reset_clears_underflow", unf == 0, f"after reset underflow={unf}")
    assert_chk.check("reset_clears_count", dc == 0, f"after reset count={dc}")
    sb.add_expected(0); sb.add_actual(ovf)


async def test_random_operations(dut, gen, sb, cov, assert_chk, num=30):
    """T13: Randomized push/pop with integrity check."""
    dut._log.info(f"T13: Random operations ({num} iterations)")
    expected_queue = []
    for i in range(num):
        dc = int(dut.data_count.value)
        op = gen.rng.choice(['push', 'pop', 'push', 'pop', 'idle'])  # bias toward push/pop
        if op == 'push' and dc < DEPTH:
            v = gen.gen_data_word()
            dut.wr_en.value = 1
            dut.wr_data.value = v
            await RisingEdge(dut.clk)
            dut.wr_en.value = 0
            await RisingEdge(dut.clk)
            expected_queue.append(v)
            await Timer(1, 'ns')
        elif op == 'pop' and dc > 0 and expected_queue:
            dut.rd_en.value = 1
            await RisingEdge(dut.clk)
            dut.rd_en.value = 0
            actual = await rd_after_edge(dut.rd_data)
            await RisingEdge(dut.clk)
            exp = expected_queue.pop(0)
            assert_chk.check(f"rand_{i}_pop", actual == exp,
                             f"rand pop expected={exp:#010x} actual={actual:#010x}")
            sb.add_expected(exp); sb.add_actual(actual)
        else:
            await RisingEdge(dut.clk)
    # Drain whatever's left
    while expected_queue:
        dut.rd_en.value = 1
        await RisingEdge(dut.clk)
        dut.rd_en.value = 0
        actual = await rd_after_edge(dut.rd_data)
        await RisingEdge(dut.clk)
        exp = expected_queue.pop(0)
        assert_chk.check(f"rand_drain", actual == exp,
                         f"drain expected={exp:#010x} actual={actual:#010x}")
        sb.add_expected(exp); sb.add_actual(actual)


@cocotb.test(timeout_time=200000, timeout_unit='ns')
async def main_test(dut):
    """Main FIFO test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.wr_en.value = 0
    dut.rd_en.value = 0
    dut.wr_data.value = 0
    dut.flush.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('fifo')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('fifo')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb FIFO Testbench")
    dut._log.info("=" * 60)

    await test_reset_clears(dut, sb, cov, assert_chk)
    await test_fill_to_depth(dut, sb, cov, assert_chk)
    await test_overflow(dut, sb, cov, assert_chk)
    await test_drain_to_empty(dut, sb, cov, assert_chk)
    await test_underflow(dut, sb, cov, assert_chk)
    await test_data_integrity(dut, sb, cov, assert_chk)
    await test_simultaneous_push_pop(dut, sb, cov, assert_chk)
    await test_wrap_around(dut, sb, cov, assert_chk)
    await test_flush(dut, sb, cov, assert_chk)
    await test_almost_full(dut, sb, cov, assert_chk)
    await test_almost_empty(dut, sb, cov, assert_chk)
    await test_reset_clears_sticky(dut, sb, cov, assert_chk)
    await test_random_operations(dut, gen, sb, cov, assert_chk, 30)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
