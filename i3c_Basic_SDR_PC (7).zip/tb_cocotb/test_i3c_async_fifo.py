"""
test_i3c_async_fifo.py — Cocotb testbench for i3c_async_fifo (CDC async FIFO)
Tests: basic CDC, fill to full, drain to empty, simultaneous wr/rd, data
       integrity across CDC, reset mid-operation, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

Default parameters: WIDTH=8, DEPTH=16.

Two clocks: wr_clk (10ns period) and rd_clk (14ns period — different to stress CDC).
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer, First, Event
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker

DEPTH = 16


def full_cov(v):
    pass
CoverPoint("afifo.full", bins=[0, 1])(full_cov)

def empty_cov(v):
    pass
CoverPoint("afifo.empty", bins=[0, 1])(empty_cov)


async def settle():
    await Timer(1, 'ns')


async def wr_push(dut, data):
    """Push one byte on wr_clk domain. Assumes not full."""
    dut.wr_en.value = 1
    dut.wr_data.value = data
    await RisingEdge(dut.wr_clk)
    dut.wr_en.value = 0
    await RisingEdge(dut.wr_clk)


async def rd_pop(dut):
    """Pop one byte on rd_clk domain. Returns rd_data.

    The async FIFO has a COMBINATIONAL read: rd_data = mem[rd_ptr].
    So we read rd_data BEFORE the rising edge that advances rd_ptr.
    """
    await settle()
    val = int(dut.rd_data.value)
    dut.rd_en.value = 1
    await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    await RisingEdge(dut.rd_clk)
    return val


async def test_reset_state(dut, sb, cov, assert_chk):
    """T1: After reset, wr_full=0, rd_empty=1."""
    dut._log.info("T1: Reset state")
    await RisingEdge(dut.wr_clk)
    await RisingEdge(dut.rd_clk)
    await settle()
    wf = int(dut.wr_full.value)
    re = int(dut.rd_empty.value)
    full_cov(wf); empty_cov(re)
    assert_chk.check("rst_not_full", wf == 0, f"wr_full={wf}")
    assert_chk.check("rst_empty", re == 1, f"rd_empty={re}")
    sb.add_expected(0); sb.add_actual(wf)
    sb.add_expected(1); sb.add_actual(re)


async def test_basic_cdc(dut, sb, cov, assert_chk):
    """T2: Push one byte on wr_clk, pop on rd_clk — data crosses CDC."""
    dut._log.info("T2: Basic CDC")
    await wr_push(dut, 0xA5)
    # Wait a few rd_clk cycles for CDC sync
    for _ in range(5):
        await RisingEdge(dut.rd_clk)
    await settle()
    re = int(dut.rd_empty.value)
    assert_chk.check("cdc_not_empty", re == 0, f"rd_empty={re} (expected 0)")
    val = await rd_pop(dut)
    assert_chk.check("cdc_data", val == 0xA5, f"val={val:#x} (expected 0xA5)")
    sb.add_expected(0xA5); sb.add_actual(val)


async def test_fill_to_full(dut, sb, cov, assert_chk):
    """T3: Fill FIFO to full on wr_clk side."""
    dut._log.info("T3: Fill to full")
    # Push DEPTH bytes
    for i in range(DEPTH):
        dut.wr_en.value = 1
        dut.wr_data.value = 0x10 + i
        await RisingEdge(dut.wr_clk)
    dut.wr_en.value = 0
    # Wait for CDC to sync
    for _ in range(5):
        await RisingEdge(dut.wr_clk)
    await settle()
    wf = int(dut.wr_full.value)
    full_cov(wf)
    assert_chk.check("full_after_fill", wf == 1, f"wr_full={wf} (expected 1)")
    sb.add_expected(1); sb.add_actual(wf)
    # Drain
    for _ in range(DEPTH):
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    for _ in range(3):
        await RisingEdge(dut.rd_clk)


async def test_drain_to_empty(dut, sb, cov, assert_chk):
    """T4: Drain FIFO to empty on rd_clk side."""
    dut._log.info("T4: Drain to empty")
    # Push a few bytes
    for i in range(4):
        await wr_push(dut, 0x20 + i)
    # Wait for CDC sync
    for _ in range(5):
        await RisingEdge(dut.rd_clk)
    # Drain
    for _ in range(4):
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    for _ in range(5):
        await RisingEdge(dut.rd_clk)
    await settle()
    re = int(dut.rd_empty.value)
    empty_cov(re)
    assert_chk.check("empty_after_drain", re == 1, f"rd_empty={re} (expected 1)")
    sb.add_expected(1); sb.add_actual(re)


async def test_data_integrity(dut, sb, cov, assert_chk):
    """T5: Push N bytes, pop them — verify order and value across CDC."""
    dut._log.info("T5: Data integrity across CDC")
    pattern = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]
    for v in pattern:
        await wr_push(dut, v)
    # Wait for CDC sync
    for _ in range(5):
        await RisingEdge(dut.rd_clk)
    for i, expected in enumerate(pattern):
        # Read rd_data BEFORE popping (combinational read)
        await settle()
        actual = int(dut.rd_data.value)
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
        dut.rd_en.value = 0
        assert_chk.check(f"di_{i}", actual == expected,
                         f"idx={i} expected={expected:#x} actual={actual:#x}")
        sb.add_expected(expected); sb.add_actual(actual)
        await RisingEdge(dut.rd_clk)


async def test_simultaneous_wr_rd(dut, sb, cov, assert_chk):
    """T6: Simultaneous wr on wr_clk and rd on rd_clk — no deadlock."""
    dut._log.info("T6: Simultaneous wr/rd")
    # Pre-fill 4 entries
    for i in range(4):
        await wr_push(dut, 0x40 + i)
    for _ in range(5):
        await RisingEdge(dut.rd_clk)
    # Now do simultaneous push/pop for several cycles
    for i in range(8):
        dut.wr_en.value = 1
        dut.wr_data.value = 0x50 + i
        dut.rd_en.value = 1
        # Advance both clocks — since they're different periods, we need to
        # be careful. Just advance wr_clk and let rd_clk advance naturally.
        await RisingEdge(dut.wr_clk)
    dut.wr_en.value = 0
    dut.rd_en.value = 0
    # Settle
    for _ in range(10):
        await RisingEdge(dut.wr_clk)
        await RisingEdge(dut.rd_clk)
    wf = int(dut.wr_full.value)
    re = int(dut.rd_empty.value)
    assert_chk.check("simul_no_full", wf == 0, f"wr_full={wf}")
    assert_chk.check("simul_not_both", not (wf == 0 and re == 1 and True), "FIFO state valid")
    sb.add_expected(0); sb.add_actual(wf)
    # Drain remaining
    while int(dut.rd_empty.value) == 0:
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    for _ in range(3):
        await RisingEdge(dut.rd_clk)


async def test_reset_mid_operation(dut, sb, cov, assert_chk):
    """T7: Assert reset mid-operation — FIFO clears."""
    dut._log.info("T7: Reset mid-operation")
    # Push some data
    for i in range(8):
        await wr_push(dut, 0x80 + i)
    # Assert both resets
    dut.rst_n.value = 0
    dut.rst_n.value = 0
    await RisingEdge(dut.wr_clk)
    await RisingEdge(dut.rd_clk)
    await settle()
    wf = int(dut.wr_full.value)
    re = int(dut.rd_empty.value)
    assert_chk.check("reset_full_clears", wf == 0, f"wr_full={wf} after reset")
    assert_chk.check("reset_empty_sets", re == 1, f"rd_empty={re} after reset")
    sb.add_expected(0); sb.add_actual(wf)
    sb.add_expected(1); sb.add_actual(re)
    # Deassert resets
    dut.rst_n.value = 1
    dut.rst_n.value = 1
    for _ in range(5):
        await RisingEdge(dut.wr_clk)
        await RisingEdge(dut.rd_clk)


async def test_wr_when_full(dut, sb, cov, assert_chk):
    """T8: Write when full — wr_full stays 1, write dropped."""
    dut._log.info("T8: Write when full")
    # Fill to full
    for i in range(DEPTH):
        dut.wr_en.value = 1
        dut.wr_data.value = 0x60 + i
        await RisingEdge(dut.wr_clk)
    dut.wr_en.value = 0
    for _ in range(5):
        await RisingEdge(dut.wr_clk)
    await settle()
    wf = int(dut.wr_full.value)
    assert_chk.check("full_before_extra_wr", wf == 1, f"wr_full={wf}")
    # Try to write one more — should be dropped
    dut.wr_en.value = 1
    dut.wr_data.value = 0xFF
    await RisingEdge(dut.wr_clk)
    dut.wr_en.value = 0
    for _ in range(3):
        await RisingEdge(dut.wr_clk)
    await settle()
    wf = int(dut.wr_full.value)
    assert_chk.check("full_stays_after_drop", wf == 1, f"wr_full={wf} (expected 1)")
    sb.add_expected(1); sb.add_actual(wf)
    # Drain
    for _ in range(DEPTH):
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    for _ in range(3):
        await RisingEdge(dut.rd_clk)


async def test_rd_when_empty(dut, sb, cov, assert_chk):
    """T9: Read when empty — rd_empty stays 1, rd_data undefined (but no crash)."""
    dut._log.info("T9: Read when empty")
    # FIFO should be empty after T8's drain
    for _ in range(3):
        await RisingEdge(dut.rd_clk)
    await settle()
    re = int(dut.rd_empty.value)
    assert_chk.check("empty_before_extra_rd", re == 1, f"rd_empty={re}")
    # Try to read — should not crash, rd_empty stays 1
    dut.rd_en.value = 1
    await RisingEdge(dut.rd_clk)
    dut.rd_en.value = 0
    for _ in range(3):
        await RisingEdge(dut.rd_clk)
    await settle()
    re = int(dut.rd_empty.value)
    assert_chk.check("empty_stays_after_rd", re == 1, f"rd_empty={re} (expected 1)")
    sb.add_expected(1); sb.add_actual(re)


async def test_random_traffic(dut, gen, sb, cov, assert_chk, num=20):
    """T10: Random push/pop with integrity check."""
    dut._log.info(f"T10: Random traffic ({num})")
    expected_q = []
    for i in range(num):
        op = gen.rng.choice(['push', 'pop', 'push', 'pop'])
        if op == 'push':
            v = gen.gen_data_byte()
            # Wait if full
            for _ in range(20):
                await settle()
                if int(dut.wr_full.value) == 0:
                    break
                await RisingEdge(dut.wr_clk)
            if int(dut.wr_full.value) == 1:
                continue  # skip
            dut.wr_en.value = 1
            dut.wr_data.value = v
            await RisingEdge(dut.wr_clk)
            dut.wr_en.value = 0
            expected_q.append(v)
            # Give CDC time
            await RisingEdge(dut.rd_clk)
        else:
            # Wait if empty
            for _ in range(20):
                await settle()
                if int(dut.rd_empty.value) == 0:
                    break
                await RisingEdge(dut.rd_clk)
            if int(dut.rd_empty.value) == 1 or not expected_q:
                continue
            # Read rd_data BEFORE popping (combinational read)
            await settle()
            actual = int(dut.rd_data.value)
            dut.rd_en.value = 1
            await RisingEdge(dut.rd_clk)
            dut.rd_en.value = 0
            exp = expected_q.pop(0)
            assert_chk.check(f"rand_{i}_pop", actual == exp,
                             f"rand pop expected={exp:#x} actual={actual:#x}")
            sb.add_expected(exp); sb.add_actual(actual)
            await RisingEdge(dut.rd_clk)
    # Drain remaining
    while expected_q:
        for _ in range(20):
            await settle()
            if int(dut.rd_empty.value) == 0:
                break
            await RisingEdge(dut.rd_clk)
        if int(dut.rd_empty.value) == 1:
            break
        # Read rd_data BEFORE popping (combinational read)
        await settle()
        actual = int(dut.rd_data.value)
        dut.rd_en.value = 1
        await RisingEdge(dut.rd_clk)
        dut.rd_en.value = 0
        exp = expected_q.pop(0)
        assert_chk.check(f"rand_drain", actual == exp,
                         f"drain expected={exp:#x} actual={actual:#x}")
        sb.add_expected(exp); sb.add_actual(actual)
        await RisingEdge(dut.rd_clk)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main async FIFO test — all test cases."""
    # Two independent clocks: wr_clk (10ns) and rd_clk (14ns)
    wr_clock = cocotb.start_soon(Clock(dut.wr_clk, 10, units='ns').start())
    rd_clock = cocotb.start_soon(Clock(dut.rd_clk, 14, units='ns').start())

    # Reset both domains
    dut.rst_n.value = 0
    dut.rst_n.value = 0
    dut.wr_en.value = 0
    dut.wr_data.value = 0
    dut.rd_en.value = 0
    for _ in range(5):
        await RisingEdge(dut.wr_clk)
        await RisingEdge(dut.rd_clk)
    dut.rst_n.value = 1
    dut.rst_n.value = 1
    for _ in range(3):
        await RisingEdge(dut.wr_clk)
        await RisingEdge(dut.rd_clk)

    sb = Scoreboard('afifo')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('afifo')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Async FIFO Testbench")
    dut._log.info("=" * 60)

    await test_reset_state(dut, sb, cov, assert_chk)
    await test_basic_cdc(dut, sb, cov, assert_chk)
    await test_fill_to_full(dut, sb, cov, assert_chk)
    await test_drain_to_empty(dut, sb, cov, assert_chk)
    await test_data_integrity(dut, sb, cov, assert_chk)
    await test_simultaneous_wr_rd(dut, sb, cov, assert_chk)
    await test_reset_mid_operation(dut, sb, cov, assert_chk)
    await test_wr_when_full(dut, sb, cov, assert_chk)
    await test_rd_when_empty(dut, sb, cov, assert_chk)
    await test_random_traffic(dut, gen, sb, cov, assert_chk, 20)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
