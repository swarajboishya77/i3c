"""
test_i3c_power_controller.py — Cocotb testbench for i3c_power_controller
Tests: power-down request, power-up sequence, isolation control, wake signal,
       bus-idle gating, reset state, full cycle, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

Power FSM states:
  PWR_CORE_ON → PWR_WAIT_IDLE → PWR_ISO_CLOSE → PWR_SWITCH_OPEN → PWR_CORE_OFF
  PWR_CORE_OFF → (wake_irq) → PWR_SWITCH_CLOSE → PWR_CORE_RESET → PWR_CORE_ON
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def state_cov(s):
    pass
CoverPoint("pwr.state", bins=[0, 1, 2, 3, 4, 5, 6, 7])(state_cov)

def off_cov(o):
    pass
CoverPoint("pwr.off", bins=[0, 1])(off_cov)


async def settle():
    await Timer(1, 'ns')


async def get_state(dut):
    """Read FSM state via internal signal (may not exist; use outputs)."""
    # We infer state from outputs:
    #   pd_core_sw_en, pd_core_iso_en, pd_core_rst, pd_core_off
    await settle()
    sw = int(dut.pd_core_sw_en.value)
    iso = int(dut.pd_core_iso_en.value)
    rst = int(dut.pd_core_rst.value)
    off = int(dut.pd_core_off.value)
    return sw, iso, rst, off


async def test_reset_state(dut, sb, cov, assert_chk):
    """T1: After reset, PWR_CORE_ON: sw_en=1, iso_en=0, rst=0, off=0."""
    dut._log.info("T1: Reset state (CORE_ON)")
    await RisingEdge(dut.clk_aon)
    await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off)
    assert_chk.check("rst_sw_en", sw == 1, f"sw_en={sw} (expected 1)")
    assert_chk.check("rst_iso_en", iso == 0, f"iso_en={iso} (expected 0)")
    assert_chk.check("rst_rst", rst == 0, f"rst={rst} (expected 0)")
    assert_chk.check("rst_off", off == 0, f"off={off} (expected 0)")
    sb.add_expected(1); sb.add_actual(sw)
    sb.add_expected(0); sb.add_actual(off)


async def test_power_down_request(dut, sb, cov, assert_chk):
    """T2: Power-down request with bus idle — FSM transitions to OFF."""
    dut._log.info("T2: Power-down request")
    # Set bus_idle=1, pd_core_req=1
    dut.bus_idle.value = 1
    dut.pd_core_req.value = 1
    dut.wake_irq.value = 0
    dut.pd_core_ack.value = 0
    # Wait for FSM to transition through WAIT_IDLE → ISO_CLOSE → SWITCH_OPEN → CORE_OFF
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
        await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off)
    assert_chk.check("pd_off", off == 1, f"off={off} (expected 1)")
    assert_chk.check("pd_sw_en_off", sw == 0, f"sw_en={sw} (expected 0 — switch open)")
    assert_chk.check("pd_iso_en_on", iso == 1, f"iso_en={iso} (expected 1 — isolation closed)")
    assert_chk.check("pd_rst_low", rst == 0, f"rst={rst} (expected 0)")
    sb.add_expected(1); sb.add_actual(off)
    sb.add_expected(0); sb.add_actual(sw)


async def test_power_down_blocked_by_bus_busy(dut, sb, cov, assert_chk):
    """T3: Power-down request with bus NOT idle — FSM stays in CORE_ON."""
    dut._log.info("T3: Power-down blocked by busy bus")
    # First, return to CORE_ON via wake
    dut.wake_irq.value = 1
    dut.pd_core_req.value = 0
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    dut.pd_core_ack.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    dut.pd_core_ack.value = 0
    await settle()
    # Now request power-down with bus busy
    dut.bus_idle.value = 0  # bus busy
    dut.pd_core_req.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off)
    assert_chk.check("pd_blocked_off", off == 0, f"off={off} (expected 0 — blocked)")
    assert_chk.check("pd_blocked_sw", sw == 1, f"sw_en={sw} (expected 1 — still powered)")
    sb.add_expected(0); sb.add_actual(off)
    sb.add_expected(1); sb.add_actual(sw)
    # Clean up
    dut.pd_core_req.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk_aon)


async def test_wake_signal(dut, sb, cov, assert_chk):
    """T4: Wake from CORE_OFF — wake_to_host asserts, FSM returns to CORE_ON."""
    dut._log.info("T4: Wake signal")
    # Power down first
    dut.bus_idle.value = 1
    dut.pd_core_req.value = 1
    dut.wake_irq.value = 0
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    await settle()
    off = int(dut.pd_core_off.value)
    assert_chk.check("wake_pre_off", off == 1, f"pre-wake off={off}")
    # Clear pd_core_req BEFORE waking (otherwise FSM re-powers-down immediately)
    dut.pd_core_req.value = 0
    # Trigger wake
    dut.wake_irq.value = 1
    # BUG-R4-041 FIX: wake_irq goes through 2-flop synchronizer, need more cycles
    for _ in range(6):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # Check wake_to_host asserted
    await settle()
    wth = int(dut.wake_to_host.value)
    assert_chk.check("wake_to_host", wth == 1, f"wake_to_host={wth} (expected 1)")
    sb.add_expected(1); sb.add_actual(wth)
    # Wait for FSM to return to CORE_ON (SWITCH_CLOSE → CORE_RESET → CORE_ON)
    # RST_DURATION = 8 cycles
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
    await settle()
    sw, iso, rst, off = await get_state(dut)
    off_cov(off)
    assert_chk.check("wake_back_on", off == 0, f"off={off} (expected 0 — back on)")
    assert_chk.check("wake_sw_en", sw == 1, f"sw_en={sw} (expected 1)")
    assert_chk.check("wake_iso_en", iso == 0, f"iso_en={iso} (expected 0)")
    assert_chk.check("wake_rst", rst == 0, f"rst={rst} (expected 0)")
    sb.add_expected(0); sb.add_actual(off)


async def test_isolation_control(dut, sb, cov, assert_chk):
    """T5: Isolation control — iso_en asserts during power-down."""
    dut._log.info("T5: Isolation control")
    # Make sure we're in CORE_ON with iso_en=0 (clear pd_core_req from T4)
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    await settle()
    # Power down and check iso_en asserts at the right time
    dut.bus_idle.value = 1
    dut.pd_core_req.value = 1
    # BUG-R4-041 FIX: pd_core_req goes through 2-flop synchronizer, need more cycles
    # Cycle 1-2: synchronizer latency
    # Cycle 3: WAIT_IDLE (iso_en still 0)
    # Cycle 4: ISO_CLOSE (iso_en=1)
    # Cycle 5: SWITCH_OPEN (iso_en=1)
    # Cycle 6: CORE_OFF (iso_en=1)
    iso_vals = []
    for _ in range(8):
        await RisingEdge(dut.clk_aon)
        await settle()
        iso_vals.append(int(dut.pd_core_iso_en.value))
    iso_1 = iso_vals[2] if len(iso_vals) > 2 else 0  # WAIT_IDLE
    iso_2 = iso_vals[3] if len(iso_vals) > 3 else 0  # ISO_CLOSE
    iso_3 = iso_vals[4] if len(iso_vals) > 4 else 0  # SWITCH_OPEN
    assert_chk.check("iso_before_close", iso_1 == 0, f"iso at WAIT_IDLE={iso_1} (expected 0)")
    assert_chk.check("iso_closes", iso_2 == 1 or iso_3 == 1,
                     f"iso after ISO_CLOSE/SWITCH_OPEN={iso_2},{iso_3} (expected 1)")
    sb.add_expected(0); sb.add_actual(iso_1)
    # Wake back up (clear req first)
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 1
    for _ in range(2):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    for _ in range(20):
        await RisingEdge(dut.clk_aon)


async def test_full_cycle(dut, sb, cov, assert_chk):
    """T6: Full power-down + power-up cycle."""
    dut._log.info("T6: Full cycle")
    # Ensure we're in CORE_ON
    dut.pd_core_req.value = 0
    dut.bus_idle.value = 1
    dut.wake_irq.value = 0
    dut.pd_core_ack.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    # Verify ON
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("cycle_start_on", off == 0, f"start off={off}")
    # Power down
    dut.pd_core_req.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("cycle_off", off == 1, f"after pd off={off}")
    assert_chk.check("cycle_iso", iso == 1, f"after pd iso={iso}")
    # Wake (clear req first to prevent immediate re-powerdown)
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 1
    for _ in range(2):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    # Wait for power-up (SWITCH_CLOSE → CORE_RESET (8 cycles) → CORE_ON)
    iso_seen_during_reset = False
    rst_seen = False
    for _ in range(20):
        await RisingEdge(dut.clk_aon)
        await settle()
        if int(dut.pd_core_rst.value) == 1:
            rst_seen = True
    sw, iso, rst, off = await get_state(dut)
    assert_chk.check("cycle_back_on", off == 0, f"after wake off={off}")
    assert_chk.check("cycle_sw_on", sw == 1, f"after wake sw={sw}")
    assert_chk.check("cycle_iso_open", iso == 0, f"after wake iso={iso}")
    assert_chk.check("cycle_rst_seen", rst_seen, "rst asserted during power-up")
    sb.add_expected(0); sb.add_actual(off)


async def test_wake_to_host_clears(dut, sb, cov, assert_chk):
    """T7: wake_to_host clears on pd_core_ack."""
    dut._log.info("T7: wake_to_host clears on ack")
    # Power down (clear req from T6 first)
    dut.pd_core_req.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk_aon)
    dut.bus_idle.value = 1
    dut.pd_core_req.value = 1
    for _ in range(10):
        await RisingEdge(dut.clk_aon)
    # Wake (clear req first)
    dut.pd_core_req.value = 0
    dut.wake_irq.value = 1
    # BUG-R4-041 FIX: 2-flop synchronizer needs more cycles
    for _ in range(6):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    await settle()
    wth = int(dut.wake_to_host.value)
    assert_chk.check("wth_set", wth == 1, f"wth={wth}")
    # Send ack — should clear wake_to_host (in PWR_CORE_RESET state)
    dut.pd_core_ack.value = 1
    for _ in range(15):
        await RisingEdge(dut.clk_aon)
    dut.pd_core_ack.value = 0
    await settle()
    wth = int(dut.wake_to_host.value)
    assert_chk.check("wth_cleared", wth == 0, f"wth after ack={wth}")
    sb.add_expected(0); sb.add_actual(wth)
    dut.pd_core_req.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk_aon)


async def test_wake_while_on(dut, sb, cov, assert_chk):
    """T8: Wake arrives while CORE_ON — wake_to_host asserts (edge case)."""
    dut._log.info("T8: Wake while ON")
    # Ensure CORE_ON
    dut.pd_core_req.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    # Send wake
    dut.wake_irq.value = 1
    # BUG-R4-041 FIX: 2-flop synchronizer needs more cycles
    for _ in range(5):
        await RisingEdge(dut.clk_aon)
    dut.wake_irq.value = 0
    await settle()
    wth = int(dut.wake_to_host.value)
    assert_chk.check("wake_while_on", wth == 1, f"wth={wth} (expected 1 — wake forwarded)")
    sb.add_expected(1); sb.add_actual(wth)


async def test_random_sequence(dut, gen, sb, cov, assert_chk, num=8):
    """T9: Randomized power-down/up sequences."""
    dut._log.info(f"T9: Random sequences ({num})")
    for i in range(num):
        # Ensure starting from CORE_ON — clear all inputs and wake if needed
        dut.pd_core_req.value = 0
        dut.wake_irq.value = 0
        dut.pd_core_ack.value = 0
        dut.bus_idle.value = 1
        # If currently OFF, wake up first
        await settle()
        if int(dut.pd_core_off.value) == 1:
            dut.wake_irq.value = 1
            for _ in range(2):
                await RisingEdge(dut.clk_aon)
            dut.wake_irq.value = 0
            for _ in range(15):
                await RisingEdge(dut.clk_aon)
        else:
            for _ in range(5):
                await RisingEdge(dut.clk_aon)
        # Confirm CORE_ON
        await settle()
        if int(dut.pd_core_off.value) != 0:
            # Skip if we couldn't reach CORE_ON
            continue
        # Random bus_idle — set BEFORE pd_core_req to avoid race
        bus_idle = gen.rng.randint(0, 1)
        dut.bus_idle.value = bus_idle
        await RisingEdge(dut.clk_aon)
        # Now request power-down
        dut.pd_core_req.value = 1
        for _ in range(10):
            await RisingEdge(dut.clk_aon)
        await settle()
        off = int(dut.pd_core_off.value)
        if bus_idle:
            assert_chk.check(f"rand_{i}_off", off == 1,
                             f"iter={i} bus_idle={bus_idle} off={off} (expected 1)")
        else:
            assert_chk.check(f"rand_{i}_blocked", off == 0,
                             f"iter={i} bus_idle={bus_idle} off={off} (expected 0)")
        sb.add_expected(1 if bus_idle else 0); sb.add_actual(off)
        off_cov(off)
        # If off, wake up (clear req first)
        if off == 1:
            dut.pd_core_req.value = 0
            dut.wake_irq.value = 1
            for _ in range(2):
                await RisingEdge(dut.clk_aon)
            dut.wake_irq.value = 0
            dut.pd_core_ack.value = 1
            for _ in range(15):
                await RisingEdge(dut.clk_aon)
            dut.pd_core_ack.value = 0


@cocotb.test(timeout_time=500000, timeout_unit='ns')
async def main_test(dut):
    """Main power controller test — all test cases."""
    cr = ClockResetAgent(dut, 'clk_aon', 'rst_aon_n', 50, 'ns')  # slow AON clock
    await cr.start_clock()
    await cr.reset(5)

    dut.pd_core_req.value = 0
    dut.pd_core_ack.value = 0
    dut.wake_irq.value = 0
    dut.bus_idle.value = 1
    await RisingEdge(dut.clk_aon)

    sb = Scoreboard('pwr')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('pwr')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Power Controller Testbench")
    dut._log.info("=" * 60)

    await test_reset_state(dut, sb, cov, assert_chk)
    await test_power_down_request(dut, sb, cov, assert_chk)
    await test_power_down_blocked_by_bus_busy(dut, sb, cov, assert_chk)
    await test_wake_signal(dut, sb, cov, assert_chk)
    await test_isolation_control(dut, sb, cov, assert_chk)
    await test_full_cycle(dut, sb, cov, assert_chk)
    await test_wake_to_host_clears(dut, sb, cov, assert_chk)
    await test_wake_while_on(dut, sb, cov, assert_chk)
    await test_random_sequence(dut, gen, sb, cov, assert_chk, 8)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
