"""
test_i3c_hotjoin_handler.py — Cocotb testbench for i3c_hotjoin_handler
Detection: SDA falling while SCL high, controller_idle, bus_idle, !ibi_active.
Tests: disabled, detection, clear, auto-DAA trigger, suppressed when busy,
       suppressed during IBI, SCL low = no detection.

NOTE: hj_detected is sticky (only cleared by external W1C register), so for
"no detection" tests we verify hj_pending (cleared via hj_clear input).
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def detected_cov(d):
    pass
CoverPoint("hj.detected", bins=[0, 1])(detected_cov)


async def clear_pending(dut):
    """Assert hj_clear for a few cycles to clear hj_pending and return FSM to IDLE."""
    dut.hj_clear.value = 1
    dut.hj_enable.value = 0
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    dut.controller_idle.value = 1
    dut.bus_idle.value = 1
    dut.ibi_active.value = 0
    for _ in range(4):
        await RisingEdge(dut.clk)
    dut.hj_clear.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)


async def setup_idle(dut):
    """Set bus idle state: SDA=1, SCL=1, controller_idle=1, bus_idle=1, ibi_active=0."""
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    dut.controller_idle.value = 1
    dut.bus_idle.value = 1
    dut.ibi_active.value = 0
    dut.hj_clear.value = 0
    # Wait a few cycles for sda_prev to register high
    for _ in range(3):
        await RisingEdge(dut.clk)


async def test_disabled(dut, sb, cov, assert_chk):
    """T1: hj_enable=0 — no detection even with SDA falling while SCL high."""
    dut._log.info("T1: Disabled")
    await clear_pending(dut)
    dut.hj_enable.value = 0
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    # Drive SDA low while SCL high
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    detected_cov(pend)
    assert_chk.check("disabled_no_detect",
                     pend == 0,
                     f"disabled: pending={pend} (expected 0)")
    sb.add_expected(0); sb.add_actual(pend)


async def test_detection(dut, sb, cov, assert_chk):
    """T2: HJ detection (manual mode — no auto DAA)."""
    dut._log.info("T2: Detection (manual mode)")
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    # BUG-R4-034 FIX: use NBA for sda_i to avoid Verilog race with posedge.
    await Timer(1, "ns")
    dut.sda_i.value = 0  # SDA falls while SCL=1 (HJ event)
    dut.scl_i.value = 1
    # Wait for detection: IDLE→DEBOUNCE(cnt 0→1)→DETECTED→DONE.
    # With DEBOUNCE_CYCLES=1, takes ~5 cycles. Wait 15 to be safe.
    # hj_pending is set on entering DEBOUNCE, cleared on reaching DONE.
    # Since manual mode (auto_daa=0) goes DETECTED→DONE immediately,
    # hj_pending may be cleared by the time we check. Check mid-detection instead.
    found_pending = False
    found_detected = False
    for _ in range(15):
        await RisingEdge(dut.clk)
        if int(dut.hj_pending.value) == 1:
            found_pending = True
        if int(dut.hj_detected.value) == 1:
            found_detected = True
    det = int(dut.hj_detected.value)
    pend = int(dut.hj_pending.value)
    trig = int(dut.hj_trigger_daa.value)
    detected_cov(det)
    assert_chk.check("detected",
                     found_detected and found_pending,
                     f"detection: detected={det} pending={pend} (expected 1,1)")
    assert_chk.check("no_trigger_manual",
                     trig == 0,
                     f"manual mode: trigger_daa={trig} (expected 0)")
    sb.add_expected(1); sb.add_actual(det)


async def test_clear(dut, sb, cov, assert_chk):
    """T3: hj_clear clears hj_pending."""
    dut._log.info("T3: Clear pending")
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    # Trigger detection
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    found_pending = False
    for _ in range(15):
        await RisingEdge(dut.clk)
        if int(dut.hj_pending.value) == 1:
            found_pending = True
    pend = int(dut.hj_pending.value)
    assert_chk.check("pre_clear_pending", found_pending, f"pre-clear pending={pend} (expected 1)")
    # Now assert hj_clear
    dut.hj_clear.value = 1
    await RisingEdge(dut.clk)
    dut.hj_clear.value = 0
    await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    assert_chk.check("cleared_pending", pend == 0, f"after clear: pending={pend} (expected 0)")
    sb.add_expected(0); sb.add_actual(pend)
    # hj_detected is cleared by hj_clear (TB convenience — in silicon, W1C register clears it)
    det = int(dut.hj_detected.value)
    assert_chk.check("detected_cleared", det == 0, f"detected after clear: {det} (expected 0)")


async def test_auto_daa_trigger(dut, sb, cov, assert_chk):
    """T4: Auto-DAA trigger — hj_trigger_daa should pulse."""
    dut._log.info("T4: Auto-DAA trigger")
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 1
    await setup_idle(dut)
    # Trigger detection
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    # Wait several cycles for FSM to progress through DETECTED -> TRIGGERING -> WAIT_DAA
    trig_seen = False
    for i in range(15):
        await RisingEdge(dut.clk)
        if int(dut.hj_trigger_daa.value) == 1:
            trig_seen = True
    det = int(dut.hj_detected.value)
    pend = int(dut.hj_pending.value)
    detected_cov(det)
    assert_chk.check("auto_daa_detected", det == 1, f"auto-DAA: detected={det} (expected 1)")
    assert_chk.check("auto_daa_trigger_pulsed", trig_seen, "auto-DAA: trigger_daa should pulse")
    # hj_pending should remain set until hj_clear
    assert_chk.check("auto_daa_pending", pend == 1, f"auto-DAA: pending={pend} (expected 1 until clear)")
    sb.add_expected(1); sb.add_actual(1 if trig_seen else 0)
    # Now clear
    dut.hj_clear.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.hj_clear.value = 0
    await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    assert_chk.check("auto_daa_cleared", pend == 0, f"after clear: pending={pend} (expected 0)")


async def test_suppressed_when_busy(dut, sb, cov, assert_chk):
    """T5: Detection suppressed when controller not idle or bus not idle."""
    dut._log.info("T5: Suppressed when busy")
    # Test 1: controller_idle=0
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    dut.controller_idle.value = 0  # controller busy
    dut.bus_idle.value = 1
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    detected_cov(pend)
    assert_chk.check("suppressed_ctrl_busy", pend == 0,
                     f"controller busy: pending={pend} (expected 0)")
    sb.add_expected(0); sb.add_actual(pend)
    # Test 2: bus_idle=0
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    dut.controller_idle.value = 1
    dut.bus_idle.value = 0  # bus busy
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    assert_chk.check("suppressed_bus_busy", pend == 0,
                     f"bus busy: pending={pend} (expected 0)")


async def test_suppressed_during_ibi(dut, sb, cov, assert_chk):
    """T6: Detection suppressed during IBI."""
    dut._log.info("T6: Suppressed during IBI")
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    dut.ibi_active.value = 1  # IBI in progress
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.sda_i.value = 0
    dut.scl_i.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    detected_cov(pend)
    assert_chk.check("suppressed_ibi", pend == 0,
                     f"IBI active: pending={pend} (expected 0)")
    sb.add_expected(0); sb.add_actual(pend)


async def test_scl_low_no_detection(dut, sb, cov, assert_chk):
    """T7: SDA falling while SCL low — no HJ detection."""
    dut._log.info("T7: SCL low = no detection")
    await clear_pending(dut)
    dut.hj_enable.value = 1
    dut.hj_auto_daa.value = 0
    await setup_idle(dut)
    # SDA falling while SCL low (not a START condition)
    dut.scl_i.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.sda_i.value = 0  # falling while SCL low
    for _ in range(3):
        await RisingEdge(dut.clk)
    pend = int(dut.hj_pending.value)
    detected_cov(pend)
    assert_chk.check("scl_low_no_detect", pend == 0,
                     f"SCL low: pending={pend} (expected 0)")
    sb.add_expected(0); sb.add_actual(pend)


async def test_random(dut, gen, sb, cov, assert_chk, num=15):
    """Randomized tests.
    NOTE: hj_detected is sticky (only cleared by W1C register outside this module),
    so we verify hj_pending instead (which can be cleared via hj_clear)."""
    dut._log.info(f"T8: Random tests ({num} iterations)")
    for i in range(num):
        # Start each iteration by clearing any pending state
        await clear_pending(dut)
        # Verify pending cleared
        pend = int(dut.hj_pending.value)
        if pend != 0:
            assert_chk.check(f"rand_{i}_clear_failed", False,
                             f"rand_{i}: pending={pend} after clear (expected 0) — skipping")
            continue
        # Random config
        en = gen.rng.randint(0, 1)
        auto = gen.rng.randint(0, 1)
        ctrl_idle = gen.rng.randint(0, 1)
        bus_idle = gen.rng.randint(0, 1)
        ibi = gen.rng.randint(0, 1)
        scl = gen.rng.choice([0, 1])
        dut.hj_enable.value = en
        dut.hj_auto_daa.value = auto
        dut.controller_idle.value = ctrl_idle
        dut.bus_idle.value = bus_idle
        dut.ibi_active.value = ibi
        dut.scl_i.value = 1
        dut.sda_i.value = 1
        for _ in range(3):
            await RisingEdge(dut.clk)
        # Now drive SDA low (falling edge)
        dut.sda_i.value = 0
        dut.scl_i.value = scl
        # Compute expected detection
        should_detect = (en and ctrl_idle and bus_idle and (not ibi) and scl == 1)
        for _ in range(5):
            await RisingEdge(dut.clk)
        pend = int(dut.hj_pending.value)
        if should_detect:
            assert_chk.check(f"rand_{i}_pending_set", pend == 1,
                             f"rand_{i}: en={en} ctrl={ctrl_idle} bus={bus_idle} ibi={ibi} scl={scl} pending={pend} (expected 1)")
        else:
            assert_chk.check(f"rand_{i}_pending_clear", pend == 0,
                             f"rand_{i}: en={en} ctrl={ctrl_idle} bus={bus_idle} ibi={ibi} scl={scl} pending={pend} (expected 0)")
        sb.add_expected(1 if should_detect else 0); sb.add_actual(pend)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main HotJoin handler test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.hj_enable.value = 0
    dut.hj_auto_daa.value = 0
    dut.controller_idle.value = 1
    dut.bus_idle.value = 1
    dut.sda_i.value = 1
    dut.scl_i.value = 1
    dut.hj_clear.value = 0
    dut.ibi_active.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('hj')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('hj')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb HotJoin Handler Testbench")
    dut._log.info("=" * 60)

    await test_disabled(dut, sb, cov, assert_chk)
    await test_detection(dut, sb, cov, assert_chk)
    await test_clear(dut, sb, cov, assert_chk)
    await test_auto_daa_trigger(dut, sb, cov, assert_chk)
    await test_suppressed_when_busy(dut, sb, cov, assert_chk)
    await test_suppressed_during_ibi(dut, sb, cov, assert_chk)
    await test_scl_low_no_detection(dut, sb, cov, assert_chk)
    await test_random(dut, gen, sb, cov, assert_chk, 15)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
