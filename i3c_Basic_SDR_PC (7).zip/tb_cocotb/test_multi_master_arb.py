"""
test_multi_master_arb.py — Multi-master arbitration via i3c_phy_mux
Module: i3c_phy_mux
Tests:
  - sel=00: Digital PHY (controller) drives SDA and SCL
  - sel=01: Target engine drives SDA only (SCL released)
  - sel=10: Bootstrap drives both SDA and SCL
  - sel=11: Reserved — all signals released (high-Z)
  - All 4 combos × all SDA/SCL input combinations
  - Pad readback broadcast to all 3 blocks
  - Mutual exclusion (only one source drives at a time)
  - Switching between sources dynamically
  - Randomized source/toggle tests
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def sel_cov(s):
    pass
CoverPoint("mux_all.sel", bins=[0, 1, 2, 3])(sel_cov)


async def settle():
    await Timer(1, 'ns')


async def check_mux(dut, sel, dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe,
                    tgt_sda_o, tgt_sda_oe,
                    boot_sda_o, boot_sda_oe, boot_scl_o, boot_scl_oe,
                    pad_sda_i, pad_scl_i,
                    sb, cov, assert_chk, name):
    """Set inputs, check outputs and readback."""
    dut.phy_mux_sel.value = sel
    dut.dphy_sda_o.value = dphy_sda_o
    dut.dphy_sda_oe.value = dphy_sda_oe
    dut.dphy_scl_o.value = dphy_scl_o
    dut.dphy_scl_oe.value = dphy_scl_oe
    dut.tgt_sda_o.value = tgt_sda_o
    dut.tgt_sda_oe.value = tgt_sda_oe
    dut.boot_sda_o.value = boot_sda_o
    dut.boot_sda_oe.value = boot_sda_oe
    dut.boot_scl_o.value = boot_scl_o
    dut.boot_scl_oe.value = boot_scl_oe
    dut.pad_sda_i.value = pad_sda_i
    dut.pad_scl_i.value = pad_scl_i
    await settle()
    sel_cov(sel)

    if sel == 0:
        exp_sda_o, exp_sda_oe = dphy_sda_o, dphy_sda_oe
        exp_scl_o, exp_scl_oe = dphy_scl_o, dphy_scl_oe
    elif sel == 1:
        exp_sda_o, exp_sda_oe = tgt_sda_o, tgt_sda_oe
        exp_scl_o, exp_scl_oe = 1, 0  # target never drives SCL
    elif sel == 2:
        exp_sda_o, exp_sda_oe = boot_sda_o, boot_sda_oe
        exp_scl_o, exp_scl_oe = boot_scl_o, boot_scl_oe
    else:  # sel == 3 (reserved)
        exp_sda_o, exp_sda_oe = 1, 0
        exp_scl_o, exp_scl_oe = 1, 0

    a_sda_o = int(dut.pad_sda_o.value)
    a_sda_oe = int(dut.pad_sda_oe.value)
    a_scl_o = int(dut.pad_scl_o.value)
    a_scl_oe = int(dut.pad_scl_oe.value)

    assert_chk.check(f"{name}_sda_o", a_sda_o == exp_sda_o,
                     f"sel={sel} pad_sda_o={a_sda_o} (exp {exp_sda_o})")
    assert_chk.check(f"{name}_sda_oe", a_sda_oe == exp_sda_oe,
                     f"sel={sel} pad_sda_oe={a_sda_oe} (exp {exp_sda_oe})")
    assert_chk.check(f"{name}_scl_o", a_scl_o == exp_scl_o,
                     f"sel={sel} pad_scl_o={a_scl_o} (exp {exp_scl_o})")
    assert_chk.check(f"{name}_scl_oe", a_scl_oe == exp_scl_oe,
                     f"sel={sel} pad_scl_oe={a_scl_oe} (exp {exp_scl_oe})")
    sb.add_expected(exp_sda_o); sb.add_actual(a_sda_o)
    sb.add_expected(exp_sda_oe); sb.add_actual(a_sda_oe)
    sb.add_expected(exp_scl_o); sb.add_actual(a_scl_o)
    sb.add_expected(exp_scl_oe); sb.add_actual(a_scl_oe)

    # Pad readback broadcast
    assert_chk.check(f"{name}_dphy_sda_i", int(dut.dphy_sda_i.value) == pad_sda_i,
                     f"dphy_sda_i={int(dut.dphy_sda_i.value)} exp={pad_sda_i}")
    assert_chk.check(f"{name}_dphy_scl_i", int(dut.dphy_scl_i.value) == pad_scl_i,
                     f"dphy_scl_i={int(dut.dphy_scl_i.value)} exp={pad_scl_i}")
    assert_chk.check(f"{name}_tgt_sda_i", int(dut.tgt_sda_i.value) == pad_sda_i,
                     f"tgt_sda_i={int(dut.tgt_sda_i.value)} exp={pad_sda_i}")
    assert_chk.check(f"{name}_tgt_scl_i", int(dut.tgt_scl_i.value) == pad_scl_i,
                     f"tgt_scl_i={int(dut.tgt_scl_i.value)} exp={pad_scl_i}")
    assert_chk.check(f"{name}_boot_sda_i", int(dut.boot_sda_i.value) == pad_sda_i,
                     f"boot_sda_i={int(dut.boot_sda_i.value)} exp={pad_sda_i}")
    assert_chk.check(f"{name}_boot_scl_i", int(dut.boot_scl_i.value) == pad_scl_i,
                     f"boot_scl_i={int(dut.boot_scl_i.value)} exp={pad_scl_i}")


async def test_sel0_controller_drives(dut, sb, cov, assert_chk):
    """T1: sel=00 (controller) drives both SDA and SCL."""
    dut._log.info("T1: sel=0 controller drives SDA+SCL")
    # Controller drives SDA=0, SCL=0 (active)
    await check_mux(dut, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1,
                    sb, cov, assert_chk, "ctrl_drives_0")
    # Controller drives SDA=1, SCL=1
    await check_mux(dut, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1,
                    sb, cov, assert_chk, "ctrl_drives_1")
    # Controller releases both
    await check_mux(dut, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1,
                    sb, cov, assert_chk, "ctrl_releases")


async def test_sel1_target_drives(dut, sb, cov, assert_chk):
    """T2: sel=01 (target) drives SDA only — SCL released."""
    dut._log.info("T2: sel=1 target drives SDA only")
    # Target drives SDA=0
    await check_mux(dut, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1,
                    sb, cov, assert_chk, "tgt_drives_sda_0")
    # Target drives SDA=1
    await check_mux(dut, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1,
                    sb, cov, assert_chk, "tgt_drives_sda_1")
    # Target releases SDA
    await check_mux(dut, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0,
                    sb, cov, assert_chk, "tgt_releases")
    # Even if dphy tries to drive SCL, target should not pass it through
    await check_mux(dut, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1,
                    sb, cov, assert_chk, "tgt_blocks_scl")


async def test_sel2_bootstrap_drives(dut, sb, cov, assert_chk):
    """T3: sel=10 (bootstrap) drives both SDA and SCL."""
    dut._log.info("T3: sel=2 bootstrap drives SDA+SCL")
    await check_mux(dut, 2, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0,
                    sb, cov, assert_chk, "boot_drives_0")
    await check_mux(dut, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1,
                    sb, cov, assert_chk, "boot_drives_1")
    await check_mux(dut, 2, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1,
                    sb, cov, assert_chk, "boot_releases")


async def test_sel3_reserved(dut, sb, cov, assert_chk):
    """T4: sel=11 (reserved) — all signals released."""
    dut._log.info("T4: sel=3 reserved (all released)")
    # Even if all sources drive, output should be released
    await check_mux(dut, 3, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0,
                    sb, cov, assert_chk, "rsv_all_drive")
    await check_mux(dut, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                    sb, cov, assert_chk, "rsv_all_drive_1")


async def test_all_combos(dut, sb, cov, assert_chk):
    """T5: All 4 sel × all 4 input combos (16 test cases)."""
    dut._log.info("T5: All 4 sel × all input combos")
    for sel in range(4):
        for sda_o in range(2):
            for scl_o in range(2):
                # Drive different values from each source
                await check_mux(dut, sel,
                                dphy_sda_o=sda_o, dphy_sda_oe=1, dphy_scl_o=scl_o, dphy_scl_oe=1,
                                tgt_sda_o=sda_o ^ 1, tgt_sda_oe=1,
                                boot_sda_o=sda_o, boot_sda_oe=1, boot_scl_o=scl_o, boot_scl_oe=1,
                                pad_sda_i=sda_o, pad_scl_i=scl_o,
                                sb=sb, cov=cov, assert_chk=assert_chk,
                                name=f"all_sel{sel}_sda{sda_o}_scl{scl_o}")


async def test_mutual_exclusion(dut, sb, cov, assert_chk):
    """T6: Mutual exclusion — only one source drives at any time."""
    dut._log.info("T6: Mutual exclusion")
    # All three sources try to drive SDA low
    dut.phy_mux_sel.value = 0  # controller selected
    dut.dphy_sda_o.value = 0
    dut.dphy_sda_oe.value = 1
    dut.tgt_sda_o.value = 0
    dut.tgt_sda_oe.value = 1
    dut.boot_sda_o.value = 0
    dut.boot_sda_oe.value = 1
    await settle()
    sel_cov(0)
    # Only dphy should drive (sel=0)
    assert_chk.check("mutex_sel0_sda_low", int(dut.pad_sda_o.value) == 0,
                     f"sel=0 pad_sda_o={int(dut.pad_sda_o.value)} (only dphy)")
    # Switch to target (sel=1)
    dut.phy_mux_sel.value = 1
    await settle()
    sel_cov(1)
    assert_chk.check("mutex_sel1_sda_low", int(dut.pad_sda_o.value) == 0,
                     f"sel=1 pad_sda_o={int(dut.pad_sda_o.value)} (only tgt)")
    # Switch to bootstrap (sel=2)
    dut.phy_mux_sel.value = 2
    await settle()
    sel_cov(2)
    assert_chk.check("mutex_sel2_sda_low", int(dut.pad_sda_o.value) == 0,
                     f"sel=2 pad_sda_o={int(dut.pad_sda_o.value)} (only boot)")
    sb.add_expected(0); sb.add_actual(int(dut.pad_sda_o.value))


async def test_dynamic_switching(dut, sb, cov, assert_chk):
    """T7: Dynamic switching between sources."""
    dut._log.info("T7: Dynamic switching")
    for sel in [0, 1, 2, 3, 0, 2, 1, 3, 0]:
        dut.phy_mux_sel.value = sel
        dut.dphy_sda_o.value = 0
        dut.dphy_sda_oe.value = 1
        dut.tgt_sda_o.value = 1
        dut.tgt_sda_oe.value = 1
        dut.boot_sda_o.value = 0
        dut.boot_sda_oe.value = 1
        await settle()
        sel_cov(sel)
        # Verify output is from selected source
        if sel == 0:
            exp = 0
        elif sel == 1:
            exp = 1
        elif sel == 2:
            exp = 0
        else:  # 3
            exp = 1
        a = int(dut.pad_sda_o.value)
        assert_chk.check(f"dyn_sel{sel}", a == exp,
                         f"dynamic sel={sel} pad_sda_o={a} (exp {exp})")
        sb.add_expected(exp); sb.add_actual(a)


async def test_readback_broadcast(dut, sb, cov, assert_chk):
    """T8: Pad readback broadcast to all 3 blocks simultaneously."""
    dut._log.info("T8: Readback broadcast")
    for pad_sda in range(2):
        for pad_scl in range(2):
            dut.phy_mux_sel.value = 0
            dut.pad_sda_i.value = pad_sda
            dut.pad_scl_i.value = pad_scl
            await settle()
            dphy_sda = int(dut.dphy_sda_i.value)
            dphy_scl = int(dut.dphy_scl_i.value)
            tgt_sda = int(dut.tgt_sda_i.value)
            tgt_scl = int(dut.tgt_scl_i.value)
            boot_sda = int(dut.boot_sda_i.value)
            boot_scl = int(dut.boot_scl_i.value)
            assert_chk.check(f"rdbk_sda{pad_sda}_scl{pad_scl}_dphy",
                             dphy_sda == pad_sda and dphy_scl == pad_scl,
                             f"dphy: sda={dphy_sda} scl={dphy_scl}")
            assert_chk.check(f"rdbk_sda{pad_sda}_scl{pad_scl}_tgt",
                             tgt_sda == pad_sda and tgt_scl == pad_scl,
                             f"tgt: sda={tgt_sda} scl={tgt_scl}")
            assert_chk.check(f"rdbk_sda{pad_sda}_scl{pad_scl}_boot",
                             boot_sda == pad_sda and boot_scl == pad_scl,
                             f"boot: sda={boot_sda} scl={boot_scl}")
            sb.add_expected(pad_sda); sb.add_actual(dphy_sda)


async def test_random_selections(dut, gen, sb, cov, assert_chk, num=20):
    """T9: Random source selections and input combinations."""
    dut._log.info(f"T9: Random selections ({num} iterations)")
    for i in range(num):
        sel = gen.rng.randint(0, 3)
        dphy_sda_o = gen.rng.randint(0, 1)
        dphy_sda_oe = gen.rng.randint(0, 1)
        dphy_scl_o = gen.rng.randint(0, 1)
        dphy_scl_oe = gen.rng.randint(0, 1)
        tgt_sda_o = gen.rng.randint(0, 1)
        tgt_sda_oe = gen.rng.randint(0, 1)
        boot_sda_o = gen.rng.randint(0, 1)
        boot_sda_oe = gen.rng.randint(0, 1)
        boot_scl_o = gen.rng.randint(0, 1)
        boot_scl_oe = gen.rng.randint(0, 1)
        pad_sda_i = gen.rng.randint(0, 1)
        pad_scl_i = gen.rng.randint(0, 1)
        await check_mux(dut, sel, dphy_sda_o, dphy_sda_oe, dphy_scl_o, dphy_scl_oe,
                        tgt_sda_o, tgt_sda_oe, boot_sda_o, boot_sda_oe, boot_scl_o, boot_scl_oe,
                        pad_sda_i, pad_scl_i, sb, cov, assert_chk, f"rand_{i}")


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main multi-master arbitration test."""
    # Mux is purely combinational — no clock needed, but use for settle timing
    dut.phy_mux_sel.value = 0
    dut.dphy_sda_o.value = 1
    dut.dphy_sda_oe.value = 0
    dut.dphy_scl_o.value = 1
    dut.dphy_scl_oe.value = 0
    dut.tgt_sda_o.value = 1
    dut.tgt_sda_oe.value = 0
    dut.boot_sda_o.value = 1
    dut.boot_sda_oe.value = 0
    dut.boot_scl_o.value = 1
    dut.boot_scl_oe.value = 0
    dut.pad_sda_i.value = 1
    dut.pad_scl_i.value = 1
    await Timer(10, 'ns')

    sb = Scoreboard('mux_all')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=55)
    assert_chk = AssertionChecker('mux_all')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb Multi-Master Arbitration Testbench")
    dut._log.info("=" * 60)

    await test_sel0_controller_drives(dut, sb, cov, assert_chk)
    await test_sel1_target_drives(dut, sb, cov, assert_chk)
    await test_sel2_bootstrap_drives(dut, sb, cov, assert_chk)
    await test_sel3_reserved(dut, sb, cov, assert_chk)
    await test_all_combos(dut, sb, cov, assert_chk)
    await test_mutual_exclusion(dut, sb, cov, assert_chk)
    await test_dynamic_switching(dut, sb, cov, assert_chk)
    await test_readback_broadcast(dut, sb, cov, assert_chk)
    await test_random_selections(dut, gen, sb, cov, assert_chk, 20)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
