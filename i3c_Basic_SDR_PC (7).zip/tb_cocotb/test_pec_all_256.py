"""
test_pec_all_256.py — Exhaustive PEC CRC-8 test for all 256 byte values
Tests:
  - All 256 single-byte CRC values (0x00 - 0xFF)
  - Multi-byte CRC chains (2-byte, 4-byte, 8-byte sequences)
  - Known reference vectors (0x00->0x00, 0x01->0x07, 0xFF->0xF3, ...)
  - PEC append/check pairs for selected values
Uses: Scoreboard, Coverage, Random generator, Assertions.

CRC-8 polynomial: 0x07 (x^8 + x^2 + x + 1) — SMBus/I3C PEC standard
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


# --------------------------------------------------------------------------
# Reference CRC-8 model (must match RTL)
# --------------------------------------------------------------------------
def crc8_byte(crc_in, data):
    """CRC-8 SMBus single byte update."""
    crc = crc_in ^ data
    for _ in range(8):
        if crc & 0x80:
            crc = ((crc << 1) ^ 0x07) & 0xFF
        else:
            crc = (crc << 1) & 0xFF
    return crc


def crc8_bytes(data_bytes, init=0x00):
    """Compute CRC-8 over a byte sequence."""
    crc = init
    for b in data_bytes:
        crc = crc8_byte(crc, b)
    return crc


# Coverage points
def crc_value_cov(crc):
    pass
CoverPoint("pec256.crc_value", bins=[0x00, 0x07, 0xF3, range(0x08, 0xF3), range(0xF4, 0xFF+1)])(crc_value_cov)

def byte_value_cov(b):
    pass
CoverPoint("pec256.byte_value", bins=[0x00, 0x01, 0x07, 0x42, 0x55, 0xAA, 0xFF, range(0x02, 0x42), range(0x43, 0x55), range(0x56, 0xAA), range(0xAB, 0xFF)])(byte_value_cov)

def error_cov(e):
    pass
CoverPoint("pec256.error_flag", bins=[0, 1])(error_cov)


async def settle():
    await Timer(1, 'ns')


async def reset_crc(dut):
    """Reset the CRC register to 0."""
    dut.pec_en.value = 1
    dut.pec_reset.value = 1
    dut.byte_valid.value = 0
    dut.pec_byte_rx.value = 0
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    await RisingEdge(dut.clk)


async def feed_byte(dut, byte_val):
    """Feed one byte to the PEC engine."""
    dut.byte_valid.value = 1
    dut.byte_in.value = byte_val
    dut.pec_byte_rx.value = 0
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)
    dut.byte_valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)  # extra settle for CRC to register


async def test_single_byte_all_256(dut, sb, cov, assert_chk):
    """T1: All 256 single-byte CRC values."""
    dut._log.info("T1: All 256 single-byte CRC values (exhaustive)")
    for byte_val in range(256):
        await reset_crc(dut)
        await feed_byte(dut, byte_val)
        actual = int(dut.crc_out.value)
        expected = crc8_byte(0x00, byte_val)
        byte_value_cov(byte_val)
        crc_value_cov(actual)
        assert_chk.check(f"crc_byte_{byte_val:02x}", actual == expected,
                         f"CRC(0x{byte_val:02x})=0x{actual:02x}, expected=0x{expected:02x}")
        sb.add_expected(expected)
        sb.add_actual(actual)


async def test_known_vectors(dut, sb, cov, assert_chk):
    """T2: Known reference vectors (computed via reference model)."""
    dut._log.info("T2: Known reference vectors")
    vectors = [
        (0x00, crc8_byte(0x00, 0x00)),
        (0x01, crc8_byte(0x00, 0x01)),
        (0x07, crc8_byte(0x00, 0x07)),
        (0x42, crc8_byte(0x00, 0x42)),
        (0x55, crc8_byte(0x00, 0x55)),
        (0xAA, crc8_byte(0x00, 0xAA)),
        (0xFF, crc8_byte(0x00, 0xFF)),
    ]
    for byte_val, expected in vectors:
        await reset_crc(dut)
        await feed_byte(dut, byte_val)
        actual = int(dut.crc_out.value)
        assert_chk.check(f"vector_{byte_val:02x}", actual == expected,
                         f"CRC(0x{byte_val:02x})=0x{actual:02x}, expected=0x{expected:02x}")
        sb.add_expected(expected)
        sb.add_actual(actual)


async def test_multibyte_chains(dut, sb, cov, assert_chk):
    """T3: Multi-byte CRC chains (2, 4, 8 bytes)."""
    dut._log.info("T3: Multi-byte CRC chains")
    test_seqs = [
        [0x00, 0x00],
        [0x01, 0x02, 0x03, 0x04],
        [0xDE, 0xAD, 0xBE, 0xEF],
        [0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0],
        [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF],
        list(range(0, 8)),
        list(range(8, 16)),
    ]
    for i, seq in enumerate(test_seqs):
        await reset_crc(dut)
        for b in seq:
            await feed_byte(dut, b)
        actual = int(dut.crc_out.value)
        expected = crc8_bytes(seq)
        assert_chk.check(f"chain_{i}", actual == expected,
                         f"CRC({seq})=0x{actual:02x}, expected=0x{expected:02x}")
        sb.add_expected(expected)
        sb.add_actual(actual)


async def test_pec_append_all_256(dut, sb, cov, assert_chk):
    """T4: PEC append (TX path) for all 256 single-byte inputs."""
    dut._log.info("T4: PEC append for all 256 single-byte inputs")
    for byte_val in range(0, 256, 16):  # sample every 16th for speed
        await reset_crc(dut)
        await feed_byte(dut, byte_val)
        expected_crc = crc8_byte(0x00, byte_val)
        # Pulse pec_append
        dut.pec_append.value = 1
        await RisingEdge(dut.clk)
        dut.pec_append.value = 0
        await RisingEdge(dut.clk)
        valid = int(dut.pec_tx_valid.value)
        tx_value = int(dut.pec_tx_value.value)
        assert_chk.check(f"append_valid_{byte_val:02x}", valid == 1,
                         f"PEC TX valid for 0x{byte_val:02x}")
        assert_chk.check(f"append_value_{byte_val:02x}", tx_value == expected_crc,
                         f"PEC TX value=0x{tx_value:02x}, expected=0x{expected_crc:02x}")
        sb.add_expected(expected_crc)
        sb.add_actual(tx_value)
        # Next cycle valid should deassert
        await RisingEdge(dut.clk)
        assert_chk.check(f"append_deassert_{byte_val:02x}", int(dut.pec_tx_valid.value) == 0,
                         f"PEC TX valid deasserts after 0x{byte_val:02x}")


async def test_pec_check_correct_all_256(dut, sb, cov, assert_chk):
    """T5: PEC check (correct) — feed byte, then check with correct CRC."""
    dut._log.info("T5: PEC check correct (sampled)")
    for byte_val in range(0, 256, 32):  # sample for speed
        await reset_crc(dut)
        await feed_byte(dut, byte_val)
        computed_crc = int(dut.crc_out.value)
        # Pulse pec_byte_rx with correct value
        dut.pec_byte_rx.value = 1
        dut.pec_rx_value.value = computed_crc
        await RisingEdge(dut.clk)
        dut.pec_byte_rx.value = 0
        await RisingEdge(dut.clk)
        actual_err = int(dut.pec_error.value)
        error_cov(actual_err)
        assert_chk.check(f"check_correct_{byte_val:02x}", actual_err == 0,
                         f"PEC check correct for 0x{byte_val:02x}: error={actual_err}")
        sb.add_expected(0)
        sb.add_actual(actual_err)


async def test_pec_check_incorrect_all_256(dut, sb, cov, assert_chk):
    """T6: PEC check (incorrect) — feed byte, then check with wrong CRC."""
    dut._log.info("T6: PEC check incorrect (sampled)")
    for byte_val in range(0, 256, 32):
        await reset_crc(dut)
        await feed_byte(dut, byte_val)
        computed_crc = int(dut.crc_out.value)
        wrong_crc = computed_crc ^ 0xFF
        dut.pec_byte_rx.value = 1
        dut.pec_rx_value.value = wrong_crc
        await RisingEdge(dut.clk)
        dut.pec_byte_rx.value = 0
        await RisingEdge(dut.clk)
        actual_err = int(dut.pec_error.value)
        error_cov(actual_err)
        assert_chk.check(f"check_incorrect_{byte_val:02x}", actual_err == 1,
                         f"PEC check incorrect for 0x{byte_val:02x}: error={actual_err}")
        sb.add_expected(1)
        sb.add_actual(actual_err)


async def test_pec_disabled_bypass(dut, sb, cov, assert_chk):
    """T7: PEC disabled — CRC stays at 0."""
    dut._log.info("T7: PEC disabled")
    dut.pec_en.value = 0
    dut.pec_reset.value = 1
    await RisingEdge(dut.clk)
    dut.pec_reset.value = 0
    for b in [0x42, 0x55, 0xFF, 0x00]:
        dut.byte_valid.value = 1
        dut.byte_in.value = b
        await RisingEdge(dut.clk)
        dut.byte_valid.value = 0
        await RisingEdge(dut.clk)
        actual = int(dut.crc_out.value)
        assert_chk.check(f"pec_dis_{b:02x}", actual == 0x00,
                         f"PEC disabled CRC(0x{b:02x})=0x{actual:02x}, expected 0x00")
        sb.add_expected(0)
        sb.add_actual(actual)


async def test_random_multibyte(dut, gen, sb, cov, assert_chk, num=20):
    """T8: Random multi-byte CRC chains."""
    dut._log.info(f"T8: Random multi-byte CRC chains ({num} iterations)")
    for i in range(num):
        await reset_crc(dut)
        n_bytes = gen.rng.randint(1, 8)
        seq = [gen.gen_data_byte() for _ in range(n_bytes)]
        for b in seq:
            await feed_byte(dut, b)
        actual = int(dut.crc_out.value)
        expected = crc8_bytes(seq)
        assert_chk.check(f"rand_chain_{i}", actual == expected,
                         f"random chain {i}: actual=0x{actual:02x}, expected=0x{expected:02x}")
        sb.add_expected(expected)
        sb.add_actual(actual)
        crc_value_cov(actual)


async def test_crc_accumulates(dut, sb, cov, assert_chk):
    """T9: Verify CRC accumulates across multiple bytes (no reset)."""
    dut._log.info("T9: CRC accumulation across bytes")
    await reset_crc(dut)
    seq = [0xAA, 0xBB, 0xCC, 0xDD]
    for i, b in enumerate(seq):
        await feed_byte(dut, b)
        actual = int(dut.crc_out.value)
        expected = crc8_bytes(seq[:i+1])
        assert_chk.check(f"acc_step_{i}", actual == expected,
                         f"step {i}: actual=0x{actual:02x}, expected=0x{expected:02x}")
        sb.add_expected(expected)
        sb.add_actual(actual)


async def test_zero_to_ff_sweep(dut, sb, cov, assert_chk):
    """T10: Sweep 0x00 -> 0xFF in sequence, single chain."""
    dut._log.info("T10: Sweep 0x00 -> 0xFF single chain")
    await reset_crc(dut)
    for b in range(256):
        await feed_byte(dut, b)
    actual = int(dut.crc_out.value)
    expected = crc8_bytes(list(range(256)))
    assert_chk.check("sweep_all", actual == expected,
                     f"sweep all: actual=0x{actual:02x}, expected=0x{expected:02x}")
    sb.add_expected(expected)
    sb.add_actual(actual)


@cocotb.test(timeout_time=300000, timeout_unit='ns')
async def main_test(dut):
    """Main PEC CRC-8 exhaustive test — all 256 byte values."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.pec_en.value = 0
    dut.pec_reset.value = 0
    dut.byte_valid.value = 0
    dut.byte_in.value = 0
    dut.pec_byte_rx.value = 0
    dut.pec_rx_value.value = 0
    dut.pec_append.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('pec256')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=123)
    assert_chk = AssertionChecker('pec256')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb PEC CRC-8 Exhaustive 256-byte Testbench")
    dut._log.info("=" * 60)

    await test_single_byte_all_256(dut, sb, cov, assert_chk)
    await test_known_vectors(dut, sb, cov, assert_chk)
    await test_multibyte_chains(dut, sb, cov, assert_chk)
    await test_pec_append_all_256(dut, sb, cov, assert_chk)
    await test_pec_check_correct_all_256(dut, sb, cov, assert_chk)
    await test_pec_check_incorrect_all_256(dut, sb, cov, assert_chk)
    await test_pec_disabled_bypass(dut, sb, cov, assert_chk)
    await test_random_multibyte(dut, gen, sb, cov, assert_chk, 20)
    await test_crc_accumulates(dut, sb, cov, assert_chk)
    await test_zero_to_ff_sweep(dut, sb, cov, assert_chk)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
