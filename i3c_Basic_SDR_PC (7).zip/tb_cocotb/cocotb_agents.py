"""
cocotb_agents.py — Reusable UVM-style agents for I3C Controller verification.
Provides: Drivers, Monitors, Scoreboards, Coverage, Random generators.
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer, ClockCycles, Event
from cocotb.clock import Clock
from cocotb.utils import get_sim_time

import random
import asyncio
from collections import deque

# =========================================================================
# CLOCK & RESET AGENT
# =========================================================================
class ClockResetAgent:
    """Drives clock and reset signals."""
    def __init__(self, dut, clk_name='clk', rst_name='rst_n', period=10, units='ns'):
        self.dut = dut
        self.clk_name = clk_name
        self.rst_name = rst_name
        self.period = period
        self.units = units
        self.clock = None

    async def start_clock(self):
        clk_sig = getattr(self.dut, self.clk_name)
        self.clock = cocotb.start_soon(Clock(clk_sig, self.period, units=self.units).start())

    async def stop_clock(self):
        if self.clock:
            self.clock.kill()

    async def reset(self, cycles=5):
        rst_sig = getattr(self.dut, self.rst_name)
        rst_sig.value = 0
        await ClockCycles(getattr(self.dut, self.clk_name), cycles)
        rst_sig.value = 1
        await ClockCycles(getattr(self.dut, self.clk_name), 2)


# =========================================================================
# AXI4-LITE DRIVER
# =========================================================================
class AXI4LiteDriver:
    """Drives AXI4-Lite write/read transactions."""
    def __init__(self, dut, clk_name='clk'):
        self.dut = dut
        self.clk = getattr(dut, clk_name)

    async def write(self, addr, data):
        """Single AXI4-Lite write transaction."""
        d = self.dut
        d.s_axi_awvalid.value = 1
        d.s_axi_awaddr.value = addr
        d.s_axi_wvalid.value = 1
        d.s_axi_wdata.value = data
        d.s_axi_wstrb.value = 0xF
        # Wait for both AW and W ready
        while not (d.s_axi_awready.value and d.s_axi_wready.value):
            await RisingEdge(self.clk)
        await RisingEdge(self.clk)
        d.s_axi_awvalid.value = 0
        d.s_axi_wvalid.value = 0
        # Wait for B response
        while not d.s_axi_bvalid.value:
            await RisingEdge(self.clk)
        await RisingEdge(self.clk)
        return int(d.s_axi_bresp.value)

    async def read(self, addr):
        """Single AXI4-Lite read transaction."""
        d = self.dut
        d.s_axi_arvalid.value = 1
        d.s_axi_araddr.value = addr
        while not d.s_axi_arready.value:
            await RisingEdge(self.clk)
        await RisingEdge(self.clk)
        d.s_axi_arvalid.value = 0
        while not d.s_axi_rvalid.value:
            await RisingEdge(self.clk)
        data = int(d.s_axi_rdata.value)
        resp = int(d.s_axi_rresp.value)
        await RisingEdge(self.clk)
        return data, resp


# =========================================================================
# FIFO DRIVER (for CMD/WR/RD/RESP FIFOs)
# =========================================================================
class FIFODriver:
    """Drives FIFO push/pop operations."""
    def __init__(self, dut, prefix, clk_name='clk'):
        self.dut = dut
        self.prefix = prefix
        self.clk = getattr(dut, clk_name)

    async def push(self, data):
        """Push one word to FIFO."""
        d = self.dut
        push_sig = getattr(d, f'{self.prefix}_push')
        data_sig = getattr(d, f'{self.prefix}_push_data')
        full_sig = getattr(d, f'{self.prefix}_full')
        while full_sig.value:
            await RisingEdge(self.clk)
        push_sig.value = 1
        data_sig.value = data
        await RisingEdge(self.clk)
        push_sig.value = 0

    async def pop(self, timeout=10000):
        """Pop one word from FIFO, returns data."""
        d = self.dut
        pop_sig = getattr(d, f'{self.prefix}_pop')
        empty_sig = getattr(d, f'{self.prefix}_empty')
        data_sig = getattr(d, f'{self.prefix}_pop_data')
        count = 0
        while empty_sig.value and count < timeout:
            await RisingEdge(self.clk)
            count += 1
        if empty_sig.value:
            raise AssertionError(f"FIFO {self.prefix} pop timeout")
        data = int(data_sig.value)
        pop_sig.value = 1
        await RisingEdge(self.clk)
        pop_sig.value = 0
        await RisingEdge(self.clk)
        return data


# =========================================================================
# SCOREBOARD
# =========================================================================
class Scoreboard:
    """UVM-style scoreboard: tracks expected vs actual."""
    def __init__(self, name='scoreboard'):
        self.name = name
        self.expected_queue = deque()
        self.actual_queue = deque()
        self.pass_count = 0
        self.fail_count = 0
        self.mismatches = []

    def add_expected(self, item):
        """Add an expected result."""
        self.expected_queue.append(item)

    def add_actual(self, item):
        """Add an actual result and compare with expected."""
        self.actual_queue.append(item)
        if self.expected_queue:
            exp = self.expected_queue.popleft()
            if item == exp:
                self.pass_count += 1
            else:
                self.fail_count += 1
                self.mismatches.append((exp, item))
                if len(self.mismatches) <= 10:
                    print(f"  [SB-{self.name}] MISMATCH: expected={exp:#010x}, actual={item:#010x}")

    def report(self):
        """Print scoreboard summary."""
        print(f"  [SB-{self.name}] PASS={self.pass_count}, FAIL={self.fail_count}")
        if self.expected_queue:
            print(f"  [SB-{self.name}] WARNING: {len(self.expected_queue)} expected items not received")
        return self.fail_count == 0


# =========================================================================
# COVERAGE COLLECTOR
# =========================================================================
class CoverageCollector:
    """Functional coverage collection."""
    def __init__(self):
        self.cover_points = {}

    def add_point(self, name, value, bins):
        """Add a cover point."""
        if name not in self.cover_points:
            self.cover_points[name] = {b: 0 for b in bins}
        if value in self.cover_points[name]:
            self.cover_points[name][value] += 1

    def report(self):
        """Print coverage report."""
        print("\n=== Coverage Report ===")
        total_hit = 0
        total_bins = 0
        for name, bins in self.cover_points.items():
            hit = sum(1 for v in bins.values() if v > 0)
            total = len(bins)
            total_hit += hit
            total_bins += total
            pct = 100 * hit / total if total > 0 else 0
            print(f"  {name}: {hit}/{total} ({pct:.0f}%)")
            for b, count in sorted(bins.items()):
                status = "✓" if count > 0 else "✗"
                print(f"    {status} bin={b}: hits={count}")
        overall = 100 * total_hit / total_bins if total_bins > 0 else 0
        print(f"\n  Overall: {total_hit}/{total_bins} ({overall:.0f}%)")
        return overall


# =========================================================================
# RANDOM TRANSACTION GENERATOR
# =========================================================================
class TransactionGenerator:
    """Generates randomized transactions (like UVM sequences)."""
    def __init__(self, seed=42):
        self.rng = random.Random(seed)

    def gen_cmd_word(self, toc=None, cp=None, i2c_mode=None, byte_cnt=None,
                     addr=None, rnw=None, ccc=None):
        """Generate a randomized command word."""
        toc = self.rng.choice([0, 1]) if toc is None else toc
        cp = self.rng.choice([0, 0, 0, 1]) if cp is None else cp  # 75% private
        i2c_mode = 0 if i2c_mode is None else i2c_mode
        byte_cnt = self.rng.randint(0, 15) if byte_cnt is None else byte_cnt
        addr = self.rng.randint(0, 0x7F) if addr is None else addr
        rnw = self.rng.choice([0, 0, 1]) if rnw is None else rnw  # 67% write
        ccc = self.rng.randint(0, 0xFF) if ccc is None else ccc
        return (toc << 31) | (cp << 30) | (0 << 28) | (i2c_mode << 24) | \
               (byte_cnt << 16) | (addr << 9) | (rnw << 8) | ccc

    def gen_data_byte(self):
        """Generate a random data byte."""
        return self.rng.randint(0, 255)

    def gen_data_word(self):
        """Generate a random 32-bit data word."""
        return self.rng.randint(0, 0xFFFFFFFF)

    def gen_addr(self, valid_range=None):
        """Generate a random address."""
        if valid_range:
            return self.rng.choice(valid_range)
        return self.rng.randint(0, 0x7F)


# =========================================================================
# I3C BUS MONITOR (for full-controller tests)
# =========================================================================
class I3CBusMonitor:
    """Monitors SDA/SCL bus activity."""
    def __init__(self, dut):
        self.dut = dut
        self.scl_prev = 1
        self.sda_prev = 1
        self.start_detected = False
        self.stop_detected = False
        self.transactions = []

    async def monitor(self):
        """Continuously monitor bus for START/STOP conditions."""
        d = self.dut
        while True:
            await RisingEdge(d.s_axi_aclk)
            scl = int(d.scl.value) if str(d.scl.value) not in ('z', 'Z', 'x', 'X') else 1
            sda = int(d.sda.value) if str(d.sda.value) not in ('z', 'Z', 'x', 'X') else 1
            # START: SDA falls while SCL high
            if scl and self.sda_prev and not sda:
                self.start_detected = True
                self.transactions.append(('START', get_sim_time()))
            # STOP: SDA rises while SCL high
            if scl and not self.sda_prev and sda:
                self.stop_detected = True
                self.transactions.append(('STOP', get_sim_time()))
            self.scl_prev = scl
            self.sda_prev = sda


# =========================================================================
# ASSERTION CHECKER (runtime SVA equivalent)
# =========================================================================
class AssertionChecker:
    """Runtime assertion checking (equivalent to SVA)."""
    def __init__(self, name='assertions'):
        self.name = name
        self.pass_count = 0
        self.fail_count = 0
        self.assertions = []

    def check(self, name, condition, msg=''):
        """Check an assertion."""
        if condition:
            self.pass_count += 1
        else:
            self.fail_count += 1
            self.assertions.append(f"  [ASSERT-{name}] FAIL: {msg}")
            print(f"  [ASSERT-{self.name}] FAIL: {name}: {msg}")

    def report(self):
        """Print assertion summary."""
        print(f"  [ASSERT-{self.name}] PASS={self.pass_count}, FAIL={self.fail_count}")
        return self.fail_count == 0
