"""
test_i3c_dnf.py — Cocotb testbench for i3c_dnf (Digital Noise Filter)
Tests: bypass (threshold=0), threshold=1/2/3, glitch rejection, SCL filtering,
       enable/disable toggle, max threshold=15.
Uses: Scoreboard, Coverage, Random generator, Assertions.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


# Coverage points
def threshold_cov(t):
    pass
CoverPoint("dnf.threshold", bins=[0, 1, 2, 3, 4, 8, 15])(threshold_cov)

def enable_cov(e):
    pass
CoverPoint("dnf.enable", bins=[0, 1])(enable_cov)


async def settle(dut, n=6):
    """Wait n cycles for filter latency to settle."""
    for _ in range(n):
        await RisingEdge(dut.clk)


async def drive_stable(dut, sda, scl, n=10):
    """Drive SDA/SCL to a stable value for n cycles."""
    dut.sda_raw.value = sda
    dut.scl_raw.value = scl
    await settle(dut, n)


async def test_bypass_threshold0(dut, sb, cov, assert_chk):
    """T1: Bypass mode when threshold=0 (output follows raw immediately)."""
    dut._log.info("T1: Bypass with threshold=0")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 0
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("bypass_th0_high",
                     int(dut.sda_filtered.value) == 1 and int(dut.scl_filtered.value) == 1,
                     f"sda_f={int(dut.sda_filtered.value)} scl_f={int(dut.scl_filtered.value)}")
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("bypass_th0_low",
                     int(dut.sda_filtered.value) == 0 and int(dut.scl_filtered.value) == 0,
                     f"sda_f={int(dut.sda_filtered.value)} scl_f={int(dut.scl_filtered.value)}")
    threshold_cov(0)
    enable_cov(1)


async def test_bypass_disabled(dut, sb, cov, assert_chk):
    """T2: Bypass mode when dnf_enable=0."""
    dut._log.info("T2: Bypass with dnf_enable=0")
    dut.dnf_enable.value = 0
    dut.dnf_threshold.value = 3
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("bypass_dis_high",
                     int(dut.sda_filtered.value) == 1 and int(dut.scl_filtered.value) == 1,
                     "filtered should follow raw (high)")
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert_chk.check("bypass_dis_low",
                     int(dut.sda_filtered.value) == 0 and int(dut.scl_filtered.value) == 0,
                     "filtered should follow raw (low)")
    enable_cov(0)
    threshold_cov(3)


async def test_threshold_stable(dut, threshold, sb, cov, assert_chk, name):
    """Stable transition 1→0 and 0→1 with given threshold."""
    dut._log.info(f"T: Stable transition with threshold={threshold}")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = threshold
    enable_cov(1)
    threshold_cov(threshold)
    # Steady high, then go low, settle, check
    await drive_stable(dut, 1, 1, 8)
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    # Allow threshold+1 cycles + margin for filter to track
    await settle(dut, threshold + 5)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check(f"{name}_low",
                     sda_f == 0 and scl_f == 0,
                     f"th={threshold} sda_f={sda_f} scl_f={scl_f} (expected 0)")
    sb.add_expected(0); sb.add_actual(sda_f)
    # Now back to high
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await settle(dut, threshold + 5)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check(f"{name}_high",
                     sda_f == 1 and scl_f == 1,
                     f"th={threshold} sda_f={sda_f} scl_f={scl_f} (expected 1)")
    sb.add_expected(1); sb.add_actual(sda_f)


async def test_glitch_rejection(dut, sb, cov, assert_chk):
    """T: Glitch (1-cycle pulse) on SDA — output should settle back to stable value."""
    dut._log.info("T: Glitch rejection (1-cycle SDA pulse)")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 3
    enable_cov(1); threshold_cov(3)
    await drive_stable(dut, 1, 1, 10)
    # 1-cycle glitch on SDA
    dut.sda_raw.value = 0
    await RisingEdge(dut.clk)
    dut.sda_raw.value = 1
    # Settle for many cycles
    await settle(dut, 10)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check("glitch_settle_back",
                     sda_f == 1,
                     f"after 1-cycle glitch + settle, sda_filtered={sda_f} (expected 1)")
    sb.add_expected(1); sb.add_actual(sda_f)


async def test_glitch_persistent_stable(dut, sb, cov, assert_chk):
    """Long stable low should propagate after enough cycles even with filter on."""
    dut._log.info("T: Long stable low propagates")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 2
    enable_cov(1); threshold_cov(2)
    await drive_stable(dut, 1, 1, 10)
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    await settle(dut, 10)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check("stable_low_propagates",
                     sda_f == 0 and scl_f == 0,
                     f"after long stable low, sda_f={sda_f} scl_f={scl_f}")


async def test_scl_filtering(dut, sb, cov, assert_chk):
    """T: SCL filtering independent of SDA — same behavior."""
    dut._log.info("T: SCL filtering")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 2
    enable_cov(1); threshold_cov(2)
    # Keep SDA high, toggle SCL
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await settle(dut, 10)
    dut.scl_raw.value = 0
    await settle(dut, 10)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check("scl_low", scl_f == 0, f"SCL filtered low: {scl_f}")
    dut.scl_raw.value = 1
    await settle(dut, 10)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check("scl_high", scl_f == 1, f"SCL filtered high: {scl_f}")
    sb.add_expected(1); sb.add_actual(scl_f)


async def test_enable_disable_toggle(dut, sb, cov, assert_chk):
    """T: Toggle enable mid-stream — bypass should reflect raw immediately."""
    dut._log.info("T: Enable/disable toggle")
    # Start with filter on, threshold=3, stable low
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 3
    enable_cov(1); threshold_cov(3)
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await settle(dut, 10)
    # Now disable, output should track raw combinationally
    dut.dnf_enable.value = 0
    enable_cov(0)
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.sda_raw.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check("disable_tracks_raw", sda_f == 0, f"disabled: sda_f={sda_f} (expected 0)")
    # Re-enable
    dut.dnf_enable.value = 1
    enable_cov(1)
    await settle(dut, 10)
    sda_f = int(dut.sda_filtered.value)
    assert_chk.check("renable_settles", sda_f == 0, f"re-enabled: sda_f={sda_f} (expected 0)")
    sb.add_expected(0); sb.add_actual(sda_f)


async def test_max_threshold(dut, sb, cov, assert_chk):
    """T: Max threshold=15."""
    dut._log.info("T: Max threshold=15")
    dut.dnf_enable.value = 1
    dut.dnf_threshold.value = 15
    enable_cov(1); threshold_cov(15)
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await settle(dut, 20)
    dut.sda_raw.value = 0
    dut.scl_raw.value = 0
    # 20+ cycles settle for max threshold
    await settle(dut, 25)
    sda_f = int(dut.sda_filtered.value)
    scl_f = int(dut.scl_filtered.value)
    assert_chk.check("max_th_low",
                     sda_f == 0 and scl_f == 0,
                     f"th=15 sda_f={sda_f} scl_f={scl_f} (expected 0,0)")
    sb.add_expected(0); sb.add_actual(sda_f)


async def test_random_inputs(dut, gen, sb, cov, assert_chk, num=15):
    """Randomized DNF tests."""
    dut._log.info(f"T: Random inputs ({num} iterations)")
    dut.dnf_enable.value = 1
    for i in range(num):
        th = gen.rng.randint(0, 15)
        dut.dnf_threshold.value = th
        threshold_cov(th)
        # Random stable value
        v = gen.rng.randint(0, 1)
        dut.sda_raw.value = v
        dut.scl_raw.value = v
        # Settle enough cycles for max threshold
        await settle(dut, 20)
        sda_f = int(dut.sda_filtered.value)
        assert_chk.check(f"rand_{i}",
                         sda_f == v,
                         f"rand th={th} v={v} sda_f={sda_f}")
        sb.add_expected(v); sb.add_actual(sda_f)
        # Random disable check
        if gen.rng.random() < 0.3:
            dut.dnf_enable.value = 0
            enable_cov(0)
            v2 = gen.rng.randint(0, 1)
            dut.sda_raw.value = v2
            await RisingEdge(dut.clk)
            await RisingEdge(dut.clk)
            sda_f = int(dut.sda_filtered.value)
            assert_chk.check(f"rand_dis_{i}",
                             sda_f == v2,
                             f"disabled th={th} v2={v2} sda_f={sda_f}")
            dut.dnf_enable.value = 1
            enable_cov(1)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main DNF test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.dnf_enable.value = 0
    dut.dnf_threshold.value = 0
    dut.sda_raw.value = 1
    dut.scl_raw.value = 1
    await RisingEdge(dut.clk)

    sb = Scoreboard('dnf')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('dnf')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb DNF Testbench")
    dut._log.info("=" * 60)

    await test_bypass_threshold0(dut, sb, cov, assert_chk)
    await test_bypass_disabled(dut, sb, cov, assert_chk)
    await test_threshold_stable(dut, 1, sb, cov, assert_chk, "th1")
    await test_threshold_stable(dut, 2, sb, cov, assert_chk, "th2")
    await test_threshold_stable(dut, 3, sb, cov, assert_chk, "th3")
    await test_glitch_rejection(dut, sb, cov, assert_chk)
    await test_glitch_persistent_stable(dut, sb, cov, assert_chk)
    await test_scl_filtering(dut, sb, cov, assert_chk)
    await test_enable_disable_toggle(dut, sb, cov, assert_chk)
    await test_max_threshold(dut, sb, cov, assert_chk)
    await test_random_inputs(dut, gen, sb, cov, assert_chk, 15)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_ok = assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
