"""
test_fifo_level_saturation_v2.py — FIFO level register saturation test.

Regression test for Bug 6.2 (WR/RD FIFO level truncated 6→5 bits).
Tests:
  T1. WR FIFO empty (free=32) reads as 0x1F (31, saturated) not 0x00
  T2. RD FIFO full (level=32) reads as 0x1F (31, saturated) not 0x00
  T3. WR FIFO full (free=0) reads as 0x00
  T4. RD FIFO empty (level=0) reads as 0x00
  T5. CMD FIFO free = 16 (empty) reads as 0x10
  T6. RESP FIFO level = 16 (full) reads as 0x10

Top module: i3c_register_file (standalone)
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from cocotb_agents import AssertionChecker

FIFO_LVL_STATUS_ADDR   = 0x2C  # [9:5]=WR_FREE, [4:0]=CMD_FREE
FIFO_LVL_STATUS_1_ADDR = 0x30  # [9:5]=RD_LEVEL, [4:0]=RESP_LEVEL

sb = AssertionChecker("fifo_sat")


async def reg_read(dut, addr):
    """Read register — sample data while reg_rd is high."""
    dut.reg_rd_addr.value = addr
    await RisingEdge(dut.clk)
    dut.reg_rd.value = 1
    await RisingEdge(dut.clk)
    # Sample data NOW (combinational read — data valid when reg_rd=1)
    val = int(dut.reg_rd_data.value)
    dut.reg_rd.value = 0
    await RisingEdge(dut.clk)
    return val


@cocotb.test()
async def main_test(dut):
    """FIFO level register saturation test."""
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset
    dut.rst_n.value = 0
    dut.reg_wr.value = 0
    dut.reg_rd.value = 0
    dut.reg_wr_addr.value = 0
    dut.reg_wr_data.value = 0
    dut.reg_wr_strb.value = 0
    dut.reg_rd_addr.value = 0

    # Stub all hw_* inputs
    for attr in dir(dut):
        if attr.startswith('hw_'):
            try:
                getattr(dut, attr).value = 0
            except:
                pass

    await Timer(100, unit="ns")
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # T1: WR FIFO empty (free=32) — should read 0x1F (saturated), not 0x00
    if hasattr(dut, 'hw_wr_fifo_free'):
        dut.hw_wr_fifo_free.value = 32  # FIFO empty (depth=32)
    if hasattr(dut, 'hw_cmd_fifo_free'):
        dut.hw_cmd_fifo_free.value = 16  # CMD empty (depth=16)
    await RisingEdge(dut.clk)
    # Keep values set during read
    if hasattr(dut, 'hw_wr_fifo_free'):
        dut.hw_wr_fifo_free.value = 32
    if hasattr(dut, 'hw_cmd_fifo_free'):
        dut.hw_cmd_fifo_free.value = 16
    val = await reg_read(dut, FIFO_LVL_STATUS_ADDR)
    wr_free = (val >> 5) & 0x1F
    cmd_free = val & 0x1F
    sb.check("T1: WR FIFO empty (free=32) → saturated to 31, not 0", wr_free == 31)
    sb.check("T1b: CMD FIFO empty (free=16) → 16", cmd_free == 16)

    # T2: RD FIFO full (level=32) — should read 0x1F (saturated), not 0x00
    if hasattr(dut, 'hw_rd_fifo_level'):
        dut.hw_rd_fifo_level.value = 32
    if hasattr(dut, 'hw_resp_fifo_level'):
        dut.hw_resp_fifo_level.value = 16
    await RisingEdge(dut.clk)
    val = await reg_read(dut, FIFO_LVL_STATUS_1_ADDR)
    rd_level = (val >> 5) & 0x1F
    resp_level = val & 0x1F
    sb.check("T2: RD FIFO full (level=32) → saturated to 31, not 0", rd_level == 31)
    sb.check("T2b: RESP FIFO full (level=16) → 16", resp_level == 16)

    # T3: WR FIFO full (free=0) — should read 0x00
    if hasattr(dut, 'hw_wr_fifo_free'):
        dut.hw_wr_fifo_free.value = 0
    await RisingEdge(dut.clk)
    val = await reg_read(dut, FIFO_LVL_STATUS_ADDR)
    wr_free = (val >> 5) & 0x1F
    sb.check("T3: WR FIFO full (free=0) → 0", wr_free == 0)

    # T4: RD FIFO empty (level=0) — should read 0x00
    if hasattr(dut, 'hw_rd_fifo_level'):
        dut.hw_rd_fifo_level.value = 0
    await RisingEdge(dut.clk)
    val = await reg_read(dut, FIFO_LVL_STATUS_1_ADDR)
    rd_level = (val >> 5) & 0x1F
    sb.check("T4: RD FIFO empty (level=0) → 0", rd_level == 0)

    # T5: Mid-range values
    if hasattr(dut, 'hw_wr_fifo_free'):
        dut.hw_wr_fifo_free.value = 15
    if hasattr(dut, 'hw_rd_fifo_level'):
        dut.hw_rd_fifo_level.value = 20
    await RisingEdge(dut.clk)
    val = await reg_read(dut, FIFO_LVL_STATUS_ADDR)
    wr_free = (val >> 5) & 0x1F
    val2 = await reg_read(dut, FIFO_LVL_STATUS_1_ADDR)
    rd_level = (val2 >> 5) & 0x1F
    sb.check("T5: WR free=15 → 15", wr_free == 15)
    sb.check("T5b: RD level=20 → 20", rd_level == 20)

    sb.report()
    assert sb.fail_count == 0, f"{sb.fail_count} failures detected"
