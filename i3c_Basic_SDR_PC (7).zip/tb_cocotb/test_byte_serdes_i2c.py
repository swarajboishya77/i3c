"""
test_byte_serdes_i2c.py — Cocotb testbench for byte_serdes_i2c (I2C Byte SerDes)
PHY simulation: when cmd_bit_xfer is high, provide phy_done=1 on the next cycle.
Tests: idle, send byte (ACK/NACK), receive byte, last byte NACK, multiple bytes,
       interleaved.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def done_cov(d):
    pass
CoverPoint("serdes_i2c.done", bins=[0, 1])(done_cov)


class I2CPhyModel:
    """Simple PHY model that responds to cmd_bit_xfer with phy_done=1 next cycle.
    Also drives sda_sampled for receive / ACK operations."""
    def __init__(self, dut):
        self.dut = dut
        self.sda_sampled_value = 0  # default: ACK / 0 bit
        self.running = False
        self.task = None

    def set_sda_sampled(self, val):
        self.sda_sampled_value = val

    async def run(self):
        d = self.dut
        d.phy_done.value = 0
        d.sda_sampled.value = 0
        self.running = True
        while self.running:
            await RisingEdge(d.clk)
            any_cmd = int(d.cmd_bit_xfer.value)
            d.phy_done.value = 1 if any_cmd else 0
            d.sda_sampled.value = self.sda_sampled_value

    def stop(self):
        self.running = False


async def wait_for_byte_done(dut, timeout=200):
    """Wait for byte_done=1 pulse. Returns cycles waited, or -1 on timeout."""
    for i in range(timeout):
        await RisingEdge(dut.clk)
        if int(dut.byte_done.value) == 1:
            return i + 1
    return -1


async def test_idle(dut, sb, cov, assert_chk):
    """T1: Idle state."""
    dut._log.info("T1: Idle")
    dut.req_send_byte.value = 0
    dut.req_recv_byte.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
    busy = int(dut.busy.value)
    done = int(dut.byte_done.value)
    assert_chk.check("idle_busy", busy == 0, f"idle: busy={busy} (expected 0)")
    assert_chk.check("idle_done", done == 0, f"idle: done={done} (expected 0)")
    sb.add_expected(0); sb.add_actual(done)


async def test_send_byte_ack(dut, phy, sb, cov, assert_chk):
    """T2: Send byte, target ACKs."""
    dut._log.info("T2: Send byte (ACK)")
    byte_val = 0xA5
    dut.req_send_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(0)  # ACK on 9th bit
    dut.byte_tx.value = byte_val
    dut.is_last_byte.value = 0
    dut.req_send_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    done_cov(1)
    assert_chk.check("send_byte_ack_done", cycles > 0,
                     f"send_byte ACK: byte_done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    ack = int(dut.ack_received.value)
    assert_chk.check("send_byte_ack_recv", ack == 1,
                     f"send_byte ACK: ack_received={ack} (expected 1)")
    await RisingEdge(dut.clk)


async def test_send_byte_nack(dut, phy, sb, cov, assert_chk):
    """T3: Send byte, target NACKs."""
    dut._log.info("T3: Send byte (NACK)")
    byte_val = 0x3C
    dut.req_send_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(1)  # NACK on 9th bit
    dut.byte_tx.value = byte_val
    dut.is_last_byte.value = 0
    dut.req_send_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    done_cov(1)
    assert_chk.check("send_byte_nack_done", cycles > 0,
                     f"send_byte NACK: byte_done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    ack = int(dut.ack_received.value)
    assert_chk.check("send_byte_nack_recv", ack == 0,
                     f"send_byte NACK: ack_received={ack} (expected 0)")
    phy.set_sda_sampled(0)
    await RisingEdge(dut.clk)


async def test_recv_byte(dut, phy, sb, cov, assert_chk):
    """T4: Receive byte — target sends 0xFF (all bits=1)."""
    dut._log.info("T4: Receive byte")
    dut.req_recv_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(1)  # all bits = 1 → byte_rx = 0xFF
    dut.is_last_byte.value = 0
    dut.req_recv_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_recv_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    done_cov(1)
    assert_chk.check("recv_byte_done", cycles > 0,
                     f"recv_byte: byte_done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    byte_rx = int(dut.byte_rx.value)
    assert_chk.check("recv_byte_value", byte_rx == 0xFF,
                     f"recv_byte: byte_rx={byte_rx:#x} (expected 0xFF)")
    phy.set_sda_sampled(0)
    await RisingEdge(dut.clk)


async def test_recv_byte_pattern(dut, phy, sb, cov, assert_chk):
    """T5: Receive byte with specific pattern (alternating 1,0,1,0... = 0xAA)."""
    dut._log.info("T5: Receive byte with pattern")
    dut.req_recv_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    # Pattern MSB-first: [1,0,1,0,1,0,1,0] should yield byte_rx=0xAA
    # The shift register shifts LEFT (new bit at LSB), so first bit becomes MSB.
    pattern = [1, 0, 1, 0, 1, 0, 1, 0]
    expected_byte = 0xAA

    # Stop default phy
    phy.stop()
    phy.task.kill()

    # Pattern PHY: provide phy_done=1 when cmd_bit_xfer=1, and drive sda_sampled
    # with the pattern bit-by-bit. The trick: in the SAME cycle that cmd_bit_xfer
    # goes high (first shift cycle), we must already have sda_sampled=pattern[0].
    # We do this by tracking the bit count and driving the pattern.
    class PATTERN_PHY(I2CPhyModel):
        def __init__(self, dut, pattern):
            super().__init__(dut)
            self.pattern = pattern
            self.idx = 0
            self.was_xfer = False

        async def run(self):
            d = self.dut
            d.phy_done.value = 0
            d.sda_sampled.value = 0
            self.running = True
            self.idx = 0
            self.was_xfer = False
            while self.running:
                await RisingEdge(d.clk)
                any_cmd = int(d.cmd_bit_xfer.value)
                d.phy_done.value = 1 if any_cmd else 0
                # Drive pattern bit when in shift phase (cmd_bit_xfer high and was_xfer or first time)
                if any_cmd:
                    if not self.was_xfer:
                        # First shift cycle — start with pattern[0]
                        self.idx = 0
                    if self.idx < len(self.pattern):
                        d.sda_sampled.value = self.pattern[self.idx]
                        self.idx += 1
                    else:
                        # 9th bit (ACK from controller for recv, or driven by controller)
                        d.sda_sampled.value = 0
                    self.was_xfer = True
                else:
                    self.was_xfer = False
                    self.idx = 0
                    d.sda_sampled.value = 0

    pattern_phy = PATTERN_PHY(dut, pattern)
    pattern_phy.task = cocotb.start_soon(pattern_phy.run())
    dut.req_recv_byte.value = 1
    dut.is_last_byte.value = 0
    await RisingEdge(dut.clk)
    dut.req_recv_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    done_cov(1)
    assert_chk.check("recv_byte_pattern_done", cycles > 0,
                     f"recv_byte pattern: byte_done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    byte_rx = int(dut.byte_rx.value)
    assert_chk.check("recv_byte_pattern_value", byte_rx == expected_byte,
                     f"recv_byte pattern: byte_rx={byte_rx:#x} (expected {expected_byte:#x})")
    # Stop pattern phy, restart default
    pattern_phy.stop()
    pattern_phy.task.kill()
    phy.task = cocotb.start_soon(phy.run())
    await RisingEdge(dut.clk)


async def test_last_byte_nack(dut, phy, sb, cov, assert_chk):
    """T6: Last byte NACK — controller NACKs on 9th bit during recv."""
    dut._log.info("T6: Last byte NACK")
    dut.req_recv_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    phy.set_sda_sampled(0)  # data bits = 0
    dut.is_last_byte.value = 1  # NACK on last byte
    dut.req_recv_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_recv_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    done_cov(1)
    assert_chk.check("last_byte_done", cycles > 0,
                     f"last byte: byte_done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    byte_rx = int(dut.byte_rx.value)
    assert_chk.check("last_byte_value", byte_rx == 0x00,
                     f"last byte: byte_rx={byte_rx:#x} (expected 0x00)")
    await RisingEdge(dut.clk)


async def test_multiple_bytes(dut, phy, sb, cov, assert_chk):
    """T7: Multiple bytes back-to-back."""
    dut._log.info("T7: Multiple bytes")
    phy.set_sda_sampled(0)  # ACK
    bytes_to_send = [0x11, 0x22, 0x33, 0x44]
    for b in bytes_to_send:
        dut.req_send_byte.value = 0
        for _ in range(2):
            await RisingEdge(dut.clk)
        dut.byte_tx.value = b
        dut.is_last_byte.value = 0
        dut.req_send_byte.value = 1
        await RisingEdge(dut.clk)
        dut.req_send_byte.value = 0
        cycles = await wait_for_byte_done(dut, 100)
        assert_chk.check(f"multi_byte_{b:#x}_done", cycles > 0,
                         f"multi byte {b:#x}: done never pulsed (waited {cycles} cycles)")
        if cycles > 0:
            sb.add_expected(1); sb.add_actual(1)
        ack = int(dut.ack_received.value)
        assert_chk.check(f"multi_byte_{b:#x}_ack", ack == 1,
                         f"multi byte {b:#x}: ack_received={ack} (expected 1)")
        await RisingEdge(dut.clk)


async def test_interleaved(dut, phy, sb, cov, assert_chk):
    """T8: Interleaved send/recv."""
    dut._log.info("T8: Interleaved send/recv")
    # Send byte
    phy.set_sda_sampled(0)
    dut.req_send_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.byte_tx.value = 0x77
    dut.is_last_byte.value = 0
    dut.req_send_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_send_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    assert_chk.check("interleaved_send_done", cycles > 0,
                     f"interleaved send: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    await RisingEdge(dut.clk)
    # Recv byte
    phy.set_sda_sampled(1)
    dut.req_recv_byte.value = 0
    for _ in range(2):
        await RisingEdge(dut.clk)
    dut.is_last_byte.value = 0
    dut.req_recv_byte.value = 1
    await RisingEdge(dut.clk)
    dut.req_recv_byte.value = 0
    cycles = await wait_for_byte_done(dut, 100)
    assert_chk.check("interleaved_recv_done", cycles > 0,
                     f"interleaved recv: done never pulsed (waited {cycles} cycles)")
    if cycles > 0:
        sb.add_expected(1); sb.add_actual(1)
    byte_rx = int(dut.byte_rx.value)
    assert_chk.check("interleaved_recv_value", byte_rx == 0xFF,
                     f"interleaved recv: byte_rx={byte_rx:#x} (expected 0xFF)")
    phy.set_sda_sampled(0)
    await RisingEdge(dut.clk)


async def test_random(dut, phy, gen, sb, cov, assert_chk, num=10):
    """Randomized tests."""
    dut._log.info(f"T9: Random tests ({num} iterations)")
    for i in range(num):
        op = gen.rng.choice(['send', 'recv'])
        for _ in range(2):
            await RisingEdge(dut.clk)
        if op == 'send':
            phy.set_sda_sampled(gen.rng.randint(0, 1))  # random ACK/NACK
            dut.byte_tx.value = gen.rng.randint(0, 0xFF)
            dut.is_last_byte.value = 0
            dut.req_send_byte.value = 1
        else:
            phy.set_sda_sampled(gen.rng.randint(0, 1))
            dut.is_last_byte.value = gen.rng.randint(0, 1)
            dut.req_recv_byte.value = 1
        await RisingEdge(dut.clk)
        dut.req_send_byte.value = 0
        dut.req_recv_byte.value = 0
        cycles = await wait_for_byte_done(dut, 100)
        assert_chk.check(f"rand_{i}_{op}_done", cycles > 0,
                         f"rand_{i}: op={op} done after {cycles} cycles")
        if cycles > 0:
            sb.add_expected(1); sb.add_actual(1)
        await RisingEdge(dut.clk)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main I2C byte serdes test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.req_send_byte.value = 0
    dut.req_recv_byte.value = 0
    dut.byte_tx.value = 0
    dut.is_last_byte.value = 0
    dut.phy_done.value = 0
    dut.sda_sampled.value = 0
    await RisingEdge(dut.clk)

    # Start PHY model in background
    phy = I2CPhyModel(dut)
    phy.task = cocotb.start_soon(phy.run())

    sb = Scoreboard('serdes_i2c')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('serdes_i2c')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb I2C Byte SerDes Testbench")
    dut._log.info("=" * 60)

    await test_idle(dut, sb, cov, assert_chk)
    await test_send_byte_ack(dut, phy, sb, cov, assert_chk)
    await test_send_byte_nack(dut, phy, sb, cov, assert_chk)
    await test_recv_byte(dut, phy, sb, cov, assert_chk)
    await test_recv_byte_pattern(dut, phy, sb, cov, assert_chk)
    await test_last_byte_nack(dut, phy, sb, cov, assert_chk)
    await test_multiple_bytes(dut, phy, sb, cov, assert_chk)
    await test_interleaved(dut, phy, sb, cov, assert_chk)
    await test_random(dut, phy, gen, sb, cov, assert_chk, 10)

    # Stop PHY model
    phy.stop()
    phy.task.kill()

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
