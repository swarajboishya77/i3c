"""
test_i2c_prescaler.py — Cocotb testbench for i2c_prescaler
Tests: default (0 → 50), Fm+ (50), standard (500), slower, back to 0,
       minimum (1), period calculation, cap at max, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

The prescaler is purely combinational:
  - speed_prescaler == 0 → output 50, active=0 (safe default Fm+)
  - speed_prescaler >= 262143 → cap at 0x3FFFF, active=1
  - else → output = prescaler, active=1
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def active_cov(a):
    pass
CoverPoint("prescaler.active", bins=[0, 1])(active_cov)


async def settle():
    await Timer(1, 'ns')


async def set_and_check(dut, prescaler, expected_high, expected_low, expected_active,
                        sb, cov, assert_chk, name):
    """Set speed_prescaler and verify outputs (combinational)."""
    dut.speed_prescaler.value = prescaler
    await RisingEdge(dut.clk)
    await settle()
    hi = int(dut.i2c_scl_high_time.value)
    lo = int(dut.i2c_scl_low_time.value)
    act = int(dut.prescaler_active.value)
    active_cov(act)
    assert_chk.check(f"{name}_high", hi == expected_high,
                     f"prescaler={prescaler} high={hi} (expected {expected_high})")
    assert_chk.check(f"{name}_low", lo == expected_low,
                     f"prescaler={prescaler} low={lo} (expected {expected_low})")
    assert_chk.check(f"{name}_active", act == expected_active,
                     f"prescaler={prescaler} active={act} (expected {expected_active})")
    sb.add_expected(expected_high); sb.add_actual(hi)
    sb.add_expected(expected_low); sb.add_actual(lo)
    sb.add_expected(expected_active); sb.add_actual(act)


async def test_default_zero(dut, sb, cov, assert_chk):
    """T1: speed_prescaler=0 → output 50 (Fm+ safe default), active=0."""
    dut._log.info("T1: Default zero")
    await set_and_check(dut, 0, 50, 50, 0, sb, cov, assert_chk, "default_zero")


async def test_fm_plus(dut, sb, cov, assert_chk):
    """T2: Fm+ speed — prescaler=50."""
    dut._log.info("T2: Fm+ (50)")
    await set_and_check(dut, 50, 50, 50, 1, sb, cov, assert_chk, "fm_plus")


async def test_standard(dut, sb, cov, assert_chk):
    """T3: Standard speed — prescaler=500."""
    dut._log.info("T3: Standard (500)")
    await set_and_check(dut, 500, 500, 500, 1, sb, cov, assert_chk, "standard")


async def test_slower(dut, sb, cov, assert_chk):
    """T4: Slower speed — prescaler=1000."""
    dut._log.info("T4: Slower (1000)")
    await set_and_check(dut, 1000, 1000, 1000, 1, sb, cov, assert_chk, "slower")


async def test_back_to_zero(dut, sb, cov, assert_chk):
    """T5: Back to 0 after programming — reverts to safe default."""
    dut._log.info("T5: Back to zero")
    await set_and_check(dut, 200, 200, 200, 1, sb, cov, assert_chk, "pre_zero")
    await set_and_check(dut, 0, 50, 50, 0, sb, cov, assert_chk, "back_zero")


async def test_minimum_one(dut, sb, cov, assert_chk):
    """T6: Minimum non-zero — prescaler=1."""
    dut._log.info("T6: Minimum (1)")
    await set_and_check(dut, 1, 1, 1, 1, sb, cov, assert_chk, "minimum_one")


async def test_cap_at_max(dut, sb, cov, assert_chk):
    """T7: Cap at 262143 — output 0x3FFFF."""
    dut._log.info("T7: Cap at max")
    await set_and_check(dut, 262143, 0x3FFFF, 0x3FFFF, 1, sb, cov, assert_chk, "cap_at_max")


async def test_above_cap(dut, sb, cov, assert_chk):
    """T8: Above cap — still capped at 0x3FFFF."""
    dut._log.info("T8: Above cap")
    await set_and_check(dut, 300000, 0x3FFFF, 0x3FFFF, 1, sb, cov, assert_chk, "above_cap")


async def test_period_calculation(dut, sb, cov, assert_chk):
    """T9: Verify period calculation: SCL_freq = PCLK / (prescaler * 2).

    At 100MHz PCLK, prescaler=125 → period = 250 cycles = 400kHz (Fm).
    """
    dut._log.info("T9: Period calculation")
    # Fm speed: 400 kHz → prescaler = 100MHz / (2 * 400kHz) = 125
    dut.speed_prescaler.value = 125
    await RisingEdge(dut.clk)
    await settle()
    hi = int(dut.i2c_scl_high_time.value)
    lo = int(dut.i2c_scl_low_time.value)
    period = hi + lo  # in PCLK cycles
    pclk_freq_mhz = 100
    scl_freq_khz = (pclk_freq_mhz * 1000) // period if period > 0 else 0
    assert_chk.check("period_250", period == 250, f"period={period} (expected 250)")
    assert_chk.check("scl_freq_400khz", scl_freq_khz == 400, f"scl_freq={scl_freq_khz}kHz")
    sb.add_expected(250); sb.add_actual(period)


async def test_high_equals_low(dut, sb, cov, assert_chk):
    """T10: 50% duty cycle — high_time always equals low_time."""
    dut._log.info("T10: 50% duty cycle")
    for p in [10, 25, 100, 250, 1000]:
        dut.speed_prescaler.value = p
        await RisingEdge(dut.clk)
        await settle()
        hi = int(dut.i2c_scl_high_time.value)
        lo = int(dut.i2c_scl_low_time.value)
        assert_chk.check(f"duty_{p}", hi == lo, f"prescaler={p} hi={hi} lo={lo}")
        sb.add_expected(hi); sb.add_actual(lo)


async def test_random_prescalers(dut, gen, sb, cov, assert_chk, num=10):
    """T11: Randomized prescaler values."""
    dut._log.info(f"T11: Random prescalers ({num})")
    for i in range(num):
        p = gen.rng.choice([0, 1, 50, 125, 500, 1000, 262143, 300000, gen.rng.randint(2, 262142)])
        dut.speed_prescaler.value = p
        await RisingEdge(dut.clk)
        await settle()
        hi = int(dut.i2c_scl_high_time.value)
        lo = int(dut.i2c_scl_low_time.value)
        act = int(dut.prescaler_active.value)
        active_cov(act)
        # Compute expected
        if p == 0:
            exp_hi, exp_act = 50, 0
        elif p >= 262143:
            exp_hi, exp_act = 0x3FFFF, 1
        else:
            exp_hi, exp_act = p, 1
        assert_chk.check(f"rand_{i}_high", hi == exp_hi,
                         f"p={p} hi={hi} (expected {exp_hi})")
        assert_chk.check(f"rand_{i}_low", lo == exp_hi,
                         f"p={p} lo={lo} (expected {exp_hi})")
        assert_chk.check(f"rand_{i}_active", act == exp_act,
                         f"p={p} active={act} (expected {exp_act})")
        sb.add_expected(exp_hi); sb.add_actual(hi)


@cocotb.test(timeout_time=100000, timeout_unit='ns')
async def main_test(dut):
    """Main I2C prescaler test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.speed_prescaler.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('prescaler')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('prescaler')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb I2C Prescaler Testbench")
    dut._log.info("=" * 60)

    await test_default_zero(dut, sb, cov, assert_chk)
    await test_fm_plus(dut, sb, cov, assert_chk)
    await test_standard(dut, sb, cov, assert_chk)
    await test_slower(dut, sb, cov, assert_chk)
    await test_back_to_zero(dut, sb, cov, assert_chk)
    await test_minimum_one(dut, sb, cov, assert_chk)
    await test_cap_at_max(dut, sb, cov, assert_chk)
    await test_above_cap(dut, sb, cov, assert_chk)
    await test_period_calculation(dut, sb, cov, assert_chk)
    await test_high_equals_low(dut, sb, cov, assert_chk)
    await test_random_prescalers(dut, gen, sb, cov, assert_chk, 10)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
