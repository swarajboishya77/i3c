"""
test_i3c_ccc_handler.py — Cocotb testbench for i3c_ccc_handler
Tests: broadcast CCC, direct CCC, error handling (addr NACK, data NACK),
       GETACCR, opcode routing, defining byte, multi-byte payload, randomized.
Uses: Scoreboard, Coverage, Random generator, Assertions.

CCC FSM: C_IDLE → C_START → C_ADDR_7E_W → C_TX_OPCODE → ...
Each state waits for prim_done to advance. The test pulses prim_done each cycle.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker


def error_cov(e):
    pass
CoverPoint("ccc.error", bins=[0, 1])(error_cov)

def done_cov(d):
    pass
CoverPoint("ccc.done", bins=[0, 1])(done_cov)


async def settle():
    await Timer(1, 'ns')


async def run_ccc(dut, opcode, is_direct, target_addr=0, defining_byte=0,
                  has_defining_byte=0, ack_recv=1, byte_recv=0x00,
                  max_cycles=50):
    """Run a CCC transaction. Pulses prim_done each cycle.

    Returns dict of observed outputs: ccc_done, ccc_error, ccc_resp_valid,
    ccc_resp_byte, ccc_getacccr_ack, ccc_getacccr_addr_nack, ccc_getacccr_data_nack.
    """
    # Trigger ccc_req
    dut.ccc_req.value = 1
    dut.ccc_opcode.value = opcode
    dut.ccc_is_direct.value = is_direct
    dut.ccc_target_addr.value = target_addr
    dut.ccc_defining_byte.value = defining_byte
    dut.ccc_has_defining_byte.value = has_defining_byte
    await RisingEdge(dut.clk)
    dut.ccc_req.value = 0
    # Default prim signals
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    dut.prim_byte_recv.value = byte_recv
    result = {
        'ccc_done': 0, 'ccc_error': 0, 'ccc_resp_valid': 0, 'ccc_resp_byte': 0,
        'ccc_getacccr_ack': 0, 'ccc_getacccr_addr_nack': 0, 'ccc_getacccr_data_nack': 0,
        'ccc_start_count': 0, 'ccc_rep_start_count': 0, 'ccc_stop_count': 0,
        'ccc_send_byte_count': 0, 'ccc_recv_byte_count': 0,
    }
    for _ in range(max_cycles):
        await settle()
        # Sample outputs for CURRENT state (before prim_done causes transition)
        if int(dut.ccc_start.value) == 1:
            result['ccc_start_count'] += 1
        if int(dut.ccc_repeat_start.value) == 1:
            result['ccc_rep_start_count'] += 1
        if int(dut.ccc_stop.value) == 1:
            result['ccc_stop_count'] += 1
        if int(dut.ccc_send_byte.value) == 1:
            result['ccc_send_byte_count'] += 1
        if int(dut.ccc_recv_byte.value) == 1:
            result['ccc_recv_byte_count'] += 1
        if int(dut.ccc_resp_valid.value) == 1:
            result['ccc_resp_valid'] = 1
            result['ccc_resp_byte'] = int(dut.ccc_resp_byte.value)
        # Now pulse prim_done to advance FSM
        dut.prim_done.value = 1
        dut.prim_ack_recv.value = ack_recv
        dut.prim_byte_recv.value = byte_recv
        await RisingEdge(dut.clk)
        dut.prim_done.value = 0
        # After edge, check if done
        await settle()
        if int(dut.ccc_done.value) == 1:
            result['ccc_done'] = 1
            result['ccc_error'] = int(dut.ccc_error.value)
            result['ccc_getacccr_ack'] = int(dut.ccc_getacccr_ack.value)
            result['ccc_getacccr_addr_nack'] = int(dut.ccc_getacccr_addr_nack.value)
            result['ccc_getacccr_data_nack'] = int(dut.ccc_getacccr_data_nack.value)
            # Wait for C_DONE → C_IDLE
            await RisingEdge(dut.clk)
            break
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    await RisingEdge(dut.clk)
    return result


async def test_broadcast_ccc_simple(dut, sb, cov, assert_chk):
    """T1: Broadcast CCC with no payload, no response (e.g. RSTDAA 0x06)."""
    dut._log.info("T1: Broadcast CCC (RSTDAA 0x06)")
    r = await run_ccc(dut, 0x06, is_direct=0, ack_recv=1)
    assert_chk.check("bcc_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("bcc_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    assert_chk.check("bcc_start", r['ccc_start_count'] >= 1, f"start_count={r['ccc_start_count']}")
    assert_chk.check("bcc_stop", r['ccc_stop_count'] >= 1, f"stop_count={r['ccc_stop_count']}")
    assert_chk.check("bcc_send_opcode", r['ccc_send_byte_count'] >= 1, f"send_byte={r['ccc_send_byte_count']}")
    assert_chk.check("bcc_no_resp", r['ccc_resp_valid'] == 0, f"resp_valid={r['ccc_resp_valid']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])
    sb.add_expected(0); sb.add_actual(r['ccc_error'])
    error_cov(r['ccc_error']); done_cov(r['ccc_done'])


async def test_broadcast_ccc_with_defining_byte(dut, sb, cov, assert_chk):
    """T2: Broadcast CCC with defining byte (e.g. RSTACT 0xAE with 1 byte)."""
    dut._log.info("T2: Broadcast CCC with defining byte (RSTACT 0xAE)")
    r = await run_ccc(dut, 0xAE, is_direct=0, defining_byte=0x01, has_defining_byte=1, ack_recv=1)
    assert_chk.check("bcc_db_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("bcc_db_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # RSTACT has 1 payload byte (the defining byte is sent, then payload)
    # Actually: has_defining_byte sends defining byte, then payload_len_bcst(0xAE)=1 sends another
    # So send_byte_count should be at least 2 (opcode + defining + payload)
    assert_chk.check("bcc_db_send_bytes", r['ccc_send_byte_count'] >= 2,
                     f"send_byte={r['ccc_send_byte_count']} (expected >=2)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_broadcast_ccc_setmrl(dut, sb, cov, assert_chk):
    """T3: SETMRL broadcast (0x0A) — 2-byte payload from cfg_mrl.
    Per MIPI I3C Basic v1.2 Table 16: SETMRL broadcast = 0x0A.
    """
    dut._log.info("T3: SETMRL broadcast (0x0A)")
    dut.cfg_mrl.value = 0x1234
    dut.cfg_mwl.value = 0x5678
    r = await run_ccc(dut, 0x0A, is_direct=0, ack_recv=1)
    assert_chk.check("setmrl_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("setmrl_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # opcode + 2 payload bytes = 3 send_byte
    assert_chk.check("setmrl_send_bytes", r['ccc_send_byte_count'] >= 3,
                     f"send_byte={r['ccc_send_byte_count']} (expected >=3)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_direct_ccc_simple(dut, sb, cov, assert_chk):
    """T4: Direct CCC with no payload, no response (e.g. SETNEWDA 0x88 has 1 payload)."""
    dut._log.info("T4: Direct CCC (SETNEWDA 0x88)")
    r = await run_ccc(dut, 0x88, is_direct=1, target_addr=0x10,
                      defining_byte=0x20, has_defining_byte=0, ack_recv=1)
    assert_chk.check("dcc_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("dcc_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # Direct CCC: opcode + re-START + addr + payload (1 byte) = send_byte >= 2
    assert_chk.check("dcc_rep_start", r['ccc_rep_start_count'] >= 1,
                     f"rep_start={r['ccc_rep_start_count']} (expected >=1)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_direct_ccc_getstatus(dut, sb, cov, assert_chk):
    """T5: Direct CCC GETSTATUS (0xA0) — expects 2-byte response."""
    dut._log.info("T5: Direct CCC GETSTATUS (0xA0)")
    r = await run_ccc(dut, 0xA0, is_direct=1, target_addr=0x20, ack_recv=1, byte_recv=0xAB)
    assert_chk.check("getstatus_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getstatus_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    assert_chk.check("getstatus_recv", r['ccc_recv_byte_count'] >= 1,
                     f"recv_byte={r['ccc_recv_byte_count']} (expected >=1)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_getaccr_accepted(dut, sb, cov, assert_chk):
    """T6: GETACCR (0x91) — target accepts.
    Per MIPI I3C Basic v1.2 §4.3.7.3.16: target returns its 7-bit DA + odd-parity bit.
    The DA returned must match the target_addr, and PAR must equal ~XOR(DA[6:0]).
    For target_addr=0x30: 0x30 = 011_0000, XOR=0, PAR=~0=1, so response byte = 0x61.
    """
    dut._log.info("T6: GETACCR accepted")
    # Build expected response: {target_addr[6:0], odd_parity(target_addr[6:0])}
    target_addr = 0x30
    parity = odd_parity_7bit(target_addr)
    expected_response = (target_addr << 1) | parity
    r = await run_ccc(dut, 0x91, is_direct=1, target_addr=target_addr,
                      ack_recv=1, byte_recv=expected_response)
    assert_chk.check("getaccr_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getaccr_ack", r['ccc_getacccr_ack'] == 1,
                     f"getacccr_ack={r['ccc_getacccr_ack']}")
    assert_chk.check("getaccr_no_addr_nack", r['ccc_getacccr_addr_nack'] == 0,
                     f"addr_nack={r['ccc_getacccr_addr_nack']}")
    assert_chk.check("getaccr_no_data_nack", r['ccc_getacccr_data_nack'] == 0,
                     f"data_nack={r['ccc_getacccr_data_nack']}")
    sb.add_expected(1); sb.add_actual(r['ccc_getacccr_ack'])


async def test_getaccr_rejected(dut, sb, cov, assert_chk):
    """T7: GETACCR — target rejects (response byte[1:0]=01)."""
    dut._log.info("T7: GETACCR rejected")
    # Reset to clear sticky getacccr_ack flag from T6
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.cfg_mrl.value = 0x1234
    dut.cfg_mwl.value = 0x5678
    for _ in range(2):
        await RisingEdge(dut.clk)
    # Response byte with [1:0]=01 means rejected
    r = await run_ccc(dut, 0x91, is_direct=1, target_addr=0x30, ack_recv=1, byte_recv=0x01)
    assert_chk.check("getaccr_rej_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getaccr_rej_data_nack", r['ccc_getacccr_data_nack'] == 1,
                     f"data_nack={r['ccc_getacccr_data_nack']}")
    assert_chk.check("getaccr_rej_no_ack", r['ccc_getacccr_ack'] == 0,
                     f"ack={r['ccc_getacccr_ack']}")
    assert_chk.check("getaccr_rej_error", r['ccc_error'] == 1, f"error={r['ccc_error']}")
    sb.add_expected(1); sb.add_actual(r['ccc_getacccr_data_nack'])
    error_cov(r['ccc_error'])


async def test_getaccr_addr_nack(dut, sb, cov, assert_chk):
    """T8: GETACCR — target address NACKed (no device)."""
    dut._log.info("T8: GETACCR addr NACK")
    # Need to NACK the DA address phase. The FSM checks prim_ack_recv in C_ADDR_DA_W.
    # We need to provide ack=0 when in C_ADDR_DA_W state.
    # Simplest: run with ack=0 for the DA address phase.
    # But run_ccc uses a fixed ack_recv. Let me do this manually.
    dut.ccc_req.value = 1
    dut.ccc_opcode.value = 0x91
    dut.ccc_is_direct.value = 1
    dut.ccc_target_addr.value = 0x40
    dut.ccc_defining_byte.value = 0
    dut.ccc_has_defining_byte.value = 0
    await RisingEdge(dut.clk)
    dut.ccc_req.value = 0
    # Run through states: C_START → C_ADDR_7E_W (ack=1) → C_TX_OPCODE (ack=1)
    # → C_REP_START → C_DIRECT_ADDR (ack=0 → NACK) → C_STOP → C_DONE
    # BUG-R4-046 FIX: CCC handler uses ccc_send_byte (not ccc_send_addr_w) for
    # the direct address. NACK when ccc_byte_val matches {target_addr, 1'b0}.
    addr_da_seen = False
    done = 0
    addr_nack = 0
    error = 0
    byte_count = 0
    nack_phase = 0
    for i in range(30):
        await settle()
        is_send_byte = int(dut.ccc_send_byte.value)
        byte_val = int(dut.ccc_byte_val.value)
        # The direct address is the 3rd ccc_send_byte (7E-W, opcode, direct addr)
        if is_send_byte:
            byte_count += 1
        if is_send_byte and byte_val == 0x80 and byte_count >= 3:  # {0x40, 1'b0} = 0x80
            addr_da_seen = True
            dut.prim_ack_recv.value = 0  # NACK the DA address
            nack_phase = 2
        elif nack_phase > 0:
            dut.prim_ack_recv.value = 0
            nack_phase -= 1
        else:
            dut.prim_ack_recv.value = 1
        dut.prim_done.value = 1
        dut.prim_byte_recv.value = 0x00
        await RisingEdge(dut.clk)
        if int(dut.ccc_done.value) == 1:
            done = 1
            addr_nack = int(dut.ccc_getacccr_addr_nack.value)
            error = int(dut.ccc_error.value)
            dut.prim_done.value = 0
            await RisingEdge(dut.clk)
            break
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    assert_chk.check("getaccr_an_done", done == 1, f"done={done}")
    assert_chk.check("getaccr_an_seen", addr_da_seen, "DA address phase seen")
    assert_chk.check("getaccr_an_nack", addr_nack == 1, f"addr_nack={addr_nack}")
    assert_chk.check("getaccr_an_error", error == 1, f"error={error}")
    sb.add_expected(1); sb.add_actual(addr_nack)
    error_cov(error)


async def test_opcode_nack(dut, sb, cov, assert_chk):
    """T9: Broadcast CCC where opcode is NACKed — error set."""
    dut._log.info("T9: Opcode NACK")
    dut.ccc_req.value = 1
    dut.ccc_opcode.value = 0x06  # RSTDAA
    dut.ccc_is_direct.value = 0
    dut.ccc_target_addr.value = 0
    dut.ccc_defining_byte.value = 0
    dut.ccc_has_defining_byte.value = 0
    await RisingEdge(dut.clk)
    dut.ccc_req.value = 0
    # NACK the opcode
    opcode_seen = False
    done = 0
    error = 0
    nack_phase = 0  # BUG-R4-046 FIX: hold NACK for 2 cycles (TX + ACK)
    for i in range(30):
        await settle()
        is_send_byte = int(dut.ccc_send_byte.value)
        if is_send_byte:
            opcode_seen = True
            dut.prim_ack_recv.value = 0  # NACK the opcode
            nack_phase = 2  # hold NACK for TX + ACK cycles
        elif nack_phase > 0:
            dut.prim_ack_recv.value = 0  # keep NACKing through ACK phase
            nack_phase -= 1
        else:
            dut.prim_ack_recv.value = 1
        dut.prim_done.value = 1
        await RisingEdge(dut.clk)
        if int(dut.ccc_done.value) == 1:
            done = 1
            error = int(dut.ccc_error.value)
            dut.prim_done.value = 0
            await RisingEdge(dut.clk)
            break
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    assert_chk.check("op_nack_done", done == 1, f"done={done}")
    assert_chk.check("op_nack_seen", opcode_seen, "opcode phase seen")
    assert_chk.check("op_nack_error", error == 1, f"error={error}")
    sb.add_expected(1); sb.add_actual(error)
    error_cov(error)


async def test_addr_7e_nack(dut, sb, cov, assert_chk):
    """T10: Broadcast address 0x7E NACKed — error set."""
    dut._log.info("T10: 0x7E address NACK")
    dut.ccc_req.value = 1
    dut.ccc_opcode.value = 0x06
    dut.ccc_is_direct.value = 0
    await RisingEdge(dut.clk)
    dut.ccc_req.value = 0
    done = 0
    error = 0
    first_byte_nacked = False
    nack_phase = 0  # BUG-R4-046 FIX: hold NACK for 2 cycles
    for i in range(30):
        await settle()
        # NACK the first ccc_send_byte (7E+W address byte)
        is_send_byte = int(dut.ccc_send_byte.value)
        if is_send_byte and not first_byte_nacked:
            first_byte_nacked = True
            dut.prim_ack_recv.value = 0
            nack_phase = 2
        elif nack_phase > 0:
            dut.prim_ack_recv.value = 0
            nack_phase -= 1
        else:
            dut.prim_ack_recv.value = 1
        dut.prim_done.value = 1
        await RisingEdge(dut.clk)
        if int(dut.ccc_done.value) == 1:
            done = 1
            error = int(dut.ccc_error.value)
            dut.prim_done.value = 0
            await RisingEdge(dut.clk)
            break
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    assert_chk.check("7e_nack_done", done == 1, f"done={done}")
    assert_chk.check("7e_nack_error", error == 1, f"error={error}")
    sb.add_expected(1); sb.add_actual(error)


async def test_setdasa(dut, sb, cov, assert_chk):
    """T11: SETDASA (0x87) — direct CCC with 1 payload byte (new DA)."""
    dut._log.info("T11: SETDASA (0x87)")
    r = await run_ccc(dut, 0x87, is_direct=1, target_addr=0x50,
                      defining_byte=0x60, has_defining_byte=0, ack_recv=1)
    assert_chk.check("setdasa_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("setdasa_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # Direct CCC should have re-START
    assert_chk.check("setdasa_rep_start", r['ccc_rep_start_count'] >= 1,
                     f"rep_start={r['ccc_rep_start_count']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_getpid(dut, sb, cov, assert_chk):
    """T12: GETPID (0x8D) — direct CCC, expects 6-byte response.
    Per MIPI I3C Basic v1.2 Table 16: GETPID Direct = 0x8D.
    """
    dut._log.info("T12: GETPID (0x8D)")
    r = await run_ccc(dut, 0x8D, is_direct=1, target_addr=0x60, ack_recv=1, byte_recv=0x11)
    assert_chk.check("getpid_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getpid_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # GETPID expects 6 response bytes
    assert_chk.check("getpid_recv", r['ccc_recv_byte_count'] >= 1,
                     f"recv_byte={r['ccc_recv_byte_count']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


def odd_parity_7bit(da):
    """Compute odd parity bit for a 7-bit dynamic address.
    Per spec: PAR = ~XOR(DA[6:0]).
    """
    p = 0
    for i in range(7):
        p ^= (da >> i) & 1
    return (~p) & 1


async def test_getaccr_wrong_da(dut, sb, cov, assert_chk):
    """T_CC1: GETACCR with wrong DA in response → data_nack.
    Per spec §4.3.7.3.16: returned DA must match target_addr. If not, data_nack.
    """
    dut._log.info("T_CC1: GETACCR wrong DA")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    # Send target_addr=0x30, but response DA=0x40 (mismatch) with valid PAR
    target_addr = 0x30
    wrong_da = 0x40
    wrong_par = odd_parity_7bit(wrong_da)  # valid PAR for wrong DA
    wrong_response = (wrong_da << 1) | wrong_par
    r = await run_ccc(dut, 0x91, is_direct=1, target_addr=target_addr,
                      ack_recv=1, byte_recv=wrong_response)
    assert_chk.check("getaccr_wrong_da_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getaccr_wrong_da_data_nack", r['ccc_getacccr_data_nack'] == 1,
                     f"data_nack={r['ccc_getacccr_data_nack']} (expected 1, DA mismatch)")
    assert_chk.check("getaccr_wrong_da_no_ack", r['ccc_getacccr_ack'] == 0,
                     f"ack={r['ccc_getacccr_ack']} (expected 0)")
    sb.add_expected(1); sb.add_actual(r['ccc_getacccr_data_nack'])


async def test_getaccr_wrong_par(dut, sb, cov, assert_chk):
    """T_CC2: GETACCR with correct DA but wrong PAR → data_nack.
    Per spec §4.3.7.3.16: PAR must equal ~XOR(DA[6:0]).
    """
    dut._log.info("T_CC2: GETACCR wrong PAR")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    # Send target_addr=0x30, response DA=0x30 (match) but PAR inverted
    target_addr = 0x30
    correct_par = odd_parity_7bit(target_addr)
    wrong_par = (~correct_par) & 0x1  # inverted parity
    wrong_response = (target_addr << 1) | wrong_par
    r = await run_ccc(dut, 0x91, is_direct=1, target_addr=target_addr,
                      ack_recv=1, byte_recv=wrong_response)
    assert_chk.check("getaccr_wrong_par_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getaccr_wrong_par_data_nack", r['ccc_getacccr_data_nack'] == 1,
                     f"data_nack={r['ccc_getacccr_data_nack']} (expected 1, PAR wrong)")
    sb.add_expected(1); sb.add_actual(r['ccc_getacccr_data_nack'])


async def test_getaccr_all_zero_response(dut, sb, cov, assert_chk):
    """T_CC3: GETACCR with response=0x00 (DA=0, PAR=0) → data_nack.
    DA=0 is reserved, so da_match with target_addr (non-zero) fails.
    """
    dut._log.info("T_CC3: GETACCR all-zero response")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    r = await run_ccc(dut, 0x91, is_direct=1, target_addr=0x30,
                      ack_recv=1, byte_recv=0x00)
    assert_chk.check("getaccr_zero_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("getaccr_zero_data_nack", r['ccc_getacccr_data_nack'] == 1,
                     f"data_nack={r['ccc_getacccr_data_nack']} (expected 1, DA=0 mismatch)")
    sb.add_expected(1); sb.add_actual(r['ccc_getacccr_data_nack'])


async def test_rstact_broadcast(dut, sb, cov, assert_chk):
    """T_CC4: RSTACT broadcast (0x2A) — defining byte only, no payload.
    Per spec §4.3.9: RSTACT broadcast sends opcode + defining byte + STOP.
    """
    dut._log.info("T_CC4: RSTACT broadcast (0x2A)")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    # RSTACT broadcast with defining byte = 0x00 (whole device reset)
    r = await run_ccc(dut, 0x2A, is_direct=0, defining_byte=0x00,
                      has_defining_byte=1, ack_recv=1)
    assert_chk.check("rstact_b_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("rstact_b_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # Should send opcode + defining byte = 2 send_byte pulses minimum
    assert_chk.check("rstact_b_send_bytes", r['ccc_send_byte_count'] >= 2,
                     f"send_byte={r['ccc_send_byte_count']} (expected >=2)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_rstact_direct(dut, sb, cov, assert_chk):
    """T_CC5: RSTACT direct (0x9A) — defining byte + target addr, no payload.
    Per spec §4.3.9: RSTACT direct = opcode + defining byte + rep-start + target + STOP.
    """
    dut._log.info("T_CC5: RSTACT direct (0x9A)")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    r = await run_ccc(dut, 0x9A, is_direct=1, target_addr=0x20,
                      defining_byte=0x01, has_defining_byte=1, ack_recv=1)
    assert_chk.check("rstact_d_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("rstact_d_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_setmwl_broadcast(dut, sb, cov, assert_chk):
    """T_CC6: SETMWL broadcast (0x09) — 2-byte MWL payload.
    Per spec Table 16: SETMWL broadcast = 0x09, payload = MWL MSB + MWL LSB.
    """
    dut._log.info("T_CC6: SETMWL broadcast (0x09)")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.cfg_mwl.value = 0xABCD
    r = await run_ccc(dut, 0x09, is_direct=0, ack_recv=1)
    assert_chk.check("setmwl_b_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("setmwl_b_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    # opcode + 2 payload bytes = 3 send_byte
    assert_chk.check("setmwl_b_send_bytes", r['ccc_send_byte_count'] >= 3,
                     f"send_byte={r['ccc_send_byte_count']} (expected >=3)")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_setmrl_direct(dut, sb, cov, assert_chk):
    """T_CC7: SETMRL direct (0x8A) — 2-byte MRL payload to specific target.
    Per spec Table 16: SETMRL direct = 0x8A.
    """
    dut._log.info("T_CC7: SETMRL direct (0x8A)")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.cfg_mrl.value = 0x1234
    r = await run_ccc(dut, 0x8A, is_direct=1, target_addr=0x30, ack_recv=1)
    assert_chk.check("setmrl_d_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("setmrl_d_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_setmwl_direct(dut, sb, cov, assert_chk):
    """T_CC8: SETMWL direct (0x89) — 2-byte MWL payload to specific target.
    Per spec Table 16: SETMWL direct = 0x89.
    """
    dut._log.info("T_CC8: SETMWL direct (0x89)")
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.cfg_mwl.value = 0x5678
    r = await run_ccc(dut, 0x89, is_direct=1, target_addr=0x30, ack_recv=1)
    assert_chk.check("setmwl_d_done", r['ccc_done'] == 1, f"done={r['ccc_done']}")
    assert_chk.check("setmwl_d_no_error", r['ccc_error'] == 0, f"error={r['ccc_error']}")
    sb.add_expected(1); sb.add_actual(r['ccc_done'])


async def test_idle_no_req(dut, sb, cov, assert_chk):
    """T13: No ccc_req — FSM stays in IDLE, no outputs."""
    dut._log.info("T13: Idle no req")
    dut.ccc_req.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk)
    await settle()
    assert_chk.check("idle_no_start", int(dut.ccc_start.value) == 0, "ccc_start=0")
    assert_chk.check("idle_no_done", int(dut.ccc_done.value) == 0, "ccc_done=0")
    assert_chk.check("idle_no_send", int(dut.ccc_send_byte.value) == 0, "ccc_send_byte=0")
    sb.add_expected(0); sb.add_actual(int(dut.ccc_start.value))


async def test_random_cccs(dut, gen, sb, cov, assert_chk, num=10):
    """T14: Randomized CCC transactions."""
    dut._log.info(f"T14: Random CCCs ({num})")
    opcodes = [0x06, 0x07, 0x0B, 0x0C, 0xAE, 0x87, 0x88, 0x91, 0x9D, 0xA0, 0x9E, 0x9F]
    for i in range(num):
        op = gen.rng.choice(opcodes)
        is_direct = (op & 0x80) != 0
        target = gen.rng.randint(0, 0x7F) if is_direct else 0
        db = gen.rng.randint(0, 0xFF)
        has_db = gen.rng.randint(0, 1) if op in [0xAE] else 0
        byte_recv = gen.rng.randint(0, 0xFF)
        r = await run_ccc(dut, op, is_direct=is_direct, target_addr=target,
                          defining_byte=db, has_defining_byte=has_db,
                          ack_recv=1, byte_recv=byte_recv)
        assert_chk.check(f"rand_{i}_done", r['ccc_done'] == 1,
                         f"op={op:#x} done={r['ccc_done']}")
        sb.add_expected(1); sb.add_actual(r['ccc_done'])
        error_cov(r['ccc_error'])
        done_cov(r['ccc_done'])


@cocotb.test(timeout_time=500000, timeout_unit='ns')
async def main_test(dut):
    """Main CCC handler test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.ccc_req.value = 0
    dut.ccc_opcode.value = 0
    dut.ccc_is_direct.value = 0
    dut.ccc_target_addr.value = 0
    dut.ccc_defining_byte.value = 0
    dut.ccc_has_defining_byte.value = 0
    dut.cfg_mrl.value = 0x1234
    dut.cfg_mwl.value = 0x5678
    dut.prim_done.value = 0
    dut.prim_ack_recv.value = 0
    dut.prim_byte_recv.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('ccc')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('ccc')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb CCC Handler Testbench")
    dut._log.info("=" * 60)

    await test_broadcast_ccc_simple(dut, sb, cov, assert_chk)
    await test_broadcast_ccc_with_defining_byte(dut, sb, cov, assert_chk)
    await test_broadcast_ccc_setmrl(dut, sb, cov, assert_chk)
    await test_direct_ccc_simple(dut, sb, cov, assert_chk)
    await test_direct_ccc_getstatus(dut, sb, cov, assert_chk)
    await test_getaccr_accepted(dut, sb, cov, assert_chk)
    await test_getaccr_rejected(dut, sb, cov, assert_chk)
    await test_getaccr_addr_nack(dut, sb, cov, assert_chk)
    await test_opcode_nack(dut, sb, cov, assert_chk)
    await test_addr_7e_nack(dut, sb, cov, assert_chk)
    await test_setdasa(dut, sb, cov, assert_chk)
    await test_getpid(dut, sb, cov, assert_chk)
    # New corner cases for MIPI I3C Basic v1.2 compliance
    await test_getaccr_wrong_da(dut, sb, cov, assert_chk)
    await test_getaccr_wrong_par(dut, sb, cov, assert_chk)
    await test_getaccr_all_zero_response(dut, sb, cov, assert_chk)
    await test_rstact_broadcast(dut, sb, cov, assert_chk)
    await test_rstact_direct(dut, sb, cov, assert_chk)
    await test_setmwl_broadcast(dut, sb, cov, assert_chk)
    await test_setmrl_direct(dut, sb, cov, assert_chk)
    await test_setmwl_direct(dut, sb, cov, assert_chk)
    await test_idle_no_req(dut, sb, cov, assert_chk)
    await test_random_cccs(dut, gen, sb, cov, assert_chk, 10)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if total_fail > 0:
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
