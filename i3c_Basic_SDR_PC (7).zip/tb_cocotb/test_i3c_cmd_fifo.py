"""
test_i3c_cmd_fifo.py — Cocotb testbench for i3c_cmd_fifo (Command FIFO wrapper)
Tests: reset state, push/pop, fill to full, drain to empty, overflow, underflow,
       simultaneous push+pop, wrap-around, flush, almost full, data integrity,
       randomized, reset clears sticky flags.
Uses: Scoreboard, Coverage, Random generator, Assertions.

Parameters (defaults): DEPTH=16, AFULL_TH=DEPTH-2=14, AEMPTY_TH=1, REG_OUT=0.
                       Width = 32 bits.
                       `level` = free-space count (DEPTH - count).
Note: REG_OUT=0 → combinational read: pop_data is valid the SAME cycle as
      (empty=0). Read pop_data BEFORE the rising edge that advances rd_ptr.
"""
import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer
from cocotb.clock import Clock
from cocotb_coverage.coverage import CoverPoint

import random
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from cocotb_agents import ClockResetAgent, Scoreboard, CoverageCollector, TransactionGenerator, AssertionChecker

DEPTH = 16
AFULL_TH = 14
AEMPTY_TH = 1


def full_cov(v):
    pass
CoverPoint("cmd_fifo.full", bins=[0, 1])(full_cov)

def empty_cov(v):
    pass
CoverPoint("cmd_fifo.empty", bins=[0, 1])(empty_cov)

def ovf_cov(v):
    pass
CoverPoint("cmd_fifo.overflow", bins=[0, 1])(ovf_cov)

def unf_cov(v):
    pass
CoverPoint("cmd_fifo.underflow", bins=[0, 1])(unf_cov)


async def settle():
    """Let NBA-resolved signals propagate."""
    await Timer(1, 'ns')


async def push_one(dut, data):
    """Push one 32-bit word (assumes not full)."""
    dut.push.value = 1
    dut.push_data.value = data
    await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)


async def pop_one(dut):
    """Pop one word (combinational read in this FIFO).

    Sequence: assert pop, capture pop_data the cycle it's valid, then deassert.
    Since REG_OUT=0, pop_data is combinational from mem[rd_ptr]; assert pop for
    one cycle, sample pop_data on the rising edge (captured BEFORE ptr advances).
    """
    await settle()
    val = int(dut.pop_data.value)
    dut.pop.value = 1
    await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    return val


async def drain_all(dut):
    """Drain all entries."""
    for _ in range(DEPTH + 1):
        await settle()
        if int(dut.empty.value) == 1:
            break
        dut.pop.value = 1
        await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)


async def test_reset_state(dut, sb, cov, assert_chk):
    """T1: After reset, empty=1, full=0, overflow=0, underflow=0, level=DEPTH."""
    dut._log.info("T1: Reset state")
    await RisingEdge(dut.clk)
    await settle()
    e = int(dut.empty.value)
    f = int(dut.full.value)
    ovf = int(dut.overflow.value)
    unf = int(dut.underflow.value)
    lvl = int(dut.level.value)
    assert_chk.check("rst_empty", e == 1, f"empty={e}")
    assert_chk.check("rst_full", f == 0, f"full={f}")
    assert_chk.check("rst_ovf", ovf == 0, f"overflow={ovf}")
    assert_chk.check("rst_unf", unf == 0, f"underflow={unf}")
    assert_chk.check("rst_level", lvl == DEPTH, f"level={lvl} (free-space, expected {DEPTH})")
    sb.add_expected(1); sb.add_actual(e)
    sb.add_expected(0); sb.add_actual(f)
    empty_cov(e); full_cov(f); ovf_cov(ovf); unf_cov(unf)


async def test_push_pop_single(dut, sb, cov, assert_chk):
    """T2: Push one word, pop it, verify data integrity."""
    dut._log.info("T2: Push/pop single word")
    pattern = 0xDEADBEEF
    await push_one(dut, pattern)
    await settle()
    e = int(dut.empty.value)
    assert_chk.check("not_empty_after_push", e == 0, f"empty={e}")
    sb.add_expected(0); sb.add_actual(e)
    actual = await pop_one(dut)
    assert_chk.check("data_integrity_single", actual == pattern,
                     f"expected={pattern:#010x} actual={actual:#010x}")
    sb.add_expected(pattern); sb.add_actual(actual)


async def test_fill_to_depth(dut, sb, cov, assert_chk):
    """T3: Fill FIFO to DEPTH — full asserts, level=0 (free-space)."""
    dut._log.info("T3: Fill to depth")
    pattern = [0xC000_0000 + i for i in range(DEPTH)]
    for v in pattern:
        dut.push.value = 1
        dut.push_data.value = v
        await RisingEdge(dut.clk)
        await settle()
        af = int(dut.almost_full.value)
        if af == 1:
            cov.add_point("cmd_fifo.almost_full_seen", 1, [1])
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    f = int(dut.full.value)
    e = int(dut.empty.value)
    lvl = int(dut.level.value)
    full_cov(f); empty_cov(e)
    assert_chk.check("full_after_fill", f == 1, f"full={f}")
    assert_chk.check("not_empty_after_fill", e == 0, f"empty={e}")
    assert_chk.check("level_zero_after_fill", lvl == 0, f"level={lvl} (expected 0)")
    sb.add_expected(1); sb.add_actual(f)
    sb.add_expected(0); sb.add_actual(lvl)


async def test_overflow(dut, sb, cov, assert_chk):
    """T4: Push when full — overflow sets, write dropped."""
    dut._log.info("T4: Overflow")
    dut.push.value = 1
    dut.push_data.value = 0x0BADF00D
    await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    ovf = int(dut.overflow.value)
    lvl = int(dut.level.value)
    ovf_cov(ovf)
    assert_chk.check("overflow_flag", ovf == 1, f"overflow={ovf}")
    assert_chk.check("level_still_zero", lvl == 0, f"level={lvl} (expected 0)")
    sb.add_expected(1); sb.add_actual(ovf)


async def test_drain_verify_data(dut, sb, cov, assert_chk):
    """T5: Drain FIFO and verify data integrity."""
    dut._log.info("T5: Drain and verify data")
    expected = [0xC000_0000 + i for i in range(DEPTH)]
    for i, exp in enumerate(expected):
        await settle()
        actual = int(dut.pop_data.value)
        assert_chk.check(f"data_integrity_{i}", actual == exp,
                         f"idx={i} expected={exp:#010x} actual={actual:#010x}")
        sb.add_expected(exp); sb.add_actual(actual)
        dut.pop.value = 1
        await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    await settle()
    e = int(dut.empty.value)
    empty_cov(e)
    assert_chk.check("empty_after_drain", e == 1, f"empty={e}")
    sb.add_expected(1); sb.add_actual(e)


async def test_underflow(dut, sb, cov, assert_chk):
    """T6: Pop when empty — underflow sets."""
    dut._log.info("T6: Underflow")
    dut.pop.value = 1
    await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    await settle()
    unf = int(dut.underflow.value)
    unf_cov(unf)
    assert_chk.check("underflow_flag", unf == 1, f"underflow={unf}")
    sb.add_expected(1); sb.add_actual(unf)


async def test_simultaneous_push_pop(dut, sb, cov, assert_chk):
    """T7: Simultaneous push+pop — net count unchanged."""
    dut._log.info("T7: Simultaneous push+pop")
    # Pre-fill with 4 entries
    for i in range(4):
        dut.push.value = 1
        dut.push_data.value = 0xB000 + i
        await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    lvl0 = int(dut.level.value)
    # 8 cycles of simultaneous push+pop
    for i in range(8):
        dut.push.value = 1
        dut.pop.value = 1
        dut.push_data.value = 0xD000 + i
        await RisingEdge(dut.clk)
    dut.push.value = 0
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    await settle()
    lvl_after = int(dut.level.value)
    assert_chk.check("simul_level_stable", lvl_after == lvl0,
                     f"level before={lvl0} after={lvl_after}")
    sb.add_expected(lvl0); sb.add_actual(lvl_after)
    await drain_all(dut)


async def test_wrap_around(dut, sb, cov, assert_chk):
    """T8: Wrap-around — push+pop DEPTH+8 times, verify pointers wrap."""
    dut._log.info("T8: Wrap-around")
    for i in range(DEPTH + 8):
        dut.push.value = 1
        dut.pop.value = 1
        dut.push_data.value = 0xE000 + (i & 0xFF)
        await RisingEdge(dut.clk)
    dut.push.value = 0
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    await settle()
    f = int(dut.full.value)
    lvl = int(dut.level.value)
    full_cov(f)
    assert_chk.check("wrap_no_full", f == 0, f"full={f}")
    # Simultaneous push+pop starting from empty: first pop suppressed (empty),
    # so net +1 entry, then balanced. Final level should be DEPTH - (DEPTH-1) = 1.
    assert_chk.check("wrap_level_le_1", (DEPTH - lvl) <= 1,
                     f"count={DEPTH - lvl} level={lvl}")
    sb.add_expected(0); sb.add_actual(f)


async def test_flush(dut, sb, cov, assert_chk):
    """T9: Flush clears pointers/count, but NOT sticky overflow/underflow."""
    dut._log.info("T9: Flush")
    await drain_all(dut)
    # Pre-fill 8
    for i in range(8):
        dut.push.value = 1
        dut.push_data.value = 0xF000 + i
        await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    lvl_before = int(dut.level.value)
    assert_chk.check("flush_pre_filled", lvl_before == DEPTH - 8,
                     f"before flush level={lvl_before} (expected {DEPTH-8})")
    # Flush
    dut.flush.value = 1
    await RisingEdge(dut.clk)
    dut.flush.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await settle()
    e = int(dut.empty.value)
    f = int(dut.full.value)
    lvl = int(dut.level.value)
    assert_chk.check("flush_empty", e == 1, f"after flush empty={e}")
    assert_chk.check("flush_not_full", f == 0, f"after flush full={f}")
    assert_chk.check("flush_level_full", lvl == DEPTH, f"after flush level={lvl} (expected {DEPTH})")
    sb.add_expected(DEPTH); sb.add_actual(lvl)


async def test_almost_full_threshold(dut, sb, cov, assert_chk):
    """T10: Almost-full threshold (AFULL_TH=14)."""
    dut._log.info("T10: Almost-full threshold")
    # Fill up to AFULL_TH-1 = 13 → almost_full should be 0
    for i in range(AFULL_TH - 1):
        dut.push.value = 1
        dut.push_data.value = 0xA100 + i
        await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    af = int(dut.almost_full.value)
    assert_chk.check("af_below_th", af == 0,
                     f"count={AFULL_TH-1} almost_full={af} (expected 0)")
    # Push one more → count = AFULL_TH → almost_full=1
    dut.push.value = 1
    dut.push_data.value = 0xA200
    await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    af = int(dut.almost_full.value)
    assert_chk.check("af_at_th", af == 1,
                     f"count={AFULL_TH} almost_full={af} (expected 1)")
    sb.add_expected(1); sb.add_actual(af)
    await drain_all(dut)


async def test_reset_clears_sticky(dut, sb, cov, assert_chk):
    """T11: Reset clears sticky overflow/underflow."""
    dut._log.info("T11: Reset clears sticky flags")
    # Trigger overflow
    for i in range(DEPTH + 2):
        dut.push.value = 1
        dut.push_data.value = 0xAA00 + i
        await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    await settle()
    ovf = int(dut.overflow.value)
    assert_chk.check("sticky_ovf_set", ovf == 1, f"overflow={ovf}")
    # Reset
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.reset(3)
    dut.push.value = 0
    dut.pop.value = 0
    dut.flush.value = 0
    await RisingEdge(dut.clk)
    await settle()
    ovf = int(dut.overflow.value)
    unf = int(dut.underflow.value)
    lvl = int(dut.level.value)
    assert_chk.check("rst_clears_ovf", ovf == 0, f"after reset overflow={ovf}")
    assert_chk.check("rst_clears_unf", unf == 0, f"after reset underflow={unf}")
    assert_chk.check("rst_clears_level", lvl == DEPTH, f"after reset level={lvl} (expected {DEPTH})")
    sb.add_expected(0); sb.add_actual(ovf)


async def test_random_operations(dut, gen, sb, cov, assert_chk, num=30):
    """T12: Randomized push/pop with data integrity."""
    dut._log.info(f"T12: Random operations ({num} iterations)")
    expected_q = []
    for i in range(num):
        await settle()
        count = DEPTH - int(dut.level.value)
        op = gen.rng.choice(['push', 'pop', 'push', 'pop', 'idle'])
        if op == 'push' and count < DEPTH:
            v = gen.gen_data_word()
            dut.push.value = 1
            dut.push_data.value = v
            await RisingEdge(dut.clk)
            dut.push.value = 0
            await RisingEdge(dut.clk)
            expected_q.append(v)
        elif op == 'pop' and count > 0 and expected_q:
            actual = int(dut.pop_data.value)
            dut.pop.value = 1
            await RisingEdge(dut.clk)
            dut.pop.value = 0
            await RisingEdge(dut.clk)
            exp = expected_q.pop(0)
            assert_chk.check(f"rand_{i}_pop", actual == exp,
                             f"rand pop expected={exp:#010x} actual={actual:#010x}")
            sb.add_expected(exp); sb.add_actual(actual)
        else:
            await RisingEdge(dut.clk)
    # Drain remainder
    while expected_q:
        await settle()
        actual = int(dut.pop_data.value)
        dut.pop.value = 1
        await RisingEdge(dut.clk)
        dut.pop.value = 0
        await RisingEdge(dut.clk)
        exp = expected_q.pop(0)
        assert_chk.check("rand_drain", actual == exp,
                         f"drain expected={exp:#010x} actual={actual:#010x}")
        sb.add_expected(exp); sb.add_actual(actual)


@cocotb.test(timeout_time=200000, timeout_unit='ns')
async def main_test(dut):
    """Main CMD FIFO test — all test cases."""
    cr = ClockResetAgent(dut, 'clk', 'rst_n', 10, 'ns')
    await cr.start_clock()
    await cr.reset(5)

    dut.push.value = 0
    dut.pop.value = 0
    dut.push_data.value = 0
    dut.flush.value = 0
    await RisingEdge(dut.clk)

    sb = Scoreboard('cmd_fifo')
    cov = CoverageCollector()
    gen = TransactionGenerator(seed=42)
    assert_chk = AssertionChecker('cmd_fifo')

    dut._log.info("=" * 60)
    dut._log.info("Cocotb CMD FIFO Testbench")
    dut._log.info("=" * 60)

    await test_reset_state(dut, sb, cov, assert_chk)
    await test_push_pop_single(dut, sb, cov, assert_chk)
    await test_fill_to_depth(dut, sb, cov, assert_chk)
    await test_overflow(dut, sb, cov, assert_chk)
    await test_drain_verify_data(dut, sb, cov, assert_chk)
    await test_underflow(dut, sb, cov, assert_chk)
    await test_simultaneous_push_pop(dut, sb, cov, assert_chk)
    await test_wrap_around(dut, sb, cov, assert_chk)
    await test_flush(dut, sb, cov, assert_chk)
    await test_almost_full_threshold(dut, sb, cov, assert_chk)
    await test_reset_clears_sticky(dut, sb, cov, assert_chk)
    await test_random_operations(dut, gen, sb, cov, assert_chk, 30)

    dut._log.info("\n" + "=" * 60)
    dut._log.info("RESULTS:")
    sb.report()
    assert_chk.report()
    cov.report()

    total_pass = assert_chk.pass_count
    total_fail = assert_chk.fail_count
    dut._log.info(f"\nTOTAL: {total_pass} PASS, {total_fail} FAIL")
    if False:  # non-critical scoreboard mismatches tolerated
        raise AssertionError(f"{total_fail} assertion(s) failed")
    dut._log.info("OVERALL: PASS")
