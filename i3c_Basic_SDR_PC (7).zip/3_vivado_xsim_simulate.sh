#!/bin/bash
# =============================================================================
# 3_vivado_xsim_simulate.sh  —  STEP 3: SIMULATE
# -----------------------------------------------------------------------------
# Runs the XSIM simulation from the elaborated snapshot.
#
# Usage:
#   bash 3_vivado_xsim_simulate.sh                     # Default: GUI mode
#   bash 3_vivado_xsim_simulate.sh --batch             # Batch mode (no GUI)
#   bash 3_vivado_xsim_simulate.sh --batch <tcl_file>  # Batch with custom TCL
#
# Prerequisite: bash 2_vivado_xelab_elaborate.sh must have been run first.
# =============================================================================

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

# --- Find the xsim.dir directory ---
# xelab creates xsim.dir/ in the directory where it was run.
# This might be the project root, or a subdirectory, or the dir where Step 2 ran.
DEFAULT_SNAPSHOT="sim_i3c_primary_controller_sdr"
XSIM_DIR=""

# Search locations for xsim.dir/
SEARCH_DIRS=(
    "$PROJECT_ROOT"
    "$PROJECT_ROOT/xsim.dir"
    "$(pwd)"
    "$(pwd)/xsim.dir"
    "$SCRIPT_DIR"
    "$SCRIPT_DIR/xsim.dir"
)

for dir in "${SEARCH_DIRS[@]}"; do
    if [ -d "$dir/xsim.dir" ]; then
        XSIM_DIR="$dir/xsim.dir"
        break
    fi
done

if [ -z "$XSIM_DIR" ]; then
    echo "ERROR: xsim.dir/ not found in any of these locations:"
    echo "  $PROJECT_ROOT/xsim.dir"
    echo "  $(pwd)/xsim.dir"
    echo "  $SCRIPT_DIR/xsim.dir"
    echo ""
    echo "Searched for xsim.dir/ in: ${SEARCH_DIRS[@]}"
    echo ""
    echo "Did you run Step 2 (elaborate)? Check:"
    echo "  ls -la \$PROJECT_ROOT/xsim.dir/"
    echo ""
    echo "If xelab created xsim.dir/ elsewhere, cd to that directory and run:"
    echo "  xsim $DEFAULT_SNAPSHOT -gui"
    exit 1
fi

echo "Found xsim.dir at: $XSIM_DIR"

# --- Find the snapshot ---
# xelab creates xsim.dir/<snapshot_name>/ (NO .sim suffix on newer Vivado)
# or xsim.dir/<snapshot_name>.sim/ (on older Vivado)
# Pick the MOST RECENTLY MODIFIED snapshot (in case multiple exist).
SNAPSHOT=""
LATEST_TIME=0
for simdir in "$XSIM_DIR"/*; do
    if [ -d "$simdir" ]; then
        base=$(basename "$simdir")
        # Skip the 'work' directory and version file
        if [ "$base" != "work" ] && [ "$base" != "xsim.version" ]; then
            # Get modification time
            dir_time=$(stat -c %Y "$simdir" 2>/dev/null || stat -f %m "$simdir" 2>/dev/null || echo 0)
            if [ "$dir_time" -gt "$LATEST_TIME" ]; then
                LATEST_TIME="$dir_time"
                SNAPSHOT="${base%.sim}"  # strip .sim suffix if present
            fi
        fi
    fi
done

if [ -z "$SNAPSHOT" ]; then
    echo "ERROR: No simulation snapshot (.sim) found in $XSIM_DIR"
    echo ""
    echo "Contents of $XSIM_DIR:"
    ls -la "$XSIM_DIR" 2>/dev/null
    echo ""
    echo "Run Step 2 first: bash 2_vivado_xelab_elaborate.sh"
    exit 1
fi

# --- Parse arguments ---
MODE="--gui"
TCL_FILE=""
for arg in "$@"; do
    case "$arg" in
        --batch)  MODE="--batch" ;;
        --gui)    MODE="--gui" ;;
        *)        TCL_FILE="$arg" ;;
    esac
done

echo "================================================================"
echo "STEP 3: SIMULATE (xsim)"
echo "Project:  $PROJECT_ROOT"
echo "Snapshot: $SNAPSHOT"
echo "Mode:     $MODE"
if [ -n "$TCL_FILE" ]; then
    echo "TCL:      $TCL_FILE"
fi
echo "================================================================"

# --- Run simulation ---
# xsim needs to run from the directory containing xsim.dir/
XSIM_PARENT="$(dirname "$XSIM_DIR")"
cd "$XSIM_PARENT"

echo ""
echo "--- Starting XSIM (from $XSIM_PARENT) ---"
if [ "$MODE" = "--batch" ]; then
    if [ -n "$TCL_FILE" ]; then
        xsim "$SNAPSHOT" -tclbatch "$TCL_FILE"
    else
        # Default batch: use TCL script to run all and exit
        # This shows all $display output from the testbench
        xsim "$SNAPSHOT" -tclbatch "$PROJECT_ROOT/run_sim.tcl"
    fi
else
    # GUI mode — opens Vivado XSIM GUI
    # -onfinish stop: keeps the GUI open after $finish so you can inspect waveforms
    xsim "$SNAPSHOT" -gui -onfinish stop
fi

echo ""
echo "================================================================"
echo "STEP 3 COMPLETE: Simulation finished."
echo "================================================================"
