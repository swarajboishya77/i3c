#!/bin/bash
# =============================================================================
# 1_vivado_compile.sh  —  STEP 1: COMPILE
# -----------------------------------------------------------------------------
# Compiles all RTL files with xvlog (Vivado XSIM compiler).
# i3c_pkg.sv is compiled FIRST (required by VRFC 10-2989).
#
# Usage:
#   bash 1_vivado_xvlog_compile.sh
#
# Output: xsim.dir/ directory with compiled work library
# Next:   bash 2_vivado_xelab_elaborate.sh
# =============================================================================

set -e

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

echo "================================================================"
echo "STEP 1: COMPILE (xvlog)"
echo "  Cleaning previous compilation logs..."
rm -rf xvlog_logs
mkdir -p xvlog_logs
echo "Project: $PROJECT_ROOT"
echo "================================================================"

# --- Step 1a: Compile SV package FIRST ---
echo ""
echo "--- Compiling i3c_pkg.sv (MUST be first) ---"
xvlog -sv rtl/include/i3c_pkg.sv

# --- Step 1b: Compile all leaf modules ---
echo ""
echo "--- Compiling RTL modules (32 files) ---"
xvlog -sv \
  rtl/io_pad/io_buf.sv \
  rtl/dnf/i3c_dnf.sv \
  rtl/pec/i3c_pec.sv \
  rtl/digital_phy/i3c_timing_control.sv \
  rtl/digital_phy/i3c_start_stop_gen.sv \
  rtl/digital_phy/i3c_phy_fsm.sv \
  rtl/digital_phy/i3c_phy_mux.sv \
  rtl/ccc/i3c_ccc_handler.sv \
  rtl/daa/i3c_daa.sv \
  rtl/ibi/i3c_ibi_handler.sv \
  rtl/hj/i3c_hotjoin_handler.sv \
  rtl/group/i3c_group_addr.sv \
  rtl/wake/i3c_wake_detector.sv \
  rtl/target/i3c_target_engine.sv \
  rtl/target/i3c_ccc_event_decoder.sv \
  rtl/target/i3c_target_table.sv \
  rtl/role/i3c_role_manager.sv \
  rtl/clock/i3c_clock_gate.sv \
  rtl/clock/i3c_async_fifo.sv \
  rtl/power/i3c_power_controller.sv \
  rtl/controller/byte_serdes_i3c.sv \
  rtl/controller/byte_serdes_i2c.sv \
  rtl/controller/i2c_controller_fsm.sv \
  rtl/controller/i2c_prescaler.sv \
  rtl/fifo/i3c_fifo.sv \
  rtl/fifo/i3c_cmd_fifo.sv \
  rtl/fifo/i3c_wr_fifo.sv \
  rtl/fifo/i3c_rd_fifo.sv \
  rtl/fifo/i3c_resp_fifo.sv \
  rtl/axi/axi4_lite_slave.sv \
  rtl/register_map/i3c_register_file.sv \
  rtl/register_map/i2c_register_file.sv

# --- Step 1c: Compile top-level controller LAST ---
echo ""
echo "--- Compiling top-level controller ---"
xvlog -sv rtl/controller/i3c_primary_controller_sdr.sv

# --- Step 1d: Compile testbenches (for simulation) ---
echo ""
echo "--- Compiling testbenches ---"
# SVA properties (needed by tb_sva_formal) — compile FIRST, show errors

output=$(xvlog -sv tb/i3c_sva_formal_properties.sv 2>&1) || true
if echo "$output" | grep -qE "^ERROR: \[[A-Z0-9-]+"; then
    log_file="xvlog_logs/i3c_sva_formal_properties.sv.log"
    echo "  FAIL: i3c_sva_formal_properties.sv (see ${log_file})"
    echo "$output" > "$log_file"
else
    echo "  OK: i3c_sva_formal_properties.sv"
fi
# All SV testbenches — don't stop on errors, continue to next TB
TB_ERRORS=0
for tb_file in tb/tb_*.sv; do
    [ -f "$tb_file" ] || continue
    tb_name=$(basename "$tb_file")
    # Run xvlog and capture output — don't let set -e kill the script
    output=$(xvlog -sv "$tb_file" 2>&1) || true
    if echo "$output" | grep -qE "^ERROR: \[[A-Z0-9-]+"; then
        log_file="xvlog_logs/${tb_name}.log"
        echo "  FAIL: $tb_name (see ${log_file})"
        echo "$output" > "$log_file"
        TB_ERRORS=$((TB_ERRORS + 1))
    else
        echo "  OK: $tb_name"
    fi
done

# --- Step 1e: Compile UVM testbenches (for simulation) ---
echo ""
echo "--- Compiling UVM testbenches ---"
# First, compile the package file which is a dependency for all other UVM tests.
if [ -f "tb_uvm/i3c_uvm_pkg.sv" ]; then
    output=$(xvlog -sv "tb_uvm/i3c_uvm_pkg.sv" 2>&1) || true
    if echo "$output" | grep -qE "^ERROR: \[[A-Z0-9-]+"; then
        log_file="xvlog_logs/i3c_uvm_pkg.sv.log"
        echo "  FAIL: i3c_uvm_pkg.sv (see ${log_file})"
        echo "$output" > "$log_file"
        TB_ERRORS=$((TB_ERRORS + 1))
    else
        echo "  OK: i3c_uvm_pkg.sv"
    fi
fi

# Now, automatically find and compile all UVM testbenches using a glob.
for tb_file in tb_uvm/tb_uvm_*.sv; do
    [ -f "$tb_file" ] || continue
    tb_name=$(basename "$tb_file")
    output=$(xvlog -sv "$tb_file" 2>&1) || true
    if echo "$output" | grep -qE "^ERROR: \[[A-Z0-9-]+"; then
        log_file="xvlog_logs/${tb_name}.log"
        echo "  FAIL: $tb_name (see ${log_file})"
        echo "$output" > "$log_file"
        TB_ERRORS=$((TB_ERRORS + 1))
    else
        echo "  OK: $tb_name"
    fi
done

echo ""
echo "================================================================"
echo "STEP 1 COMPLETE: Compile done."
echo "Output: xsim.dir/ (compiled work library)"
if [ $TB_ERRORS -gt 0 ]; then
    echo ""
    echo "WARNING: $TB_ERRORS testbench(es) had compile errors (see above)."
    echo "Testbenches that compiled OK can still be used in Step 2."
fi
echo ""
echo "Available top modules for Step 2:"
echo "  i3c_primary_controller_sdr    (DUT only — no testbench)"
echo "  tb_axi_corner_cases           (AXI4-Lite testbench — 78 tests)"
echo "  tb_i3c_transaction_e2e        (I3C transaction E2E — 11 tests)"
echo "  tb_i3c_role_manager           (role manager testbench — 33 tests)"
echo ""
echo "NEXT: bash 2_vivado_xelab_elaborate.sh <top_module>"
echo "  Example: bash 2_vivado_xelab_elaborate.sh tb_axi_corner_cases"
echo "================================================================"
