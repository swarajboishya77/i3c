// =============================================================================
// tb_i3c_submodule_audit_v2.sv
// Comprehensive submodule + corner-case testbench
// Tests: CCC, DAA, Target Engine, PHY FSM, HJ Handler, IBI Handler
// All tests in a SINGLE initial block with proper reset timing
// =============================================================================


module tb_i3c_submodule_audit_v2;

    logic clk = 1'b0;
    logic rst_n = 1'b0;
    always #5000 clk = ~clk;

    integer pass_count = 0;
    integer ii;
    integer fail_count = 0;
    integer test_num = 0;

    task check(input [255:0] name, input condition);
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // =====================================================================
    // DUT INSTANTIATIONS
    // =====================================================================

    // --- CCC Handler ---
    logic        ccc_req = 0, ccc_is_direct = 0;
    logic [7:0]  ccc_opcode = 0;
    logic [6:0]  ccc_target_addr = 0;
    logic [15:0] ccc_defining_byte = 0;
    logic        ccc_has_defining_byte = 0;
    logic        prim_done = 0, prim_ack_recv = 0;
    logic [7:0]  prim_byte_recv = 0;
    logic        ccc_start_w, ccc_repeat_start_w, ccc_stop_w;
    logic        ccc_send_addr_w_w, ccc_send_addr_r_w;
    logic [6:0]  ccc_addr_val_w;
    logic        ccc_send_byte_w, ccc_recv_byte_w, ccc_expect_response_w;
    logic        ccc_done_w, ccc_resp_valid_w;
    logic [7:0]  ccc_resp_byte_w;
    logic        ccc_getacccr_ack_w, ccc_getacccr_addr_nack_w, ccc_getacccr_data_nack_w;
    logic        ccc_error_w;

    i3c_ccc_handler u_ccc (
        .clk(clk), .rst_n(rst_n),
        .cfg_mwl(16'hFFFF), .cfg_mrl(16'hFFFF),
        .ccc_req(ccc_req), .ccc_is_direct(ccc_is_direct),
        .ccc_opcode(ccc_opcode), .ccc_target_addr(ccc_target_addr),
        .ccc_defining_byte(ccc_defining_byte),
        .ccc_has_defining_byte(ccc_has_defining_byte),
        .prim_done(prim_done), .prim_ack_recv(prim_ack_recv),
        .prim_byte_recv(prim_byte_recv),
        .ccc_start(ccc_start_w), .ccc_repeat_start(ccc_repeat_start_w),
        .ccc_stop(ccc_stop_w),
        .ccc_send_addr_w(ccc_send_addr_w_w), .ccc_send_addr_r(ccc_send_addr_r_w),
        .ccc_addr_val(ccc_addr_val_w),
        .ccc_send_byte(ccc_send_byte_w), .ccc_byte_val(),
        .ccc_recv_byte(ccc_recv_byte_w),
        .ccc_expect_response(ccc_expect_response_w),
        .ccc_done(ccc_done_w), .ccc_resp_valid(ccc_resp_valid_w),
        .ccc_resp_byte(ccc_resp_byte_w),
        .ccc_getacccr_ack(ccc_getacccr_ack_w),
        .ccc_getacccr_addr_nack(ccc_getacccr_addr_nack_w),
        .ccc_getacccr_data_nack(ccc_getacccr_data_nack_w),
        .ccc_error(ccc_error_w)
    );

    // --- HJ Handler ---
    logic        hj_enable = 0, hj_auto_daa = 0;
    logic        controller_idle = 1, bus_idle_hj = 1;
    logic        sda_i_hj = 1, scl_i_hj = 1;
    logic        hj_trigger_daa_w, hj_detected_w, hj_pending_w;
    logic        hj_clear = 0, ibi_active = 0;

    i3c_hotjoin_handler #(.DEBOUNCE_CYCLES(3)) u_hj (
        .clk(clk), .rst_n(rst_n),
        .hj_enable(hj_enable), .hj_auto_daa(hj_auto_daa),
        .controller_idle(controller_idle), .bus_idle(bus_idle_hj),
        .sda_i(sda_i_hj), .scl_i(scl_i_hj),
        .hj_trigger_daa(hj_trigger_daa_w),
        .hj_detected(hj_detected_w), .hj_pending(hj_pending_w),
        .hj_clear(hj_clear), .ibi_active(ibi_active)
    );

    // --- PHY FSM ---
    logic        cmd_start = 0, cmd_stop = 0, cmd_bit_xfer = 0, cmd_bit_xfer_od = 0;
    logic        cmd_drive_scl_low = 0, cmd_release_bus = 0;
    logic        sda_drive_val = 1, mode_pushpull = 1;
    logic        phy_done_w, phy_busy_w, sda_sampled_w, stretch_w;
    logic        phy_sda_o, phy_sda_oe, phy_scl_o, phy_scl_oe;
    logic        phy_sda_i = 1, phy_scl_i = 1;

    i3c_phy_fsm u_phy (
        .clk(clk), .rst_n(rst_n),
        .cfg_scl_high_time(18'd4), .cfg_scl_low_time(18'd4),
        .cfg_sda_hold_time(18'd4), .cfg_bus_free_time(18'd10),
        .cfg_tsu_start(18'd4), .cfg_thd_start(18'd4), .cfg_tsu_stop(18'd4),
        .cfg_scl_od_high_time(18'd26), .cfg_scl_od_low_time(18'd50),
        .bus_type(2'd1), .cfg_scl_high_time_mixed(18'd4),
        .cmd_start(cmd_start), .cmd_repeat_start(1'b0),
        .cmd_stop(cmd_stop), .cmd_drive_scl_low(cmd_drive_scl_low),
        .cmd_release_bus(cmd_release_bus),
        .cmd_bit_xfer(cmd_bit_xfer), .cmd_bit_xfer_od(cmd_bit_xfer_od),
        .sda_drive_val(sda_drive_val), .mode_pushpull(mode_pushpull),
        .done(phy_done_w), .busy(phy_busy_w),
        .sda_sampled(sda_sampled_w), .stretch_detected(stretch_w),
        .sda_o(phy_sda_o), .sda_oe(phy_sda_oe),
        .scl_o(phy_scl_o), .scl_oe(phy_scl_oe),
        .sda_i(phy_sda_i), .scl_i(phy_scl_i)
    );

    // --- Target Engine ---
    logic        target_en = 0;
    logic [6:0]  target_dyn_addr = 7'h08;
    logic        target_ibi_en = 0;
    logic        reclaim_test_active = 0;
    logic        target_addressed_w, target_busy_w;
    logic        target_rx_done_w;
    logic [7:0]  target_rx_byte_w;
    logic        target_tx_req_w;
    logic [7:0]  target_tx_byte = 0;
    logic        target_tx_valid = 0;
    logic        target_ibi_req_w;
    logic        tgt_sda_o_w, tgt_sda_oe_w;
    logic        target_nack_sent_w, role_return_w;
    logic        scl_filt_t = 1, sda_filt_t = 1;
    logic        scl_filt_rst_n_t = 1;

    i3c_target_engine u_target (
        .clk_sys(clk), .rst_sys_n(rst_n),
        .scl_filt(scl_filt_t), .sda_filt(sda_filt_t),
        .scl_filt_rst_n(scl_filt_rst_n_t),
        .target_en(target_en), .target_dyn_addr(target_dyn_addr),
        .target_ibi_en(target_ibi_en),
        .reclaim_test_active(reclaim_test_active),
        .target_addressed(target_addressed_w), .target_busy(target_busy_w),
        .target_rx_done(target_rx_done_w), .target_rx_byte(target_rx_byte_w),
        .target_tx_req(target_tx_req_w),
        .target_tx_byte(target_tx_byte), .target_tx_valid(target_tx_valid),
        .target_ibi_req(target_ibi_req_w),
        .tgt_sda_o(tgt_sda_o_w), .tgt_sda_oe(tgt_sda_oe_w),
        .target_nack_sent(target_nack_sent_w),
        .role_return(role_return_w),
        .ccc_getrtgl_byte(8'h00), .ccc_getrtgl_valid(1'b0)
    );

    // --- IBI Handler ---
    logic        ibi_enable = 0;
    logic        bus_idle_ibi = 1, controller_idle_ibi = 1;
    logic        sda_i_ibi = 1, scl_i_ibi = 1;
    logic        ibi_req_bus_w, ibi_req_start_w, ibi_req_recv_byte_w, ibi_req_nack_w, ibi_req_stop_w;
    logic        bus_done_ibi = 0, bus_ack_recv_ibi = 0;
    logic [7:0]  bus_byte_rx_ibi = 0;
    logic        ibi_fifo_push_w;
    logic [31:0] ibi_fifo_push_data_w;
    logic        ibi_irq_w, ibi_active_w;
    logic        crr_received_w;
    logic [6:0]  crr_dev_addr_w;
    logic [6:0]  ibi_detected_addr_w;

    // IBI handler target table arrays — use logic arrays instead of pattern
    logic [6:0]  tgt_da_arr  [0:15];
    logic [7:0]  tgt_bcr_arr [0:15];
    logic [15:0] tgt_mrl_arr [0:15];
    logic [7:0]  tgt_ibi_arr [0:15];
    logic        tgt_val_arr [0:15];

    i3c_ibi_handler u_ibi (
        .clk(clk), .rst_n(rst_n),
        .ibi_enable(ibi_enable),
        .bus_idle(bus_idle_ibi), .controller_idle(controller_idle_ibi),
        .sda_i(sda_i_ibi), .scl_i(scl_i_ibi),
        .ibi_req_bus(ibi_req_bus_w), .ibi_req_start(ibi_req_start_w),
        .ibi_req_recv_byte(ibi_req_recv_byte_w), .ibi_req_nack(ibi_req_nack_w),
        .ibi_req_stop(ibi_req_stop_w),
        .bus_done(bus_done_ibi), .bus_ack_recv(bus_ack_recv_ibi),
        .bus_byte_rx(bus_byte_rx_ibi),
        .ibi_fifo_push(ibi_fifo_push_w), .ibi_fifo_push_data(ibi_fifo_push_data_w),
        .ibi_irq(ibi_irq_w), .ibi_active(ibi_active_w),
        .crr_received(crr_received_w), .crr_dev_addr(crr_dev_addr_w),
        .hj_received(),
        .ibi_detected_addr(),
        .ibi_lookup_da(), .ibi_lookup_idx(), .ibi_lookup_valid(),
        .ibi_lookup_mrl(), .ibi_lookup_ibi_max(), .ibi_lookup_bcr()
    );

    // =====================================================================
    // HELPER: Drive SDA falling edge on HJ bus
    // =====================================================================
    task hj_fire_sda_fall;
        begin
            sda_i_hj = 1'b1; scl_i_hj = 1'b1;
            @(posedge clk);
            @(posedge clk);
            sda_i_hj = 1'b0; // SDA falls while SCL high
            // BUGFIX: need 2 (sync) + 1 (detect) + 3 (debounce) + 1 (detected) + margin = 10 cycles
            repeat(10) @(posedge clk); // debounce (DEBOUNCE_CYCLES=3) + 2-flop sync
        end
    endtask

    // =====================================================================
    // MAIN TEST SEQUENCE — ALL IN ONE INITIAL BLOCK
    // =====================================================================
    initial begin
        $dumpfile("/tmp/tb_audit_v2.vcd");
        $dumpvars(0, tb_i3c_submodule_audit_v2);

        // ===== RESET =====
        rst_n = 1'b0;
        $monitor("[%0t] rst=%b clear=%b detected_q=%b state=%0d", $time, rst_n, hj_clear, hj_detected_w, u_hj.state);
        repeat(10) @(posedge clk);
        rst_n = 1'b1;
        repeat(10) @(posedge clk);

        // =============================================================
        // CCC HANDLER TESTS
        // =============================================================

        // T1: CCC broadcast — ENEC (0x00), no defining byte
        test_num = 1;
        ccc_req = 1'b1; ccc_is_direct = 1'b0; ccc_opcode = 8'h00;
        ccc_has_defining_byte = 1'b0;
        @(posedge clk); ccc_req = 1'b0;

        // Wait for ccc_start (1-cycle pulse — check immediately when detected)
        fork begin wait(ccc_start_w); end begin repeat(100) @(posedge clk); end join_any
        disable fork;
        check("CCC: ccc_start asserted for broadcast", ccc_start_w);
        @(posedge clk); // wait for FSM to enter C_ADDR_7E_W
        #1;

        // Simulate ACK on 0x7E address
        prim_done = 1'b1; prim_ack_recv = 1'b1; // byte send
        @(posedge clk); prim_done = 1'b0;
        repeat(2) @(posedge clk);
        prim_done = 1'b1; prim_ack_recv = 1'b1; // ACK phase
        @(posedge clk); prim_done = 1'b0;

        // Wait for opcode send
        fork
            begin
                wait (ccc_send_byte_w || ccc_done_w);
            end
            begin
                repeat(10) @(posedge clk);
            end
        join_any
        disable fork;
        
        #1;
        check("CCC: opcode phase reached", ccc_send_byte_w || ccc_done_w);

        // Complete remaining cycles with ACK
        begin: ccc_loop1
            integer i;
            for (i = 0; i < 20; i = i + 1) begin
                if (ccc_done_w) begin i = 20; end
                else begin
                    prim_done = 1'b1; prim_ack_recv = 1'b1;
                    @(posedge clk); prim_done = 1'b0;
                    // wait for next state before asserting again
                    repeat(2) @(posedge clk);
                end
            end
        end
        check("CCC: ccc_done asserted", ccc_done_w);
        check("CCC: no error", !ccc_error_w);
        repeat(5) @(posedge clk);

        // T2: CCC with NACK on address — should go to error
        test_num = 2;
        ccc_req = 1'b1; ccc_is_direct = 1'b0; ccc_opcode = 8'h01; // DISEC
        ccc_has_defining_byte = 1'b1; ccc_defining_byte = 16'h0001;
        @(posedge clk); ccc_req = 1'b0;
        
        fork begin wait(ccc_start_w); end begin repeat(100) @(posedge clk); end join_any
        disable fork;
        @(posedge clk); // wait for FSM to enter C_ADDR_7E_W
        #1;

        // ACK the START and 0x7E address byte send, then NACK the ACK phase
        prim_done = 1'b1; prim_ack_recv = 1'b1; // ACK the 0x7E byte send
        @(posedge clk); prim_done = 1'b0;
        repeat(2) @(posedge clk);
        // Now NACK the address ACK phase
        prim_done = 1'b1; prim_ack_recv = 1'b0; // NACK
        @(posedge clk); prim_done = 1'b0;
        
        $display("[%0t] T2: Sent NACK, waiting...", $time);
        
        // Wait for ccc_error_w or ccc_done_w to assert
        fork
            begin
                wait (ccc_error_w || ccc_done_w);
                $display("[%0t] T2: wait finished! ccc_error_w=%b, ccc_done_w=%b, state=%0d", $time, ccc_error_w, ccc_done_w, u_ccc.state);
            end
            begin
                repeat(20) @(posedge clk);
                $display("[%0t] T2: timeout reached! state=%0d", $time, u_ccc.state);
            end
        join_any
        disable fork;
        
        #1;
        check("CCC: NACK produces error or done", ccc_error_w || ccc_done_w);
        repeat(5) @(posedge clk);

        // =============================================================
        // HJ HANDLER TESTS
        // =============================================================

        // T3: HJ detection — SDA falls while SCL high, bus idle
        test_num = 3;
        hj_enable = 1'b1; hj_auto_daa = 1'b1;
        bus_idle_hj = 1'b1; controller_idle = 1'b1;
        ibi_active = 1'b0;
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(5) @(posedge clk);

        // Generate SDA falling edge while SCL high
        hj_fire_sda_fall;

        check("HJ: hj_detected after SDA fall + debounce", hj_detected_w);

        // T4: HJ should NOT fire when bus is NOT idle
        test_num = 4;
        hj_clear = 1'b1; @(posedge clk); #1 hj_clear = 1'b0;
        repeat(5) @(posedge clk);
        $display("[%0t] T4: After clear, hj_detected_w=%b, state=%0d", $time, hj_detected_w, u_hj.state);
        bus_idle_hj = 1'b0; // bus busy
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(3) @(posedge clk);
        sda_i_hj = 1'b0; // falling edge while bus busy
        repeat(5) @(posedge clk);
        #1;
        $display("[%0t] T4: After fall, hj_detected_w=%b, state=%0d", $time, hj_detected_w, u_hj.state);
        check("HJ: no detection when bus_busy", !hj_detected_w);
        bus_idle_hj = 1'b1;

        // T5: HJ should NOT fire when ibi_active
        test_num = 5;
        hj_clear = 1'b1; @(posedge clk); #1 hj_clear = 1'b0;  // BUGFIX: clear sticky hj_detected
        repeat(2) @(posedge clk);
        ibi_active = 1'b1;
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(3) @(posedge clk);
        sda_i_hj = 1'b0;
        repeat(10) @(posedge clk);  // BUGFIX: 10 cycles for 2-flop sync + debounce
        #1;
        check("HJ: no detection when ibi_active", !hj_detected_w);
        ibi_active = 1'b0;

        // T6: HJ should NOT fire when hj_enable=0
        test_num = 6;
        hj_clear = 1'b1; @(posedge clk); hj_clear = 1'b0;  // BUGFIX: clear sticky hj_detected
        repeat(2) @(posedge clk);
        hj_enable = 1'b0;
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(3) @(posedge clk);
        sda_i_hj = 1'b0;
        repeat(10) @(posedge clk);  // BUGFIX: 10 cycles for 2-flop sync + debounce
        #1;
        check("HJ: no detection when disabled", !hj_detected_w);
        hj_enable = 1'b1;

        // T7: HJ clear via hj_clear
        test_num = 7;
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(3) @(posedge clk);
        sda_i_hj = 1'b0;
        // BUGFIX: need 10 cycles for 2-flop sync + debounce
        repeat(10) @(posedge clk);
        // hj_detected should be set
        if (hj_detected_w) begin
            hj_clear = 1'b1; @(posedge clk); @(posedge clk); hj_clear = 1'b0;  // BUGFIX: hold 2 cycles
            repeat(3) @(posedge clk);
            #1;
            check("HJ: hj_clear clears detected", !hj_detected_w);
        end else begin
            check("HJ: hj_detected set before clear test", 1'b0);
        end

        // T8: HJ pending and auto_daa trigger
        test_num = 8;
        sda_i_hj = 1'b1; scl_i_hj = 1'b1;
        repeat(3) @(posedge clk);
        sda_i_hj = 1'b0;
        repeat(5) @(posedge clk);
        // After debounce, should enter DETECTED → TRIGGERING
        repeat(10) @(posedge clk);
        #1;
        check("HJ: hj_pending set after detection", hj_pending_w || hj_trigger_daa_w);

        // =============================================================
        // PHY FSM TESTS
        // =============================================================

        // T9: Bit transfer — SCL high should be > 1 cycle (timing fix)
        test_num = 9;
        repeat(10) @(posedge clk);
        #1 cmd_bit_xfer = 1'b1; sda_drive_val = 1'b0; mode_pushpull = 1'b1;
        @(posedge clk); #1 cmd_bit_xfer = 1'b0;

        begin: scl_count_pp
            integer scl_high_cycles;
            integer j;
            scl_high_cycles = 0;
            // Wait for SCL to go high
            for (j = 0; j < 100; j = j + 1) begin
                @(posedge clk);
                if (phy_scl_o === 1'b1 && phy_scl_oe === 1'b1) j = 100;
            end
            // Count cycles SCL stays high
            while (phy_scl_o === 1'b1 && phy_scl_oe === 1'b1) begin
                scl_high_cycles = scl_high_cycles + 1;
                @(posedge clk);
                if (scl_high_cycles > 20) disable scl_count_pp;
            end
            check("PHY: SCL high > 1 cycle (timing fix)", scl_high_cycles > 1);
            check("PHY: SCL high = 5 cycles", scl_high_cycles == 5);
        end

        // T10: Open-drain bit=1 — SDA should be released (oe=0)
        test_num = 10;
        repeat(10) @(posedge clk);
        #1 cmd_bit_xfer_od = 1'b1; sda_drive_val = 1'b1; mode_pushpull = 1'b0;
        @(posedge clk); #1 cmd_bit_xfer_od = 1'b0;
        repeat(15) @(posedge clk);  // BUGFIX: was 5, need more for bus_free_wait + SCL phases
        // Check during SCL high
        for (integer k = 0; k < 50; k = k + 1) begin
            @(posedge clk);
            if (phy_scl_o === 1'b1 && phy_scl_oe === 1'b1) k = 50;
        end
        check("PHY: OD bit=1 → sda_oe=0 (release)", phy_sda_oe === 1'b0);

        // T11: Open-drain bit=0 — SDA driven low (oe=1, o=0)
        test_num = 11;
        repeat(10) @(posedge clk);
        cmd_bit_xfer_od = 1'b1; sda_drive_val = 1'b0; mode_pushpull = 1'b0;
        @(posedge clk); cmd_bit_xfer_od = 1'b0;
        repeat(5) @(posedge clk);
        for (integer k = 0; k < 50; k = k + 1) begin
            @(posedge clk);
            if (phy_scl_o === 1'b1 && phy_scl_oe === 1'b1) k = 50;
        end
        check("PHY: OD bit=0 → sda_oe=1 (drive)", phy_sda_oe === 1'b1);
        check("PHY: OD bit=0 → sda_o=0", phy_sda_o === 1'b0);

        // T12: Push-pull bit=1 — SDA driven high (oe=1, o=1)
        test_num = 12;
        repeat(10) @(posedge clk);
        cmd_bit_xfer = 1'b1; sda_drive_val = 1'b1; mode_pushpull = 1'b1;
        @(posedge clk); cmd_bit_xfer = 1'b0;
        repeat(5) @(posedge clk);
        for (integer k = 0; k < 50; k = k + 1) begin
            @(posedge clk);
            if (phy_scl_o === 1'b1 && phy_scl_oe === 1'b1) k = 50;
        end
        check("PHY: PP bit=1 → sda_oe=1 (drive high)", phy_sda_oe === 1'b1);
        check("PHY: PP bit=1 → sda_o=1", phy_sda_o === 1'b1);

        // =============================================================
        // TARGET ENGINE TESTS
        // =============================================================

        // T13: Target not enabled — idle
        test_num = 13;
        target_en = 1'b0;
        repeat(5) @(posedge clk);
        #1;
        check("TGT: not busy when disabled", !target_busy_w);
        check("TGT: not addressed when disabled", !target_addressed_w);

        // T14: Enable target — ibi_req should reflect ibi_en
        test_num = 14;
        target_en = 1'b1; target_ibi_en = 1'b1;
        repeat(5) @(posedge clk);
        #1;
        check("TGT: ibi_req when enabled+ibi_en", target_ibi_req_w);

        // T15: Disable ibi_en — ibi_req should go low
        test_num = 15;
        target_ibi_en = 1'b0;
        repeat(5) @(posedge clk);
        #1;
        check("TGT: no ibi_req when ibi_en=0", !target_ibi_req_w);

        // T16: Address match — send 0x08+W via SCL/SDA
        test_num = 16;
        target_en = 1'b1;
        scl_filt_t = 1'b1; sda_filt_t = 1'b1;
        repeat(3) @(posedge clk);
        // START: SDA falls while SCL high
        sda_filt_t = 1'b0;
        repeat(2) @(posedge clk);
        scl_filt_t = 1'b0;
        @(posedge clk);
        // Send address 0x08 + W=0 = 0x10, MSB first
        begin: addr_loop
            logic [7:0] addr_byte;
            addr_byte = {target_dyn_addr, 1'b0};
            for (integer i = 7; i >= 0; i = i - 1) begin
                sda_filt_t = addr_byte[i];
                @(posedge clk);
                scl_filt_t = 1'b1; // SCL rise — target samples
                @(posedge clk); // scl_rise fires — target samples
                @(posedge clk);
                scl_filt_t = 1'b0; // SCL fall
                @(posedge clk);
            end
        end
        repeat(5) @(posedge clk);
        #1;
        check("TGT: addressed after addr match", target_addressed_w);

        // T17: Wrong address — should not be addressed
        test_num = 17;
        // STOP
        scl_filt_t = 1'b1; sda_filt_t = 1'b0;
        repeat(2) @(posedge clk);
        sda_filt_t = 1'b1; // SDA rises while SCL high = STOP
        repeat(5) @(posedge clk);
        #1;
        check("TGT: not addressed after STOP", !target_addressed_w);

        // Send wrong address 0x09+W
        scl_filt_t = 1'b1; sda_filt_t = 1'b1;
        repeat(3) @(posedge clk);
        sda_filt_t = 1'b0; // START
        repeat(2) @(posedge clk);
        scl_filt_t = 1'b0;
        @(posedge clk);
        begin: wrong_addr
            logic [7:0] addr_byte;
            addr_byte = {7'h09, 1'b0}; // wrong address
            for (integer i = 7; i >= 0; i = i - 1) begin
                sda_filt_t = addr_byte[i];
                @(posedge clk);
                scl_filt_t = 1'b1;
                @(posedge clk);
                @(posedge clk); // scl_rise fires — target samples
                scl_filt_t = 1'b0;
                @(posedge clk);
            end
        end
        repeat(5) @(posedge clk);
        #1;
        check("TGT: not addressed for wrong addr", !target_addressed_w);

        // =============================================================
        // IBI HANDLER TESTS
        // =============================================================

        // T18: IBI disabled — no activity
        test_num = 18;
        ibi_enable = 1'b0;
        bus_idle_ibi = 1'b1; controller_idle_ibi = 1'b1;
        sda_i_ibi = 1'b1; scl_i_ibi = 1'b1;
        repeat(10) @(posedge clk);
        #1;
        check("IBI: no active when disabled", !ibi_active_w);

        // T19: IBI enabled but no START — no activity
        test_num = 19;
        ibi_enable = 1'b1;
        repeat(10) @(posedge clk);
        #1;
        check("IBI: no active when no START detected", !ibi_active_w);

        // T20: IBI enabled + START detected — should become active
        test_num = 20;
        sda_i_ibi = 1'b1; scl_i_ibi = 1'b1;
        repeat(3) @(posedge clk);
        // SDA falls while SCL high = START
        sda_i_ibi = 1'b0;
        repeat(5) @(posedge clk);
        #1;
        check("IBI: active after START when enabled", ibi_active_w || ibi_req_bus_w);

        // =============================================================
        // SUMMARY
        // =============================================================
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0) $display("OVERALL: PASS");
        else $display("OVERALL: FAIL");
        $display("============================================================");
        $finish;
    end

    initial begin
        #2000000000;  // 2us timeout
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count + 1);
        $display("OVERALL: FAIL (watchdog timeout)");
        $display("============================================================");
        $finish;
    end

endmodule
