// =============================================================================
// tb_i3c_async_fifo_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_async_fifo (CDC FIFO).
// 24 corner-case tests covering:
//   - fast write/slow read
//   - slow write/fast read
//   - same frequency
//   - full → overflow
//   - empty → underflow
//   - gray code pointer verification
//   - reset domain crossing
//   - simultaneous write+read
//   - wrap-around with CDC
//   - deep fill (>half), drain to empty
// =============================================================================

module tb_i3c_async_fifo_sv;

    logic        wr_clk = 1'b0;
    logic        rd_clk = 1'b0;
    logic        rst_n = 1'b0;
    always #3000 wr_clk = ~wr_clk;  // fast write clock (3ns half)
    always #8000 rd_clk = ~rd_clk;  // slow read clock (8ns half)

    logic             wr_en = 1'b0;
    logic [7:0]       wr_data = 8'h0;
    logic             wr_full;
    logic             wr_overflow;
    logic             rd_en = 1'b0;
    logic [7:0]       rd_data;
    logic             rd_empty;
    logic             rd_underflow;

    i3c_async_fifo #(
        .WIDTH   (8),
        .DEPTH   (16),
        .REG_OUT (1)
    ) u_dut (
        .wr_clk       (wr_clk),
        .rst_n        (rst_n),
        .wr_en        (wr_en),
        .wr_data      (wr_data),
        .wr_full      (wr_full),
        .wr_overflow  (wr_overflow),
        .rd_clk       (rd_clk),
        .rd_en        (rd_en),
        .rd_data      (rd_data),
        .rd_empty     (rd_empty),
        .rd_underflow (rd_underflow)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    task wpush;
        input [7:0] data;
        begin
            @(negedge wr_clk);
            wr_en = 1'b1;
            wr_data = data;
            @(negedge wr_clk);
            wr_en = 1'b0;
        end
    endtask

    task rpop;
        begin
            @(negedge rd_clk);
            rd_en = 1'b1;
            @(negedge rd_clk);
            rd_en = 1'b0;
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_async_fifo_sv.vcd");
        $dumpvars(0, tb_i3c_async_fifo_sv);

        rst_n = 1'b0;
        wr_en = 1'b0;
        rd_en = 1'b0;
        wr_data = 8'h0;
        repeat (10) @(posedge wr_clk);
        @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        // Allow reset sync to propagate
        repeat (5) @(posedge rd_clk);

        $display("");
        $display("============================================================");
        $display("I3C Async FIFO (CDC) Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state
        test_num = 1;
        $display("--- T1: Reset state ---");
        check("wr_full == 0 after reset", wr_full == 1'b0);
        check("rd_empty == 1 after reset", rd_empty == 1'b1);
        check("wr_overflow == 0 after reset", wr_overflow == 1'b0);
        check("rd_underflow == 0 after reset", rd_underflow == 1'b0);

        // T2: Single push, single pop (basic CDC)
        test_num = 2;
        $display("--- T2: Single push/pop ---");
        wpush(8'hA5);
        // Allow CDC sync
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 0 after push", rd_empty == 1'b0);
        rpop;
        @(posedge rd_clk);
        @(posedge rd_clk);  // REG_OUT latency
        check("rd_data == 0xA5", rd_data == 8'hA5);

        // T3: Fast write, slow read (fill > drain)
        test_num = 3;
        $display("--- T3: Fast write / slow read ---");
        begin : t3_loop
            integer i;
            for (i = 0; i < 8; i = i + 1) wpush(8'h10 + i);
        end
        repeat (10) @(posedge rd_clk);
        check("rd_empty == 0 (FIFO has data)", rd_empty == 1'b0);
        // Drain
        begin : t3_drain
            integer i;
            for (i = 0; i < 8; i = i + 1) begin
                rpop;
                @(posedge rd_clk);
                @(posedge rd_clk);
            end
        end
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 1 after drain", rd_empty == 1'b1);

        // T4: Slow write, fast read
        test_num = 4;
        $display("--- T4: Slow write / fast read ---");
        wpush(8'h01);
        repeat (5) @(posedge rd_clk);
        rpop;
        @(posedge rd_clk);
        @(posedge rd_clk);
        check("rd_data == 0x01", rd_data == 8'h01);
        // Try to pop again — should underflow
        rpop;
        @(posedge rd_clk);
        check("rd_underflow == 1 after pop from empty", rd_underflow == 1'b1);

        // T5: Fill to full (16 items)
        test_num = 5;
        $display("--- T5: Fill to full ---");
        // Reset to clear sticky flags
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        begin : fill_loop
            integer i;
            for (i = 0; i < 16; i = i + 1) wpush(8'h20 + i);
        end
        @(posedge wr_clk);
        check("wr_full == 1 after 16 pushes", wr_full == 1'b1);

        // T6: Overflow when full
        test_num = 6;
        $display("--- T6: Overflow ---");
        wpush(8'hFF);
        @(posedge wr_clk);
        check("wr_overflow == 1 after push when full", wr_overflow == 1'b1);

        // T7: Underflow when empty
        test_num = 7;
        $display("--- T7: Underflow ---");
        // Drain all
        repeat (5) @(posedge rd_clk);
        begin : drain_loop
            integer i;
            for (i = 0; i < 16; i = i + 1) rpop;
        end
        repeat (5) @(posedge rd_clk);
        rpop;  // empty pop
        @(posedge rd_clk);
        check("rd_underflow == 1 after pop from empty", rd_underflow == 1'b1);

        // T8: Wrap-around with CDC (write to full, read all, write again)
        test_num = 8;
        $display("--- T8: Wrap-around with CDC ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        // First fill
        begin : wrap_fill1
            integer i;
            for (i = 0; i < 16; i = i + 1) wpush(8'hA0 + i);
        end
        @(posedge wr_clk);
        check("wr_full after first fill", wr_full == 1'b1);
        // Drain
        repeat (5) @(posedge rd_clk);
        begin : wrap_drain1
            integer i;
            for (i = 0; i < 16; i = i + 1) rpop;
        end
        repeat (5) @(posedge rd_clk);
        check("rd_empty after drain", rd_empty == 1'b1);
        // Refill
        begin : wrap_fill2
            integer i;
            for (i = 0; i < 16; i = i + 1) wpush(8'hB0 + i);
        end
        @(posedge wr_clk);
        check("wr_full after refill (wrap)", wr_full == 1'b1);

        // T9: Data integrity after wrap
        test_num = 9;
        $display("--- T9: Data integrity after wrap ---");
        repeat (5) @(posedge rd_clk);
        rpop;
        @(posedge rd_clk);
        @(posedge rd_clk);
        check("first read after wrap == 0xB0", rd_data == 8'hB0);

        // T10: Drain to empty after wrap
        test_num = 10;
        $display("--- T10: Drain to empty ---");
        begin : drain2
            integer i;
            for (i = 0; i < 15; i = i + 1) begin
                rpop;
                @(posedge rd_clk);
                @(posedge rd_clk);
            end
        end
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 1 after full drain", rd_empty == 1'b1);

        // T11: Same frequency clocks
        test_num = 11;
        $display("--- T11: Same frequency (manual sync) ---");
        // Just push and pop with manual timing
        @(negedge wr_clk);
        wr_en = 1'b1;
        wr_data = 8'h77;
        @(negedge wr_clk);
        wr_en = 1'b0;
        // Wait enough for CDC
        repeat (10) @(posedge rd_clk);
        check("rd_empty == 0 after push", rd_empty == 1'b0);
        rpop;
        @(posedge rd_clk);
        @(posedge rd_clk);
        check("rd_data == 0x77", rd_data == 8'h77);

        // T12: Simultaneous write + read (CDC parallel)
        test_num = 12;
        $display("--- T12: Simultaneous write + read ---");
        // Pre-load with one item
        @(negedge wr_clk);
        wr_en = 1'b1;
        wr_data = 8'h88;
        @(negedge wr_clk);
        wr_en = 1'b0;
        repeat (10) @(posedge rd_clk);
        check("rd_empty == 0", rd_empty == 1'b0);
        // Simultaneous push (wr_clk) and pop (rd_clk) — they're independent
        fork
            begin
                @(negedge wr_clk);
                wr_en = 1'b1;
                wr_data = 8'h99;
                @(negedge wr_clk);
                wr_en = 1'b0;
            end
            begin
                @(negedge rd_clk);
                rd_en = 1'b1;
                @(negedge rd_clk);
                rd_en = 1'b0;
            end
        join
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 0 after simultaneous", rd_empty == 1'b0);

        // T13: Deep fill (>half)
        test_num = 13;
        $display("--- T13: Deep fill (>half) ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        begin : deep_fill
            integer i;
            for (i = 0; i < 12; i = i + 1) wpush(8'hC0 + i);
        end
        @(posedge wr_clk);
        // 12 items > 8 (half) — verify FIFO has data
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 0 (deep fill)", rd_empty == 1'b0);
        // Push 4 more to fill
        begin : deep_more
            integer i;
            for (i = 0; i < 4; i = i + 1) wpush(8'hCC + i);
        end
        @(posedge wr_clk);
        check("wr_full == 1 after deep fill", wr_full == 1'b1);

        // T14: Drain to empty from full
        test_num = 14;
        $display("--- T14: Drain from full ---");
        repeat (5) @(posedge rd_clk);
        begin : drain3
            integer i;
            for (i = 0; i < 16; i = i + 1) rpop;
        end
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 1 after drain from full", rd_empty == 1'b1);

        // T15: Reset domain crossing (assert reset from one side)
        test_num = 15;
        $display("--- T15: Reset domain crossing ---");
        // Push some items
        wpush(8'h11);
        wpush(8'h22);
        @(posedge wr_clk);
        // Assert reset
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 1 after reset", rd_empty == 1'b1);
        check("wr_full == 0 after reset", wr_full == 1'b0);

        // T16: Continuous write until full, then read until empty
        test_num = 16;
        $display("--- T16: Fill-drain cycle ---");
        begin : t16_loop
            integer i;
            for (i = 0; i < 16; i = i + 1) wpush(8'h30 + i);
        end
        @(posedge wr_clk);
        check("wr_full == 1", wr_full == 1'b1);
        repeat (5) @(posedge rd_clk);
        begin : drain4
            integer i;
            for (i = 0; i < 16; i = i + 1) rpop;
        end
        repeat (5) @(posedge rd_clk);
        check("rd_empty == 1", rd_empty == 1'b1);

        // T17: Pattern verification (push known sequence, pop and check)
        test_num = 17;
        $display("--- T17: Pattern verification ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        begin : pattern_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 8; i = i + 1) wpush(8'h40 + i);
            repeat (5) @(posedge rd_clk);
            for (i = 0; i < 8; i = i + 1) begin
                rpop;
                @(posedge rd_clk);
                @(posedge rd_clk);
                if (rd_data !== 8'h40 + i) begin
                    ok = 0;
                    $display("    pop %0d: got 0x%02x, exp 0x%02x", i, rd_data, 8'h40 + i);
                end
            end
            check("pattern preserved through CDC", ok == 1);
        end

        // T18: Sticky overflow stays until reset
        test_num = 18;
        $display("--- T18: Sticky overflow ---");
        begin : t18_fill
            integer i;
            for (i = 0; i < 16; i = i + 1) wpush(8'h50 + i);
        end
        @(posedge wr_clk);
        wpush(8'hFF);  // overflow
        @(posedge wr_clk);
        check("wr_overflow set", wr_overflow == 1'b1);
        // Drain some
        repeat (5) @(posedge rd_clk);
        rpop;
        @(posedge rd_clk);
        check("wr_overflow still set (sticky)", wr_overflow == 1'b1);

        // T19: Sticky underflow stays until reset
        test_num = 19;
        $display("--- T19: Sticky underflow ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        rpop;  // empty pop
        @(posedge rd_clk);
        check("rd_underflow set", rd_underflow == 1'b1);
        wpush(8'hAA);
        repeat (5) @(posedge rd_clk);
        rpop;
        @(posedge rd_clk);
        @(posedge rd_clk);
        check("rd_underflow still set (sticky)", rd_underflow == 1'b1);

        // T20: Reset clears sticky flags
        test_num = 20;
        $display("--- T20: Reset clears sticky ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        check("wr_overflow == 0 after reset", wr_overflow == 1'b0);
        check("rd_underflow == 0 after reset", rd_underflow == 1'b0);

        // T21: Gray code pointer verification (no glitches via CDC)
        // Implicit verification: if pointers were not gray-coded, CDC would
        // occasionally cause spurious full/empty. We just verify stable behavior.
        test_num = 21;
        $display("--- T21: Gray code stability ---");
        begin : t21_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 16; i = i + 1) begin
                wpush(8'h60 + i);
                // No spurious full before reaching 16
                if (i < 15 && wr_full === 1'b1) ok = 0;
            end
            @(posedge wr_clk);
            if (wr_full !== 1'b1) ok = 0;
            check("gray code pointers stable (no spurious full)", ok == 1);
        end

        // T22: Back-to-back writes
        test_num = 22;
        $display("--- T22: Back-to-back writes ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        // Push 4 items back-to-back
        @(negedge wr_clk);
        wr_en = 1'b1; wr_data = 8'h01;
        @(negedge wr_clk); wr_data = 8'h02;
        @(negedge wr_clk); wr_data = 8'h03;
        @(negedge wr_clk); wr_data = 8'h04;
        @(negedge wr_clk);
        wr_en = 1'b0;
        repeat (10) @(posedge rd_clk);
        check("rd_empty == 0 after back-to-back writes", rd_empty == 1'b0);

        // T23: Back-to-back reads
        test_num = 23;
        $display("--- T23: Back-to-back reads ---");
        @(negedge rd_clk);
        rd_en = 1'b1;
        @(negedge rd_clk);
        @(negedge rd_clk);
        @(negedge rd_clk);
        @(negedge rd_clk);
        rd_en = 1'b0;
        @(posedge rd_clk);
        @(posedge rd_clk);
        check("rd_data captured from back-to-back reads", rd_data == 8'h04 || rd_data == 8'h03);

        // T24: Sustained mixed traffic
        test_num = 24;
        $display("--- T24: Sustained mixed traffic ---");
        @(negedge wr_clk);
        rst_n = 1'b0;
        repeat (5) @(negedge wr_clk);
        rst_n = 1'b1;
        repeat (10) @(posedge wr_clk);
        repeat (5) @(posedge rd_clk);
        begin : t24_loop
            integer i;
            integer ok;
            ok = 1;
            // Mix pushes and pops
            for (i = 0; i < 32; i = i + 1) begin
                if (i < 16) begin
                    if (!wr_full) wpush(8'h70 + i[7:0]);
                end else begin
                    if (!rd_empty) rpop;
                end
            end
            repeat (20) @(posedge rd_clk);
            // Drain rest
            for (i = 0; i < 20; i = i + 1) begin
                if (!rd_empty) rpop;
            end
            repeat (10) @(posedge rd_clk);
            if (rd_empty !== 1'b1) ok = 0;
            check("sustained mixed traffic drains to empty", ok == 1);
        end

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
