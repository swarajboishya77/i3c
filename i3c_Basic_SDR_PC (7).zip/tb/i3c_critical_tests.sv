// =============================================================================
// i3c_critical_tests.sv
// UVM-style test cases for v11.1 verification
// =============================================================================

class i3c_reset_chaos_test;
  // Randomly assert reset during active transfers
  // Verify: ctrl_state returns to CTRL_IDLE, no X-propagation
  // Coverage: All FSM states hit with reset
endclass

class i3c_daa_collision_test;
  // Two targets with same PID prefix
  // Verify: RESP_DAA_COLLISION reported, bus recovered
  // Coverage: DAA_COLLISION_DETECT state
endclass

class i3c_ccc_nack_test;
  // Direct CCC to non-existent target address
  // Verify: RESP_NACK_ADDR, controller issues STOP
  // Coverage: C_DIRECT_ADDR_ACK -> NACK path
endclass

class i3c_ibi_priority_test;
  // Three targets request IBI with different BCR priorities
  // Verify: Lowest BCR[2:0] value wins arbitration
  // Coverage: IBI_EVAL_PRIORITY state
endclass

class i3c_hotjoin_noise_test;
  // Inject glitches on SDA during bus idle
  // Verify: HJ_DEBOUNCE filters glitches, no spurious DAA
  // Coverage: HJ_DEBOUNCE -> HJ_IDLE rejection path
endclass

class i3c_tbuf_clamp_test;
  // Program cfg_bus_free_time = 0
  // Verify: Hardware clamps to 250 ns (pure) or 1.3 us (mixed)
  // Coverage: bus_free_clamped logic
endclass

class i3c_target_timeout_test;
  // Controller stops clocking mid-transfer
  // Verify: Target releases SDA after 1ms, returns to TGT_IDLE
  // Coverage: TGT_TIMEOUT_RECOVERY state
endclass

class i3c_cdc_stress_test;
  // Change cfg_* timing registers while PHY is active
  // Verify: Shadow registers load only in IDLE, no glitches
  // Coverage: T_SHADOW_LOAD state
endclass

class i3c_async_fifo_reset_test;
  // Assert wr_rst_n while rd_clk running, release asynchronously
  // Verify: No pointer misalignment, overflow/underflow flags correct
  // Coverage: wr_rst_sync / rd_rst_sync logic
endclass

