// =============================================================================
// tb_i3c_role_manager.sv
// -----------------------------------------------------------------------------
// Standalone Role Manager testbench — tests GETACCR handoff, reclaim, and
// voluntary return (role_return) paths per MIPI I3C Basic v1.2 Figure 186.
//
// Tests:
//   T1. Successful handoff: ACTIVE → PREPARING → MONITORING → TARGET
//   T2. Failed handoff (addr NACK): ACTIVE → PREPARING → FAILED → ACTIVE
//   T3. Failed handoff (data NACK): ACTIVE → PREPARING → FAILED → ACTIVE
//   T4. Reclaim: TARGET → MONITORING → TESTING → RECLAIMING → ACTIVE
//   T5. Voluntary return: TARGET → ACTIVE (via role_return pulse)
//   T6. Bus activity keeps target alive (no false reclaim)
//   T7. phy_mux_sel correctness for each state
//
// Simulator: Icarus Verilog 12.0
// =============================================================================


module tb_i3c_role_manager;

    logic clk_sys = 1'b0;
    logic rst_sys_n = 1'b0;
    always #5 clk_sys = ~clk_sys;  // 100 MHz

    // Config
    logic        reclaim_en = 1'b1;
    logic [15:0] reclaim_timeout_us = 16'd100;  // 100µs default

    // Handoff control
    logic        handoff_trigger = 1'b0;
    logic        getacccr_done = 1'b0;
    logic        getacccr_ack = 1'b0;
    logic        getacccr_addr_nack = 1'b0;
    logic        getacccr_data_nack = 1'b0;

    // Bus activity
    logic        scl_falling = 1'b0;
    logic        sda_falling = 1'b0;
    logic        scl_filt = 1'b1;
    logic        sda_filt = 1'b1;

    // Bootstrap
    logic        bootstrap_active = 1'b0;

    // Voluntary return
    logic        role_return = 1'b0;

    // Outputs
    logic        role_is_controller;
    logic        role_is_target;
    logic        reclaim_in_progress;
    logic        handoff_done_pulse;
    logic        handoff_failed_pulse;
    logic [1:0]  handoff_fail_reason;
    logic [1:0]  phy_mux_sel;
    logic        target_engine_en;
    logic [2:0]  role_state_out;

    // DUT
    i3c_role_manager u_role_mgr (
        .clk_sys            (clk_sys),
        .rst_sys_n          (rst_sys_n),
        .reclaim_en         (reclaim_en),
        .reclaim_timeout_us (reclaim_timeout_us),
        .handoff_trigger    (handoff_trigger),
        .getacccr_done      (getacccr_done),
        .getacccr_ack       (getacccr_ack),
        .getacccr_addr_nack (getacccr_addr_nack),
        .getacccr_data_nack (getacccr_data_nack),
        .scl_falling        (scl_falling),
        .sda_falling        (sda_falling),
        .scl_filt           (scl_filt),
        .sda_filt           (sda_filt),
        .bootstrap_active   (bootstrap_active),
        .role_is_controller (role_is_controller),
        .role_is_target     (role_is_target),
        .reclaim_in_progress(reclaim_in_progress),
        .handoff_done_pulse (handoff_done_pulse),
        .handoff_failed_pulse(handoff_failed_pulse),
        .handoff_fail_reason(handoff_fail_reason),
        .phy_mux_sel        (phy_mux_sel),
        .target_engine_en   (target_engine_en),
        .role_return        (role_return),
        .role_state_out     (role_state_out)
    );

    // Test helpers
    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    task pulse_handoff;
        begin
            @(posedge clk_sys);
            handoff_trigger <= 1'b1;
            @(posedge clk_sys);
            handoff_trigger <= 1'b0;
        end
    endtask

    task send_getacccr_result;
        input ack_val;
        input addr_nack_val;
        input data_nack_val;
        begin
            @(posedge clk_sys);
            getacccr_done      <= 1'b1;
            getacccr_ack       <= ack_val;
            getacccr_addr_nack <= addr_nack_val;
            getacccr_data_nack <= data_nack_val;
            @(posedge clk_sys);
            getacccr_done      <= 1'b0;
            getacccr_ack       <= 1'b0;
            getacccr_addr_nack <= 1'b0;
            getacccr_data_nack <= 1'b0;
        end
    endtask

    task pulse_scl_falling;
        begin
            @(posedge clk_sys);
            scl_falling <= 1'b1;
            @(posedge clk_sys);
            scl_falling <= 1'b0;
        end
    endtask

    task pulse_role_return;
        begin
            @(posedge clk_sys);
            role_return <= 1'b1;
            @(posedge clk_sys);
            role_return <= 1'b0;
        end
    endtask

    // Wait for idle timer to expire (short timeout for sim = 1µs = 100 cycles)
    task wait_idle_timeout;
        integer i;
        begin
            // reclaim_timeout_us=1 would give 100 cycles. We set it to 1 for fast sim.
            for (i = 0; i < 120; i = i + 1)
                @(posedge clk_sys);
        end
    endtask

    // Main test
    initial begin
        $dumpfile("/tmp/tb_i3c_role_manager.vcd");
        $dumpvars(0, tb_i3c_role_manager);

        rst_sys_n = 1'b0;
        repeat (5) @(posedge clk_sys);
        rst_sys_n = 1'b1;
        repeat (5) @(posedge clk_sys);

        $display("");
        $display("============================================================");
        $display("I3C Role Manager Testbench (Figure 186)");
        $display("============================================================");
        $display("");

        // Use 1µs timeout for fast simulation (100 PCLK cycles)
        reclaim_timeout_us = 16'd1;

        // Verify initial state
        check("initial state = ACTIVE_CONTROLLER", role_state_out == 3'd0);
        check("initial phy_mux = DPHY", phy_mux_sel == 2'd0);
        check("initial role_is_controller = 1", role_is_controller == 1'b1);

        // -----------------------------------------------------
        // T1: Successful handoff
        // -----------------------------------------------------
        test_num = 1;
        $display("--- T1: Successful handoff ---");
        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        check("state = PREPARING_HANDOFF", role_state_out == 3'd1);
        check("phy_mux = DPHY during prep", phy_mux_sel == 2'd0);

        send_getacccr_result(1'b1, 1'b0, 1'b0);  // ACK
        @(posedge clk_sys);
        // handoff_done_pulse fires 1 cycle after getacccr_done (registered)
        check("handoff_done_pulse fired", handoff_done_pulse == 1'b1);
        @(posedge clk_sys);
        check("state = MONITORING_NEW", role_state_out == 3'd2);
        check("phy_mux = TARGET during monitoring", phy_mux_sel == 2'd1);
        check("target_engine_en = 1", target_engine_en == 1'b1);

        // Simulate bus activity (SCL falling) → transition to TARGET
        pulse_scl_falling;
        repeat (4) @(posedge clk_sys);
        check("state = TARGET (after bus activity)", role_state_out == 3'd5);
        check("role_is_target = 1", role_is_target == 1'b1);

        // -----------------------------------------------------
        // T2: Failed handoff (addr NACK)
        // -----------------------------------------------------
        test_num = 2;
        $display("");
        $display("--- T2: Failed handoff (addr NACK) ---");
        // First return to ACTIVE via role_return
        pulse_role_return;
        repeat (4) @(posedge clk_sys);
        check("state = ACTIVE after role_return", role_state_out == 3'd0);

        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        send_getacccr_result(1'b0, 1'b1, 1'b0);  // addr NACK
        @(posedge clk_sys);
        check("handoff_failed_pulse fired", handoff_failed_pulse == 1'b1);
        check("fail_reason = 1 (addr NACK)", handoff_fail_reason == 2'd1);
        check("state = HANDOFF_FAILED", role_state_out == 3'd6);
        @(posedge clk_sys);
        check("state = ACTIVE (auto-recover)", role_state_out == 3'd0);

        // -----------------------------------------------------
        // T3: Failed handoff (data NACK)
        // -----------------------------------------------------
        test_num = 3;
        $display("");
        $display("--- T3: Failed handoff (data NACK) ---");
        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        send_getacccr_result(1'b0, 1'b0, 1'b1);  // data NACK
        @(posedge clk_sys);
        check("fail_reason = 2 (data NACK)", handoff_fail_reason == 2'd2);
        check("state = HANDOFF_FAILED", role_state_out == 3'd6);
        @(posedge clk_sys);
        check("state = ACTIVE (auto-recover)", role_state_out == 3'd0);

        // -----------------------------------------------------
        // T4: Reclaim path
        // -----------------------------------------------------
        test_num = 4;
        $display("");
        $display("--- T4: Reclaim path ---");
        // Do successful handoff first
        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        send_getacccr_result(1'b1, 1'b0, 1'b0);  // ACK
        repeat (4) @(posedge clk_sys);
        check("state = MONITORING_NEW", role_state_out == 3'd2);

        // Wait for idle timer to expire → transition to TESTING
        wait_idle_timeout;
        repeat (4) @(posedge clk_sys);
        check("state = TESTING_NEW (after idle timeout)", role_state_out == 3'd3);

        // Wait for another idle timeout → transition to RECLAIMING
        wait_idle_timeout;
        repeat (4) @(posedge clk_sys);
        check("state = RECLAIMING", role_state_out == 3'd4);
        check("reclaim_in_progress = 1", reclaim_in_progress == 1'b1);
        check("phy_mux = DPHY during reclaim", phy_mux_sel == 2'd0);

        // Wait for RECLAIM_DURATION (10000 cycles = 100µs — too long for sim)
        // The counter uses 16 bits, so max 65535. Let's wait enough.
        // Actually for 1µs timeout we need 10000 PCLK cycles = 100µs
        // That's 10000*10ns = 100µs. Let's wait 10100 cycles.
        begin: reclaim_wait
            integer i;
            for (i = 0; i < 10100; i = i + 1)
                @(posedge clk_sys);
        end
        repeat (4) @(posedge clk_sys);
        check("state = ACTIVE (reclaim complete)", role_state_out == 3'd0);
        check("role_is_controller = 1 after reclaim", role_is_controller == 1'b1);

        // -----------------------------------------------------
        // T5: Voluntary return
        // -----------------------------------------------------
        test_num = 5;
        $display("");
        $display("--- T5: Voluntary return ---");
        // Handoff to target
        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        send_getacccr_result(1'b1, 1'b0, 1'b0);
        repeat (4) @(posedge clk_sys);
        pulse_scl_falling;  // bus activity → TARGET
        repeat (4) @(posedge clk_sys);
        check("state = TARGET", role_state_out == 3'd5);

        // Voluntary return
        pulse_role_return;
        repeat (4) @(posedge clk_sys);
        check("state = ACTIVE (voluntary return)", role_state_out == 3'd0);
        check("phy_mux = DPHY after return", phy_mux_sel == 2'd0);

        // -----------------------------------------------------
        // T6: Bus activity prevents reclaim
        // -----------------------------------------------------
        test_num = 6;
        $display("");
        $display("--- T6: Bus activity prevents reclaim ---");
        pulse_handoff;
        repeat (4) @(posedge clk_sys);
        send_getacccr_result(1'b1, 1'b0, 1'b0);
        repeat (4) @(posedge clk_sys);
        check("state = MONITORING_NEW", role_state_out == 3'd2);

        // Send SCL falling every 50 cycles to keep timer reset
        begin: keep_alive
            integer i;
            for (i = 0; i < 200; i = i + 1) begin
                @(posedge clk_sys);
                if (i % 50 == 49) begin
                    scl_falling <= 1'b1;
                    @(posedge clk_sys);
                    scl_falling <= 1'b0;
                end
            end
        end
        check("state = TARGET (bus activity detected)", role_state_out == 3'd5);

        // -----------------------------------------------------
        // T7: phy_mux_sel for all states
        // -----------------------------------------------------
        test_num = 7;
        $display("");
        $display("--- T7: phy_mux_sel correctness ---");
        // We're in TARGET from T6 (bus activity → TARGET)
        check("TARGET: mux=TARGET", phy_mux_sel == 2'd1);
        check("TARGET: target_engine_en=1", target_engine_en == 1'b1);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL — see failures above");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000; // 50 ms
        $display("TIMEOUT — test did not complete in 50 ms");
        $finish;
    end

endmodule
