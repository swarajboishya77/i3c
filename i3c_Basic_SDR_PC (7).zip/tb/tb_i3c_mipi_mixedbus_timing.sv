// =============================================================================
// tb_i3c_mipi_mixedbus_timing.sv
// -----------------------------------------------------------------------------
// Verify that the i3c_timing_control FSM produces on-bus SCL/SDA timing that
// matches the MIPI I3C Basic v1.2 Mixed Bus Fm+ register defaults:
//
//   Push-pull SCL high (tHIGH):  register = 4 cyc, expect >= 40 ns on bus
//   Push-pull SCL low  (tLOW):   register = 4 cyc, expect >= 40 ns on bus
//   Open-drain SCL high (tHIGH_OD):  register = 26 cyc, expect >= 260 ns on bus
//   Open-drain SCL low  (tLOW_OD):   register = 50 cyc, expect >= 500 ns on bus
//   TSU_START:                    register = 26 cyc, expect >= 260 ns on bus
//   THD_START:                    register = 26 cyc, expect >= 260 ns on bus
//   TSU_STOP:                     register = 26 cyc, expect >= 260 ns on bus
//   BUS_FREE:                     register = 130 cyc, expect >= 1300 ns on bus
//   SDA_HOLD:                     register = 4 cyc,  expect >= 40 ns on bus
//
// All measurements are made on the actual sda_o/scl_o waveforms using
// $time snapshots at SCL transitions.
//
// Simulator: Icarus Verilog 12.0 (uses Verilog, NOT SystemVerilog constructs)
// =============================================================================


module tb_i3c_mipi_mixedbus_timing;

    // -------------------------------------------------------------------------
    // Clock / reset (PCLK = 100 MHz -> 10 ns period)
    // -------------------------------------------------------------------------
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    always #5000 clk = ~clk;   // 10 ns period

    // -------------------------------------------------------------------------
    // Mixed Bus Fm+ register defaults (matching i3c_register_file.sv reset values)
    // -------------------------------------------------------------------------
    localparam [17:0] SCL_HIGH_TIME      = 18'd4;    // 40 ns push-pull tHIGH
    localparam [17:0] SCL_LOW_TIME       = 18'd4;    // 40 ns push-pull tLOW
    localparam [17:0] SDA_HOLD_TIME      = 18'd4;    // 40 ns SDA hold
    localparam [17:0] BUS_FREE_TIME      = 18'd130;  // 1300 ns Pure tBUF
    localparam [17:0] TSU_START_TIME     = 18'd26;   // 260 ns Fm+ tSU_STA
    localparam [17:0] THD_START_TIME     = 18'd26;   // 260 ns Fm+ tHD_STA
    localparam [17:0] TSU_STOP_TIME      = 18'd26;   // 260 ns Fm+ tSU_STO
    localparam [17:0] SCL_OD_HIGH_TIME   = 18'd26;   // 260 ns Fm+ tHIGH_OD
    localparam [17:0] SCL_OD_LOW_TIME    = 18'd50;   // 500 ns Fm+ tLOW_OD
    localparam [1:0]  BUS_TYPE           = 2'd1;     // MIXED_FAST
    localparam [17:0] SCL_HIGH_TIME_MIXED = 18'd4;   // 40 ns tDIG_H_MIXED

    // -------------------------------------------------------------------------
    // DUT signals
    // -------------------------------------------------------------------------
    logic        cmd_start, cmd_repeat_start, cmd_stop;
    logic        cmd_drive_scl_low, cmd_release_bus;
    logic        cmd_bit_xfer, cmd_bit_xfer_od;
    logic        sda_drive_val, mode_pushpull;
    logic        done, bit_done_w, byte_done_w, busy, sda_sampled, stretch_detected;
    logic        sda_o, sda_oe, sda_i;
    logic        scl_o, scl_oe, scl_i;

    // Pull-up on SCL and SDA (open-drain model: 1k pullup to VDD)
    // SCL/SDA read as '1' when not driven (oe=0).
    wire  scl_bus = scl_oe ? scl_o : 1'bz;
    wire  sda_bus = sda_oe ? sda_o : 1'bz;
    pullup(scl_bus);
    pullup(sda_bus);
    // Loop back for clock-stretching tolerance: scl_i reads the actual bus
    buf(scl_i, scl_bus);
    buf(sda_i, sda_bus);

    // -------------------------------------------------------------------------
    // DUT
    // -------------------------------------------------------------------------
    i3c_timing_control u_dut (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .cfg_scl_high_time     (SCL_HIGH_TIME),
        .cfg_scl_low_time      (SCL_LOW_TIME),
        .cfg_sda_hold_time     (SDA_HOLD_TIME),
        .cfg_bus_free_time     (BUS_FREE_TIME),
        .cfg_tsu_start         (TSU_START_TIME),
        .cfg_thd_start         (THD_START_TIME),
        .cfg_tsu_stop          (TSU_STOP_TIME),
        .cfg_scl_od_high_time  (SCL_OD_HIGH_TIME),
        .cfg_scl_od_low_time   (SCL_OD_LOW_TIME),
        .bus_type              (BUS_TYPE),
        .cfg_scl_high_time_mixed (SCL_HIGH_TIME_MIXED),
        .tcmd_start             (cmd_start),
        .tcmd_bit_xfer          (cmd_bit_xfer),
        .tcmd_bit_xfer_od       (cmd_bit_xfer_od),
        .tcmd_drive_scl_low     (cmd_drive_scl_low),
        .tcmd_release           (cmd_release_bus),
        .tcmd_stop              (cmd_stop),
        .tx_bit                 ({7'h00, sda_drive_val}),  // BUG-R4-053: tx_bit[0] = sda_drive_val
        .sda_i                  (sda_i),
        .sda_sampled            (sda_sampled),
        .scl_out                (scl_o),
        .sda_out                (sda_o),
        .scl_oe                 (scl_oe),
        .sda_oe                 (sda_oe),
        .bit_done               (bit_done_w),
        .byte_done              (byte_done_w),
        .timing_violation       (stretch_detected)
    );

    assign done = bit_done_w | byte_done_w;

    // -------------------------------------------------------------------------
    // Test result tracking
    // -------------------------------------------------------------------------
    integer pass_count = 0;
    integer fail_count = 0;
    integer i;

    always @(u_dut.state) begin
        $display("[%0t] FSM state changed to %0d, timer=%0d", $time, u_dut.state, u_dut.timer);
    end

    ///////////////////////////////////////////////////////////////////////////////
    // Task: pulse a single command for one cycle
    ///////////////////////////////////////////////////////////////////////////////
    task pulse_start;
        begin
            @(negedge clk);
            cmd_start = 1'b1;
            @(negedge clk);
            cmd_start = 1'b0;
        end
    endtask

    task pulse_stop;
        begin
            @(negedge clk);
            cmd_stop = 1'b1;
            repeat (200) @(negedge clk);
            cmd_stop = 1'b0;
        end
    endtask

    task pulse_bit_pp;
        input sda_val;
        begin
            @(posedge clk);
            cmd_bit_xfer = 1'b1;
            sda_drive_val <= sda_val;
            @(posedge clk);
            cmd_bit_xfer = 1'b0;
        end
    endtask

    task pulse_bit_od;
        input sda_val;
        begin
            @(posedge clk);
            cmd_bit_xfer_od = 1'b1;
            mode_pushpull = 1'b0;
            sda_drive_val <= sda_val;
            @(posedge clk);
            cmd_bit_xfer_od = 1'b0;
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // Wait until `done` is observed
    ///////////////////////////////////////////////////////////////////////////////
    task wait_done;
        begin
            $display("[%0t] wait_done: waiting for done", $time);
            while (!done) @(negedge clk);
            $display("[%0t] wait_done: saw done, waiting for posedge clk", $time);
            @(posedge clk);  // settle
            $display("[%0t] wait_done: finished", $time);
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // Measurement tasks - record $time at SCL transitions
    ///////////////////////////////////////////////////////////////////////////////
    time t_scl_rise, t_scl_fall;
    time t_high_dur, t_low_dur;

    task measure_next_pp_bit;
        input sda_val;
        begin
            // Pulse a push-pull bit, then sample SCL rise/fall times
            @(posedge clk);
            cmd_bit_xfer = 1'b1;
            mode_pushpull = 1'b1;
            sda_drive_val <= sda_val;
            @(posedge clk);
            cmd_bit_xfer = 1'b0;
            // Wait for SCL to go low (entering T_BIT_SCL_LOW)
            while (scl_bus === 1'b1) @(posedge clk);
            // Now wait for SCL to go high (T_BIT_SCL_HIGH begins)
            while (scl_bus === 1'b0) @(posedge clk);
            t_scl_rise = $time;
            // Wait for SCL to fall again (end of T_BIT_SCL_HIGH)
            while (scl_bus === 1'b1) @(posedge clk);
            t_scl_fall = $time;
            t_high_dur = t_scl_fall - t_scl_rise;
            // Wait for done to be safe before continuing
            wait_done;
        end
    endtask

    task measure_next_pp_bit_full;
        input sda_val;
        begin
            // Pulse bit and measure BOTH tLOW and tHIGH for push-pull
            @(posedge clk);
            cmd_bit_xfer <= 1'b1;
            mode_pushpull <= 1'b1;
            sda_drive_val <= sda_val;
            @(posedge clk);
            cmd_bit_xfer <= 1'b0;
            // SCL currently high (idle). Wait for it to go low (start of tLOW)
            while (scl_bus === 1'b1) @(posedge clk);
            t_scl_fall = $time;
            // Wait for SCL to go high (start of tHIGH, end of tLOW)
            while (scl_bus === 1'b0) @(posedge clk);
            t_scl_rise = $time;
            t_low_dur = t_scl_rise - t_scl_fall;
            // End of tHIGH is when 'done' is pulsed
            wait_done;
            t_high_dur = $time - t_scl_rise;
        end
    endtask

    task measure_next_od_bit_full;
        input sda_val;
        begin
            // Pulse bit and measure BOTH tLOW and tHIGH for open-drain
            @(posedge clk);
            cmd_bit_xfer_od <= 1'b1;
            mode_pushpull <= 1'b0;
            sda_drive_val <= sda_val;
            @(posedge clk);
            cmd_bit_xfer_od <= 1'b0;
            while (scl_bus === 1'b1) @(posedge clk);
            t_scl_fall = $time;
            while (scl_bus === 1'b0) @(posedge clk);
            t_scl_rise = $time;
            t_low_dur = t_scl_rise - t_scl_fall;
            // End of tHIGH is when 'done' is pulsed
            wait_done;
            t_high_dur = $time - t_scl_rise;
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // START condition measurement (TSU_START + THD_START)
    //   START = SDA falls while SCL high, then SCL falls.
    //   TSU_START = time SDA falls BEFORE SCL falls (SCL high during this)
    //   THD_START = time SDA stays low AFTER SCL falls (before next bit's tLOW)
    ///////////////////////////////////////////////////////////////////////////////
    time t_start_sda_fall, t_start_scl_fall;
    time tsu_start_meas, thd_start_meas;
    time t_cmd_start_pulse, t_start_thd_end;
    time tsu_start_full, thd_start_full;

    task measure_start;
        begin
            @(posedge clk);
            cmd_start = 1'b1;
            t_cmd_start_pulse = $time;
            @(posedge clk);
            cmd_start = 1'b0;
            // SDA falls at end of T_TSU_START_WAIT (entering T_START_SDA_FALL)
            // SCL falls at end of T_START_SDA_FALL (entering T_START_SCL_FALL)
            while (sda_bus === 1'b1) @(posedge clk);   // SDA falls
            t_start_sda_fall = $time;
            while (scl_bus === 1'b1) @(posedge clk);   // SCL falls
            t_start_scl_fall = $time;
            tsu_start_meas = t_start_scl_fall - t_start_sda_fall;
            // FSM asserts done at end of T_START_SCL_FALL (target==tsu_start)
            wait_done;
        end
    endtask

    task measure_start_full;
        begin
            @(posedge clk);
            cmd_start <= 1'b1;
            t_cmd_start_pulse = $time;
            @(posedge clk);
            cmd_start <= 1'b0;
            // Wait for SDA to fall (end of T_TSU_START_WAIT + start of T_START_SDA_FALL)
            while (sda_bus === 1'b1) @(posedge clk);
            t_start_sda_fall = $time;
            // TSU_START FULL = (T_TSU_START_WAIT duration) + (T_START_SDA_FALL duration)
            //   = time from cmd_start pulse to SCL fall
            while (scl_bus === 1'b1) @(posedge clk);   // SCL falls (end of TSU window)
            t_start_scl_fall = $time;
            tsu_start_full = t_start_scl_fall - t_cmd_start_pulse;
            tsu_start_meas = t_start_scl_fall - t_start_sda_fall;
            // THD_START = T_START_SCL_FALL state duration
            // = time from SCL fall until FSM returns to IDLE
            wait_done;
            thd_start_full = $time - t_start_scl_fall;
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // STOP condition measurement (TSU_STOP)
    //   STOP = SCL high, SDA low -> SDA rises while SCL high
    //   TSU_STOP = time SCL held high with SDA low before SDA rises
    ///////////////////////////////////////////////////////////////////////////////
    time t_stop_scl_high, t_stop_sda_rise;
    time tsu_stop_meas;

    task measure_stop;
        begin
            @(negedge clk);
            cmd_stop = 1'b1;
            @(negedge clk);
            cmd_stop = 1'b0;
            // FSM: T_STOP_SCL_HIGH (SCL high, SDA low) -> T_STOP_SDA_RISE (SDA rises)
            // T_STOP_SCL_HIGH duration = cfg_tsu_stop = 26 cyc = 260 ns
            // SDA rises at end of T_STOP_SCL_HIGH
            // Wait for SDA to actually be low (entry into T_STOP_SCL_HIGH sets sda=0,scl=1)
            while (sda_bus === 1'b0) @(posedge clk);  // SDA rises
            t_stop_sda_rise = $time;
            // The T_STOP_SCL_HIGH state started when cmd_stop was issued
            // (Actually: cmd_stop asserts -> IDLE -> T_STOP_SCL_HIGH on next cycle)
            // So TSU_STOP = t_stop_sda_rise - (cmd_stop pulse cycle + 1 cycle)
            // For simplicity, measure from cmd_stop issue:
            tsu_stop_meas = t_stop_sda_rise - t_cmd_start_pulse;  // re-using var; actual value set by caller
            // Wait for done (after T_BUS_FREE_WAIT)
            wait_done;
        end
    endtask

    task measure_stop_full;
        begin
            @(posedge clk);
            cmd_stop <= 1'b1;
            t_cmd_start_pulse = $time;
            @(posedge clk);
            cmd_stop <= 1'b0;
            // Wait for SCL to go low (entering T_STOP_SDA_LOW)
            $display("[%0t] measure_stop_full: waiting for SCL low", $time);
            while (scl_bus === 1'b1) @(posedge clk);
            $display("[%0t] measure_stop_full: waiting for SCL high", $time);
            // Wait for SCL to go high (entering T_STOP_SCL_HIGH)
            while (scl_bus === 1'b0) @(posedge clk);
            t_scl_rise = $time;
            $display("[%0t] measure_stop_full: waiting for SDA high", $time);
            // Then wait for SDA high (T_STOP_SDA_HIGH)
            while (sda_bus === 1'b0) @(posedge clk);
            t_stop_sda_rise = $time;
            tsu_stop_meas = t_stop_sda_rise - t_scl_rise;
            $display("[%0t] measure_stop_full: waiting for done", $time);
            // Now FSM enters T_STOP_SDA_RISE -> T_BUS_FREE_WAIT
            wait_done;
            $display("[%0t] measure_stop_full: finished", $time);
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // BUS_FREE measurement (tBUF)
    //   After STOP, FSM enters T_BUS_FREE_WAIT for cfg_bus_free_time cycles
    //   = 130 cycles = 1300 ns. done asserts at end of T_BUS_FREE_WAIT.
    //   We measure from SDA rise (STOP edge) to done.
    ///////////////////////////////////////////////////////////////////////////////
    time t_stop_edge, t_bus_free_done;
    time bus_free_meas;

    task measure_bus_free;
        begin
            // Issue STOP. FSM will run T_STOP_SCL_HIGH + T_STOP_SDA_RISE + T_BUS_FREE_WAIT
            @(negedge clk);
            cmd_stop = 1'b1;
            @(negedge clk);
            cmd_stop = 1'b0;
            // First wait for SDA to fall (entering T_STOP_SCL_HIGH)
            while (sda_bus === 1'b1) @(posedge clk);
            // Then wait for SDA to rise (STOP edge at end of T_STOP_SCL_HIGH)
            while (sda_bus === 1'b0) @(posedge clk);
            t_stop_edge = $time;
            // Now in T_STOP_SDA_RISE -> T_BUS_FREE_WAIT
            // Wait for done to assert (end of T_BUS_FREE_WAIT)
            while (!done) @(posedge clk);
            t_bus_free_done = $time;
            // BUS_FREE includes T_STOP_SDA_RISE + T_BUS_FREE_WAIT
            // (T_STOP_SDA_RISE is the post-STOP hold; T_BUS_FREE_WAIT is tBUF)
            // MIPI tBUF starts at STOP edge, so include T_STOP_SDA_RISE
            bus_free_meas = t_bus_free_done - t_stop_edge;
            @(posedge clk);
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // Check helper
    ///////////////////////////////////////////////////////////////////////////////
    task check;
        input [255:0] name;
        input [63:0]  measured_ns;
        input [63:0]  expected_min_ns;
        input [63:0]  expected_max_ns;
        reg [255:0] status;
        begin
            if (measured_ns >= expected_min_ns && measured_ns <= expected_max_ns) begin
                status = "PASS";
                pass_count = pass_count + 1;
            end else begin
                status = "FAIL";
                fail_count = fail_count + 1;
            end
            $display("[%s] %0s: measured=%0d ns, expected=[%0d, %0d] ns",
                     status, name, measured_ns, expected_min_ns, expected_max_ns);
        end
    endtask

    ///////////////////////////////////////////////////////////////////////////////
    // Main test sequence
    ///////////////////////////////////////////////////////////////////////////////
    initial begin
        // Init
        cmd_start = 0; cmd_repeat_start = 0; cmd_stop = 0;
        cmd_drive_scl_low = 0; cmd_release_bus = 0;
        cmd_bit_xfer = 0; cmd_bit_xfer_od = 0;
        sda_drive_val = 0; mode_pushpull = 1;

        // Reset
        rst_n = 0;
        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("MIPI I3C Basic v1.2 Mixed Bus Fm+ Timing Verification");
        $display("PCLK = 100 MHz (10 ns), SCL target = 12.5 MHz SDR");
        $display("BUS_TYPE = MIXED_FAST (1)");
        $display("============================================================");
        $display("");

        // -----------------------------------------------------
        // TEST 1: Push-pull SCL high/low timing (4 cyc = 40 ns each)
        // -----------------------------------------------------
        $display("[%0t] --- Test 1: Push-Pull SCL bit timing (SCL_HIGH=4, SCL_LOW=4) ---", $time);
        // First issue a START to enter bus-active state
        $display("[%0t] Calling pulse_start", $time);
        pulse_start;
        $display("[%0t] Calling wait_done for START", $time);
        wait_done;
        $display("[%0t] wait_done finished for START", $time);

        // Now issue a few push-pull bits and measure each
        for (i = 0; i < 3; i = i + 1) begin
            $display("[%0t] Calling measure_next_pp_bit_full", $time);
            measure_next_pp_bit_full(1'b1);
            $display("  PP bit %0d: tLOW=%0d ns (target >= 40), tHIGH=%0d ns (target >= 40)",
                     i, t_low_dur/1000, t_high_dur/1000);
        end
        // Spec: tHIGH >= 24 ns (Table 50 Pure), tLOW >= 24 ns. Project default 4 cyc = 40 ns.
        // FSM adds 1-2 cyc latency, so expect 50-70 ns on bus.
        // PASS range: [40, 200]
        check("PP_tLOW_bit1",  t_low_dur/1000,  40, 200);
        check("PP_tHIGH_bit1", t_high_dur/1000, 40, 200);

        // -----------------------------------------------------
        // TEST 2: Open-drain SCL high/low timing (26 cyc high, 50 cyc low)
        // -----------------------------------------------------
        $display("");
        $display("--- Test 2: Open-Drain SCL bit timing (SCL_OD_HIGH=26, SCL_OD_LOW=50) ---");
        for (i = 0; i < 3; i = i + 1) begin
            measure_next_od_bit_full(1'b1);
            $display("  OD bit %0d: tLOW_OD=%0d ns (target >= 500), tHIGH_OD=%0d ns (target >= 260)",
                     i, t_low_dur/1000, t_high_dur/1000);
        end
        check("OD_tLOW_bit1",  t_low_dur/1000,  500, 700);
        check("OD_tHIGH_bit1", t_high_dur/1000, 260, 360);

        // -----------------------------------------------------
        // TEST 3: Issue STOP and measure TSU_STOP + BUS_FREE
        // -----------------------------------------------------
        $display("");
        $display("--- Test 3: STOP timing (TSU_STOP=26, BUS_FREE=130) ---");
        measure_stop_full;
        $display("  TSU_STOP: %0d ns (target >= 260)", tsu_stop_meas/1000);
        check("TSU_STOP", tsu_stop_meas/1000, 260, 400);

        // After STOP, FSM enters T_BUS_FREE_WAIT. done asserts at end.
        // Issue another START -> bit -> STOP sequence and measure BUS_FREE.
        pulse_start;
        wait_done;
        pulse_bit_pp(1'b1);
        wait_done;
        measure_bus_free;
        // BUS_FREE = T_STOP_SDA_RISE (260 ns hold after STOP) + T_BUS_FREE_WAIT (1300 ns tBUF)
        // Total = ~1560 ns + overhead. MIPI tBUF Pure min = 1300 ns.
        $display("  BUS_FREE (post-STOP edge to done): %0d ns (target >= 1300)", bus_free_meas/1000);
        check("BUS_FREE", bus_free_meas/1000, 1300, 1700);

        // -----------------------------------------------------
        // TEST 4: Fresh START measurement (TSU_START + THD_START)
        // -----------------------------------------------------
        $display("");
        $display("--- Test 4: START timing (TSU_START=26, THD_START=26) ---");
        measure_start_full;
        // TSU_START full = T_TSU_START_WAIT (26 cyc) + T_START_SDA_FALL (1 cyc) = 27 cyc + overhead
        // = ~310 ns. MIPI tSU_STA Fm+ min = 260 ns. RTL has 50 ns margin (1 FSM cycle + entry latency).
        $display("  TSU_START: %0d ns (target >= 260, MIPI Fm+ min)", tsu_start_meas/1000);
        check("TSU_START", tsu_start_meas/1000, 260, 400);
        $display("  THD_START:        %0d ns (target >= 260)", thd_start_full/1000);
        check("THD_START", thd_start_full/1000, 260, 360);

        // -----------------------------------------------------
        // Done
        // -----------------------------------------------------
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS  -  MIPI I3C Basic v1.2 Mixed Bus Fm+ timing verified");
        else
            $display("OVERALL: FAIL  -  see failures above");
        $display("============================================================");
        $display("");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;  // 100us
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count + 1);
        $display("OVERALL: FAIL (watchdog timeout)");
        $display("============================================================");
        $finish;
    end

    // Dump waveform for debug (optional)
    initial begin
        $dumpfile("/tmp/tb_mipi_mixedbus_timing.vcd");
        $dumpvars(0, tb_i3c_mipi_mixedbus_timing);
    end

endmodule
