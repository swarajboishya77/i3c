// i3c_async_fifo_sva.sv
// External assertions bound to i3c_async_fifo
// Does NOT modify synthesizable RTL — only for simulation/formal

module i3c_async_fifo_sva #(
  parameter int WIDTH = 8,
  parameter int DEPTH = 16,
  parameter int AW    = $clog2(DEPTH)
)(
  input logic wr_clk,
  input logic wr_rst_n,
  input logic rd_clk,
  input logic rd_rst_n,
  input logic [AW:0] wr_ptr_gray,
  input logic [AW:0] rd_ptr_gray,
  input logic [AW:0] wr_ptr_gray_sync2,
  input logic [AW:0] rd_ptr_gray_sync2,
  input logic wr_en,
  input logic rd_en,
  input logic wr_full,
  input logic rd_empty
);

  // Gray code monotonicity: only 1 bit changes per clock
  property p_gray_mono_wr;
    @(posedge wr_clk) disable iff (!wr_rst_n)
      $onehot(wr_ptr_gray ^ $past(wr_ptr_gray));
  endproperty
  assert property (p_gray_mono_wr) else $error("WR Gray code violation");

  property p_gray_mono_rd;
    @(posedge rd_clk) disable iff (!rd_rst_n)
      $onehot(rd_ptr_gray ^ $past(rd_ptr_gray));
  endproperty
  assert property (p_gray_mono_rd) else $error("RD Gray code violation");

  // No write when full
  property p_no_wr_full;
    @(posedge wr_clk) disable iff (!wr_rst_n)
      wr_en |-> !wr_full;
  endproperty
  assert property (p_no_wr_full) else $error("Write to full FIFO");

  // No read when empty
  property p_no_rd_empty;
    @(posedge rd_clk) disable iff (!rd_rst_n)
      rd_en |-> !rd_empty;
  endproperty
  assert property (p_no_rd_empty) else $error("Read from empty FIFO");

  // Full/Empty mutual exclusion
  property p_full_empty_excl;
    @(posedge wr_clk) disable iff (!wr_rst_n)
      !(wr_full && !rd_empty);  // Can't be full and have data to read
  endproperty
  assert property (p_full_empty_excl) else $error("Full and not-empty");

endmodule

// Bind to actual instance
bind i3c_async_fifo i3c_async_fifo_sva #(
  .WIDTH(WIDTH),
  .DEPTH(DEPTH),
  .AW(AW)
) u_sva (.*);
