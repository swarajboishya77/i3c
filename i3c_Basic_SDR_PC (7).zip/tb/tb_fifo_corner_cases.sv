// =============================================================================
// tb_fifo_corner_cases.sv
// -----------------------------------------------------------------------------
// Corner-case testbench for the generic i3c_fifo module (used as the building
// block for CMD/WR/RD/RESP FIFOs in the I3C controller).
//
// Tests:
//   T1. Overflow           — push > DEPTH, verify full + overflow sticky flag
//   T2. Underflow          — pop when empty, verify empty + underflow sticky
//   T3. Simultaneous push+pop — verify data integrity under backpressure
//   T4. Wrap-around        — fill, drain, fill again, verify pointer wrap
//   T5. Flush              — push, assert flush, verify empty
//   T6. Almost full/empty  — verify threshold flags
//   T7. Reset clears sticky flags
//
// Simulator: Icarus Verilog 12.0
// Compile: iverilog -g2012 -o /tmp/tb.vvp -c i3c_controller_top.f tb/tb_fifo_corner_cases.sv
// Run:     vvp /tmp/tb.vvp
// =============================================================================


module tb_fifo_corner_cases;

  // -------------------------------------------------------------------------
  // DUT parameters
  // -------------------------------------------------------------------------
  localparam int unsigned WIDTH     = 32;
  localparam int unsigned DEPTH     = 16;
  localparam int unsigned AFULL_TH  = 14;
  localparam int unsigned AEMPTY_TH = 2;

  // -------------------------------------------------------------------------
  // DUT signals
  // -------------------------------------------------------------------------
  logic        clk = 1'b0;
  logic        rst_n = 1'b0;
  logic        wr_en = 1'b0;
  logic [WIDTH-1:0] wr_data = '0;
  logic        rd_en = 1'b0;
  logic [WIDTH-1:0] rd_data;
  logic        empty;
  logic        full;
  logic        almost_full;
  logic        almost_empty;
  logic [$clog2(DEPTH+1)-1:0] data_count;
  logic        overflow;
  logic        underflow;
  logic        flush = 1'b0;

  // -------------------------------------------------------------------------
  // Clock
  // -------------------------------------------------------------------------
  always #5000 clk = ~clk;   // 100 MHz, 10ns period

  // -------------------------------------------------------------------------
  // DUT instantiation
  // -------------------------------------------------------------------------
  i3c_fifo #(
    .WIDTH    (WIDTH),
    .DEPTH    (DEPTH),
    .AFULL_TH (AFULL_TH),
    .AEMPTY_TH(AEMPTY_TH)
  ) u_dut (
    .clk          (clk),
    .rst_n        (rst_n),
    .wr_en        (wr_en),
    .wr_data      (wr_data),
    .rd_en        (rd_en),
    .rd_data      (rd_data),
    .empty        (empty),
    .full         (full),
    .almost_full  (almost_full),
    .almost_empty (almost_empty),
    .data_count   (data_count),
    .overflow     (overflow),
    .underflow    (underflow),
    .flush        (flush)
  );

  // -------------------------------------------------------------------------
  // Scoreboard
  // -------------------------------------------------------------------------
  int pass_count = 0;
  int fail_count = 0;

  task check(input int tnum, input string name, input logic cond);
    if (cond) begin
      $display("[PASS] T%0d %0s", tnum, name);
      pass_count = pass_count + 1;
    end else begin
      $display("[FAIL] T%0d %0s", tnum, name);
      fail_count = fail_count + 1;
    end
  endtask

  // -------------------------------------------------------------------------
  // Helper tasks
  // -------------------------------------------------------------------------
  // Apply reset for several cycles
  task do_reset();
    rst_n   = 1'b0;
    wr_en   = 1'b0;
    rd_en   = 1'b0;
    flush   = 1'b0;
    wr_data = '0;
    @(posedge clk);
    @(posedge clk);
    @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk);
    @(posedge clk);
  endtask

  // Single-cycle push (blocking — returns after the push has been clocked)
  task push(input logic [WIDTH-1:0] data);
    @(negedge clk);
    wr_en   = 1'b1;
    wr_data = data;
    @(posedge clk);
    @(negedge clk);
    wr_en   = 1'b0;
  endtask

  // Single-cycle pop (returns after rd_data is valid)
  task pop(output logic [WIDTH-1:0] data);
    @(negedge clk);
    rd_en = 1'b1;
    @(posedge clk);
    @(negedge clk);
    rd_en = 1'b0;
    // rd_data is registered: valid on the cycle AFTER rd_en was asserted
    data = rd_data;
  endtask

  // Single-cycle simultaneous push+pop
  task push_pop(input  logic [WIDTH-1:0] wdata,
                          output logic [WIDTH-1:0] rdata);
    @(negedge clk);
    wr_en = 1'b1;
    rd_en = 1'b1;
    wr_data = wdata;
    @(posedge clk);
    @(negedge clk);
    wr_en = 1'b0;
    rd_en = 1'b0;
    rdata = rd_data;
  endtask

  // Pulse flush for one cycle
  task do_flush();
    @(negedge clk);
    flush = 1'b1;
    @(posedge clk);
    @(negedge clk);
    flush = 1'b0;
    @(posedge clk);   // let registered status update
  endtask

  // -------------------------------------------------------------------------
  // Watchdog
  // -------------------------------------------------------------------------
  initial begin
    #2000000000;
    $display("[FAIL] WATCHDOG TIMEOUT — testbench stuck");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Test sequencer
  // -------------------------------------------------------------------------
  initial begin
    $display("==========================================================");
    $display("tb_fifo_corner_cases — starting");
    $display("==========================================================");

    // ------------------------------------------------------------------
    // Reset & initial state
    // ------------------------------------------------------------------
    do_reset();
    check(0, "post-reset empty",          empty == 1'b1);
    check(0, "post-reset full",           full  == 1'b0);
    check(0, "post-reset overflow",       overflow  == 1'b0);
    check(0, "post-reset underflow",      underflow == 1'b0);
    check(0, "post-reset data_count",     data_count == 0);
    check(0, "post-reset almost_empty",   almost_empty == 1'b1);
    check(0, "post-reset almost_full",    almost_full   == 1'b0);

    // ------------------------------------------------------------------
    // T1. Overflow
    // ------------------------------------------------------------------
    do_reset();
    // Push DEPTH items — FIFO should become full but not overflow
    // (the 16th push transitions FIFO to full; per RTL M2 fix the
    // overflow sticky flag may be set on the cycle the FIFO BECOMES
    // full, so we tolerate overflow=1 once full.)
    for (int i = 0; i < DEPTH; i++) begin
      push(32'hA000_0000 + i);
    end
    @(posedge clk);
    check(1, "full flag after DEPTH pushes",   full == 1'b1);
    check(1, "data_count at DEPTH",            data_count == DEPTH);

    // Now push more — overflow flag must be set, count must NOT exceed DEPTH
    for (int i = 0; i < 4; i++) begin
      push(32'hB000_0000 + i);
    end
    @(posedge clk);
    check(1, "overflow flag set on over-push", overflow == 1'b1);
    check(1, "data_count saturates at DEPTH",  data_count == DEPTH);
    check(1, "still full after over-pushes",   full == 1'b1);

    // ------------------------------------------------------------------
    // T2. Underflow
    // ------------------------------------------------------------------
    do_reset();
    check(2, "empty before underflow read", empty == 1'b1);
    // Attempt 3 reads when empty
    for (int i = 0; i < 3; i++) begin
      logic [WIDTH-1:0] dummy;
      pop(dummy);
    end
    @(posedge clk);
    check(2, "underflow flag set on empty read", underflow == 1'b1);
    check(2, "still empty after underflow reads", empty == 1'b1);
    check(2, "data_count still 0 after underflows", data_count == 0);

    // ------------------------------------------------------------------
    // T3. Simultaneous push + pop (data integrity)
    // ------------------------------------------------------------------
    do_reset();
    // Pre-load 4 items
    for (int i = 0; i < 4; i++) push(32'hC000_0000 + i);
    @(posedge clk);
    // Now do 8 simultaneous push+pop cycles. Each pop should return
    // the oldest pre-loaded item first, then the newly pushed items.
    begin : sim_pushpop
      logic [WIDTH-1:0] rdata;
      logic [WIDTH-1:0] expected[0:7];
      // Expected sequence: 4 pre-loaded + 4 newly pushed (FIFO order)
      expected[0] = 32'hC000_0000;
      expected[1] = 32'hC000_0001;
      expected[2] = 32'hC000_0002;
      expected[3] = 32'hC000_0003;
      expected[4] = 32'hD000_0000;
      expected[5] = 32'hD000_0001;
      expected[6] = 32'hD000_0002;
      expected[7] = 32'hD000_0003;
      for (int i = 0; i < 8; i++) begin
        push_pop(32'hD000_0000 + i, rdata);
        if (rdata !== expected[i]) begin
          $display("  sim-push/pop i=%0d got=%h exp=%h", i, rdata, expected[i]);
        end
        check(3, $sformatf("sim-push/pop data integrity i=%0d", i),
              rdata === expected[i]);
      end
      @(posedge clk);
      check(3, "FIFO retains 4 entries after 4 net pushes",
            data_count == 4);
    end

    // ------------------------------------------------------------------
    // T4. Wrap-around
    // ------------------------------------------------------------------
    do_reset();
    // Round 1: fill all DEPTH slots, drain them, verify each
    begin : wrap_round1
      logic [WIDTH-1:0] rdata;
      for (int i = 0; i < DEPTH; i++) push(32'hE000_0000 + i);
      check(4, "wrap: full after fill #1", full == 1'b1);
      for (int i = 0; i < DEPTH; i++) begin
        pop(rdata);
        check(4, $sformatf("wrap: drain #1 i=%0d", i),
              rdata === (32'hE000_0000 + i));
      end
      check(4, "wrap: empty after drain #1", empty == 1'b1);
    end
    // Round 2: fill + drain again — exercises pointer wrap
    begin : wrap_round2
      logic [WIDTH-1:0] rdata;
      for (int i = 0; i < DEPTH; i++) push(32'hF000_0000 + i);
      check(4, "wrap: full after fill #2", full == 1'b1);
      for (int i = 0; i < DEPTH; i++) begin
        pop(rdata);
        check(4, $sformatf("wrap: drain #2 i=%0d", i),
              rdata === (32'hF000_0000 + i));
      end
      check(4, "wrap: empty after drain #2", empty == 1'b1);
    end

    // ------------------------------------------------------------------
    // T5. Flush
    // ------------------------------------------------------------------
    do_reset();
    for (int i = 0; i < 8; i++) push(32'hA100_0000 + i);
    @(posedge clk);
    check(5, "flush: pre-flush not empty", empty == 1'b0);
    check(5, "flush: pre-flush count=8",   data_count == 8);
    do_flush();
    check(5, "flush: empty after flush",            empty == 1'b1);
    check(5, "flush: count=0 after flush",          data_count == 0);
    check(5, "flush: full=0 after flush",           full == 1'b0);
    // Flush must NOT clear sticky overflow/underflow flags
    // (only rst_n clears them — verify by re-asserting overflow then flushing)
    do_reset();
    for (int i = 0; i < DEPTH+2; i++) push(32'hA200_0000 + i);
    @(posedge clk);
    check(5, "flush: overflow set before flush", overflow == 1'b1);
    do_flush();
    check(5, "flush: empty after flush #2",      empty == 1'b1);
    check(5, "flush: overflow STAYS set (sticky)", overflow == 1'b1);

    // ------------------------------------------------------------------
    // T6. Almost full / almost empty thresholds
    // ------------------------------------------------------------------
    do_reset();
    check(6, "afull: almost_empty at reset (count<=AEMPTY_TH)",
          almost_empty == 1'b1 && almost_full == 1'b0);
    // Push up to AFULL_TH
    for (int i = 0; i < AFULL_TH-1; i++) push(32'hB000_0000 + i);
    @(posedge clk);
    check(6, $sformatf("afull: count=%0d not yet almost_full", AFULL_TH-1),
          almost_full == 1'b0);
    push(32'hB000_0000 + (AFULL_TH-1));
    @(posedge clk);
    check(6, $sformatf("afull: count=%0d => almost_full", AFULL_TH),
          almost_full == 1'b1 && full == 1'b0);
    // Drain down to AEMPTY_TH
    begin : ae_drain
      logic [WIDTH-1:0] rdata;
      // Drain until count is AEMPTY_TH+1
      for (int i = 0; i < (AFULL_TH - AEMPTY_TH - 1); i++) pop(rdata);
      @(posedge clk);
      check(6, $sformatf("aempty: count=%0d not yet almost_empty", AEMPTY_TH+1),
            almost_empty == 1'b0);
      pop(rdata);
      @(posedge clk);
      check(6, $sformatf("aempty: count=%0d => almost_empty", AEMPTY_TH),
            almost_empty == 1'b1 && empty == 1'b0);
    end

    // ------------------------------------------------------------------
    // T7. Reset clears sticky flags & pointers
    // ------------------------------------------------------------------
    do_reset();
    // Force overflow + underflow
    for (int i = 0; i < DEPTH+2; i++) push(32'hC100_0000 + i);
    begin
      logic [WIDTH-1:0] d;
      pop(d); // (will still underflow since full)
    end
    @(posedge clk);
    // Now assert reset
    do_reset();
    check(7, "rst clears overflow",  overflow  == 1'b0);
    check(7, "rst clears underflow", underflow == 1'b0);
    check(7, "rst empties FIFO",     empty == 1'b1);
    check(7, "rst clears data_count", data_count == 0);

    // ------------------------------------------------------------------
    // Summary
    // ------------------------------------------------------------------
    $display("==========================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
    if (fail_count == 0) $display("OVERALL: PASS");
    else                 $display("OVERALL: FAIL");
    $display("==========================================================");
    $finish;
  end

endmodule : tb_fifo_corner_cases
