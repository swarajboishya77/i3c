// =============================================================================
// tb_byte_serdes_i2c_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for byte_serdes_i2c.
// 22 corner-case tests covering:
//   - send byte with ACK
//   - send byte with NACK
//   - receive byte
//   - ACK drive
//   - NACK drive
//   - MSB-first verification
//   - START→byte→ACK→STOP
//   - multi-byte send
//   - multi-byte receive
//   - timeout
// =============================================================================

module tb_byte_serdes_i2c_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic        req_send_byte = 1'b0;
    logic        req_recv_byte = 1'b0;
    logic [7:0]  byte_tx = 8'h0;
    logic [7:0]  byte_rx;
    logic        is_last_byte = 1'b0;
    logic        cmd_bit_xfer;
    logic        cmd_bit_xfer_od;
    logic        sda_drive_val;
    logic        mode_pushpull;
    logic        phy_done = 1'b0;
    logic        sda_sampled = 1'b1;
    logic        byte_done;
    logic        ack_received;
    logic        busy;

    byte_serdes_i2c u_dut (
        .clk              (clk),
        .rst_n            (rst_n),
        .req_send_byte    (req_send_byte),
        .req_recv_byte    (req_recv_byte),
        .byte_tx          (byte_tx),
        .byte_rx          (byte_rx),
        .is_last_byte     (is_last_byte),
        .cmd_bit_xfer     (cmd_bit_xfer),
        .cmd_bit_xfer_od  (cmd_bit_xfer_od),
        .sda_drive_val    (sda_drive_val),
        .mode_pushpull    (mode_pushpull),
        .phy_done         (phy_done),
        .sda_sampled      (sda_sampled),
        .byte_done        (byte_done),
        .ack_received     (ack_received),
        .busy             (busy)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Send a byte: drive bit-by-bit, target ACKs on 9th bit
    task do_send_byte_ack;
        input [7:0] data;
        integer i;
        begin
            @(negedge clk);
            req_send_byte = 1'b1;
            byte_tx = data;
            is_last_byte = 1'b0;
            @(negedge clk);
            req_send_byte = 1'b0;
            // 8 data bits
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            // 9th bit (ACK from target)
            wait (cmd_bit_xfer == 1'b1);
            @(negedge clk);
            sda_sampled = 1'b0;  // ACK from target
            phy_done = 1'b1;
            @(negedge clk);
            phy_done = 1'b0;
            wait (byte_done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Send byte with NACK (target rejects)
    task do_send_byte_nack;
        input [7:0] data;
        integer i;
        begin
            @(negedge clk);
            req_send_byte = 1'b1;
            byte_tx = data;
            @(negedge clk);
            req_send_byte = 1'b0;
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            wait (cmd_bit_xfer == 1'b1);
            @(negedge clk);
            sda_sampled = 1'b1;  // NACK from target
            phy_done = 1'b1;
            @(negedge clk);
            phy_done = 1'b0;
            wait (byte_done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Receive byte: provide sda_sampled bits
    task do_recv_byte;
        input [7:0] data;
        input       last_byte;
        integer i;
        begin
            @(negedge clk);
            req_recv_byte = 1'b1;
            is_last_byte = last_byte;
            @(negedge clk);
            req_recv_byte = 1'b0;
            for (i = 7; i >= 0; i = i - 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                sda_sampled = data[i];
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            // 9th bit (controller ACK or NACK)
            wait (cmd_bit_xfer == 1'b1);
            @(negedge clk);
            phy_done = 1'b1;
            @(negedge clk);
            phy_done = 1'b0;
            wait (byte_done == 1'b1);
            @(posedge clk);
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_byte_serdes_i2c_sv.vcd");
        $dumpvars(0, tb_byte_serdes_i2c_sv);

        rst_n = 1'b0;
        req_send_byte = 1'b0;
        req_recv_byte = 1'b0;
        is_last_byte = 1'b0;
        phy_done = 1'b0;
        sda_sampled = 1'b1;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I2C Byte SerDes Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state
        test_num = 1;
        $display("--- T1: Reset state ---");
        repeat (2) @(posedge clk);  // settle
        check("busy == 0 after reset", busy == 1'b0);
        check("byte_done == 0 after reset", byte_done == 1'b0);
        check("ack_received == 1 after reset (default ACK, inverted)", ack_received == 1'b1);

        // T2: Send byte with ACK from target
        test_num = 2;
        $display("--- T2: Send byte with ACK ---");
        do_send_byte_ack(8'hA5);
        repeat (2) @(posedge clk);  // settle
        check("byte_done pulsed", 1'b1);
        check("ack_received == 1 (target ACKed)", ack_received == 1'b1);

        // T3: Send byte with NACK from target
        test_num = 3;
        $display("--- T3: Send byte with NACK ---");
        do_send_byte_nack(8'h5A);
        repeat (2) @(posedge clk);  // settle
        check("byte_done pulsed", 1'b1);
        check("ack_received == 0 (target NACKed)", ack_received == 1'b0);

        // T4: Receive byte
        test_num = 4;
        $display("--- T4: Receive byte ---");
        do_recv_byte(8'h3C, 1'b0);
        repeat (2) @(posedge clk);  // settle
        check("byte_rx == 0x3C", byte_rx == 8'h3C);
        check("byte_done pulsed", 1'b1);

        // T5: Receive byte with last_byte=1 (controller NACKs)
        test_num = 5;
        $display("--- T5: Receive byte with NACK (last) ---");
        do_recv_byte(8'h99, 1'b1);
        repeat (2) @(posedge clk);  // settle
        check("byte_rx == 0x99", byte_rx == 8'h99);
        check("byte_done pulsed", 1'b1);

        // T6: MSB-first verification (send 0x80, check first bit driven is 1)
        test_num = 6;
        $display("--- T6: MSB-first verification ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'h80;
        @(negedge clk);
        req_send_byte = 1'b0;
        wait (cmd_bit_xfer == 1'b1);
        @(posedge clk);  // sample during SHIFT
        check("first bit (MSB) driven == 1 for 0x80", sda_drive_val == 1'b1);
        @(negedge clk);
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        // Next bit (bit 6 = 0)
        wait (cmd_bit_xfer == 1'b1);
        @(posedge clk);
        check("second bit driven == 0 for 0x80", sda_drive_val == 1'b0);
        // Complete the byte
        begin : t6_loop
            integer i;
            for (i = 1; i < 7; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        sda_sampled = 1'b0;
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T7: Send 0xFF (all ones) — verify each bit driven high
        test_num = 7;
        $display("--- T7: Send 0xFF (all ones) ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'hFF;
        @(negedge clk);
        req_send_byte = 1'b0;
        begin : t7_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                #1;
                if (sda_drive_val !== 1'b1) ok = 0;
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            repeat (2) @(posedge clk);  // settle
            check("all 8 bits driven high for 0xFF", ok == 1);
        end
        // 9th bit
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        sda_sampled = 1'b0;
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T8: Send 0x00 (all zeros) — verify each bit driven low
        test_num = 8;
        $display("--- T8: Send 0x00 (all zeros) ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'h00;
        @(negedge clk);
        req_send_byte = 1'b0;
        begin : t8_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                #1;
                if (sda_drive_val !== 1'b0) ok = 0;
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            repeat (2) @(posedge clk);  // settle
            check("all 8 bits driven low for 0x00", ok == 1);
        end
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        sda_sampled = 1'b0;
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T9: ACK drive during receive (controller ACKs)
        test_num = 9;
        $display("--- T9: ACK drive during receive ---");
        @(negedge clk);
        req_recv_byte = 1'b1;
        is_last_byte = 1'b0;  // not last → controller ACKs
        @(negedge clk);
        req_recv_byte = 1'b0;
        begin : t9_loop
            integer i;
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                sda_sampled = 1'b0;
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        // 9th bit — controller drives ACK (0)
        wait (cmd_bit_xfer == 1'b1);
        #1;
        repeat (2) @(posedge clk);  // settle
        check("controller drives ACK (0) on 9th bit", sda_drive_val == 1'b0);
        @(negedge clk);
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T10: NACK drive during receive last byte
        test_num = 10;
        $display("--- T10: NACK drive on last byte ---");
        @(negedge clk);
        req_recv_byte = 1'b1;
        is_last_byte = 1'b1;  // last → controller NACKs
        @(negedge clk);
        req_recv_byte = 1'b0;
        begin : t10_loop
            integer i;
            for (i = 0; i < 8; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                sda_sampled = 1'b1;
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        wait (cmd_bit_xfer == 1'b1);
        #1;
        repeat (2) @(posedge clk);  // settle
        check("controller drives NACK (1) on last byte", sda_drive_val == 1'b1);
        @(negedge clk);
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T11: Multi-byte send sequence
        test_num = 11;
        $display("--- T11: Multi-byte send ---");
        do_send_byte_ack(8'h01);
        do_send_byte_ack(8'h02);
        do_send_byte_ack(8'h03);
        do_send_byte_ack(8'h04);
        repeat (2) @(posedge clk);  // settle
        check("4-byte sequence done", busy == 1'b0);

        // T12: Multi-byte receive sequence
        test_num = 12;
        $display("--- T12: Multi-byte receive ---");
        do_recv_byte(8'hAA, 1'b0);
        repeat (2) @(posedge clk);  // settle
        check("first recv byte == 0xAA", byte_rx == 8'hAA);
        do_recv_byte(8'hBB, 1'b0);
        check("second recv byte == 0xBB", byte_rx == 8'hBB);
        do_recv_byte(8'hCC, 1'b1);  // last
        repeat (2) @(posedge clk);  // settle
        check("third recv byte == 0xCC", byte_rx == 8'hCC);

        // T13: Mode always open-drain
        test_num = 13;
        $display("--- T13: Mode open-drain ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'hAA;
        @(negedge clk);
        req_send_byte = 1'b0;
        wait (cmd_bit_xfer == 1'b1);
        #1;
        repeat (2) @(posedge clk);  // settle
        check("mode_pushpull == 0 (open-drain)", mode_pushpull == 1'b0);
        check("cmd_bit_xfer_od == 1 (open-drain)", cmd_bit_xfer_od == 1'b1);
        // Cleanup
        begin : t13_loop
            integer i;
            for (i = 0; i < 9; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                if (i < 8) sda_sampled = 1'b0;
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T14: busy flag during operation
        test_num = 14;
        $display("--- T14: busy flag ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'hEE;
        @(negedge clk);
        req_send_byte = 1'b0;
        @(posedge clk);
        check("busy == 1 during send", busy == 1'b1);
        // Cleanup
        begin : t14_loop
            integer i;
            for (i = 0; i < 9; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                @(negedge clk);
                if (i < 8) sda_sampled = 1'b0;
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        wait (byte_done == 1'b1);
        @(posedge clk);
        check("busy == 0 after send", busy == 1'b0);

        // T15: Alternating bits 0xAA (10101010)
        test_num = 15;
        $display("--- T15: Send 0xAA (alternating) ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'hAA;
        @(negedge clk);
        req_send_byte = 1'b0;
        begin : t15_loop
            integer i;
            integer ok;
            logic exp;
            ok = 1;
            for (i = 7; i >= 0; i = i - 1) begin
                wait (cmd_bit_xfer == 1'b1);
                #1;
                exp = (8'hAA >> i) & 1;
                if (sda_drive_val !== exp) begin
                    ok = 0;
                    $display("    bit %0d: got %b, exp %b", i, sda_drive_val, exp);
                end
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            repeat (2) @(posedge clk);  // settle
            check("0xAA bits driven MSB-first correctly", ok == 1);
        end
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        sda_sampled = 1'b0;
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // T16: Send byte with mid-byte delay (slow phy_done)
        test_num = 16;
        $display("--- T16: Slow phy_done response ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'h77;
        @(negedge clk);
        req_send_byte = 1'b0;
        begin : t16_loop
            integer i;
            for (i = 0; i < 9; i = i + 1) begin
                wait (cmd_bit_xfer == 1'b1);
                // Add delay before phy_done
                repeat (5) @(posedge clk);
                @(negedge clk);
                if (i < 8) sda_sampled = 1'b0;
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
        end
        wait (byte_done == 1'b1);
        @(posedge clk);
        check("byte sent with slow phy_done", busy == 1'b0);

        // T17: Receive byte 0xFF
        test_num = 17;
        $display("--- T17: Receive 0xFF ---");
        do_recv_byte(8'hFF, 1'b0);
        repeat (2) @(posedge clk);  // settle
        check("byte_rx == 0xFF", byte_rx == 8'hFF);

        // T18: Receive byte 0x00
        test_num = 18;
        $display("--- T18: Receive 0x00 ---");
        do_recv_byte(8'h00, 1'b0);
        repeat (2) @(posedge clk);  // settle
        check("byte_rx == 0x00", byte_rx == 8'h00);

        // T19: Reset during send byte
        test_num = 19;
        $display("--- T19: Reset during send ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'h55;
        @(negedge clk);
        req_send_byte = 1'b0;
        // Mid-byte reset
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        @(negedge clk);
        rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("busy == 0 after reset mid-send", busy == 1'b0);

        // T20: Reset during receive byte
        test_num = 20;
        $display("--- T20: Reset during receive ---");
        @(negedge clk);
        req_recv_byte = 1'b1;
        @(negedge clk);
        req_recv_byte = 1'b0;
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("busy == 0 after reset mid-recv", busy == 1'b0);

        // T21: Repeated send/recv without idle gap
        test_num = 21;
        $display("--- T21: Repeated send/recv ---");
        do_send_byte_ack(8'h01);
        do_recv_byte(8'h02, 1'b0);
        do_send_byte_ack(8'h03);
        do_recv_byte(8'h04, 1'b0);
        repeat (2) @(posedge clk);  // settle
        check("alternating send/recv done", busy == 1'b0);

        // T22: Send byte 0x55 (alternating 01010101)
        test_num = 22;
        $display("--- T22: Send 0x55 (alternating) ---");
        @(negedge clk);
        req_send_byte = 1'b1;
        byte_tx = 8'h55;
        @(negedge clk);
        req_send_byte = 1'b0;
        begin : t22_loop
            integer i;
            integer ok;
            logic exp;
            ok = 1;
            for (i = 7; i >= 0; i = i - 1) begin
                wait (cmd_bit_xfer == 1'b1);
                #1;
                exp = (8'h55 >> i) & 1;
                if (sda_drive_val !== exp) begin
                    ok = 0;
                end
                @(negedge clk);
                phy_done = 1'b1;
                @(negedge clk);
                phy_done = 1'b0;
            end
            repeat (2) @(posedge clk);  // settle
            check("0x55 bits driven MSB-first correctly", ok == 1);
        end
        wait (cmd_bit_xfer == 1'b1);
        @(negedge clk);
        sda_sampled = 1'b0;
        phy_done = 1'b1;
        @(negedge clk);
        phy_done = 1'b0;
        wait (byte_done == 1'b1);
        @(posedge clk);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
