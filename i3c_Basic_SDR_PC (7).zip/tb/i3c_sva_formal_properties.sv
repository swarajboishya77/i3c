// =============================================================================
// i3c_sva_formal_properties.sv
// -----------------------------------------------------------------------------
// Protocol compliance and invariant property checks for the I3C Primary
// Controller. Written as simulation monitors (always blocks) that are also
// synthesizable as SVA assertions in formal tools.
//
// Categories:
//   1. AXI4-Lite protocol compliance (handshake stability, response validity)
//   2. FIFO invariant properties (mutual exclusion, stickiness)
//   3. FSM liveness (no deadlocks — busy eventually returns to idle)
//   4. I3C protocol compliance (idle bus released, SDA/SCL stability)
//   5. Reset assertion (async reset clears all state)
//
// Usage:
//   - Icarus Verilog: runtime checking during simulation (this file)
//   - Formal tools (SymbiYosys/JasperGold/VC Formal): rewrite the always
//     blocks as `assert property` statements. The logic is identical.
// =============================================================================

`ifndef I3C_SVA_FORMAL_PROPERTIES_SV
`define I3C_SVA_FORMAL_PROPERTIES_SV

// =========================================================================
// AXI4-Lite Protocol Properties
// =========================================================================
module sva_axi4_lite (
    input logic        clk,
    input logic        rst_n,
    input logic        awvalid,
    input logic        awready,
    input logic [31:0] awaddr,
    input logic        wvalid,
    input logic        wready,
    input logic [31:0] wdata,
    input logic        bvalid,
    input logic        bready,
    input logic [1:0]  bresp,
    input logic        arvalid,
    input logic        arready,
    input logic [31:0] araddr,
    input logic        rvalid,
    input logic        rready,
    input logic [31:0] rdata,
    input logic [1:0]  rresp
);

    // Previous-cycle values for stability checks
    logic awvalid_q, wvalid_q, bvalid_q, arvalid_q, rvalid_q;
    logic awready_q, wready_q, bready_q, arready_q, rready_q;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            awvalid_q <= 1'b0;  wvalid_q  <= 1'b0;  bvalid_q  <= 1'b0;
            arvalid_q <= 1'b0;  rvalid_q  <= 1'b0;
            awready_q <= 1'b0;  wready_q  <= 1'b0;  bready_q  <= 1'b0;
            arready_q <= 1'b0;  rready_q  <= 1'b0;
        end else begin
            awvalid_q <= awvalid;  wvalid_q  <= wvalid;  bvalid_q  <= bvalid;
            arvalid_q <= arvalid;  rvalid_q  <= rvalid;
            awready_q <= awready;  wready_q  <= wready;  bready_q  <= bready;
            arready_q <= arready;  rready_q  <= rready;
        end
    end

    // P1: awvalid stays high until awready (AXI handshake stability)
    // Check: if awvalid was high last cycle AND awready was NOT high last cycle
    // AND awvalid is now low → violation (deasserted before handshake)
    // But if awready WAS high last cycle (handshake occurred), then deasserting is OK.
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 &&
            awvalid_q === 1'b1 && !(awvalid_q && awready_q) && awvalid === 1'b0)
            $display("  [%0t] SVA FAIL: awvalid deasserted before awready", $time);
    end

    // P2: wvalid stays high until wready
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 &&
            wvalid_q === 1'b1 && !(wvalid_q && wready_q) && wvalid === 1'b0)
            $display("  [%0t] SVA FAIL: wvalid deasserted before wready", $time);
    end

    // P3: bvalid stays high until bready
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 &&
            bvalid_q === 1'b1 && !(bvalid_q && bready_q) && bvalid === 1'b0)
            $display("  [%0t] SVA FAIL: bvalid deasserted before bready", $time);
    end

    // P4: arvalid stays high until arready
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 &&
            arvalid_q === 1'b1 && !(arvalid_q && arready_q) && arvalid === 1'b0)
            $display("  [%0t] SVA FAIL: arvalid deasserted before arready", $time);
    end

    // P5: rvalid stays high until rready
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 &&
            rvalid_q === 1'b1 && !(rvalid_q && rready_q) && rvalid === 1'b0)
            $display("  [%0t] SVA FAIL: rvalid deasserted before rready", $time);
    end

    // P6: bresp is valid (never 2'b01 — reserved)
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 && bvalid && bresp == 2'b01)
            $display("  [%0t] SVA FAIL: bresp = 2'b01 (reserved)", $time);
    end

    // P7: rresp is valid (never 2'b01)
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 && rvalid && rresp == 2'b01)
            $display("  [%0t] SVA FAIL: rresp = 2'b01 (reserved)", $time);
    end

endmodule

// =========================================================================
// FIFO Invariant Properties
// =========================================================================
module sva_fifo_invariants (
    input logic        clk,
    input logic        rst_n,
    input logic        wr_en,
    input logic [31:0] wr_data,
    input logic        rd_en,
    input logic [31:0] rd_data,
    input logic        full,
    input logic        empty,
    input logic        almost_full,
    input logic        almost_empty,
    input logic [5:0]  data_count,
    input logic        overflow,
    input logic        underflow
);

    // P1: full and empty are mutually exclusive
    always_ff @(posedge clk) begin
        if (rst_n && full && empty)
            $display("  [%0t] SVA FAIL: FIFO full and empty simultaneously", $time);
    end

    // P2: data_count=0 when empty
    always_ff @(posedge clk) begin
        if (rst_n && empty && data_count != 0)
            $display("  [%0t] SVA FAIL: FIFO empty but data_count=%0d", $time, data_count);
    end

    // P3: overflow is sticky (only cleared by reset)
    logic overflow_q;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) overflow_q <= 1'b0;
        else        overflow_q <= overflow;
    end
    always_ff @(posedge clk) begin
        if (rst_n && overflow_q && !overflow)
            $display("  [%0t] SVA FAIL: overflow cleared without reset", $time);
    end

    // P4: underflow is sticky (only cleared by reset)
    logic underflow_q;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) underflow_q <= 1'b0;
        else        underflow_q <= underflow;
    end
    always_ff @(posedge clk) begin
        if (rst_n && underflow_q && !underflow)
            $display("  [%0t] SVA FAIL: underflow cleared without reset", $time);
    end

endmodule

// =========================================================================
// FSM Liveness Properties (no deadlocks)
// =========================================================================
module sva_fsm_liveness (
    input logic        clk,
    input logic        rst_n,
    input logic        controller_busy,
    input logic        controller_idle,
    input logic        cmd_fifo_empty,
    input logic        resp_fifo_full
);

    // P1: If CMD FIFO is empty and controller is idle, it stays idle
    // (No spurious wakeups)
    logic idle_q, cmd_empty_q;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            idle_q <= 1'b1;
            cmd_empty_q <= 1'b1;
        end else begin
            idle_q <= controller_idle;
            cmd_empty_q <= cmd_fifo_empty;
        end
    end

    always_ff @(posedge clk) begin
        if (rst_n && idle_q && cmd_empty_q && !controller_idle)
            $display("  [%0t] SVA FAIL: controller woke from idle with empty CMD FIFO", $time);
    end

endmodule

// =========================================================================
// I3C Protocol Compliance Properties
// =========================================================================
module sva_i3c_protocol (
    input logic        clk,
    input logic        rst_n,
    input logic        scl,
    input logic        sda,
    input logic        controller_busy,
    input logic        controller_idle,
    input logic        target_addressed
);

    // P1: Controller idle implies bus is released (SCL=1 or Z, SDA=1 or Z)
    // SIM-22: Time-gated, and use === to avoid X-propagation
    always_ff @(posedge clk) begin
        if (rst_n && $time > 200 && controller_idle === 1'b1) begin
            if (scl !== 1'b1 && scl !== 1'bz)
                $display("  [%0t] SVA FAIL: controller idle but SCL=%b (not released)", $time, scl);
            if (sda !== 1'b1 && sda !== 1'bz)
                $display("  [%0t] SVA FAIL: controller idle but SDA=%b (not released)", $time, sda);
        end
    end

endmodule

// =========================================================================
// Reset Assertion Properties
// =========================================================================
module sva_reset_properties (
    input logic        clk,
    input logic        rst_n,
    input logic        controller_idle,
    input logic        controller_busy,
    input logic        cmd_fifo_empty,
    input logic        resp_fifo_empty,
    input logic        wr_fifo_empty,
    input logic        rd_fifo_empty
);

    // P1: During reset, controller is idle
    always_ff @(posedge clk) begin
        if (!rst_n && !controller_idle)
            $display("  [%0t] SVA FAIL: reset asserted but controller not idle", $time);
    end

    // P2: During reset, all FIFOs are empty
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            if (!cmd_fifo_empty)
                $display("  [%0t] SVA FAIL: reset asserted but CMD FIFO not empty", $time);
            if (!resp_fifo_empty)
                $display("  [%0t] SVA FAIL: reset asserted but RESP FIFO not empty", $time);
        end
    end

endmodule

`endif // I3C_SVA_FORMAL_PROPERTIES_SV
