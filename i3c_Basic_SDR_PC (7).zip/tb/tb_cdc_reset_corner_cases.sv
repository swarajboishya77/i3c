// =============================================================================
// tb_cdc_reset_corner_cases.sv
// -----------------------------------------------------------------------------
// Corner-case testbench for CDC (Clock Domain Crossing) and reset scenarios.
//
// DUTs:
//   - i3c_async_fifo (rtl/clock/i3c_async_fifo.sv) — dual-clock FIFO using
//     Gray-coded pointer CDC.
//   - i3c_target_engine (rtl/target/i3c_target_engine.sv) — exercises async
//     reset recovery on the SCL-domain FSM.
//
// Tests:
//   T1. Async FIFO basic CDC (push 8, pop 8, verify data integrity)
//   T2. Async FIFO full (push DEPTH, verify wr_full)
//   T3. Async FIFO empty (drain, verify rd_empty)
//   T4. Async FIFO write-faster-than-read (100 MHz wr vs 71 MHz rd)
//   T5. Reset during FIFO operation (assert reset mid-push, verify empty)
//   T6. Async reset recovery (reset, deassert, push/pop again)
//   T7. Target engine reset (verify status outputs are clean after reset)
//   T8. Target engine reset mid-transaction (START, assert reset, verify clean)
//
// Simulator: Icarus Verilog 12.0
// =============================================================================


module tb_cdc_reset_corner_cases;

  // -------------------------------------------------------------------------
  // Clocks (independent, non-harmonic to stress CDC)
  // -------------------------------------------------------------------------
  logic wr_clk = 1'b0;
  logic rd_clk = 1'b0;
  logic clk_sys = 1'b0;

  // wr_clk: 100 MHz (5 ns half)
  always #5000  wr_clk = ~wr_clk;
  // rd_clk: ~71 MHz (7 ns half — non-harmonic)
  always #7000  rd_clk = ~rd_clk;
  // clk_sys: 100 MHz
  always #5000  clk_sys = ~clk_sys;

  // =========================================================================
  // DUT #1: i3c_async_fifo
  // =========================================================================
  localparam int AFIFO_WIDTH = 8;
  localparam int AFIFO_DEPTH = 16;

  logic wr_rst_n = 1'b0;
  logic rd_rst_n = 1'b0;
  logic                    wr_en   = 1'b0;
  logic [AFIFO_WIDTH-1:0]  wr_data = '0;
  logic                    wr_full;
  logic                    rd_en    = 1'b0;
  logic [AFIFO_WIDTH-1:0]  rd_data;
  logic                    rd_empty;

  i3c_async_fifo #(
    .WIDTH (AFIFO_WIDTH),
    .DEPTH (AFIFO_DEPTH),
    .REG_OUT (0)  // BUG-R4-051 FIX: combinational read for TB
  ) u_afifo (
    .wr_clk    (wr_clk),
    .rst_n     (wr_rst_n),  // BUG-R4-051 FIX: single common reset (not wr_rst_n/rd_rst_n)
    .wr_en     (wr_en),
    .wr_data   (wr_data),
    .wr_full   (wr_full),
    .rd_clk    (rd_clk),
    .rd_en     (rd_en),
    .rd_data   (rd_data),
    .rd_empty  (rd_empty)
  );

  // =========================================================================
  // DUT #2: i3c_target_engine (for reset recovery tests)
  // =========================================================================
  logic        rst_sys_n          = 1'b0;
  logic        scl_filt           = 1'b1;   // idle = high
  logic        sda_filt           = 1'b1;   // idle = high
  logic        scl_filt_rst_n     = 1'b0;
  logic        target_en          = 1'b0;
  logic [6:0]  target_dyn_addr    = 7'h08;
  // target_ibi_en removed: port does not exist on i3c_target_engine (IBI enable is internal via ENEC/DISEC)
  // logic        target_ibi_en      = 1'b0;
  logic        reclaim_test_active= 1'b0;

  logic        target_addressed;
  logic        target_busy;
  logic        target_rx_done;
  logic [7:0]  target_rx_byte;
  logic        target_tx_req;
  logic [7:0]  target_tx_byte     = 8'h00;
  logic        target_tx_valid    = 1'b0;
  logic        target_ibi_req;
  logic        tgt_sda_o;
  logic        tgt_sda_oe;
  logic        target_nack_sent;
  logic        role_return;
  logic [7:0]  ccc_getrtgl_byte  = 8'h00;
  logic        ccc_getrtgl_valid = 1'b0;

  i3c_target_engine u_target (
    .clk_sys             (clk_sys),
    .rst_sys_n           (rst_sys_n),
    .scl_filt            (scl_filt),
    .sda_filt            (sda_filt),
    .scl_filt_rst_n      (scl_filt_rst_n),
    .target_en           (target_en),
    .target_dyn_addr     (target_dyn_addr),
    .target_ibi_en       (1'b0),  // BUG-R4-051 FIX: connect port (was removed, caused X)
    .reclaim_test_active (reclaim_test_active),
    .target_addressed    (target_addressed),
    .target_busy         (target_busy),
    .target_rx_done      (target_rx_done),
    .target_rx_byte      (target_rx_byte),
    .target_tx_req       (target_tx_req),
    .target_tx_byte      (target_tx_byte),
    .target_tx_valid     (target_tx_valid),
    .target_ibi_req      (target_ibi_req),
    .tgt_sda_o           (tgt_sda_o),
    .tgt_sda_oe          (tgt_sda_oe),
    .target_nack_sent    (target_nack_sent),
    .role_return         (role_return),
    .ccc_getrtgl_byte    (ccc_getrtgl_byte),
    .ccc_getrtgl_valid   (ccc_getrtgl_valid)
  );

  // -------------------------------------------------------------------------
  // Scoreboard
  // -------------------------------------------------------------------------
  int pass_count = 0;
  int fail_count = 0;

  task automatic check(input int tnum, input string name, input logic cond);
    if (cond) begin
      $display("[PASS] T%0d %0s", tnum, name);
      pass_count = pass_count + 1;
    end else begin
      $display("[FAIL] T%0d %0s", tnum, name);
      fail_count = fail_count + 1;
    end
  endtask

  // -------------------------------------------------------------------------
  // Async FIFO helpers
  // -------------------------------------------------------------------------
  task automatic afifo_reset();
    wr_rst_n = 1'b0;
    rd_rst_n = 1'b0;
    wr_en    = 1'b0;
    rd_en    = 1'b0;
    @(posedge wr_clk);
    @(posedge rd_clk);
    @(posedge wr_clk);
    @(posedge rd_clk);
    wr_rst_n = 1'b1;
    rd_rst_n = 1'b1;
    // Let CDC sync registers settle (2 cycles in each domain)
    repeat (4) @(posedge wr_clk);
    repeat (4) @(posedge rd_clk);
  endtask

  // Push one byte on wr_clk (blocks until accepted)
  task automatic afifo_push(input logic [7:0] data);
    @(negedge wr_clk);
    while (wr_full) @(negedge wr_clk);
    wr_en   = 1'b1;
    wr_data = data;
    @(posedge wr_clk);
    @(negedge wr_clk);
    wr_en   = 1'b0;
  endtask

  // Pop one byte on rd_clk (blocks until data available)
  task automatic afifo_pop(output logic [7:0] data);
    @(negedge rd_clk);
    while (rd_empty) @(negedge rd_clk);
    rd_en = 1'b1;
    data  = rd_data;     // combinational read
    @(posedge rd_clk);
    @(negedge rd_clk);
    rd_en = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // Target engine helpers
  // -------------------------------------------------------------------------
  task automatic target_reset();
    rst_sys_n       = 1'b0;
    scl_filt_rst_n  = 1'b0;
    target_en       = 1'b0;
    scl_filt        = 1'b1;
    sda_filt        = 1'b1;
    @(posedge clk_sys);
    // The SCL-domain always block is edge-sensitive (no level sensitivity).
    // With scl_filt_rst_n starting low, we must force an evaluation by
    // toggling sda_filt (which is in the sensitivity list). The reset
    // path takes priority and sets all FSM state to IDLE.
    sda_filt = 1'b0;
    @(posedge clk_sys);
    sda_filt = 1'b1;
    @(posedge clk_sys);
    @(posedge clk_sys);
    rst_sys_n       = 1'b1;
    scl_filt_rst_n  = 1'b1;
    @(posedge clk_sys);
    @(posedge clk_sys);
  endtask

  // Generate START condition: SCL high, SDA high→low (FSM moves out of IDLE)
  task automatic gen_start();
    sda_filt = 1'b1;
    scl_filt = 1'b1;
    #25000;
    sda_filt = 1'b0;   // START: SDA falls while SCL high
    #25000;
  endtask

  // -------------------------------------------------------------------------
  // Watchdog
  // -------------------------------------------------------------------------
  initial begin
    #2000000000;
    $display("[FAIL] WATCHDOG TIMEOUT — testbench stuck");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Test sequencer
  // -------------------------------------------------------------------------
  initial begin
    $display("==========================================================");
    $display("tb_cdc_reset_corner_cases — starting");
    $display("==========================================================");

    // ------------------------------------------------------------------
    // T1. Async FIFO basic CDC (8 bytes, verify data integrity)
    // ------------------------------------------------------------------
    afifo_reset();
    check(1, "T1 empty after reset", rd_empty == 1'b1);
    begin : t1_basic
      logic [7:0] rdata;
      for (int i = 0; i < 8; i++) afifo_push(8'h10 + i);
      // Let CDC sync settle so rd_empty reflects the pushes
      repeat (5) @(posedge rd_clk);
      check(1, "T1 not empty after pushes", rd_empty == 1'b0);
      for (int i = 0; i < 8; i++) begin
        afifo_pop(rdata);
        check(1, $sformatf("T1 CDC data i=%0d", i), rdata === (8'h10 + i));
      end
      repeat (5) @(posedge rd_clk);
      check(1, "T1 empty after drain", rd_empty == 1'b1);
    end

    // ------------------------------------------------------------------
    // T2. Async FIFO full
    // ------------------------------------------------------------------
    afifo_reset();
    begin : t2_full
      for (int i = 0; i < AFIFO_DEPTH; i++) afifo_push(8'hA0 + i);
      repeat (5) @(posedge wr_clk);
      check(2, "T2 full after DEPTH pushes", wr_full == 1'b1);
      // Push one more — should be blocked (wr_full stays 1)
      // Verify by checking wr_full is still 1 after some time
      repeat (5) @(posedge wr_clk);
      check(2, "T2 still full when over-pushing", wr_full == 1'b1);
    end

    // ------------------------------------------------------------------
    // T3. Async FIFO empty (drain verification)
    // ------------------------------------------------------------------
    afifo_reset();
    check(3, "T3 empty at reset", rd_empty == 1'b1);
    begin : t3_drain
      logic [7:0] rdata;
      afifo_push(8'h55);
      afifo_push(8'hAA);
      repeat (5) @(posedge rd_clk);
      check(3, "T3 not empty after pushes", rd_empty == 1'b0);
      afifo_pop(rdata);
      check(3, "T3 pop #1 data", rdata === 8'h55);
      afifo_pop(rdata);
      check(3, "T3 pop #2 data", rdata === 8'hAA);
      repeat (5) @(posedge rd_clk);
      check(3, "T3 empty after drain", rd_empty == 1'b1);
    end

    // ------------------------------------------------------------------
    // T4. Write faster than read (100 MHz wr vs ~71 MHz rd)
    // ------------------------------------------------------------------
    afifo_reset();
    begin : t4_wr_fast
      logic [7:0] rdata;
      // Push 8 bytes back-to-back on fast wr_clk
      for (int i = 0; i < 8; i++) afifo_push(8'hB0 + i);
      // Pop them on slower rd_clk — CDC must preserve order & data
      for (int i = 0; i < 8; i++) begin
        afifo_pop(rdata);
        check(4, $sformatf("T4 wr-fast data i=%0d", i), rdata === (8'hB0 + i));
      end
    end

    // ------------------------------------------------------------------
    // T5. Reset during FIFO operation
    // ------------------------------------------------------------------
    afifo_reset();
    begin : t5_reset_mid
      logic [7:0] rdata;
      // Push 4 bytes
      for (int i = 0; i < 4; i++) afifo_push(8'hC0 + i);
      repeat (3) @(posedge rd_clk);
      check(5, "T5 not empty before reset", rd_empty == 1'b0);
      // Assert both resets mid-operation (async)
      wr_rst_n = 1'b0;
      rd_rst_n = 1'b0;
      @(posedge wr_clk);
      @(posedge rd_clk);
      @(posedge wr_clk);
      @(posedge rd_clk);
      // Deassert
      wr_rst_n = 1'b1;
      rd_rst_n = 1'b1;
      // Wait for CDC sync to settle
      repeat (6) @(posedge rd_clk);
      repeat (6) @(posedge wr_clk);
      check(5, "T5 empty after mid-op reset", rd_empty == 1'b1);
      check(5, "T5 not full after mid-op reset", wr_full == 1'b0);
    end

    // ------------------------------------------------------------------
    // T6. Async reset recovery (push/pop after reset)
    // ------------------------------------------------------------------
    afifo_reset();
    begin : t6_recovery
      logic [7:0] rdata;
      // Phase 1: push/pop some data
      for (int i = 0; i < 4; i++) afifo_push(8'hD0 + i);
      for (int i = 0; i < 4; i++) afifo_pop(rdata);
      // Phase 2: assert async reset
      wr_rst_n = 1'b0;
      rd_rst_n = 1'b0;
      @(posedge wr_clk);
      @(posedge rd_clk);
      @(posedge wr_clk);
      @(posedge rd_clk);
      wr_rst_n = 1'b1;
      rd_rst_n = 1'b1;
      repeat (6) @(posedge wr_clk);
      repeat (6) @(posedge rd_clk);
      check(6, "T6 empty after async reset", rd_empty == 1'b1);
      // Phase 3: push/pop again — FIFO must be usable
      for (int i = 0; i < 4; i++) afifo_push(8'hE0 + i);
      for (int i = 0; i < 4; i++) begin
        afifo_pop(rdata);
        check(6, $sformatf("T6 recovery data i=%0d", i), rdata === (8'hE0 + i));
      end
    end

    // ------------------------------------------------------------------
    // T7. Target engine reset (status outputs clean)
    // ------------------------------------------------------------------
    target_reset();
    target_en = 1'b1;
    @(posedge clk_sys);
    @(posedge clk_sys);
    check(7, "T7 target not busy after reset",     target_busy      == 1'b0);
    check(7, "T7 not addressed after reset",       target_addressed == 1'b0);
    check(7, "T7 nack_sent=0 after reset",         target_nack_sent == 1'b0);
    check(7, "T7 ibi_req=0 after reset",           target_ibi_req   == 1'b0);
    check(7, "T7 role_return=0 after reset",       role_return      == 1'b0);

    // ------------------------------------------------------------------
    // T8. Target engine reset mid-transaction
    // ------------------------------------------------------------------
    target_reset();
    target_en = 1'b1;
    scl_filt  = 1'b1;
    sda_filt  = 1'b1;
    @(posedge clk_sys);
    @(posedge clk_sys);
    check(8, "T8 idle before START", target_busy == 1'b0);
    // Issue START to move FSM out of IDLE
    gen_start();
    #50000;
    check(8, "T8 busy after START", target_busy == 1'b1);
    // Assert async reset mid-transaction
    scl_filt_rst_n = 1'b0;
    #30000;
    check(8, "T8 not busy during reset",   target_busy == 1'b0);
    check(8, "T8 nack_sent cleared by rst", target_nack_sent == 1'b0);
    // Deassert reset — verify FSM stays in IDLE (clean recovery)
    scl_filt_rst_n = 1'b1;
    // Return bus to idle
    scl_filt = 1'b1;
    sda_filt = 1'b1;
    #100000;  // 100ns settle delay
    check(8, "T8 stays not busy after reset deassert",
          target_busy == 1'b0);
    check(8, "T8 not addressed after recovery",
          target_addressed == 1'b0);

    // ------------------------------------------------------------------
    // Summary
    // ------------------------------------------------------------------
    $display("==========================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
    if (fail_count == 0) $display("OVERALL: PASS");
    else                 $display("OVERALL: FAIL");
    $display("==========================================================");
    $finish;
  end

endmodule : tb_cdc_reset_corner_cases
