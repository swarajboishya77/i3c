// =============================================================================
// tb_i3c_phy_mux_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_phy_mux.
// 24 corner-case tests covering:
//   - all 4 select values
//   - SDA/SCL routing for each mode
//   - target mode (SCL not driven)
//   - boot mode
//   - switching modes mid-transfer
//   - default mode after reset (combinational, default = RSV/release)
//   - all inputs active simultaneously
//   - pad readback broadcast
// =============================================================================

module tb_i3c_phy_mux_sv;

    logic [1:0]  phy_mux_sel = 2'd3;  // default RSV
    logic        dphy_sda_o = 1'b1;
    logic        dphy_sda_oe = 1'b0;
    logic        dphy_scl_o = 1'b1;
    logic        dphy_scl_oe = 1'b0;
    logic        tgt_sda_o = 1'b1;
    logic        tgt_sda_oe = 1'b0;
    logic        boot_sda_o = 1'b1;
    logic        boot_sda_oe = 1'b0;
    logic        boot_scl_o = 1'b1;
    logic        boot_scl_oe = 1'b0;
    logic        pad_sda_o;
    logic        pad_sda_oe;
    logic        pad_scl_o;
    logic        pad_scl_oe;
    logic        pad_sda_i = 1'b1;
    logic        pad_scl_i = 1'b1;
    logic        dphy_sda_i;
    logic        dphy_scl_i;
    logic        tgt_sda_i;
    logic        tgt_scl_i;
    logic        boot_sda_i;
    logic        boot_scl_i;

    i3c_phy_mux u_dut (
        .phy_mux_sel   (phy_mux_sel),
        .dphy_sda_o    (dphy_sda_o),
        .dphy_sda_oe   (dphy_sda_oe),
        .dphy_scl_o    (dphy_scl_o),
        .dphy_scl_oe   (dphy_scl_oe),
        .tgt_sda_o     (tgt_sda_o),
        .tgt_sda_oe    (tgt_sda_oe),
        .boot_sda_o    (boot_sda_o),
        .boot_sda_oe   (boot_sda_oe),
        .boot_scl_o    (boot_scl_o),
        .boot_scl_oe   (boot_scl_oe),
        .pad_sda_o     (pad_sda_o),
        .pad_sda_oe    (pad_sda_oe),
        .pad_scl_o     (pad_scl_o),
        .pad_scl_oe    (pad_scl_oe),
        .pad_sda_i     (pad_sda_i),
        .pad_scl_i     (pad_scl_i),
        .dphy_sda_i    (dphy_sda_i),
        .dphy_scl_i    (dphy_scl_i),
        .tgt_sda_i     (tgt_sda_i),
        .tgt_scl_i     (tgt_scl_i),
        .boot_sda_i    (boot_sda_i),
        .boot_scl_i    (boot_scl_i)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_phy_mux_sv.vcd");
        $dumpvars(0, tb_i3c_phy_mux_sv);

        $display("");
        $display("============================================================");
        $display("I3C PHY Mux Comprehensive Testbench");
        $display("============================================================");

        // T1: Default mode (RSV) — bus released
        test_num = 1;
        $display("--- T1: Default mode (RSV=2'd3) ---");
        phy_mux_sel = 2'd3;
        #1;
        check("pad_sda_oe == 0 (released) in RSV mode", pad_sda_oe == 1'b0);
        check("pad_scl_oe == 0 (released) in RSV mode", pad_scl_oe == 1'b0);
        check("pad_sda_o == 1 (idle) in RSV mode", pad_sda_o == 1'b1);
        check("pad_scl_o == 1 (idle) in RSV mode", pad_scl_o == 1'b1);

        // T2: DPHY mode (sel=0) — both SDA and SCL driven by DPHY
        test_num = 2;
        $display("--- T2: DPHY mode ---");
        phy_mux_sel = 2'd0;
        dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
        dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
        #1;
        check("pad_sda_o == dphy_sda_o", pad_sda_o == dphy_sda_o);
        check("pad_sda_oe == dphy_sda_oe", pad_sda_oe == dphy_sda_oe);
        check("pad_scl_o == dphy_scl_o", pad_scl_o == dphy_scl_o);
        check("pad_scl_oe == dphy_scl_oe", pad_scl_oe == dphy_scl_oe);

        // T3: DPHY mode — high values
        test_num = 3;
        $display("--- T3: DPHY mode high values ---");
        dphy_sda_o = 1'b1; dphy_sda_oe = 1'b1;
        dphy_scl_o = 1'b1; dphy_scl_oe = 1'b1;
        #1;
        check("pad_sda_o == 1 (DPHY high)", pad_sda_o == 1'b1);
        check("pad_scl_o == 1 (DPHY high)", pad_scl_o == 1'b1);

        // T4: DPHY mode — high-Z (oe=0)
        test_num = 4;
        $display("--- T4: DPHY high-Z ---");
        dphy_sda_oe = 1'b0;
        dphy_scl_oe = 1'b0;
        #1;
        check("pad_sda_oe == 0 (DPHY high-Z)", pad_sda_oe == 1'b0);
        check("pad_scl_oe == 0 (DPHY high-Z)", pad_scl_oe == 1'b0);

        // T5: Target mode (sel=1) — SDA from target, SCL never driven
        test_num = 5;
        $display("--- T5: Target mode SDA ---");
        phy_mux_sel = 2'd1;
        tgt_sda_o = 1'b0; tgt_sda_oe = 1'b1;
        #1;
        check("pad_sda_o == tgt_sda_o", pad_sda_o == tgt_sda_o);
        check("pad_sda_oe == tgt_sda_oe", pad_sda_oe == tgt_sda_oe);

        // T6: Target mode — SCL always released (oe=0)
        test_num = 6;
        $display("--- T6: Target mode SCL released ---");
        // Even if target tries to drive SCL (it shouldn't), mux forces scl_oe=0
        #1;
        check("pad_scl_oe == 0 (target never drives SCL)", pad_scl_oe == 1'b0);
        check("pad_scl_o == 1 (target SCL idle high)", pad_scl_o == 1'b1);

        // T7: Boot mode (sel=2) — both SDA and SCL driven by BOOT
        test_num = 7;
        $display("--- T7: Boot mode ---");
        phy_mux_sel = 2'd2;
        boot_sda_o = 1'b0; boot_sda_oe = 1'b1;
        boot_scl_o = 1'b0; boot_scl_oe = 1'b1;
        #1;
        check("pad_sda_o == boot_sda_o", pad_sda_o == boot_sda_o);
        check("pad_sda_oe == boot_sda_oe", pad_sda_oe == boot_sda_oe);
        check("pad_scl_o == boot_scl_o", pad_scl_o == boot_scl_o);
        check("pad_scl_oe == boot_scl_oe", pad_scl_oe == boot_scl_oe);

        // T8: Boot mode high values
        test_num = 8;
        $display("--- T8: Boot mode high values ---");
        boot_sda_o = 1'b1; boot_sda_oe = 1'b1;
        boot_scl_o = 1'b1; boot_scl_oe = 1'b1;
        #1;
        check("pad_sda_o == 1 (boot high)", pad_sda_o == 1'b1);
        check("pad_scl_o == 1 (boot high)", pad_scl_o == 1'b1);

        // T9: Boot mode high-Z
        test_num = 9;
        $display("--- T9: Boot high-Z ---");
        boot_sda_oe = 1'b0;
        boot_scl_oe = 1'b0;
        #1;
        check("pad_sda_oe == 0 (boot high-Z)", pad_sda_oe == 1'b0);
        check("pad_scl_oe == 0 (boot high-Z)", pad_scl_oe == 1'b0);

        // T10: Switching modes mid-transfer (DPHY -> Target)
        test_num = 10;
        $display("--- T10: DPHY -> Target switch ---");
        phy_mux_sel = 2'd0;
        dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
        #1;
        check("DPHY drives SDA low", pad_sda_o == 1'b0 && pad_sda_oe == 1'b1);
        phy_mux_sel = 2'd1;
        tgt_sda_o = 1'b1; tgt_sda_oe = 1'b0;
        #1;
        check("Target now drives SDA high-Z", pad_sda_oe == 1'b0);

        // T11: Switching modes mid-transfer (Target -> Boot)
        test_num = 11;
        $display("--- T11: Target -> Boot switch ---");
        phy_mux_sel = 2'd1;
        tgt_sda_o = 1'b0; tgt_sda_oe = 1'b1;
        #1;
        check("Target drives SDA low", pad_sda_o == 1'b0);
        phy_mux_sel = 2'd2;
        boot_sda_o = 1'b1; boot_sda_oe = 1'b1;
        #1;
        check("Boot drives SDA high", pad_sda_o == 1'b1);

        // T12: All inputs active simultaneously — only selected one wins
        test_num = 12;
        $display("--- T12: All inputs active simultaneously ---");
        dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
        dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
        tgt_sda_o = 1'b1; tgt_sda_oe = 1'b1;
        boot_sda_o = 1'b0; boot_sda_oe = 1'b1;
        boot_scl_o = 1'b1; boot_scl_oe = 1'b1;
        phy_mux_sel = 2'd0;  // DPHY selected
        #1;
        check("DPHY wins SDA when all active", pad_sda_o == 1'b0 && pad_sda_oe == 1'b1);
        check("DPHY wins SCL when all active", pad_scl_o == 1'b0 && pad_scl_oe == 1'b1);
        phy_mux_sel = 2'd1;  // Target selected
        #1;
        check("Target wins SDA when all active", pad_sda_o == 1'b1 && pad_sda_oe == 1'b1);
        check("Target never drives SCL", pad_scl_oe == 1'b0);
        phy_mux_sel = 2'd2;  // Boot selected
        #1;
        check("Boot wins SDA when all active", pad_sda_o == 1'b0 && pad_sda_oe == 1'b1);
        check("Boot wins SCL when all active", pad_scl_o == 1'b1 && pad_scl_oe == 1'b1);

        // T13: Pad readback broadcast to all blocks
        test_num = 13;
        $display("--- T13: Pad readback broadcast ---");
        pad_sda_i = 1'b0;
        pad_scl_i = 1'b1;
        #1;
        check("dphy_sda_i == pad_sda_i", dphy_sda_i == 1'b0);
        check("dphy_scl_i == pad_scl_i", dphy_scl_i == 1'b1);
        check("tgt_sda_i == pad_sda_i", tgt_sda_i == 1'b0);
        check("tgt_scl_i == pad_scl_i", tgt_scl_i == 1'b1);
        check("boot_sda_i == pad_sda_i", boot_sda_i == 1'b0);
        check("boot_scl_i == pad_scl_i", boot_scl_i == 1'b1);

        // T14: Pad readback with both low
        test_num = 14;
        $display("--- T14: Pad readback both low ---");
        pad_sda_i = 1'b0;
        pad_scl_i = 1'b0;
        #1;
        check("all blocks see SDA low", dphy_sda_i == 1'b0 && tgt_sda_i == 1'b0 && boot_sda_i == 1'b0);
        check("all blocks see SCL low", dphy_scl_i == 1'b0 && tgt_scl_i == 1'b0 && boot_scl_i == 1'b0);

        // T15: Toggle SDA output values in DPHY mode
        test_num = 15;
        $display("--- T15: Toggle DPHY SDA values ---");
        phy_mux_sel = 2'd0;
        dphy_sda_oe = 1'b1;
        dphy_sda_o = 1'b0;
        #1;
        check("pad SDA low when dphy low", pad_sda_o == 1'b0);
        dphy_sda_o = 1'b1;
        #1;
        check("pad SDA high when dphy high", pad_sda_o == 1'b1);

        // T16: Toggle SCL output values in DPHY mode
        test_num = 16;
        $display("--- T16: Toggle DPHY SCL values ---");
        dphy_scl_oe = 1'b1;
        dphy_scl_o = 1'b0;
        #1;
        check("pad SCL low when dphy low", pad_scl_o == 1'b0);
        dphy_scl_o = 1'b1;
        #1;
        check("pad SCL high when dphy high", pad_scl_o == 1'b1);

        // T17: RSV mode (sel=3) — bus released
        test_num = 17;
        $display("--- T17: RSV mode bus release ---");
        phy_mux_sel = 2'd3;
        // Set all input drives to 0
        dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
        dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
        tgt_sda_o = 1'b0; tgt_sda_oe = 1'b1;
        boot_sda_o = 1'b0; boot_sda_oe = 1'b1;
        boot_scl_o = 1'b0; boot_scl_oe = 1'b1;
        #1;
        check("pad_sda_oe == 0 (RSV release)", pad_sda_oe == 1'b0);
        check("pad_scl_oe == 0 (RSV release)", pad_scl_oe == 1'b0);
        check("pad_sda_o == 1 (RSV idle)", pad_sda_o == 1'b1);
        check("pad_scl_o == 1 (RSV idle)", pad_scl_o == 1'b1);

        // T18: All input enables cleared in any mode (bus released)
        test_num = 18;
        $display("--- T18: All enables cleared ---");
        phy_mux_sel = 2'd0;
        dphy_sda_oe = 1'b0;
        dphy_scl_oe = 1'b0;
        tgt_sda_oe = 1'b0;
        boot_sda_oe = 1'b0;
        boot_scl_oe = 1'b0;
        #1;
        check("pad_sda_oe == 0 (no driver)", pad_sda_oe == 1'b0);
        check("pad_scl_oe == 0 (no driver)", pad_scl_oe == 1'b0);

        // T19: Rapid mode switching (stress)
        test_num = 19;
        $display("--- T19: Rapid mode switching ---");
        begin : t19_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 20; i = i + 1) begin
                phy_mux_sel = i[1:0];
                dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
                dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
                tgt_sda_o = 1'b1; tgt_sda_oe = 1'b1;
                boot_sda_o = 1'b1; boot_sda_oe = 1'b1;
                boot_scl_o = 1'b0; boot_scl_oe = 1'b1;
                #1;
                case (i[1:0])
                    2'd0: if (!(pad_sda_oe == 1'b1 && pad_sda_o == 1'b0)) ok = 0;
                    2'd1: if (!(pad_sda_oe == 1'b1 && pad_sda_o == 1'b1)) ok = 0;
                    2'd2: if (!(pad_sda_oe == 1'b1 && pad_sda_o == 1'b1)) ok = 0;
                    2'd3: if (!(pad_sda_oe == 1'b0)) ok = 0;
                endcase
            end
            check("rapid mode switching correct", ok == 1);
        end

        // T20: Pad readback independent of mux_sel
        test_num = 20;
        $display("--- T20: Pad readback independent of sel ---");
        begin : t20_loop
            integer i;
            integer ok;
            ok = 1;
            pad_sda_i = 1'b1;
            pad_scl_i = 1'b0;
            for (i = 0; i < 4; i = i + 1) begin
                phy_mux_sel = i[1:0];
                #1;
                if (dphy_sda_i !== 1'b1 || tgt_sda_i !== 1'b1 || boot_sda_i !== 1'b1) ok = 0;
                if (dphy_scl_i !== 1'b0 || tgt_scl_i !== 1'b0 || boot_scl_i !== 1'b0) ok = 0;
            end
            check("readback independent of sel", ok == 1);
        end

        // T21: DPHY driving SCL while Target mode (SCL should be released)
        test_num = 21;
        $display("--- T21: DPHY drives SCL, but Target selected ---");
        phy_mux_sel = 2'd1;
        dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
        #1;
        check("pad_scl_oe == 0 (target mode, DPHY ignored)", pad_scl_oe == 1'b0);

        // T22: Boot mode SDA while target SDA also driving (boot wins)
        test_num = 22;
        $display("--- T22: Boot SDA wins in boot mode ---");
        phy_mux_sel = 2'd2;
        boot_sda_o = 1'b1; boot_sda_oe = 1'b1;
        tgt_sda_o = 1'b0; tgt_sda_oe = 1'b1;
        #1;
        check("pad SDA follows boot in boot mode", pad_sda_o == 1'b1 && pad_sda_oe == 1'b1);

        // T23: All inputs at 0 with all enables=1, RSV mode (release)
        test_num = 23;
        $display("--- T23: RSV ignores all drivers ---");
        phy_mux_sel = 2'd3;
        dphy_sda_o = 1'b0; dphy_sda_oe = 1'b1;
        dphy_scl_o = 1'b0; dphy_scl_oe = 1'b1;
        tgt_sda_o = 1'b0; tgt_sda_oe = 1'b1;
        boot_sda_o = 1'b0; boot_sda_oe = 1'b1;
        boot_scl_o = 1'b0; boot_scl_oe = 1'b1;
        #1;
        check("RSV pad_sda_o == 1 (idle)", pad_sda_o == 1'b1);
        check("RSV pad_scl_o == 1 (idle)", pad_scl_o == 1'b1);
        check("RSV pad_sda_oe == 0", pad_sda_oe == 1'b0);
        check("RSV pad_scl_oe == 0", pad_scl_oe == 1'b0);

        // T24: Pad readback toggling
        test_num = 24;
        $display("--- T24: Pad readback toggles ---");
        begin : t24_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 8; i = i + 1) begin
                pad_sda_i = i[0];
                pad_scl_i = i[1];
                #1;
                if (dphy_sda_i !== i[0] || tgt_sda_i !== i[0] || boot_sda_i !== i[0]) ok = 0;
                if (dphy_scl_i !== i[1] || tgt_scl_i !== i[1] || boot_scl_i !== i[1]) ok = 0;
            end
            check("pad readback toggles correctly", ok == 1);
        end

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
