// =============================================================================
// tb_i3c_timing_guard.sv
// -----------------------------------------------------------------------------
// Testbench timing guard (spec compliance clamping).
//
// Tests:
//   1. Out-of-spec SCL_HIGH_TIME write (below 32 ns min) → clamped, violation bit set
//   2. In-spec SCL_HIGH_TIME write → stored as-is, no violation
//   3. SCL_HIGH_TIME_MIXED write above 45 ns max → clamped to max, violation set
//   4. SCL_HIGH_TIME_MIXED write below 32 ns min → clamped to min, violation set
//   5. SCL_HIGH_TIME_MIXED write within [32,45] ns → stored as-is, no violation
//   6. BUS_FREE_TIME below 1.3 µs → clamped, violation set
//   7. TIMING_GUARD_EN=0 → all out-of-spec writes accepted, no violations
//   8. TSU_START below 260 ns (Fm+ I3C) → clamped to 26 cycles, violation set
//   9. W1C clear of violation bits
//
// Note: This testbench instantiates ONLY the register file (not the full DUT)
// to isolate the timing guard logic.
// =============================================================================


module tb_i3c_timing_guard;

    // -------------------------------------------------------------------------
    // Clock / reset
    // -------------------------------------------------------------------------
    logic clk = 1'b0;
    logic rst_n = 1'b0;

    always #5000 clk = ~clk;

    // -------------------------------------------------------------------------
    // AXI signals (minimal — just what the regfile needs)
    // -------------------------------------------------------------------------
    logic        reg_wr;
    logic [31:0] reg_wr_addr;
    logic [31:0] reg_wr_data;
    logic [3:0]  reg_wr_strb;
    logic        reg_wr_ack;
    logic        reg_rd;
    logic [31:0] reg_rd_addr;
    logic [31:0] reg_rd_data;
    logic        reg_rd_ack;

    // -------------------------------------------------------------------------
    // DUT signals (stub all unused inputs)
    // -------------------------------------------------------------------------
    logic        hw_bus_busy, hw_controller_idle;
    logic [7:0]  hw_bytes_xferd;
    logic [4:0]  hw_cmd_fifo_free, hw_resp_fifo_level;
    logic [4:0]  hw_wr_fifo_free, hw_rd_fifo_level;
    logic        hw_err_timeout, hw_err_nack_addr, hw_err_nack_data;
    logic        hw_err_fifo_overflow, hw_err_fifo_underflow, hw_err_pec;
    logic        hw_xfer_done, hw_ibi_received, hw_hj_received;
    logic        hw_wake_event, hw_clk_stall;
    logic        hw_handoff_done, hw_handoff_failed, hw_reclaim_done;
    logic        hw_cmd_fifo_almost_full, hw_wr_fifo_almost_full;
    logic        hw_rd_fifo_almost_full, hw_resp_fifo_not_empty;
    logic        sw_reset, sw_flush_cmd, sw_flush_wr, sw_flush_rd, sw_flush_resp;
    logic [3:0]  clk_gate_ctrl;
    logic [2:0]  speed_mode;
    logic        ctrl_en, ctrl_ibi_en;
    logic        ibi_payload_en;
    logic        ibi_fifo_push;
    logic [31:0] ibi_fifo_push_data;
    logic        ibi_irq, ibi_active;
    logic        hj_enable, hj_auto_daa, hj_detected, hj_pending, hj_clear;
    logic        group_enable;
    logic [6:0]  group_count;
    logic [31:0] group_table_0, group_table_1, group_table_2, group_table_3;
    logic [31:0] group_table_4, group_table_5, group_table_6, group_table_7;
    logic [3:0]  dnf_threshold;
    logic        dnf_enable;
    logic        wake_en, wake_start_en, wake_scl_en;
    logic        target_en;
    logic [6:0]  target_dyn_addr;
    logic        target_ibi_en;
    logic        abort_req, resume_req;
    logic [1:0]  bus_type;
    logic        reclaim_en;
    logic [15:0] reclaim_timeout_us;
    logic [17:0] scl_high_time_mixed;
    logic [2:0]  role_state_in;
    logic [1:0]  handoff_status_in;

    // -------------------------------------------------------------------------
    // DUT instantiation
    // -------------------------------------------------------------------------
    i3c_register_file #(
        .AXI_CLK_FREQ_HZ (100_000_000),  // 100 MHz → 10 ns PCLK
        .SCL_CLK_FREQ_HZ (12_500_000)
    ) u_dut (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .reg_wr                (reg_wr),
        .reg_wr_addr           (reg_wr_addr),
        .reg_wr_data           (reg_wr_data),
        .reg_wr_strb           (reg_wr_strb),
        .reg_wr_ack            (reg_wr_ack),
        .reg_rd                (reg_rd),
        .reg_rd_addr           (reg_rd_addr),
        .reg_rd_data           (reg_rd_data),
        .reg_rd_ack            (reg_rd_ack),
        .hw_bus_busy           (1'b0),
        .hw_controller_idle    (1'b1),
        .hw_bytes_xferd        (8'h0),
        .hw_cmd_fifo_free      (5'h10),
        .hw_resp_fifo_level    (5'h0),
        .hw_wr_fifo_free       (5'h10),
        .hw_rd_fifo_level      (5'h0),
        .cfg_scl_high_time     (),
        .cfg_scl_low_time      (),
        .cfg_sda_hold_time     (),
        .cfg_bus_free_time     (),
        .cfg_tsu_start         (),
        .cfg_thd_start         (),
        .cfg_tsu_stop          (),
        .cfg_scl_od_high_time  (),
        .cfg_scl_od_low_time   (),
        // .cfg_mwl removed (not a port)
        // .cfg_mrl removed (not a port)
        // .cfg_static_addr removed (not a port)
        // .cfg_static_addr_valid removed (not a port)
        .hw_err_timeout        (1'b0),
        .hw_err_nack_addr      (1'b0),
        .hw_err_nack_data      (1'b0),
        .hw_err_fifo_overflow  (1'b0),
        .hw_err_fifo_underflow (1'b0),
        .hw_err_pec            (1'b0),
        .hw_xfer_done          (1'b0),
        .hw_ibi_received       (1'b0),
        .hw_hj_received        (1'b0),
        .hw_wake_event         (1'b0),
        .hw_clk_stall          (1'b0),
        .hw_handoff_done       (1'b0),
        .hw_handoff_failed     (1'b0),
        .hw_reclaim_done       (1'b0),
        .hw_cmd_fifo_almost_full (1'b0),
        .hw_wr_fifo_almost_full  (1'b0),
        .hw_rd_fifo_almost_full  (1'b0),
        .hw_resp_fifo_not_empty  (1'b0),
        .sw_reset              (sw_reset),
        .sw_flush_cmd          (sw_flush_cmd),
        .sw_flush_wr           (sw_flush_wr),
        .sw_flush_rd           (sw_flush_rd),
        .sw_flush_resp         (sw_flush_resp),
        .clk_gate_ctrl         (clk_gate_ctrl),
        .speed_mode            (speed_mode),
        .ctrl_en               (ctrl_en),
        // .ctrl_ibi_en removed (not a port)
        // .ibi_payload_en removed (not a port)
        .ibi_fifo_push         (1'b0),
        .ibi_fifo_push_data    (32'h0),
        .ibi_irq               (1'b0),
        .ibi_active            (1'b0),
        // .hj_enable removed (not a port)
        .hj_auto_daa           (hj_auto_daa),
        .hj_detected           (1'b0),
        .hj_pending            (1'b0),
        .hj_clear              (hj_clear),
        .group_enable          (group_enable),
        .group_count           (group_count),
        .group_table_0         (group_table_0),
        .group_table_1         (group_table_1),
        .group_table_2         (group_table_2),
        .group_table_3         (group_table_3),
        .group_table_4         (group_table_4),
        .group_table_5         (group_table_5),
        .group_table_6         (group_table_6),
        .group_table_7         (group_table_7),
        .dnf_threshold         (dnf_threshold),
        .dnf_enable            (dnf_enable),
        .wake_en               (wake_en),
        .wake_start_en         (wake_start_en),
        .wake_scl_en           (wake_scl_en),
        // .target_en removed
        // .target_dyn_addr removed
        // .target_ibi_en removed
        .abort_req             (abort_req),
        .resume_req            (resume_req),
        .bus_type              (bus_type),
        .reclaim_en            (reclaim_en),
        .reclaim_timeout_us    (reclaim_timeout_us),
        .scl_high_time_mixed   (scl_high_time_mixed),
        .role_state_in         (3'd0),
        .handoff_status_in     (2'd0)
    );

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    integer pass_count = 0;
    integer fail_count = 0;

    task check(input cond, input [255:0] msg);
        begin
            if (cond) begin
                pass_count = pass_count + 1;
                $display("[PASS] %s", msg);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] %s", msg);
            end
        end
    endtask

    // Write a register
    task reg_write(input [31:0] addr, input [31:0] data);
        begin
            @(negedge clk);
            reg_wr      = 1'b1;
            reg_wr_addr = addr;
            reg_wr_data = data;
            reg_wr_strb = 4'hF;
            @(posedge clk);
            @(negedge clk);
            reg_wr      = 1'b0;
        end
    endtask

    // Read a register
    task reg_read(input [31:0] addr, output [31:0] data);
        begin
            @(negedge clk);
            reg_rd      = 1'b1;
            reg_rd_addr = addr;
            @(posedge clk);
            @(negedge clk);
            data        = reg_rd_data;
            reg_rd      = 1'b0;
        end
    endtask

    // Read TIMING_VIOLATION_STATUS
    logic [31:0] violation_status;
    task read_violations;
        begin
            reg_read(32'hB0, violation_status);
        end
    endtask

    // -------------------------------------------------------------------------
    // Tests
    // -------------------------------------------------------------------------
    logic [31:0] read_val;

    initial begin
        // Init
        reg_wr = 1'b0;
        reg_rd = 1'b0;
        reg_wr_addr = 0;
        reg_wr_data = 0;
        reg_wr_strb = 0;
        reg_rd_addr = 0;

        // Reset
        rst_n = 1'b0;
        #100000;
        rst_n = 1'b1;
        #100000;

        $display("=============================================================");
        $display("Timing Guard Testbench — starting");
        $display("=============================================================");

        // =====================================================================
        // Test 1: SCL_HIGH_TIME below 32 ns (4 cycles at 100 MHz) → clamped
        // =====================================================================
        $display("\n--- Test 1: SCL_HIGH_TIME = 2 (20 ns, below 32 ns min) ---");
        reg_write(32'h4C, 32'h0000_0002);  // SCL_HIGH_TIME_CFG = 2
        reg_read(32'h4C, read_val);
        // At 100 MHz, 32 ns = 4 cycles. So 2 should be clamped to 4.
        check(read_val[17:0] == 18'd4, "SCL_HIGH_TIME clamped to 4 (32 ns min)");

        read_violations;
        check(violation_status[0] == 1'b1, "Violation bit [0] set for SCL_HIGH_TIME");

        // Clear violation
        reg_write(32'hB0, 32'h0000_0001);  // W1C bit 0
        read_violations;
        check(violation_status[0] == 1'b0, "Violation bit [0] cleared by W1C");

        // =====================================================================
        // Test 2: SCL_HIGH_TIME in-spec (10 cycles = 100 ns) → no clamp
        // =====================================================================
        $display("\n--- Test 2: SCL_HIGH_TIME = 10 (100 ns, in-spec) ---");
        reg_write(32'h4C, 32'h0000_000A);
        reg_read(32'h4C, read_val);
        check(read_val[17:0] == 18'd10, "SCL_HIGH_TIME stored as 10 (in-spec)");

        read_violations;
        check(violation_status[0] == 1'b0, "No violation for in-spec write");

        // =====================================================================
        // Test 3: SCL_HIGH_TIME_MIXED above 45 ns (6 cycles at 100 MHz)
        // =====================================================================
        $display("\n--- Test 3: SCL_HIGH_TIME_MIXED = 6 (60 ns, above 45 ns max) ---");
        reg_write(32'hA8, 32'h0000_0006);
        reg_read(32'hA8, read_val);
        // 45 ns = 4.5 cycles → floor = 4. But 32 ns min = 4 cycles.
        // So range is [4, 4] at 100 MHz. Value 6 → clamped to 4.
        check(read_val[17:0] == 18'd4, "SCL_HIGH_TIME_MIXED clamped to 4 (45 ns max)");

        read_violations;
        check(violation_status[2] == 1'b1, "Violation bit [2] set for MIXED above max");

        // Clear
        reg_write(32'hB0, 32'h0000_0004);
        read_violations;
        check(violation_status[2] == 1'b0, "Violation bit [2] cleared");

        // =====================================================================
        // Test 4: SCL_HIGH_TIME_MIXED below 32 ns (2 cycles)
        // =====================================================================
        $display("\n--- Test 4: SCL_HIGH_TIME_MIXED = 2 (20 ns, below 32 ns min) ---");
        reg_write(32'hA8, 32'h0000_0002);
        reg_read(32'hA8, read_val);
        check(read_val[17:0] == 18'd4, "SCL_HIGH_TIME_MIXED clamped to 4 (32 ns min)");

        read_violations;
        check(violation_status[2] == 1'b1, "Violation bit [2] set for MIXED below min");

        reg_write(32'hB0, 32'h0000_0004);  // clear

        // =====================================================================
        // Test 5: SCL_HIGH_TIME_MIXED in-spec (4 cycles = 40 ns, within [32,45])
        // =====================================================================
        $display("\n--- Test 5: SCL_HIGH_TIME_MIXED = 4 (40 ns, in-spec) ---");
        reg_write(32'hA8, 32'h0000_0004);
        reg_read(32'hA8, read_val);
        check(read_val[17:0] == 18'd4, "SCL_HIGH_TIME_MIXED stored as 4 (in-spec)");

        read_violations;
        check(violation_status[2] == 1'b0, "No violation for in-spec MIXED write");

        // =====================================================================
        // Test 6: BUS_FREE_TIME below 1.3 µs (130 cycles at 100 MHz)
        // =====================================================================
        $display("\n--- Test 6: BUS_FREE_TIME = 50 (500 ns, below 1.3 µs min) ---");
        reg_write(32'h58, 32'h0000_0032);  // BUS_FREE_TIME = 500 ns
        reg_read(32'h58, read_val);
        // 1.3 µs = 1300 ns = 130 cycles at 100 MHz
        check(read_val[17:0] == 18'd130, "BUS_FREE_TIME clamped to 130 (1.3 µs min)");

        read_violations;
        check(violation_status[8] == 1'b1, "Violation bit [8] set for BUS_FREE_TIME");

        reg_write(32'hB0, 32'h0001_0000);  // clear bit 8

        // =====================================================================
        // Test 7: Disable guard → out-of-spec write accepted
        // =====================================================================
        $display("\n--- Test 7: TIMING_GUARD_EN=0, write out-of-spec ---");
        reg_write(32'hAC, 32'h0000_0000);  // TIMING_GUARD_CTRL = 0 (disable)
        reg_read(32'hAC, read_val);
        check(read_val[0] == 1'b0, "TIMING_GUARD_EN = 0 (disabled)");

        // Now write out-of-spec SCL_HIGH_TIME = 1 (10 ns, way below 32 ns)
        reg_write(32'h4C, 32'h0000_0001);
        reg_read(32'h4C, read_val);
        check(read_val[17:0] == 18'd1, "SCL_HIGH_TIME = 1 accepted (guard disabled)");

        read_violations;
        check(violation_status[0] == 1'b0, "No violation when guard disabled");

        // Re-enable guard
        reg_write(32'hAC, 32'h0000_0001);  // re-enable
        reg_read(32'hAC, read_val);
        check(read_val[0] == 1'b1, "TIMING_GUARD_EN = 1 (re-enabled)");

        // =====================================================================
        // Test 8: TSU_START below 260 ns (26 cycles at 100 MHz, Fm+ I3C spec)
        // MIPI I3C Basic v1.2 Fm+: tSU_STA = 260 ns min (not 600 ns which is Fm I2C)
        // =====================================================================
        $display("\n--- Test 8: TSU_START = 10 (100 ns, below 260 ns Fm+ min) ---");
        reg_write(32'h5C, 32'h0000_000A);
        reg_read(32'h5C, read_val);
        check(read_val[17:0] == 18'd26, "TSU_START clamped to 26 (260 ns Fm+ min)");

        read_violations;
        check(violation_status[3] == 1'b1, "Violation bit [3] set for TSU_START");

        reg_write(32'hB0, 32'h0000_0008);  // clear bit 3

        $display("\n=============================================================");
        $display("Test Summary:");
        $display("  Passed: %0d", pass_count);
        $display("  Failed: %0d", fail_count);
        if (fail_count == 0)
            $display("  RESULT: ALL PASS");
        else
            $display("  RESULT: FAILURES DETECTED");
        $display("=============================================================\n");

        $finish;
    end

    initial begin
        #2000000000;
        $display("[ERROR] Simulation timeout");
        $finish;
    end

endmodule : tb_i3c_timing_guard
