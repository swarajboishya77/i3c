// =============================================================================
// tb_i3c_getaccr_deep_audit.sv
// Deep audit testbench for GETACCR role transfer.
// Tests: handoff, reclaim, voluntary return, BCR rejection, pulse integrity,
//        timeout, and state coverage.
// Run: iverilog -g2012 -o sim.vvp tb_i3c_getaccr_deep_audit.sv rtl/role/i3c_role_manager.sv
//      vvp sim.vvp
// =============================================================================


module tb_i3c_getaccr_deep_audit;

    logic clk = 0;
    logic rst_n = 0;
    always #5000 clk = ~clk;

    // DUT signals
    logic        reclaim_en;
    logic [15:0] reclaim_timeout_us;
    logic        handoff_trigger;
    logic        getacccr_done;
    logic        getacccr_ack;
    logic        getacccr_addr_nack;
    logic        getacccr_data_nack;
    logic        scl_falling;
    logic        sda_falling;
    logic        scl_filt;
    logic        sda_filt;
    logic        bootstrap_active;
    logic        role_return;
    logic        role_is_controller;
    logic        role_is_target;
    logic        reclaim_in_progress;
    logic        handoff_done_pulse;
    logic        handoff_failed_pulse;
    logic [1:0]  handoff_fail_reason;
    logic [1:0]  phy_mux_sel;
    logic        target_engine_en;
    logic [2:0]  role_state_out;

    i3c_role_manager u_dut (
        .clk_sys(clk), .rst_sys_n(rst_n),
        .reclaim_en(reclaim_en), .reclaim_timeout_us(reclaim_timeout_us),
        .handoff_trigger(handoff_trigger), .getacccr_done(getacccr_done),
        .getacccr_ack(getacccr_ack), .getacccr_addr_nack(getacccr_addr_nack),
        .getacccr_data_nack(getacccr_data_nack),
        .scl_falling(scl_falling), .sda_falling(sda_falling),
        .scl_filt(scl_filt), .sda_filt(sda_filt),
        .bootstrap_active(bootstrap_active), .role_return(role_return),
        .role_is_controller(role_is_controller), .role_is_target(role_is_target),
        .reclaim_in_progress(reclaim_in_progress),
        .handoff_done_pulse(handoff_done_pulse), .handoff_failed_pulse(handoff_failed_pulse),
        .handoff_fail_reason(handoff_fail_reason), .phy_mux_sel(phy_mux_sel),
        .target_engine_en(target_engine_en), .role_state_out(role_state_out)
    );

    integer pass = 0, fail = 0;
    task check(input bit cond, input string msg);
        if (cond) begin pass++; $display("[PASS] %0t: %s", $time, msg); end
        else begin fail++; $display("[FAIL] %0t: %s", $time, msg); end
    endtask

    task reset_dut();
        rst_n = 0; reclaim_en = 0; reclaim_timeout_us = 1000;
        handoff_trigger = 0; getacccr_done = 0; getacccr_ack = 0;
        getacccr_addr_nack = 0; getacccr_data_nack = 0;
        scl_falling = 0; sda_falling = 0; scl_filt = 1; sda_filt = 1;
        bootstrap_active = 0; role_return = 0;
        repeat(20) @(posedge clk);
        rst_n = 1; repeat(5) @(posedge clk);
    endtask

    task pulse_handoff();
        @(negedge clk); handoff_trigger = 1;
        @(posedge clk); @(negedge clk); handoff_trigger = 0;
    endtask

    task send_ccc_result(input bit ack, input bit anack, input bit dnack);
        @(negedge clk);
        getacccr_done = 1; getacccr_ack = ack;
        getacccr_addr_nack = anack; getacccr_data_nack = dnack;
        @(posedge clk); @(negedge clk);
        getacccr_done = 0; getacccr_ack = 0;
        getacccr_addr_nack = 0; getacccr_data_nack = 0;
    endtask

    // BUGFIX: check_done_pulse checks handoff_done_pulse at the EXACT cycle
    // it fires. The pulse is 1 only on the posedge where getacccr_done is first
    // seen (state_q==1, getacccr_done=1, getacccr_done_q=0). By the next
    // posedge, getacccr_done_q=1 and the pulse is gone. So we must check
    // at the posedge INSIDE send_ccc_result, not after it returns.
    task send_ccc_result_and_check(input bit ack, input bit anack, input bit dnack);
        @(negedge clk);
        getacccr_done = 1; getacccr_ack = ack;
        getacccr_addr_nack = anack; getacccr_data_nack = dnack;
        // At this posedge, handoff_done_q/failed_q will be set (NBA fires)
        @(posedge clk);
        // Check the pulse NOW — handoff_done_q is valid (NBA committed)
        #1;  // small delay to let NBA settle
        if (ack) begin
            check(handoff_done_pulse == 1'b1, "T1: done_pulse asserted (exactly 1 cycle)");
        end else begin
            check(handoff_failed_pulse == 1'b1, "T2: failed_pulse asserted (exactly 1 cycle)");
        end
        @(negedge clk);
        getacccr_done = 0; getacccr_ack = 0;
        getacccr_addr_nack = 0; getacccr_data_nack = 0;
    endtask

    // Test 1: Basic handoff success
    initial begin
        $display("=== Test 1: Handoff Success ===");
        reset_dut();
        check(role_state_out == 3'd0, "T1: Initial ACTIVE");
        pulse_handoff();
        check(role_state_out == 3'd1, "T1: PREPARING_HANDOFF");
        send_ccc_result_and_check(1, 0, 0);
        #1;
        check(role_state_out == 3'd2, "T1: MONITORING_NEW");
        check(phy_mux_sel == 2'd1, "T1: MUX=TARGET");
        check(target_engine_en == 1'b1, "T1: target_engine_en=1 in MONITORING (target listens for addr)");

        // Bus activity -> TARGET
        @(negedge clk); scl_falling = 1; @(posedge clk); @(negedge clk); scl_falling = 0;
        repeat(2) @(posedge clk);
        #1;
        check(role_state_out == 3'd5, "T1: TARGET steady");
        check(target_engine_en == 1'b1, "T1: target_engine_en=1 in TARGET");

        // Voluntary return
        @(negedge clk); role_return = 1; @(posedge clk); @(negedge clk); role_return = 0;
        repeat(2) @(posedge clk);
        #1;
        check(role_state_out == 3'd0, "T1: Voluntary return to ACTIVE");
        check(phy_mux_sel == 2'd0, "T1: MUX=DPHY after return");

        // Test 2: Handoff fail (addr NACK)
        $display("=== Test 2: Handoff Fail (addr NACK) ===");
        reset_dut();
        pulse_handoff();
        send_ccc_result_and_check(0, 1, 0);
        #1;
        check(role_state_out == 3'd6, "T2: HANDOFF_FAILED");
        check(handoff_fail_reason == 2'd1, "T2: fail_reason=addr_nack");
        @(posedge clk);
        #1;
        check(role_state_out == 3'd0, "T2: Auto-recover to ACTIVE");

        // Test 3: Handoff fail (data NACK)
        $display("=== Test 3: Handoff Fail (data NACK) ===");
        reset_dut();
        pulse_handoff();
        send_ccc_result_and_check(0, 0, 1);
        #1;
        check(role_state_out == 3'd6, "T3: HANDOFF_FAILED");
        check(handoff_fail_reason == 2'd2, "T3: fail_reason=data_nack");

        // Test 4: Reclaim timer
        $display("=== Test 4: Reclaim Timer ===");
        reset_dut();
        reclaim_en = 1; reclaim_timeout_us = 10;
        pulse_handoff();
        send_ccc_result(1, 0, 0);
        repeat(3) @(posedge clk);
        #1;
        check(role_state_out == 3'd2, "T4: MONITORING");
        repeat(2500) @(posedge clk);
        #1;
        check(role_state_out == 3'd4 || role_state_out == 3'd0, "T4: RECLAIMING or ACTIVE");

        // Test 5: Pulse integrity (done pulse must be exactly 1 cycle)
        $display("=== Test 5: Pulse Integrity ===");
        reset_dut();
        pulse_handoff();
        send_ccc_result_and_check(1, 0, 0);
        // T5: done_pulse was checked inside send_ccc_result_and_check (cycle 1)
        // Now check it's LOW on subsequent cycles (pulse integrity)
        @(posedge clk);
        #1;
        check(handoff_done_pulse == 1'b0, "T5: done_pulse low on cycle 2 (pulse)");
        @(posedge clk);
        #1;
        check(handoff_done_pulse == 1'b0, "T5: done_pulse still low on cycle 3");

        // Test 6: Bootstrap mode
        $display("=== Test 6: Bootstrap ===");
        reset_dut();
        @(negedge clk); bootstrap_active = 1;
        @(posedge clk);
        #1;
        check(role_state_out == 3'd7, "T6: BOOTSTRAP");
        check(phy_mux_sel == 2'd2, "T6: MUX=BOOT");
        @(negedge clk); bootstrap_active = 0;
        @(posedge clk);
        #1;
        check(role_state_out == 3'd0, "T6: Back to ACTIVE");

        // Test 7: Multiple consecutive handoffs
        $display("=== Test 7: Multiple Handoffs ===");
        for (int i = 0; i < 5; i++) begin
            reset_dut();
            pulse_handoff();
            if (i % 3 == 0)
                send_ccc_result(1, 0, 0);
            else if (i % 3 == 1)
                send_ccc_result(0, 1, 0);
            else
                send_ccc_result(0, 0, 1);
            repeat(3) @(posedge clk);
            #1;
            check(role_state_out inside {3'd0, 3'd2, 3'd6}, $sformatf("T7: Valid state after handoff %0d", i));
        end

        // Summary
        $display("========================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass, fail);
        if (fail == 0) $display("OVERALL: PASS");
        else $display("OVERALL: FAIL");
        $display("========================================");
        $finish;
    end

    initial begin #2000000000; $display(""); $display("============================================================"); $display("SUMMARY: %0d PASS, %0d FAIL", pass, fail + 1); $display("OVERALL: FAIL (watchdog timeout)"); $display("============================================================"); $finish; end
endmodule
