// =============================================================================
// tb_i3c_register_bitfield.sv
// -----------------------------------------------------------------------------
// Comprehensive register-level testbench — tests every register's reset value,
// read/write behavior, bitfield access, and W1C/RWSC/RO semantics.
//
// Tests:
//   T1.  VERSION (0x00) RO — read returns 0x0001_0002
//   T2.  I3C_SPEED_MODE_CFG (0x04) R/W — write/read back SPEED_MODE[2:0]
//   T3.  TRANSACTION_CTRL (0x08) R/W — EN[0] and IBI_EN[1]
//   T4.  TRANSACTION_STATUS (0x0C) RO — read returns status bits
//   T5.  INTERRUPT_ENABLE_CTRL (0x10) R/W — 19-bit enable mask
//   T6.  INTERRUPT_STATUS (0x14) W1C — sticky bits, write-1-clears
//   T7.  IBI_ENABLE_CTRL (0x18) R/W — IBI_PAYLOAD_EN[0]
//   T8.  IBI_STATUS (0x1C) W1C — sticky IBI status bits
//   T9.  HJ_ENABLE_CTRL (0x24) R/W — HJ_ENABLE[0], HJ_AUTO_DAA[1]
//   T10. HJ_STATUS (0x28) W1C — HJ_DETECTED sticky
//   T11. FIFO_LVL_STATUS (0x2C) RO — FIFO fill levels
//   T12. SW_RESET_CTRL (0x40) RWSC — write 1 triggers reset, auto-clears
//   T13. SW_RESET_STATUS (0x44) W1C — survives all resets
//   T14. FIFO_FLUSH_CTRL (0x48) RWSC — flush individual FIFOs
//   T15. ABORT_CTRL (0x4C) RWSC — abort[0] and resume[1]
//   T16. SCL_HIGH_TIME_CFG (0x50) R/W with timing guard
//   T17. SCL_LOW_TIME_CFG (0x54) R/W with timing guard
//   T18. TIMING_GUARD_CTRL (0xBC) R/W — enable/disable clamping
//   T19. TIMING_VIOLATION_STATUS (0xC0) W1C — violation bits
//   T20. DNF_CTRL (0x74) R/W — threshold[3:1] and enable[0]
//   T21. WAKE_CTRL (0x78) R/W — wake enable bits
//   T22. CLK_GATE_CTRL (0x80) R/W — gate control bits
//   T23. POWER_CTRL (0x84) R/W — power control bits
//   T24. CTRL_DYN_ADDR_CFG (0x88) R/W — target_en, dyn_addr, ibi_en
//   T25. GROUP_ADDR_CFG (0x90) R/W — group enable + count
//   T26. STATIC_ADDR_CFG (0x98) R/W — static addr + valid
//   T27. BUS_CONFIG (0xA8) R/W — bus_type[1:0], default=0x1 (Mixed Fast)
//   T28. RECLAIM_CONFIG (0xB4) R/W — enable + timeout
//   T29. SCL_HIGH_TIME_MIXED_CFG (0xB8) R/W with guard
//   T30. ROLE_STATE (0xAC) RO — role manager state
//   T31. All timing registers default values match MIPI Mixed Bus Fm+
//   T32. W1C clear: write 1 to sticky bit clears it
//   T33. RO register: write ignored, read returns current value
//   T34. RWSC auto-clear: SW_RESET_CTRL clears after 2 cycles
//   T35. FIFO_FLUSH_CTRL auto-clear after 2 cycles
//   T36. Timing guard clamps out-of-spec writes
//   T37. Timing guard allows in-spec writes
//   T38. TIMING_VIOLATION_STATUS set on clamped write
// =============================================================================


module tb_i3c_register_bitfield;

    logic clk = 1'b0;
    logic rst_n = 1'b0;
    always #5000 clk = ~clk;

    // AXI4-Lite
    logic             awvalid = 0, awready;
    logic [31:0]      awaddr = 0;
    logic             wvalid = 0, wready;
    logic [31:0]      wdata = 0;
    logic [3:0]       wstrb = 4'hf;
    logic             bvalid, bready = 1;
    logic [1:0]       bresp;
    logic             arvalid = 0, arready;
    logic [31:0]      araddr = 0;
    logic             rvalid, rready = 1;
    logic [31:0]      rdata;
    logic [1:0]       rresp;

    // Read register (shared by check task)
    logic [31:0]      rd_reg;

    // DUT ports (minimal — stub non-AXI)
    logic        cmd_fifo_push = 0;
    logic [31:0] cmd_fifo_push_data = 0;
    logic        cmd_fifo_full, cmd_fifo_empty;
    logic        wr_fifo_push = 0;
    logic [31:0] wr_fifo_push_data = 0;
    logic        wr_fifo_full, wr_fifo_empty;
    logic [31:0] rd_fifo_pop_data;
    logic        rd_fifo_pop = 0;
    logic        rd_fifo_full, rd_fifo_empty;
    logic [31:0] resp_fifo_pop_data;
    logic        resp_fifo_pop = 0;
    logic        resp_fifo_full, resp_fifo_empty;

    wire sda, scl;
    pullup(sda); pullup(scl);

    logic clk_aon = 1'b0;
    logic rst_aon_n = 1'b0;
    always #15000000 clk_aon = ~clk_aon;

    logic wake_irq, wake_src_start, wake_src_scl;
    logic pd_core_off, pd_core_sw_en, pd_core_iso_en, pd_core_rst, wake_to_host;
    logic target_addressed, target_busy, target_rx_done;
    logic [7:0] target_rx_byte;
    logic target_tx_req, target_ibi_req, target_nack_sent;
    logic sda_pullup_en, scl_pullup_en;
    logic controller_busy, controller_idle, i2c_irq, i3c_irq;

    i3c_primary_controller_sdr #(
        .AXI_CLK_FREQ_HZ(100_000_000),
        .SCL_CLK_FREQ_HZ(12_500_000)
    ) u_dut (
        .s_axi_aclk(clk), .s_axi_aresetn(rst_n),
        .s_axi_awvalid(awvalid), .s_axi_awready(awready), .s_axi_awaddr(awaddr),
        .s_axi_awprot(3'b000),
        .s_axi_wvalid(wvalid), .s_axi_wready(wready), .s_axi_wdata(wdata), .s_axi_wstrb(wstrb),
        .s_axi_bvalid(bvalid), .s_axi_bready(bready), .s_axi_bresp(bresp),
        .s_axi_arvalid(arvalid), .s_axi_arready(arready), .s_axi_araddr(araddr),
        .s_axi_arprot(3'b000),
        .s_axi_rvalid(rvalid), .s_axi_rready(rready), .s_axi_rdata(rdata), .s_axi_rresp(rresp),
        .sda(sda), .scl(scl), .sda_pullup_en(sda_pullup_en), .scl_pullup_en(scl_pullup_en),
        .clk_aon(clk_aon), .rst_aon_n(rst_aon_n),
        .wake_irq(wake_irq), .wake_src_start(wake_src_start), .wake_src_scl(wake_src_scl),
        .pd_core_req(1'b0), .pd_core_off(pd_core_off), .pd_core_ack(1'b0),
        .pd_core_sw_en(pd_core_sw_en), .pd_core_iso_en(pd_core_iso_en),
        .pd_core_rst(pd_core_rst), .wake_to_host(wake_to_host),
        .target_addressed(target_addressed), .target_busy(target_busy),
        .target_rx_done(target_rx_done), .target_rx_byte(target_rx_byte),
        .target_tx_req(target_tx_req), .target_tx_byte(8'h00), .target_tx_valid(1'b0),
        .target_ibi_req(target_ibi_req), .target_nack_sent(target_nack_sent),
        .i2c_irq(i2c_irq), .i3c_irq(i3c_irq),
        .controller_busy(controller_busy), .controller_idle(controller_idle),
        .cmd_fifo_push(cmd_fifo_push), .cmd_fifo_push_data(cmd_fifo_push_data),
        .cmd_fifo_full(cmd_fifo_full), .cmd_fifo_empty(cmd_fifo_empty),
        .wr_fifo_push(wr_fifo_push), .wr_fifo_push_data(wr_fifo_push_data),
        .wr_fifo_full(wr_fifo_full), .wr_fifo_empty(wr_fifo_empty),
        .rd_fifo_pop_data(rd_fifo_pop_data), .rd_fifo_pop(rd_fifo_pop),
        .rd_fifo_full(rd_fifo_full), .rd_fifo_empty(rd_fifo_empty),
        .resp_fifo_pop_data(resp_fifo_pop_data), .resp_fifo_pop(resp_fifo_pop),
        .resp_fifo_full(resp_fifo_full), .resp_fifo_empty(resp_fifo_empty)
    );

    // AXI tasks
    task axi_write(input [31:0] addr, input [31:0] data);
        begin
            @(posedge clk);
            awvalid <= 1'b1; awaddr <= addr;
            wvalid <= 1'b1; wdata <= data; wstrb <= 4'hf;
            while (!(awready && wready)) @(posedge clk);
            @(posedge clk);
            awvalid <= 1'b0; wvalid <= 1'b0;
            while (!bvalid) @(posedge clk);
            @(posedge clk);
        end
    endtask

    task axi_read(input [31:0] addr, output [31:0] data);
        begin
            @(posedge clk);
            arvalid <= 1'b1; araddr <= addr;
            while (!arready) @(posedge clk);
            @(posedge clk);
            arvalid <= 1'b0;
            while (!rvalid) @(posedge clk);
            data = rdata;
            @(posedge clk);
        end
    endtask

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num = 0;

    task check(input [255:0] name, input condition);
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s (got=0x%08x)", test_num, name, rd_reg);
            end
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_register_bitfield.vcd");
        $dumpvars(0, tb_i3c_register_bitfield);

        rst_n = 1'b0; rst_aon_n = 1'b0;
        repeat (10) @(posedge clk);
        rst_n = 1'b1; rst_aon_n = 1'b1;
        repeat (10) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C Register & Bitfield Testbench");
        $display("============================================================");

        // T1: VERSION RO
        test_num = 1; $display("\n--- T1: VERSION (0x00) ---");
        axi_read(32'h00, rd_reg);
        check("VERSION = 0x0001_0002", rd_reg == 32'h0001_0002);

        // T2: I3C_SPEED_MODE_CFG R/W
        test_num = 2; $display("\n--- T2: I3C_SPEED_MODE_CFG (0x04) ---");
        axi_read(32'h08, rd_reg);
        check("default = 0x0000_0000 (SDR)", rd_reg == 32'h0000_0000);
        axi_write(32'h08, 32'h0000_0001);
        axi_read(32'h08, rd_reg);
        check("write 0x1, readback = 0x1 (HJ_ENABLE only)", rd_reg == 32'h0000_0001);
        axi_write(32'h08, 32'h0000_0000);  // restore

        // T3: TRANSACTION_CTRL R/W
        test_num = 3; $display("\n--- T3: TRANSACTION_CTRL (0x08) ---");
        axi_read(32'h0C, rd_reg);
        check("default = 0x0 (EN=0, IBI_EN=0)", rd_reg == 32'h0000_0000);
        axi_write(32'h0C, 32'h0000_0001);  // EN=1 (IBI_EN moved to 0x18)
        axi_read(32'h0C, rd_reg);
        check("write 0x1, readback = 0x1 (HJ_ENABLE only)", rd_reg == 32'h0000_0001);
        axi_write(32'h0C, 32'h0000_0000);  // restore

        // T5: INTERRUPT_ENABLE_CTRL R/W
        test_num = 5; $display("\n--- T5: INTERRUPT_ENABLE_CTRL (0x10) ---");
        axi_read(32'h14, rd_reg);
        check("default = 0x0", rd_reg == 32'h0000_0000);
        axi_write(32'h14, 32'h0007_FFFF);  // enable all 19 bits
        axi_read(32'h14, rd_reg);
        check("write all 1s, readback", rd_reg == 32'h0007_FFFF);
        axi_write(32'h14, 32'h0000_0000);

        // T6: INTERRUPT_STATUS W1C
        test_num = 6; $display("\n--- T6: INTERRUPT_STATUS (0x14) W1C ---");
        axi_read(32'h18, rd_reg);
        $display("  DEBUG: INT_STATUS=0x%08x rd_almost_full=%b cmd_af=%b wr_af=%b resp_ne=%b",
                 rd_reg, u_dut.rd_almost_full, u_dut.cmd_almost_full, u_dut.wr_almost_full, ~u_dut.resp_empty);
        check("default = 0x0 (no interrupts pending)", rd_reg == 32'h0000_0000);
        // Can't easily set sticky bits without HW events, so test write-ignored
        axi_write(32'h18, 32'h0000_0001);  // try to clear bit 0 (should be no-op if not set)
        axi_read(32'h18, rd_reg);
        check("W1C write to unset bit = no change", rd_reg == 32'h0000_0000);

        // T7: IBI_ENABLE_CTRL removed
        test_num = 7; $display("\n--- T7: IBI_ENABLE_CTRL removed ---");
        axi_read(32'h1C, rd_reg);
        check("IBI_ENABLE_CTRL removed", rd_reg == 32'h0000_0000);

        // T9: HJ_ENABLE_CTRL removed
        test_num = 9; $display("\n--- T9: HJ_ENABLE_CTRL removed ---");
        axi_read(32'h28, rd_reg);
        check("HJ_ENABLE_CTRL removed — no register here", rd_reg != 32'h0000_0003);

        // T12: SW_RESET_CTRL RWSC — write 1 triggers reset, auto-clears
        test_num = 12; $display("\n--- T12: SW_RESET_CTRL (0x3C) RWSC ---");
        axi_write(32'h3C, 32'h0000_0001);  // trigger SW reset
        repeat (3) @(posedge clk);
        axi_read(32'h3C, rd_reg);
        check("SW_RESET_CTRL auto-clears after 2 cycles", rd_reg[0] == 1'b0);

        // T13: SW_RESET_STATUS W1C — after SW reset, should be set
        test_num = 13; $display("\n--- T13: SW_RESET_STATUS (0x40) W1C ---");
        axi_read(32'h40, rd_reg);
        check("SW_RESET_STATUS set after reset", rd_reg[0] == 1'b1);
        axi_write(32'h40, 32'h0000_0001);  // W1C clear
        repeat (2) @(posedge clk);
        axi_read(32'h40, rd_reg);
        check("SW_RESET_STATUS cleared by W1C", rd_reg[0] == 1'b0);

        // T14: FIFO_FLUSH_CTRL RWSC
        test_num = 14; $display("\n--- T14: FIFO_FLUSH_CTRL (0x44) RWSC ---");
        axi_write(32'h44, 32'h0000_000F);  // flush all FIFOs
        repeat (3) @(posedge clk);
        axi_read(32'h44, rd_reg);
        check("FIFO_FLUSH_CTRL auto-clears", rd_reg == 32'h0);

        // T15: ABORT_CTRL RWSC
        test_num = 15; $display("\n--- T15: ABORT_CTRL (0x48) RWSC ---");
        axi_write(32'h48, 32'h0000_0001);  // abort
        repeat (3) @(posedge clk);
        axi_read(32'h48, rd_reg);
        check("ABORT_CTRL auto-clears", rd_reg[0] == 1'b0);

        // T16: SCL_HIGH_TIME_CFG R/W
        test_num = 16; $display("\n--- T16: SCL_HIGH_TIME_CFG (0x4C) R/W ---");
        axi_read(32'h4C, rd_reg);
        check("SCL_HIGH default = 4", rd_reg == 32'h0000_0004);
        axi_write(32'h4C, 32'h0000_0008);
        repeat (2) @(posedge clk);
        axi_read(32'h4C, rd_reg);
        check("SCL_HIGH write 8, readback = 8", rd_reg == 32'h0000_0008);
        axi_write(32'h4C, 32'h0000_0004);  // restore

        // T17: SCL_LOW_TIME_CFG R/W
        test_num = 17; $display("\n--- T17: SCL_LOW_TIME_CFG (0x50) R/W ---");
        axi_read(32'h50, rd_reg);
        check("SCL_LOW default = 4", rd_reg == 32'h0000_0004);
        axi_write(32'h50, 32'h0000_0010);
        repeat (2) @(posedge clk);
        axi_read(32'h50, rd_reg);
        check("SCL_LOW write 16, readback = 16", rd_reg == 32'h0000_0010);
        axi_write(32'h50, 32'h0000_0004);  // restore

        // T18: TIMING_GUARD_CTRL R/W
        test_num = 18; $display("\n--- T18: TIMING_GUARD_CTRL (0xAC) R/W ---");
        axi_read(32'hAC, rd_reg);
        check("TIMING_GUARD default = 1 (enabled)", rd_reg[0] == 1'b1);

        // T19: TIMING_VIOLATION_STATUS W1C
        test_num = 19; $display("\n--- T19: TIMING_VIOLATION_STATUS (0xB0) W1C ---");
        axi_read(32'hB0, rd_reg);
        check("TIMING_VIOLATION default = 0", rd_reg == 32'h0);

        // T20: DNF_CTRL R/W
        test_num = 20; $display("\n--- T20: DNF_CTRL (0x70) R/W ---");
        axi_read(32'h70, rd_reg);
        check("DNF_CTRL default = 0", rd_reg == 32'h0);
        axi_write(32'h70, 32'h0000_0009);  // threshold=4, enable=1
        repeat (2) @(posedge clk);
        axi_read(32'h70, rd_reg);
        check("DNF_CTRL write 0x9, readback", rd_reg == 32'h0000_0009);
        axi_write(32'h70, 32'h0000_0000);  // restore

        // T21: WAKE_CTRL R/W
        test_num = 21; $display("\n--- T21: WAKE_CTRL (0x74) R/W ---");
        axi_read(32'h74, rd_reg);
        check("WAKE_CTRL default = 0", rd_reg == 32'h0);
        axi_write(32'h74, 32'h0000_0003);
        repeat (2) @(posedge clk);
        axi_read(32'h74, rd_reg);
        check("WAKE_CTRL write 0x3, readback", rd_reg == 32'h0000_0003);
        axi_write(32'h74, 32'h0000_0000);

        // T22: CLK_GATE_CTRL R/W
        test_num = 22; $display("\n--- T22: CLK_GATE_CTRL (0x7C) R/W ---");
        axi_read(32'h7C, rd_reg);
        check("CLK_GATE_CTRL default = 0", rd_reg == 32'h0);
        axi_write(32'h7C, 32'h0000_0005);
        repeat (2) @(posedge clk);
        axi_read(32'h7C, rd_reg);
        check("CLK_GATE_CTRL write 0x5, readback", rd_reg == 32'h0000_0005);
        axi_write(32'h7C, 32'h0000_0000);

        // T23: POWER_CTRL R/W
        test_num = 23; $display("\n--- T23: POWER_CTRL (0x80) R/W ---");
        axi_read(32'h80, rd_reg);
        check("POWER_CTRL default = 0", rd_reg == 32'h0);

        // T24: CTRL_DYN_ADDR_CFG R/W (at 0x04)
        test_num = 24; $display("\n--- T24: CTRL_DYN_ADDR_CFG (0x04) R/W ---");
        axi_write(32'h04, 32'h0000_0042);  // dyn_addr=0x42
        repeat (2) @(posedge clk);
        axi_read(32'h04, rd_reg);
        check("CTRL_DYN_ADDR write 0x42, readback", rd_reg[6:0] == 7'h42);

        // T25: GROUP_ADDR_CFG R/W
        test_num = 25; $display("\n--- T25: GROUP_ADDR_CFG (0x88) R/W ---");
        axi_write(32'h88, 32'h0000_0013);  // enable + count=3
        repeat (2) @(posedge clk);
        axi_read(32'h88, rd_reg);
        check("GROUP_ADDR_CFG write 0x13, readback", rd_reg == 32'h0000_0013);
        axi_write(32'h88, 32'h0000_0000);

        // T26: STATIC_ADDR_CFG — check it's removed (reads 0)
        test_num = 26; $display("\n--- T26: STATIC_ADDR_CFG removed ---");
        // No static addr register at 0x98 — that's BUS_CONFIG now

        // T27: BUS_CONFIG R/W — default should be 0x1 (Mixed Fast)
        test_num = 27; $display("\n--- T27: BUS_CONFIG (0x98) R/W ---");
        axi_read(32'h98, rd_reg);
        check("BUS_CONFIG default = 0x1 (Mixed Fast)", rd_reg[1:0] == 2'd1);
        axi_write(32'h98, 32'h0000_0000);  // Pure
        repeat (2) @(posedge clk);
        axi_read(32'h98, rd_reg);
        check("BUS_CONFIG write 0 (Pure), readback", rd_reg[1:0] == 2'd0);
        axi_write(32'h98, 32'h0000_0001);  // restore Mixed Fast

        // T28: RECLAIM_CONFIG R/W
        test_num = 28; $display("\n--- T28: RECLAIM_CONFIG (0xA4) R/W ---");
        axi_write(32'hA4, 32'h0000_8001);  // enable + timeout
        repeat (2) @(posedge clk);
        axi_read(32'hA4, rd_reg);
        check("RECLAIM_CONFIG write 0x8001, readback", rd_reg == 32'h0000_8001);
        axi_write(32'hA4, 32'h0000_0000);

        // T29: SCL_HIGH_TIME_MIXED_CFG R/W (timing guard clamps to 4 min, 4 max)
        test_num = 29; $display("\n--- T29: SCL_HIGH_TIME_MIXED_CFG (0xA8) R/W ---");
        axi_read(32'hA8, rd_reg);
        check("SCL_HIGH_MIXED default = 4", rd_reg == 32'h0000_0004);
        // Write 2 (below min 4) — should clamp to 4
        axi_write(32'hA8, 32'h0000_0002);
        repeat (2) @(posedge clk);
        axi_read(32'hA8, rd_reg);
        check("SCL_HIGH_MIXED write 2 clamped to 4", rd_reg == 32'h0000_0004);
        // Write 5 (above max 4) — should clamp to 4
        axi_write(32'hA8, 32'h0000_0005);
        repeat (2) @(posedge clk);
        axi_read(32'hA8, rd_reg);
        check("SCL_HIGH_MIXED write 5 clamped to 4 (45ns max)", rd_reg == 32'h0000_0004);
        axi_write(32'hA8, 32'h0000_0004);  // restore

        // T30: ROLE_STATE RO
        test_num = 30; $display("\n--- T30: ROLE_STATE (0x9C) RO ---");
        axi_read(32'h9C, rd_reg);
        check("ROLE_STATE default = 0 (ACTIVE_CONTROLLER)", rd_reg[2:0] == 3'd0);

        // T31: PID0_STATUS RO
        test_num = 31; $display("\n--- T31: PID0_STATUS (0x90) RO ---");
        axi_read(32'h90, rd_reg);
        check("PID0_STATUS readable", rd_reg !== 32'hxxxxxxxx);

        // T32: PID1_BCR_DCR_STATUS RO
        test_num = 32; $display("\n--- T32: PID1_BCR_DCR_STATUS (0x94) RO ---");
        axi_read(32'h94, rd_reg);
        check("PID1_BCR_DCR_STATUS readable", rd_reg !== 32'hxxxxxxxx);

        // T33: GROUP_ADDR_TBL_CFG R/W (indirect table access)
        test_num = 33; $display("\n--- T33: GROUP_ADDR_TBL_CFG (0x8C) R/W ---");
        axi_write(32'h8C, 32'h0000_0055);  // some table entry
        repeat (2) @(posedge clk);
        axi_read(32'h8C, rd_reg);
        check("GROUP_ADDR_TBL_CFG write/readback", rd_reg == 32'h0000_0055);

        // T34: RO register write ignored (VERSION)
        test_num = 34; $display("\n--- T34: VERSION RO write ignored ---");
        axi_write(32'h00, 32'hDEAD_BEEF);  // try to write RO
        repeat (2) @(posedge clk);
        axi_read(32'h00, rd_reg);
        check("VERSION write ignored (still 0x0001_0002)", rd_reg == 32'h0001_0002);

        // T35: WAKE_STATUS W1C (no HW event, should be 0)
        test_num = 35; $display("\n--- T35: WAKE_STATUS (0x78) W1C ---");
        axi_read(32'h78, rd_reg);
        check("WAKE_STATUS default = 0", rd_reg == 32'h0);

        // T36: HANDOFF_STATUS RO
        test_num = 36; $display("\n--- T36: HANDOFF_STATUS (0xA0) RO ---");
        axi_read(32'hA0, rd_reg);
        check("HANDOFF_STATUS readable", rd_reg !== 32'hxxxxxxxx);

        // T37: FIFO_LVL_STATUS RO
        test_num = 37; $display("\n--- T37: FIFO_LVL_STATUS (0x28) RO ---");
        axi_read(32'h28, rd_reg);
        check("FIFO_LVL_STATUS readable", rd_reg !== 32'hxxxxxxxx);

        // T38: IBI_STATUS W1C
        test_num = 38; $display("\n--- T38: IBI_STATUS (0x1C) W1C ---");
        axi_read(32'h1C, rd_reg);
        check("IBI_STATUS default = 0", rd_reg == 32'h0);

        // T39: HJ_STATUS W1C
        test_num = 39; $display("\n--- T39: HJ_STATUS (0x24) W1C ---");
        axi_read(32'h24, rd_reg);
        check("HJ_STATUS default = 0", rd_reg == 32'h0);

        // T40: FIFO_LVL_STATUS_1 RO
        test_num = 40; $display("\n--- T40: FIFO_LVL_STATUS_1 (0x2C) RO ---");
        axi_read(32'h2C, rd_reg);
        check("FIFO_LVL_STATUS_1 readable", rd_reg !== 32'hxxxxxxxx);



        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0) $display("OVERALL: PASS");
        else             $display("OVERALL: FAIL");
        $display("============================================================");
        $finish;
    end

    initial begin
        #2000000000;
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count + 1);
        $display("OVERALL: FAIL (watchdog timeout)");
        $display("============================================================");
        $finish;
    end

endmodule
