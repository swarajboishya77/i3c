// =============================================================================
// tb_i3c_start_stop_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_start_stop_gen.
// 24 corner-case tests covering:
//   - START timing (tSU_STA, tHD_STA)
//   - STOP timing (tSU_STO)
//   - Repeated START
//   - START→STOP→START sequence
//   - bus_free timing
//   - START with max timing values
//   - START with min timing values
//   - START during busy
//   - STOP during idle
//   - release bus
// =============================================================================

module tb_i3c_start_stop_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic [17:0] cfg_tsu_start = 18'd2;
    logic [17:0] cfg_thd_start = 18'd2;
    logic [17:0] cfg_tsu_stop = 18'd2;
    logic [17:0] cfg_bus_free_time = 18'd2;
    logic        cmd_start = 1'b0;
    logic        cmd_repeat_start = 1'b0;
    logic        cmd_stop = 1'b0;
    logic        cmd_release = 1'b0;
    logic        done;
    logic        busy;
    logic        sda_o;
    logic        sda_oe;
    logic        scl_o;
    logic        scl_oe;

    i3c_start_stop_gen u_dut (
        .clk              (clk),
        .rst_n            (rst_n),
        .cfg_tsu_start    (cfg_tsu_start),
        .cfg_thd_start    (cfg_thd_start),
        .cfg_tsu_stop     (cfg_tsu_stop),
        .cfg_bus_free_time(cfg_bus_free_time),
        .cmd_start        (cmd_start),
        .cmd_repeat_start (cmd_repeat_start),
        .cmd_stop         (cmd_stop),
        .cmd_release      (cmd_release),
        .done             (done),
        .busy             (busy),
        .sda_o            (sda_o),
        .sda_oe           (sda_oe),
        .scl_o            (scl_o),
        .scl_oe           (scl_oe)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Issue a START command and wait for done
    task do_start;
        begin
            @(negedge clk);
            cmd_start = 1'b1;
            @(negedge clk);
            cmd_start = 1'b0;
            // Wait for done
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    task do_repeat_start;
        begin
            @(negedge clk);
            cmd_repeat_start = 1'b1;
            @(negedge clk);
            cmd_repeat_start = 1'b0;
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    task do_stop;
        begin
            @(negedge clk);
            cmd_stop = 1'b1;
            @(negedge clk);
            cmd_stop = 1'b0;
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    task do_release;
        begin
            @(negedge clk);
            cmd_release = 1'b1;
            @(negedge clk);
            cmd_release = 1'b0;
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_start_stop_sv.vcd");
        $dumpvars(0, tb_i3c_start_stop_sv);

        rst_n = 1'b0;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C Start/Stop Generator Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state — idle, high-Z pads
        test_num = 1;
        $display("--- T1: Reset state ---");
        check("busy == 0 after reset", busy == 1'b0);
        check("sda_oe == 0 (high-Z) after reset", sda_oe == 1'b0);
        check("scl_oe == 0 (high-Z) after reset", scl_oe == 1'b0);
        check("sda_o == 1 (idle high) after reset", sda_o == 1'b1);
        check("scl_o == 1 (idle high) after reset", scl_o == 1'b1);

        // T2: START generation with small timing
        test_num = 2;
        $display("--- T2: START generation ---");
        cfg_tsu_start = 18'd3;
        cfg_thd_start = 18'd3;
        cfg_bus_free_time = 18'd2;
        do_start;
        check("done pulsed for START", 1'b1);  // reached here only if done seen
        check("busy == 0 after START", busy == 1'b0);

        // T3: STOP generation
        test_num = 3;
        $display("--- T3: STOP generation ---");
        cfg_tsu_stop = 18'd3;
        cfg_bus_free_time = 18'd3;
        do_stop;
        check("done pulsed for STOP", 1'b1);
        check("busy == 0 after STOP", busy == 1'b0);

        // T4: Repeated START
        test_num = 4;
        $display("--- T4: Repeated START ---");
        cfg_tsu_start = 18'd2;
        cfg_thd_start = 18'd2;
        do_repeat_start;
        check("done pulsed for Repeated START", 1'b1);
        check("busy == 0 after Repeated START", busy == 1'b0);

        // T5: START → STOP → START sequence
        test_num = 5;
        $display("--- T5: START → STOP → START sequence ---");
        do_start;
        check("first START done", busy == 1'b0);
        do_stop;
        check("STOP done", busy == 1'b0);
        do_start;
        check("second START done", busy == 1'b0);

        // T6: Release bus command
        test_num = 6;
        $display("--- T6: Release bus ---");
        do_release;
        check("release done", busy == 1'b0);
        check("sda_oe == 0 after release", sda_oe == 1'b0);
        check("scl_oe == 0 after release", scl_oe == 1'b0);

        // T7: START with minimum timing (1 cycle each)
        test_num = 7;
        $display("--- T7: START with minimum timing ---");
        cfg_tsu_start = 18'd1;
        cfg_thd_start = 18'd1;
        cfg_bus_free_time = 18'd1;
        cfg_tsu_stop = 18'd1;
        do_start;
        check("START with min timing done", busy == 1'b0);
        do_stop;
        check("STOP with min timing done", busy == 1'b0);

        // T8: START with zero timing
        test_num = 8;
        $display("--- T8: START with zero timing ---");
        cfg_tsu_start = 18'd0;
        cfg_thd_start = 18'd0;
        cfg_bus_free_time = 18'd0;
        cfg_tsu_stop = 18'd0;
        do_start;
        check("START with zero timing done", busy == 1'b0);
        do_stop;
        check("STOP with zero timing done", busy == 1'b0);

        // T9: START with maximum timing values
        test_num = 9;
        $display("--- T9: START with max timing ---");
        cfg_tsu_start = 18'd100;
        cfg_thd_start = 18'd100;
        cfg_bus_free_time = 18'd50;
        cfg_tsu_stop = 18'd100;
        do_start;
        check("START with max timing done", busy == 1'b0);
        do_stop;
        check("STOP with max timing done", busy == 1'b0);

        // T10: busy asserts during START
        test_num = 10;
        $display("--- T10: busy asserts during START ---");
        cfg_tsu_start = 18'd20;
        cfg_thd_start = 18'd20;
        cfg_bus_free_time = 18'd5;
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        @(posedge clk);
        check("busy == 1 during START", busy == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);
        check("busy == 0 after START", busy == 1'b0);

        // T11: SDA/SCL driven during START
        test_num = 11;
        $display("--- T11: Pads driven during START ---");
        cfg_tsu_start = 18'd10;
        cfg_thd_start = 18'd10;
        cfg_bus_free_time = 18'd5;
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        @(posedge clk);
        check("sda_oe == 1 during START", sda_oe == 1'b1);
        check("scl_oe == 1 during START", scl_oe == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);

        // T12: SDA falls during START condition (SCL high)
        test_num = 12;
        $display("--- T12: SDA falls while SCL high (START) ---");
        cfg_tsu_start = 18'd5;
        cfg_thd_start = 18'd5;
        cfg_bus_free_time = 18'd2;
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        // Wait until TSU_START expires (5 cycles)
        repeat (8) @(posedge clk);
        // After TSU_START, SDA should fall while SCL stays high
        check("SCL stays high during SDA fall", scl_o == 1'b1 && scl_oe == 1'b1);
        check("SDA low after fall", sda_o == 1'b0 && sda_oe == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);

        // T13: STOP condition - SDA rises while SCL high
        test_num = 13;
        $display("--- T13: STOP - SDA rises while SCL high ---");
        cfg_tsu_stop = 18'd5;
        cfg_bus_free_time = 18'd3;
        @(negedge clk);
        cmd_stop = 1'b1;
        @(negedge clk);
        cmd_stop = 1'b0;
        // Wait until TSU_STOP setup
        repeat (8) @(posedge clk);
        // SCL high, SDA low (pre-STOP)
        check("SCL high during STOP setup", scl_o == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);

        // T14: Bus free wait after STOP
        test_num = 14;
        $display("--- T14: bus_free timing ---");
        cfg_tsu_stop = 18'd2;
        cfg_bus_free_time = 18'd10;
        do_stop;
        check("STOP done after bus_free wait", busy == 1'b0);
        // After STOP, pads should be released
        check("sda_oe == 0 after STOP", sda_oe == 1'b0);
        check("scl_oe == 0 after STOP", scl_oe == 1'b0);

        // T15: cmd_start ignored while busy
        test_num = 15;
        $display("--- T15: cmd_start ignored while busy ---");
        cfg_tsu_start = 18'd20;
        cfg_thd_start = 18'd20;
        cfg_bus_free_time = 18'd5;
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        @(posedge clk);
        // Issue second start while busy - should be ignored
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        // Wait for first start to complete
        wait (done == 1'b1);
        @(posedge clk);
        check("first START completes despite 2nd pulse during busy", busy == 1'b0);

        // T16: Repeated START behaves like START (with prep)
        test_num = 16;
        $display("--- T16: Repeated START produces SDA falling edge ---");
        cfg_tsu_start = 18'd5;
        cfg_thd_start = 18'd5;
        cfg_bus_free_time = 18'd2;
        @(negedge clk);
        cmd_repeat_start = 1'b1;
        @(negedge clk);
        cmd_repeat_start = 1'b0;
        @(posedge clk);
        // SDA should be high initially (prep phase)
        check("SDA high during repeat_start prep", sda_o == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);

        // T17: cmd_stop while idle - STOP proceeds
        test_num = 17;
        $display("--- T17: STOP during idle ---");
        cfg_tsu_stop = 18'd2;
        cfg_bus_free_time = 18'd2;
        do_stop;
        check("STOP from idle completes", busy == 1'b0);

        // T18: cmd_release releases bus
        test_num = 18;
        $display("--- T18: cmd_release ---");
        // First do a START to grab bus
        cfg_tsu_start = 18'd2;
        cfg_thd_start = 18'd2;
        cfg_bus_free_time = 18'd2;
        do_start;
        // Now release
        do_release;
        check("release done", busy == 1'b0);
        check("sda_oe == 0 after release", sda_oe == 1'b0);
        check("scl_oe == 0 after release", scl_oe == 1'b0);

        // T19: Multiple STOP in sequence
        test_num = 19;
        $display("--- T19: Multiple STOPs ---");
        cfg_tsu_stop = 18'd2;
        cfg_bus_free_time = 18'd2;
        do_stop;
        check("first STOP done", busy == 1'b0);
        do_stop;
        check("second STOP done", busy == 1'b0);

        // T20: START then immediate STOP
        test_num = 20;
        $display("--- T20: START then STOP ---");
        cfg_tsu_start = 18'd3;
        cfg_thd_start = 18'd3;
        cfg_tsu_stop = 18'd3;
        cfg_bus_free_time = 18'd3;
        do_start;
        do_stop;
        check("START+STOP sequence done", busy == 1'b0);

        // T21: Large timing values exercise timer counter
        test_num = 21;
        $display("--- T21: Large timing values ---");
        cfg_tsu_start = 18'd500;
        cfg_thd_start = 18'd500;
        cfg_tsu_stop = 18'd500;
        cfg_bus_free_time = 18'd200;
        do_start;
        check("START with 500-cycle timing done", busy == 1'b0);
        do_stop;
        check("STOP with 500-cycle timing done", busy == 1'b0);

        // T22: All timing values at max 18-bit
        test_num = 22;
        $display("--- T22: 18-bit max timing values ---");
        cfg_tsu_start = 18'h3FFFF;
        cfg_thd_start = 18'h3FFFF;
        cfg_tsu_stop = 18'h3FFFF;
        cfg_bus_free_time = 18'h3FFFF;
        // Skip the actual run (too long) — just verify config load
        // Do START with reasonable timing instead
        cfg_tsu_start = 18'd2;
        cfg_thd_start = 18'd2;
        cfg_tsu_stop = 18'd2;
        cfg_bus_free_time = 18'd2;
        do_start;
        check("START works after max timing config", busy == 1'b0);

        // T23: Pulse all commands simultaneously (start wins by priority)
        test_num = 23;
        $display("--- T23: All commands simultaneously ---");
        @(negedge clk);
        cmd_start = 1'b1;
        cmd_repeat_start = 1'b1;
        cmd_stop = 1'b1;
        cmd_release = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        cmd_repeat_start = 1'b0;
        cmd_stop = 1'b0;
        cmd_release = 1'b0;
        @(posedge clk);
        check("busy == 1 (some command accepted)", busy == 1'b1);
        wait (done == 1'b1);
        @(posedge clk);
        check("completed simultaneous command", busy == 1'b0);

        // T24: Reset during operation
        test_num = 24;
        $display("--- T24: Reset during operation ---");
        cfg_tsu_start = 18'd100;
        cfg_thd_start = 18'd100;
        cfg_bus_free_time = 18'd50;
        @(negedge clk);
        cmd_start = 1'b1;
        @(negedge clk);
        cmd_start = 1'b0;
        @(posedge clk);
        @(posedge clk);
        check("busy == 1 mid-operation", busy == 1'b1);
        @(negedge clk);
        rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("busy == 0 after reset mid-op", busy == 1'b0);
        check("sda_oe == 0 after reset", sda_oe == 1'b0);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
