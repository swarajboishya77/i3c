// =============================================================================
// tb_axi_stall_cases.sv
// -----------------------------------------------------------------------------
// AXI4-Lite Corner Case Testbench: Stalls
//
// Verifies that the AXI4-Lite slave correctly handles back-pressure from the
// master by de-asserting the bready (write response) and rready (read response)
// signals.
//
// V2: Corrected to use valid R/W register addresses based on the spec.
//
// TEST PLAN:
//   1. Write to a valid R/W register (0x4C), stalling BREADY.
//   2. Read from the same register, stalling RREADY, and verify data.
//   3. Perform back-to-back writes to several R/W registers with stalls.
//   4. Verify the data from the back-to-back writes.
// =============================================================================

module tb_axi_stall_cases;

    // -------------------------------------------------------------------------
    // Clock & Reset
    // -------------------------------------------------------------------------
    logic s_axi_aclk = 1'b0;
    logic s_axi_aresetn = 1'b0;
    always #5000 s_axi_aclk = ~s_axi_aclk; // 100 MHz clock

    // -------------------------------------------------------------------------
    // DUT Signals & Test Variables
    // -------------------------------------------------------------------------
    // AXI Interface
    logic        s_axi_awvalid = 0;
    logic        s_axi_awready;
    logic [31:0] s_axi_awaddr = 0;
    logic        s_axi_wvalid = 0;
    logic        s_axi_wready;
    logic [31:0] s_axi_wdata = 0;
    logic [3:0]  s_axi_wstrb = 4'hf;
    logic        s_axi_bvalid;
    logic        s_axi_bready = 1;
    logic [1:0]  s_axi_bresp;
    logic        s_axi_arvalid = 0;
    logic        s_axi_arready;
    logic [31:0] s_axi_araddr = 0;
    logic        s_axi_rvalid;
    logic        s_axi_rready = 1;
    logic [31:0] s_axi_rdata;
    logic [1:0]  s_axi_rresp;
    // Unused DUT signals
    wire scl_pad, sda_pad;

    // Test variables
    integer pass_count = 0;
    integer fail_count = 0;
    reg [31:0] read_data;
    reg [31:0] write_data;

    // -------------------------------------------------------------------------
    // DUT Instantiation
    // -------------------------------------------------------------------------
    i3c_primary_controller_sdr #(
        .AXI_CLK_FREQ_HZ(100_000_000)
    ) u_dut (
        .s_axi_aclk(s_axi_aclk), .s_axi_aresetn(s_axi_aresetn),
        .s_axi_awvalid(s_axi_awvalid), .s_axi_awready(s_axi_awready), .s_axi_awaddr(s_axi_awaddr), .s_axi_awprot(3'b0),
        .s_axi_wvalid(s_axi_wvalid), .s_axi_wready(s_axi_wready), .s_axi_wdata(s_axi_wdata), .s_axi_wstrb(s_axi_wstrb),
        .s_axi_bvalid(s_axi_bvalid), .s_axi_bready(s_axi_bready), .s_axi_bresp(s_axi_bresp),
        .s_axi_arvalid(s_axi_arvalid), .s_axi_arready(s_axi_arready), .s_axi_araddr(s_axi_araddr), .s_axi_arprot(3'b0),
        .s_axi_rvalid(s_axi_rvalid), .s_axi_rready(s_axi_rready), .s_axi_rdata(s_axi_rdata), .s_axi_rresp(s_axi_rresp),
        .scl(scl_pad), .sda(sda_pad)
    );

    // -------------------------------------------------------------------------
    // Test Helper Task
    // -------------------------------------------------------------------------
    task check;
        input [255:0] name;
        input condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] %s", name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] %s", name);
            end
        end
    endtask

    // -------------------------------------------------------------------------
    // AXI Tasks with Stall Injection
    // -------------------------------------------------------------------------
    task axi_write;
        input [31:0] addr;
        input [31:0] data;
        begin
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b1;
            s_axi_wvalid  <= 1'b1;
            s_axi_awaddr  <= addr;
            s_axi_wdata   <= data;
            while (!(s_axi_awready && s_axi_wready)) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b0;
            s_axi_wvalid  <= 1'b0;
            s_axi_bready  <= 1'b0; 
            while (!s_axi_bvalid) @(posedge s_axi_aclk);

            if ($random % 2 == 0) begin
                $display("  INFO: Stalling BREADY for 5 cycles");
                s_axi_bready <= 1'b0;
                repeat (5) @(posedge s_axi_aclk);
            end
            s_axi_bready <= 1'b1;
            @(posedge s_axi_aclk);
            s_axi_bready <= 1'b0;
            check("Write operation completed", s_axi_bresp === 2'b00);
        end
    endtask

    task axi_read;
        input [31:0]  addr;
        output [31:0] data;
        begin
            @(posedge s_axi_aclk);
            s_axi_arvalid <= 1'b1;
            s_axi_araddr  <= addr;
            while (!s_axi_arready) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
            s_axi_arvalid <= 1'b0;
            s_axi_rready <= 1'b0;
            while (!s_axi_rvalid) @(posedge s_axi_aclk);

            if ($random % 2 == 0) begin
                $display("  INFO: Stalling RREADY for 8 cycles");
                s_axi_rready <= 1'b0;
                repeat (8) @(posedge s_axi_aclk);
            end
            s_axi_rready <= 1'b1;
            @(posedge s_axi_aclk);
            data = s_axi_rdata;
            s_axi_rready <= 1'b0;
            check("Read operation completed", s_axi_rresp === 2'b00);
        end
    endtask

    // -------------------------------------------------------------------------
    // Test Sequence
    // -------------------------------------------------------------------------
    initial begin
        $display("=================================================");
        $display("Starting AXI Stall Condition Testbench");
        $display("=================================================");

        s_axi_aresetn <= 1'b0;
        s_axi_bready <= 1'b0;
        s_axi_rready <= 1'b0;
        repeat (10) @(posedge s_axi_aclk);
        s_axi_aresetn <= 1'b1;
        @(posedge s_axi_aclk);

        // --- Test 1: Write and Readback a known R/W register ---
        write_data = 32'hCAFE_BABE;
        $display("\n--- Test 1: Write to SCL_HIGH_TIME_CFG (0x4C) with BREADY stall ---");
        axi_write(32'h4C, write_data);

        $display("\n--- Test 2: Read from SCL_HIGH_TIME_CFG (0x4C) with RREADY stall ---");
        axi_read(32'h4C, read_data);
        if (read_data[17:0] === write_data[17:0]) begin // Register is 18 bits wide
            check("Readback matches written data", 1'b1);
        end else begin
            $display("[FAIL] Readback matches written data. Expected: %h, Actual: %h", write_data[17:0], read_data[17:0]);
            fail_count = fail_count + 1;
        end

        // --- Test 3: Write to multiple R/W timing registers ---
        $display("\n--- Test 3: Back-to-back writes to R/W registers with stalls ---");
        axi_write(32'h4C, 32'hAAAA); // SCL_HIGH_TIME_CFG
        axi_write(32'h50, 32'hBBBB); // SCL_LOW_TIME_CFG
        axi_write(32'h54, 32'hCCCC); // SDA_HOLD_TIME_CFG
        
        // --- Test 4: Verify writes ---
        $display("\n--- Test 4: Verify back-to-back writes ---");
        axi_read(32'h4C, read_data);
        if (read_data[17:0] === 32'hAAAA) check("Readback SCL_HIGH_TIME", 1'b1);
        else begin $display("[FAIL] Readback SCL_HIGH_TIME. Expected: %h, Actual: %h", 32'hAAAA, read_data); fail_count = fail_count + 1; end
        
        axi_read(32'h50, read_data);
        if (read_data[17:0] === 32'hBBBB) check("Readback SCL_LOW_TIME", 1'b1);
        else begin $display("[FAIL] Readback SCL_LOW_TIME. Expected: %h, Actual: %h", 32'hBBBB, read_data); fail_count = fail_count + 1; end

        axi_read(32'h54, read_data);
        if (read_data[17:0] === 32'hCCCC) check("Readback SDA_HOLD_TIME", 1'b1);
        else begin $display("[FAIL] Readback SDA_HOLD_TIME. Expected: %h, Actual: %h", 32'hCCCC, read_data); fail_count = fail_count + 1; end

        $display("\n=================================================");
        if (fail_count == 0) $display("  RESULT: ALL TESTS PASS (%0d checks)", pass_count);
        else $display("  RESULT: %0d FAILURES out of %0d checks", fail_count, pass_count + fail_count);
        $display("=================================================");
        $finish;
    end

    // Watchdog timer
    initial begin
        #1000000; // 1ms timeout
        $display("ERROR: Simulation timed out!");
        fail_count = fail_count + 1;
        $finish;
    end

endmodule
