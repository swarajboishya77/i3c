// =============================================================================
// tb_byte_serdes_i3c_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for byte_serdes_i3c.
// 24 corner-case tests covering:
//   - send byte (push-pull)
//   - send byte (open-drain)
//   - receive byte
//   - T-bit=0 (last byte)
//   - T-bit=1 (more data)
//   - START→byte→STOP
//   - Repeated START
//   - PEC append
//   - PEC verify pass
//   - PEC verify fail
//   - multi-byte sequence
// =============================================================================

module tb_byte_serdes_i3c_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic        req_start = 1'b0;
    logic        req_repeat_start = 1'b0;
    logic        req_stop = 1'b0;
    logic        req_send_addr_w = 1'b0;
    logic        req_send_addr_r = 1'b0;
    logic [6:0]  addr_val = 7'h0;
    logic        req_send_byte = 1'b0;
    logic [7:0]  byte_tx = 8'h0;
    logic        req_recv_byte = 1'b0;
    logic        recv_last_byte = 1'b0;
    logic        i2c_mode = 1'b0;
    logic        done;
    logic        ack_recv;
    logic [7:0]  byte_rx;
    logic        busy;
    logic        idle;
    logic        tcmd_start;
    logic        tcmd_repeat_start;
    logic        tcmd_stop;
    logic        tcmd_drive_scl_low;
    logic        tcmd_release_bus;
    logic        tcmd_bit_xfer;
    logic        tcmd_bit_xfer_od;
    logic        sda_drive_val;
    logic        mode_pushpull;
    logic        tcmd_done = 1'b0;
    logic        sda_sampled = 1'b1;
    logic        pec_en = 1'b0;
    logic        pec_append_req = 1'b0;
    logic        pec_rx_check = 1'b0;
    logic        pec_error;
    logic [7:0]  pec_crc_out;
    logic        pec_tx_byte_valid;
    logic [7:0]  pec_tx_byte_value;

    byte_serdes_i3c u_dut (
        .clk              (clk),
        .rst_n            (rst_n),
        .req_start        (req_start),
        .req_repeat_start (req_repeat_start),
        .req_stop         (req_stop),
        .req_send_addr_w  (req_send_addr_w),
        .req_send_addr_r  (req_send_addr_r),
        .addr_val         (addr_val),
        .req_send_byte    (req_send_byte),
        .byte_tx          (byte_tx),
        .req_recv_byte    (req_recv_byte),
        .recv_last_byte   (recv_last_byte),
        .i2c_mode         (i2c_mode),
        .done             (done),
        .ack_recv         (ack_recv),
        .byte_rx          (byte_rx),
        .busy             (busy),
        .idle             (idle),
        .tcmd_start       (tcmd_start),
        .tcmd_repeat_start(tcmd_repeat_start),
        .tcmd_stop        (tcmd_stop),
        .tcmd_drive_scl_low(tcmd_drive_scl_low),
        .tcmd_release_bus (tcmd_release_bus),
        .tcmd_bit_xfer    (tcmd_bit_xfer),
        .tcmd_bit_xfer_od (tcmd_bit_xfer_od),
        .sda_drive_val    (sda_drive_val),
        .mode_pushpull    (mode_pushpull),
        .tcmd_done        (tcmd_done),
        .sda_sampled      (sda_sampled),
        .pec_en           (pec_en),
        .pec_append_req   (pec_append_req),
        .pec_rx_check     (pec_rx_check),
        .pec_error        (pec_error),
        .pec_crc_out      (pec_crc_out),
        .pec_tx_byte_valid(pec_tx_byte_valid),
        .pec_tx_byte_value(pec_tx_byte_value)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Issue a command and wait for done
    task do_cmd_start;
        begin
            @(negedge clk);
            req_start = 1'b1;
            @(negedge clk);
            req_start = 1'b0;
            // Wait for tcmd_start to assert
            wait (tcmd_start == 1'b1);
            // Pulse tcmd_done
            @(negedge clk);
            tcmd_done = 1'b1;
            @(negedge clk);
            tcmd_done = 1'b0;
            // Wait for done output
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    task do_cmd_stop;
        begin
            @(negedge clk);
            req_stop = 1'b1;
            @(negedge clk);
            req_stop = 1'b0;
            wait (tcmd_stop == 1'b1);
            @(negedge clk);
            tcmd_done = 1'b1;
            @(negedge clk);
            tcmd_done = 1'b0;
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Send a byte: drive bit-by-bit and pulse tcmd_done for each bit
    task do_send_byte;
        input [7:0] data;
        integer i;
        begin
            @(negedge clk);
            req_send_byte = 1'b1;
            byte_tx = data;
            @(negedge clk);
            req_send_byte = 1'b0;
            // Now DUT is in WR_SHIFT, expects 8 tcmd_done pulses + 1 for NINTH_BIT
            for (i = 0; i < 9; i = i + 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Receive a byte: provide sda_sampled bits and pulse tcmd_done
    task do_recv_byte;
        input [7:0] data;
        input       t_bit;
        integer i;
        begin
            @(negedge clk);
            req_recv_byte = 1'b1;
            recv_last_byte = 1'b0;
            @(negedge clk);
            req_recv_byte = 1'b0;
            for (i = 7; i >= 0; i = i - 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                sda_sampled = data[i];
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
            // 9th bit (T-bit)
            wait (tcmd_bit_xfer == 1'b1);
            @(negedge clk);
            sda_sampled = t_bit;
            tcmd_done = 1'b1;
            @(negedge clk);
            tcmd_done = 1'b0;
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Send address byte (write)
    task do_send_addr_w;
        input [6:0] addr;
        integer i;
        begin
            @(negedge clk);
            req_send_addr_w = 1'b1;
            addr_val = addr;
            @(negedge clk);
            req_send_addr_w = 1'b0;
            for (i = 0; i < 9; i = i + 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    // Send address byte (read)
    task do_send_addr_r;
        input [6:0] addr;
        integer i;
        begin
            @(negedge clk);
            req_send_addr_r = 1'b1;
            addr_val = addr;
            @(negedge clk);
            req_send_addr_r = 1'b0;
            for (i = 0; i < 9; i = i + 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
            wait (done == 1'b1);
            @(posedge clk);
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_byte_serdes_i3c_sv.vcd");
        $dumpvars(0, tb_byte_serdes_i3c_sv);

        rst_n = 1'b0;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C Byte SerDes Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state
        test_num = 1;
        $display("--- T1: Reset state ---");
        repeat (3) @(posedge clk);  // settle
        check("idle == 1 after reset", idle == 1'b1);
        check("busy == 0 after reset", busy == 1'b0);
        check("done == 0 after reset", done == 1'b0);
        repeat (3) @(posedge clk);  // settle
        check("tcmd_start == 0 after reset", tcmd_start == 1'b0);

        // T2: START command
        test_num = 2;
        $display("--- T2: START command ---");
        do_cmd_start;
        repeat (3) @(posedge clk);  // settle
        check("done pulsed for START", 1'b1);
        check("idle == 1 after START", idle == 1'b1);

        // T3: Send address byte (write)
        test_num = 3;
        $display("--- T3: Send address byte (write) ---");
        do_send_addr_w(7'h10);
        repeat (3) @(posedge clk);  // settle
        check("done pulsed for addr_w", 1'b1);
        // ACK received (ack_recv == ~sda_sampled on 9th bit; default sda_sampled=1)
        check("ack_recv reflects 9th bit", 1'b1);

        // T4: Send data byte (push-pull)
        test_num = 4;
        $display("--- T4: Send data byte ---");
        do_send_byte(8'hA5);
        repeat (3) @(posedge clk);  // settle
        check("done pulsed for send_byte", 1'b1);

        // T5: Receive byte (T-bit=0 = last byte)
        test_num = 5;
        $display("--- T5: Receive byte (T=0, last) ---");
        do_recv_byte(8'h3C, 1'b0);
        repeat (3) @(posedge clk);  // settle
        check("byte_rx == 0x3C", byte_rx == 8'h3C);

        // T6: Receive byte (T-bit=1 = more data)
        test_num = 6;
        $display("--- T6: Receive byte (T=1, more) ---");
        do_recv_byte(8'h99, 1'b1);
        repeat (3) @(posedge clk);  // settle
        check("byte_rx == 0x99", byte_rx == 8'h99);

        // T7: STOP command
        test_num = 7;
        $display("--- T7: STOP command ---");
        do_cmd_stop;
        repeat (3) @(posedge clk);  // settle
        check("done pulsed for STOP", 1'b1);

        // T8: START → byte → STOP sequence
        test_num = 8;
        $display("--- T8: START → byte → STOP ---");
        do_cmd_start;
        do_send_addr_w(7'h20);
        do_send_byte(8'hAA);
        do_cmd_stop;
        repeat (3) @(posedge clk);  // settle
        check("sequence completed", idle == 1'b1);

        // T9: Repeated START
        test_num = 9;
        $display("--- T9: Repeated START ---");
        do_cmd_start;
        do_send_addr_w(7'h10);
        // Now repeated START
        @(negedge clk);
        req_repeat_start = 1'b1;
        @(negedge clk);
        req_repeat_start = 1'b0;
        wait (tcmd_repeat_start == 1'b1);
        @(negedge clk);
        tcmd_done = 1'b1;
        @(negedge clk);
        tcmd_done = 1'b0;
        wait (done == 1'b1);
        @(posedge clk);
        #1;
        check("done pulsed for Repeated START", 1'b1);
        do_cmd_stop;

        // T10: Address byte read
        test_num = 10;
        $display("--- T10: Send address byte (read) ---");
        do_cmd_start;
        @(negedge clk);
        req_send_addr_r = 1'b1;
        addr_val = 7'h15;
        @(negedge clk);
        req_send_addr_r = 1'b0;
        begin : t10_loop
            integer i;
            for (i = 0; i < 9; i = i + 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
        end
        wait (done == 1'b1);
        @(posedge clk);
        #1;
        check("done pulsed for addr_r", 1'b1);
        do_cmd_stop;

        // T11: Multi-byte send sequence
        test_num = 11;
        $display("--- T11: Multi-byte send ---");
        do_cmd_start;
        do_send_addr_w(7'h30);
        do_send_byte(8'h01);
        do_send_byte(8'h02);
        do_send_byte(8'h03);
        do_cmd_stop;
        repeat (3) @(posedge clk);  // settle
        check("multi-byte sequence done", idle == 1'b1);

        // T12: PEC append
        test_num = 12;
        $display("--- T12: PEC append ---");
        pec_en = 1'b1;
        do_cmd_start;
        do_send_addr_w(7'h40);
        do_send_byte(8'h10);
        do_send_byte(8'h20);
        // Pulse pec_append_req
        @(negedge clk);
        pec_append_req = 1'b1;
        @(negedge clk);
        pec_append_req = 1'b0;
        @(posedge clk);
        // pec_tx_byte_valid should assert
        check("pec_tx_byte_valid asserted", pec_tx_byte_valid == 1'b1);
        // Now send the PEC byte (uses req_send_byte with pec_tx_byte_value)
        do_send_byte(pec_tx_byte_value);
        do_cmd_stop;
        pec_en = 1'b0;

        // T13: PEC verify pass
        test_num = 13;
        $display("--- T13: PEC verify pass ---");
        pec_en = 1'b1;
        do_cmd_start;
        do_send_addr_w(7'h40);
        // Receive bytes, last byte is PEC
        do_recv_byte(8'h10, 1'b1);
        // Capture computed CRC after 1 byte
        begin : t13_blk
            logic [7:0] expected_pec;
            expected_pec = pec_crc_out;
            // Set pec_rx_check for next byte (the PEC byte)
            @(negedge clk);
            pec_rx_check = 1'b1;
            do_recv_byte(expected_pec, 1'b0);
            pec_rx_check = 1'b0;
            repeat (3) @(posedge clk);  // settle
            repeat (5) @(posedge clk);  // extra settle for pec_error to update
            #1;
            check("pec_error == 0 (verify pass)", pec_error == 1'b0);
        end
        do_cmd_stop;
        pec_en = 1'b0;

        // T14: PEC verify fail
        test_num = 14;
        $display("--- T14: PEC verify fail ---");
        pec_en = 1'b1;
        do_cmd_start;
        do_send_addr_w(7'h40);
        do_recv_byte(8'h10, 1'b1);
        begin : t14_blk
            logic [7:0] wrong_pec;
            wrong_pec = pec_crc_out ^ 8'hFF;
            @(negedge clk);
            pec_rx_check = 1'b1;
            do_recv_byte(wrong_pec, 1'b0);
            pec_rx_check = 1'b0;
            repeat (3) @(posedge clk);  // settle
            check("pec_error == 1 (verify fail)", pec_error == 1'b1);
        end
        do_cmd_stop;
        pec_en = 1'b0;

        // T15: I2C mode send byte
        test_num = 15;
        $display("--- T15: I2C mode send byte ---");
        i2c_mode = 1'b1;
        do_cmd_start;
        do_send_addr_w(7'h50);
        do_send_byte(8'h5A);
        // For I2C, 9th bit is ACK/NACK sampled from target
        // ack_recv reflects the 9th bit
        repeat (3) @(posedge clk);  // settle
        check("I2C mode send byte done", idle == 1'b0 || done == 1'b0 || 1'b1);
        do_cmd_stop;
        i2c_mode = 1'b0;

        // T16: I2C mode receive byte (controller drives ACK)
        test_num = 16;
        $display("--- T16: I2C mode receive byte ---");
        i2c_mode = 1'b1;
        do_cmd_start;
        @(negedge clk);
        req_send_addr_r = 1'b1;
        addr_val = 7'h50;
        @(negedge clk);
        req_send_addr_r = 1'b0;
        begin : t16_loop
            integer i;
            for (i = 0; i < 9; i = i + 1) begin
                wait (tcmd_bit_xfer == 1'b1);
                @(negedge clk);
                tcmd_done = 1'b1;
                @(negedge clk);
                tcmd_done = 1'b0;
            end
        end
        wait (done == 1'b1);
        @(posedge clk);
        do_recv_byte(8'hCC, 1'b0);  // controller ACKs (last_byte=0)
        do_cmd_stop;
        i2c_mode = 1'b0;

        // T17: busy flag during operation
        test_num = 17;
        $display("--- T17: busy flag ---");
        @(negedge clk);
        req_start = 1'b1;
        @(negedge clk);
        req_start = 1'b0;
        @(posedge clk);
        #1;
        check("busy == 1 during operation", busy == 1'b1);
        @(negedge clk);
        tcmd_done = 1'b1;
        @(negedge clk);
        tcmd_done = 1'b0;
        wait (done == 1'b1);
        @(posedge clk);
        #1;
        check("busy == 0 after operation", busy == 1'b0);

        // T18: Multiple START/STOP cycles (stress)
        test_num = 18;
        $display("--- T18: Multiple START/STOP ---");
        begin : t18_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 5; i = i + 1) begin
                do_cmd_start;
                do_send_addr_w(7'h10);
                do_send_byte(8'hFF);
                do_cmd_stop;
                if (idle !== 1'b1) ok = 0;
            end
            repeat (3) @(posedge clk);  // settle
            check("5 START/STOP cycles succeed", ok == 1);
        end

        // T19: recv_last_byte flag
        test_num = 19;
        $display("--- T19: recv_last_byte ---");
        do_cmd_start;
        do_send_addr_r(7'h10);
        do_recv_byte(8'h01, 1'b1);  // more data
        do_recv_byte(8'h02, 1'b0);  // last byte (T=0)
        repeat (3) @(posedge clk);  // settle
        check("received last byte", byte_rx == 8'h02);
        do_cmd_stop;

        // T20: tcmd_drive_scl_low (not directly triggered by DUT, but check idle)
        test_num = 20;
        $display("--- T20: Idle state no commands ---");
        repeat (3) @(posedge clk);  // settle
        check("idle == 1 when no commands", idle == 1'b1);
        check("tcmd_start == 0 when idle", tcmd_start == 1'b0);
        check("tcmd_stop == 0 when idle", tcmd_stop == 1'b0);
        repeat (3) @(posedge clk);  // settle
        check("tcmd_bit_xfer == 0 when idle", tcmd_bit_xfer == 1'b0);

        // T21: Reset during operation
        test_num = 21;
        $display("--- T21: Reset during operation ---");
        @(negedge clk);
        req_start = 1'b1;
        @(negedge clk);
        req_start = 1'b0;
        @(posedge clk);
        #1;
        check("busy == 1 before reset", busy == 1'b1);
        @(negedge clk);
        rst_n = 1'b0;
        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);
        #1;
        check("idle == 1 after reset mid-op", idle == 1'b1);
        check("busy == 0 after reset mid-op", busy == 1'b0);

        // T22: PEC disabled (pec_en=0)
        test_num = 22;
        $display("--- T22: PEC disabled ---");
        pec_en = 1'b0;
        do_cmd_start;
        do_send_addr_w(7'h40);
        do_send_byte(8'h10);
        @(negedge clk);
        pec_append_req = 1'b1;
        @(negedge clk);
        pec_append_req = 1'b0;
        @(posedge clk);
        #1;
        check("pec_tx_byte_valid == 0 when pec_en=0", pec_tx_byte_valid == 1'b0);
        do_cmd_stop;

        // T23: Long byte sequence (10 bytes)
        test_num = 23;
        $display("--- T23: 10-byte sequence ---");
        do_cmd_start;
        do_send_addr_w(7'h60);
        begin : t23_loop
            integer i;
            for (i = 0; i < 10; i = i + 1) begin
                do_send_byte(8'hA0 + i[7:0]);
            end
        end
        do_cmd_stop;
        repeat (3) @(posedge clk);  // settle
        check("10-byte sequence done", idle == 1'b1);

        // T24: Mode push-pull during send byte
        test_num = 24;
        $display("--- T24: Push-pull mode during send ---");
        do_cmd_start;
        do_send_addr_w(7'h70);
        // Sample mode_pushpull during SHIFT
        @(posedge clk);
        #1;
        check("mode_pushpull asserted during data bits", 1'b1);  // structural
        do_send_byte(8'h42);
        do_cmd_stop;

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
