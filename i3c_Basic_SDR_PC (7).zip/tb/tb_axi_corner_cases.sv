// =============================================================================
// tb_axi_corner_cases.sv
// -----------------------------------------------------------------------------
// Corner-case testbench for the AXI4-Lite slave (axi4_lite_slave.sv).
//
// Backs the slave with a simple mock register file (16 32-bit registers at
// 0x00..0x3C). Out-of-range addresses are rejected with reg_wr_ack=0 /
// reg_rd_ack=0, which the slave maps to SLVERR (bresp/rresp = 2'b10).
// AMBA IHI 0022H §R3.1: SLVERR=0b10 (slave error), DECERR=0b11 (interconnect decode error).
//
// Tests:
//   T1. Back-to-back writes (10 registers, no delay between transactions)
//   T2. Back-to-back reads  (10 registers, no delay between transactions)
//   T3. Interleaved write→read→write→read
//   T4. AW/W ordering — (a) simultaneous, (b) AW before W, (c) W before AW
//   T5. Read-during-write — arvalid asserted while awvalid+wvalid asserted
//   T6. Error response — write to invalid address => SLVERR
//   T7. Read error response — read from invalid address => SLVERR
//
// Simulator: Icarus Verilog 12.0
// =============================================================================


module tb_axi_corner_cases;

  // -------------------------------------------------------------------------
  // Clock / reset
  // -------------------------------------------------------------------------
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5000 clk = ~clk;   // 100 MHz

  // -------------------------------------------------------------------------
  // AXI4-Lite signals
  // -------------------------------------------------------------------------
  logic        s_axi_awvalid = 1'b0;
  logic        s_axi_awready;
  logic [31:0] s_axi_awaddr  = 32'h0;
  logic        s_axi_wvalid  = 1'b0;
  logic        s_axi_wready;
  logic [31:0] s_axi_wdata   = 32'h0;
  logic [3:0]  s_axi_wstrb   = 4'h0;
  logic        s_axi_bvalid;
  logic        s_axi_bready  = 1'b0;
  logic [1:0]  s_axi_bresp;
  logic        s_axi_arvalid = 1'b0;
  logic        s_axi_arready;
  logic [31:0] s_axi_araddr  = 32'h0;
  logic        s_axi_rvalid;
  logic        s_axi_rready  = 1'b0;
  logic [31:0] s_axi_rdata;
  logic [1:0]  s_axi_rresp;

  // -------------------------------------------------------------------------
  // Register-file interface
  // -------------------------------------------------------------------------
  logic        reg_wr;
  logic [31:0] reg_wr_addr;
  logic [31:0] reg_wr_data;
  logic [3:0]  reg_wr_strb;
  logic        reg_wr_ack;
  logic        reg_rd;
  logic [31:0] reg_rd_addr;
  logic [31:0] reg_rd_data;
  logic        reg_rd_ack;

  // -------------------------------------------------------------------------
  // DUTs
  // -------------------------------------------------------------------------
  axi4_lite_slave #(
    .ADDR_W (32),
    .DATA_W (32)
  ) u_axi (
    .clk              (clk),
    .rst_n            (rst_n),
    .s_axi_awvalid    (s_axi_awvalid),
    .s_axi_awready    (s_axi_awready),
    .s_axi_awaddr     (s_axi_awaddr),
    .s_axi_awprot     (3'b000),
    .s_axi_wvalid     (s_axi_wvalid),
    .s_axi_wready     (s_axi_wready),
    .s_axi_wdata      (s_axi_wdata),
    .s_axi_wstrb      (s_axi_wstrb),
    .s_axi_bvalid     (s_axi_bvalid),
    .s_axi_bready     (s_axi_bready),
    .s_axi_bresp      (s_axi_bresp),
    .s_axi_arvalid    (s_axi_arvalid),
    .s_axi_arready    (s_axi_arready),
    .s_axi_araddr     (s_axi_araddr),
    .s_axi_arprot     (3'b000),
    .s_axi_rvalid     (s_axi_rvalid),
    .s_axi_rready     (s_axi_rready),
    .s_axi_rdata      (s_axi_rdata),
    .s_axi_rresp      (s_axi_rresp),
    .reg_wr           (reg_wr),
    .reg_wr_addr      (reg_wr_addr),
    .reg_wr_data      (reg_wr_data),
    .reg_wr_strb      (reg_wr_strb),
    .reg_wr_ack       (reg_wr_ack),
    .reg_rd           (reg_rd),
    .reg_rd_addr      (reg_rd_addr),
    .reg_rd_data      (reg_rd_data),
    .reg_rd_ack       (reg_rd_ack)
  );

  // -------------------------------------------------------------------------
  // Mock register file: 16 32-bit registers at 0x00..0x3C
  // -------------------------------------------------------------------------
  mock_regfile u_regfile (
    .clk         (clk),
    .rst_n       (rst_n),
    .reg_wr      (reg_wr),
    .reg_wr_addr (reg_wr_addr),
    .reg_wr_data (reg_wr_data),
    .reg_wr_strb (reg_wr_strb),
    .reg_wr_ack  (reg_wr_ack),
    .reg_rd      (reg_rd),
    .reg_rd_addr (reg_rd_addr),
    .reg_rd_data (reg_rd_data),
    .reg_rd_ack  (reg_rd_ack)
  );

  // -------------------------------------------------------------------------
  // Scoreboard
  // -------------------------------------------------------------------------
  int pass_count = 0;
  int fail_count = 0;

  task automatic check(input int tnum, input string name, input logic cond);
    if (cond) begin
      $display("[PASS] T%0d %0s", tnum, name);
      pass_count = pass_count + 1;
    end else begin
      $display("[FAIL] T%0d %0s", tnum, name);
      fail_count = fail_count + 1;
    end
  endtask

  // -------------------------------------------------------------------------
  // Helper: idle AXI
  // -------------------------------------------------------------------------
  task automatic idle_axi();
    s_axi_awvalid = 1'b0;
    s_axi_wvalid  = 1'b0;
    s_axi_arvalid = 1'b0;
    s_axi_bready  = 1'b0;
    s_axi_rready  = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // Reset
  // -------------------------------------------------------------------------
  task automatic do_reset();
    idle_axi();
    rst_n = 1'b0;
    @(posedge clk);
    @(posedge clk);
    @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk);
    @(posedge clk);
  endtask

  // -------------------------------------------------------------------------
  // AXI write — simultaneous AW + W
  // -------------------------------------------------------------------------
  task automatic axi_write_sim(input  logic [31:0] addr,
                     input  logic [31:0] data,
                     output logic [1:0]  resp);
    logic aw_done = 1'b0, w_done = 1'b0;
    @(negedge clk);
    s_axi_awvalid = 1'b1; s_axi_awaddr = addr;
    s_axi_wvalid  = 1'b1; s_axi_wdata  = data; s_axi_wstrb = 4'hF;
    s_axi_bready  = 1'b1;
    while (!aw_done || !w_done) begin
      @(posedge clk);
      if (s_axi_awvalid && s_axi_awready) aw_done = 1'b1;
      if (s_axi_wvalid  && s_axi_wready)  w_done  = 1'b1;
      @(negedge clk);
      if (aw_done) s_axi_awvalid = 1'b0;
      if (w_done)  s_axi_wvalid  = 1'b0;
    end
    // Wait for B response
    while (!s_axi_bvalid) @(posedge clk);
    resp = s_axi_bresp;
    @(negedge clk);
    s_axi_bready = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // AXI write — AW before W
  // -------------------------------------------------------------------------
  task automatic axi_write_aw_first(input  logic [31:0] addr,
                          input  logic [31:0] data,
                          output logic [1:0]  resp);
    logic aw_done = 1'b0, w_done = 1'b0;
    @(negedge clk);
    s_axi_awvalid = 1'b1; s_axi_awaddr = addr;
    s_axi_bready  = 1'b1;
    while (!aw_done || !w_done) begin
      @(posedge clk);
      if (s_axi_awvalid && s_axi_awready) aw_done = 1'b1;
      if (s_axi_wvalid  && s_axi_wready)  w_done  = 1'b1;
      @(negedge clk);
      if (aw_done) s_axi_awvalid = 1'b0;
      if (aw_done && !w_done && !s_axi_wvalid) begin
        s_axi_wvalid = 1'b1;
        s_axi_wdata  = data;
        s_axi_wstrb  = 4'hF;
      end
      if (w_done) s_axi_wvalid = 1'b0;
    end
    while (!s_axi_bvalid) @(posedge clk);
    resp = s_axi_bresp;
    @(negedge clk);
    s_axi_bready = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // AXI write — W before AW
  // -------------------------------------------------------------------------
  task automatic axi_write_w_first(input  logic [31:0] addr,
                         input  logic [31:0] data,
                         output logic [1:0]  resp);
    logic aw_done = 1'b0, w_done = 1'b0;
    @(negedge clk);
    s_axi_wvalid = 1'b1; s_axi_wdata = data; s_axi_wstrb = 4'hF;
    s_axi_bready = 1'b1;
    while (!aw_done || !w_done) begin
      @(posedge clk);
      if (s_axi_awvalid && s_axi_awready) aw_done = 1'b1;
      if (s_axi_wvalid  && s_axi_wready)  w_done  = 1'b1;
      @(negedge clk);
      if (w_done) s_axi_wvalid = 1'b0;
      if (w_done && !aw_done && !s_axi_awvalid) begin
        s_axi_awvalid = 1'b1;
        s_axi_awaddr  = addr;
      end
      if (aw_done) s_axi_awvalid = 1'b0;
    end
    while (!s_axi_bvalid) @(posedge clk);
    resp = s_axi_bresp;
    @(negedge clk);
    s_axi_bready = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // AXI read
  // -------------------------------------------------------------------------
  task automatic axi_read(input  logic [31:0] addr,
                output logic [31:0] data,
                output logic [1:0]  resp);
    @(negedge clk);
    s_axi_arvalid = 1'b1; s_axi_araddr = addr;
    s_axi_rready  = 1'b1;
    @(posedge clk);
    while (!(s_axi_arvalid && s_axi_arready)) @(posedge clk);
    @(negedge clk);
    s_axi_arvalid = 1'b0;
    while (!s_axi_rvalid) @(posedge clk);
    data = s_axi_rdata;
    resp = s_axi_rresp;
    @(negedge clk);
    s_axi_rready = 1'b0;
  endtask

  // -------------------------------------------------------------------------
  // Watchdog
  // -------------------------------------------------------------------------
  initial begin
    #2000000000;
    $display("[FAIL] WATCHDOG TIMEOUT — testbench stuck");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Test sequencer
  // -------------------------------------------------------------------------
  initial begin
    $display("==========================================================");
    $display("tb_axi_corner_cases — starting");
    $display("==========================================================");

    do_reset();
    check(0, "post-reset bvalid=0", s_axi_bvalid == 1'b0);
    check(0, "post-reset rvalid=0", s_axi_rvalid == 1'b0);

    // ------------------------------------------------------------------
    // T1. Back-to-back writes (10 registers)
    // ------------------------------------------------------------------
    do_reset();
    begin : b2b_writes
      logic [1:0] bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      for (int i = 0; i < 10; i++) begin
        axi_write_sim(32'h0000_0000 + i*4, 32'hD000_0000 + i, bresp);
        check(1, $sformatf("b2b write i=%0d OKAY", i), bresp == 2'b00);
      end
      // Read back all 10
      for (int i = 0; i < 10; i++) begin
        axi_read(32'h0000_0000 + i*4, rdata, rresp);
        check(1, $sformatf("b2b readback i=%0d OKAY", i), rresp == 2'b00);
        check(1, $sformatf("b2b readback i=%0d data", i),
              rdata === (32'hD000_0000 + i));
      end
    end

    // ------------------------------------------------------------------
    // T2. Back-to-back reads (10 registers)
    // ------------------------------------------------------------------
    do_reset();
    begin : b2b_reads
      logic [1:0] bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      // Pre-fill 10 registers
      for (int i = 0; i < 10; i++) begin
        axi_write_sim(32'h0000_0000 + i*4, 32'hE000_0000 + i, bresp);
      end
      // Read them back-to-back
      for (int i = 0; i < 10; i++) begin
        axi_read(32'h0000_0000 + i*4, rdata, rresp);
        check(2, $sformatf("b2b read i=%0d OKAY", i), rresp == 2'b00);
        check(2, $sformatf("b2b read i=%0d data", i),
              rdata === (32'hE000_0000 + i));
      end
    end

    // ------------------------------------------------------------------
    // T3. Interleaved write→read→write→read
    // ------------------------------------------------------------------
    do_reset();
    begin : interleaved
      logic [1:0] bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      axi_write_sim(32'h0000_0010, 32'hAABB_CCD0, bresp);
      check(3, "interleave write #1 OKAY", bresp == 2'b00);
      axi_read (32'h0000_0010, rdata, rresp);
      check(3, "interleave read #1 OKAY", rresp == 2'b00);
      check(3, "interleave read #1 data", rdata === 32'hAABB_CCD0);
      axi_write_sim(32'h0000_0014, 32'h1122_3344, bresp);
      check(3, "interleave write #2 OKAY", bresp == 2'b00);
      axi_read (32'h0000_0014, rdata, rresp);
      check(3, "interleave read #2 OKAY", rresp == 2'b00);
      check(3, "interleave read #2 data", rdata === 32'h1122_3344);
      // Re-read first register to ensure no corruption
      axi_read (32'h0000_0010, rdata, rresp);
      check(3, "interleave re-read #1 uncorrupted",
            rresp == 2'b00 && rdata === 32'hAABB_CCD0);
    end

    // ------------------------------------------------------------------
    // T4. AW/W ordering
    // ------------------------------------------------------------------
    do_reset();
    begin : aw_w_order
      logic [1:0] bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      // (a) Simultaneous
      axi_write_sim      (32'h0000_0000, 32'h1111_1111, bresp);
      check(4, "T4a sim write OKAY", bresp == 2'b00);
      axi_read           (32'h0000_0000, rdata, rresp);
      check(4, "T4a sim read OKAY",  rresp == 2'b00);
      check(4, "T4a sim read data",  rdata === 32'h1111_1111);
      // (b) AW before W
      axi_write_aw_first (32'h0000_0004, 32'h2222_2222, bresp);
      check(4, "T4b AW-first write OKAY", bresp == 2'b00);
      axi_read           (32'h0000_0004, rdata, rresp);
      check(4, "T4b AW-first read OKAY",  rresp == 2'b00);
      check(4, "T4b AW-first read data",  rdata === 32'h2222_2222);
      // (c) W before AW
      axi_write_w_first  (32'h0000_0008, 32'h3333_3333, bresp);
      check(4, "T4c W-first write OKAY", bresp == 2'b00);
      axi_read           (32'h0000_0008, rdata, rresp);
      check(4, "T4c W-first read OKAY",  rresp == 2'b00);
      check(4, "T4c W-first read data",  rdata === 32'h3333_3333);
    end

    // ------------------------------------------------------------------
    // T5. Read during write (arvalid asserted while awvalid+wvalid)
    // ------------------------------------------------------------------
    do_reset();
    begin : rd_during_wr
      logic [1:0]  bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      // Pre-fill reg[0]
      axi_write_sim(32'h0000_0000, 32'hAAAA_BBBB, bresp);
      // Now issue a simultaneous write to reg[1] and read of reg[0]
      fork
        axi_write_sim(32'h0000_0004, 32'hCCCC_DDDD, bresp);
        axi_read     (32'h0000_0000, rdata, rresp);
      join
      check(5, "T5 concurrent write OKAY", bresp == 2'b00);
      check(5, "T5 concurrent read OKAY",  rresp == 2'b00);
      check(5, "T5 concurrent read data",  rdata === 32'hAAAA_BBBB);
      // Verify write landed
      axi_read(32'h0000_0004, rdata, rresp);
      check(5, "T5 write landed OKAY", rresp == 2'b00);
      check(5, "T5 write landed data", rdata === 32'hCCCC_DDDD);
    end

    // ------------------------------------------------------------------
    // T6. Error response — write to invalid address
    // ------------------------------------------------------------------
    do_reset();
    begin : err_write
      logic [1:0] bresp;
      axi_write_sim(32'h0000_0100, 32'hDEAD_BEEF, bresp);
      check(6, "T6 invalid write returns SLVERR", bresp == 2'b10);
      // Valid write still works after error
      axi_write_sim(32'h0000_0000, 32'h1234_5678, bresp);
      check(6, "T6 valid write after error OKAY", bresp == 2'b00);
    end

    // ------------------------------------------------------------------
    // T7. Read error response — read from invalid address
    // ------------------------------------------------------------------
    do_reset();
    begin : err_read
      logic [1:0]  bresp;
      logic [31:0] rdata;
      logic [1:0]  rresp;
      axi_write_sim(32'h0000_0000, 32'hFEED_C0DE, bresp);
      axi_read     (32'h0000_0100, rdata, rresp);
      check(7, "T7 invalid read returns SLVERR", rresp == 2'b10);
      // Valid read still works after error
      axi_read     (32'h0000_0000, rdata, rresp);
      check(7, "T7 valid read after error OKAY", rresp == 2'b00);
      check(7, "T7 valid read after error data", rdata === 32'hFEED_C0DE);
    end

    // ------------------------------------------------------------------
    // Summary
    // ------------------------------------------------------------------
    $display("==========================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
    if (fail_count == 0) $display("OVERALL: PASS");
    else                 $display("OVERALL: FAIL");
    $display("==========================================================");
    $finish;
  end

endmodule : tb_axi_corner_cases


// =============================================================================
// mock_regfile — simple 16-register backing store for the AXI slave.
//   - Valid address range: 0x00..0x3C (16 4-byte registers)
//   - Out-of-range addresses return reg_wr_ack=0 / reg_rd_ack=0
//   - Byte strobes supported on writes
// =============================================================================
module mock_regfile (
  input  logic        clk,
  input  logic        rst_n,
  // Write port
  input  logic        reg_wr,
  input  logic [31:0] reg_wr_addr,
  input  logic [31:0] reg_wr_data,
  input  logic [3:0]  reg_wr_strb,
  output logic        reg_wr_ack,
  // Read port
  input  logic        reg_rd,
  input  logic [31:0] reg_rd_addr,
  output logic [31:0] reg_rd_data,
  output logic        reg_rd_ack
);
  localparam int NUM_REGS = 16;

  logic [31:0] regs [0:NUM_REGS-1];

  // Address decode: bits [31:6] must be 0 and bits [5:2] < 16
  logic wr_in_range, rd_in_range;
  assign wr_in_range = (reg_wr_addr[31:6] == 26'h0);
  assign rd_in_range = (reg_rd_addr[31:6] == 26'h0);

  assign reg_wr_ack  = reg_wr && wr_in_range;
  assign reg_rd_ack  = reg_rd && rd_in_range;
  assign reg_rd_data = rd_in_range ? regs[reg_rd_addr[5:2]] : 32'h0;

  // Synthesizable write with byte strobes
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_REGS; i++) regs[i] <= 32'h0;
    end else if (reg_wr && wr_in_range) begin
      if (reg_wr_strb[0]) regs[reg_wr_addr[5:2]][7:0]   <= reg_wr_data[7:0];
      if (reg_wr_strb[1]) regs[reg_wr_addr[5:2]][15:8]  <= reg_wr_data[15:8];
      if (reg_wr_strb[2]) regs[reg_wr_addr[5:2]][23:16] <= reg_wr_data[23:16];
      if (reg_wr_strb[3]) regs[reg_wr_addr[5:2]][31:24] <= reg_wr_data[31:24];
    end
  end

endmodule : mock_regfile
