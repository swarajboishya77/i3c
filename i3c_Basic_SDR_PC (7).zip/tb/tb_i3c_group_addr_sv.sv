// =============================================================================
// tb_i3c_group_addr_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_group_addr.
// 26 corner-case tests covering:
//   - all 8 group slots
//   - group_count=0 (no groups), group_count=8 (max)
//   - group address=0x00 (reserved), 0x7E (broadcast), 0x7F (reserved)
//   - duplicate group addresses (first-wins priority)
//   - GETRTGL with no groups, GETRTGL with all groups
//   - first-wins priority
//   - group_enable=0 (no match)
//   - CCC SETRTGL/GETRTGL interface
// =============================================================================

module tb_i3c_group_addr_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic        group_enable = 1'b0;
    logic [6:0]  group_count = 7'd0;
    logic [31:0] group_table_0 = 32'h0;
    logic [31:0] group_table_1 = 32'h0;
    logic [31:0] group_table_2 = 32'h0;
    logic [31:0] group_table_3 = 32'h0;
    logic [31:0] group_table_4 = 32'h0;
    logic [31:0] group_table_5 = 32'h0;
    logic [31:0] group_table_6 = 32'h0;
    logic [31:0] group_table_7 = 32'h0;
    logic [6:0]  addr_val = 7'd0;
    logic        group_match;
    logic [2:0]  group_idx;
    logic [15:0] group_targets;
    logic        ccc_setrtgl = 1'b0;
    logic        ccc_getrtgl = 1'b0;
    logic [7:0]  ccc_payload_byte = 8'h0;
    logic [7:0]  ccc_response_byte;
    logic        ccc_response_valid;

    i3c_group_addr u_dut (
        .clk                (clk),
        .rst_n              (rst_n),
        .group_enable       (group_enable),
        .group_count        (group_count),
        .group_table_0      (group_table_0),
        .group_table_1      (group_table_1),
        .group_table_2      (group_table_2),
        .group_table_3      (group_table_3),
        .group_table_4      (group_table_4),
        .group_table_5      (group_table_5),
        .group_table_6      (group_table_6),
        .group_table_7      (group_table_7),
        .addr_val           (addr_val),
        .group_match        (group_match),
        .group_idx          (group_idx),
        .group_targets      (group_targets),
        .ccc_setrtgl        (ccc_setrtgl),
        .ccc_getrtgl        (ccc_getrtgl),
        .ccc_payload_byte   (ccc_payload_byte),
        .ccc_response_byte  (ccc_response_byte),
        .ccc_response_valid (ccc_response_valid)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Build a group entry: {group_addr[6:0], targets[15:0], reserved[8:0]}
    // Actually: [31:25]=group_addr, [24:9]=targets, [7:0]=reserved
    function automatic logic [31:0] mk_entry(input logic [6:0] gaddr,
                                              input logic [15:0] targets,
                                              input logic [7:0] rsvd);
        begin
            // RTL format: [31:25]=gaddr(7), [24:9]=targets(16), [8:0]=rsvd(9)
            // Pad rsvd to 9 bits to match 32-bit total
            mk_entry = {gaddr, targets, 1'b0, rsvd};
        end
    endfunction

    task clear_tables;
        begin
            group_table_0 = 32'h0;
            group_table_1 = 32'h0;
            group_table_2 = 32'h0;
            group_table_3 = 32'h0;
            group_table_4 = 32'h0;
            group_table_5 = 32'h0;
            group_table_6 = 32'h0;
            group_table_7 = 32'h0;
        end
    endtask

    // Pulse GETRTGL for one cycle
    task pulse_getrtgl;
        begin
            @(negedge clk);
            ccc_getrtgl = 1'b1;
            @(negedge clk);
            ccc_getrtgl = 1'b0;
        end
    endtask

    task pulse_setrtgl;
        begin
            @(negedge clk);
            ccc_setrtgl = 1'b1;
            @(negedge clk);
            ccc_setrtgl = 1'b0;
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_group_addr_sv.vcd");
        $dumpvars(0, tb_i3c_group_addr_sv);

        rst_n = 1'b0;
        group_enable = 1'b0;
        group_count = 7'd0;
        clear_tables;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C Group Address Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state — no match, response idle
        test_num = 1;
        $display("--- T1: Reset state ---");
        repeat (3) @(posedge clk);  // settle
        check("group_match == 0 after reset", group_match == 1'b0);
        check("group_targets == 0 after reset", group_targets == 16'h0);
        check("ccc_response_valid == 0 after reset", ccc_response_valid == 1'b0);

        // T2: group_enable=0 — no match regardless of tables
        test_num = 2;
        $display("--- T2: group_enable=0 ---");
        group_enable = 1'b0;
        group_count = 7'd2;
        group_table_0 = mk_entry(7'h10, 16'h000F, 8'h00);
        group_table_1 = mk_entry(7'h20, 16'h00F0, 8'h00);
        addr_val = 7'h10;
        @(posedge clk);
        #1;
        check("group_match == 0 when disabled", group_match == 1'b0);

        // T3: group_count=0 — no match even with enable
        test_num = 3;
        $display("--- T3: group_count=0 ---");
        group_enable = 1'b1;
        group_count = 7'd0;
        clear_tables;
        addr_val = 7'h10;
        @(posedge clk);
        #1;
        check("group_match == 0 with count=0", group_match == 1'b0);

        // T4: Single group slot match
        test_num = 4;
        $display("--- T4: Single group slot match ---");
        group_enable = 1'b1;
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h10, 16'h000F, 8'h00);
        addr_val = 7'h10;
        @(posedge clk);
        #1;
        check("group_match == 1 for slot 0", group_match == 1'b1);
        check("group_idx == 0", group_idx == 3'd0);
        check("group_targets == 0x000F", group_targets == 16'h000F);

        // T5: Single group slot no match
        test_num = 5;
        $display("--- T5: Single group slot no match ---");
        addr_val = 7'h11;
        @(posedge clk);
        #1;
        check("group_match == 0 for non-matching addr", group_match == 1'b0);

        // T6: All 8 group slots — match each
        test_num = 6;
        $display("--- T6: All 8 group slots ---");
        group_count = 7'd8;
        group_table_0 = mk_entry(7'h10, 16'h0001, 8'h00);
        group_table_1 = mk_entry(7'h20, 16'h0002, 8'h00);
        group_table_2 = mk_entry(7'h30, 16'h0004, 8'h00);
        group_table_3 = mk_entry(7'h40, 16'h0008, 8'h00);
        group_table_4 = mk_entry(7'h50, 16'h0010, 8'h00);
        group_table_5 = mk_entry(7'h60, 16'h0020, 8'h00);
        group_table_6 = mk_entry(7'h6A, 16'h0040, 8'h00);
        group_table_7 = mk_entry(7'h6B, 16'h0080, 8'h00);
        // Slot 0
        addr_val = 7'h10; @(posedge clk);
        #1;
        check("slot 0 match", group_match == 1'b1 && group_idx == 3'd0 && group_targets == 16'h0001);
        // Slot 1
        addr_val = 7'h20; @(posedge clk);
        #1;
        check("slot 1 match", group_match == 1'b1 && group_idx == 3'd1 && group_targets == 16'h0002);
        // Slot 2
        addr_val = 7'h30; @(posedge clk);
        #1;
        check("slot 2 match", group_match == 1'b1 && group_idx == 3'd2 && group_targets == 16'h0004);
        // Slot 3
        addr_val = 7'h40; @(posedge clk);
        #1;
        check("slot 3 match", group_match == 1'b1 && group_idx == 3'd3 && group_targets == 16'h0008);
        // Slot 4
        addr_val = 7'h50; @(posedge clk);
        #1;
        check("slot 4 match", group_match == 1'b1 && group_idx == 3'd4 && group_targets == 16'h0010);
        // Slot 5
        addr_val = 7'h60; @(posedge clk);
        #1;
        check("slot 5 match", group_match == 1'b1 && group_idx == 3'd5 && group_targets == 16'h0020);
        // Slot 6
        addr_val = 7'h6A; @(posedge clk);
        #1;
        check("slot 6 match", group_match == 1'b1 && group_idx == 3'd6 && group_targets == 16'h0040);
        // Slot 7
        addr_val = 7'h6B; @(posedge clk);
        #1;
        check("slot 7 match", group_match == 1'b1 && group_idx == 3'd7 && group_targets == 16'h0080);

        // T7: group_count=8 but only first 3 slots set, address in slot 7 — no match
        test_num = 7;
        $display("--- T7: count=8, address not in table ---");
        addr_val = 7'h7E;
        @(posedge clk);
        #1;
        check("no match for absent address", group_match == 1'b0);

        // T8: group_count limits search (count=3, addr in slot 5 — no match)
        test_num = 8;
        $display("--- T8: count limits search ---");
        group_count = 7'd3;
        addr_val = 7'h60;  // slot 5
        @(posedge clk);
        #1;
        check("no match for slot beyond count", group_match == 1'b0);

        // T9: Reserved group address 0x00
        test_num = 9;
        $display("--- T9: Group address 0x00 (reserved) ---");
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h00, 16'hFFFF, 8'h00);
        addr_val = 7'h00;
        @(posedge clk);
        #1;
        check("match on address 0x00", group_match == 1'b1);

        // T10: Broadcast address 0x7E
        test_num = 10;
        $display("--- T10: Group address 0x7E (broadcast) ---");
        group_table_0 = mk_entry(7'h7E, 16'hFFFF, 8'h00);
        addr_val = 7'h7E;
        @(posedge clk);
        #1;
        check("match on address 0x7E", group_match == 1'b1);

        // T11: Reserved address 0x7F
        test_num = 11;
        $display("--- T11: Group address 0x7F (reserved) ---");
        group_table_0 = mk_entry(7'h7F, 16'hFFFF, 8'h00);
        addr_val = 7'h7F;
        @(posedge clk);
        #1;
        check("match on address 0x7F", group_match == 1'b1);

        // T12: Duplicate group addresses — first wins (lowest index)
        test_num = 12;
        $display("--- T12: Duplicate group addresses (first wins) ---");
        group_count = 7'd3;
        group_table_0 = mk_entry(7'h33, 16'h0001, 8'h00);
        group_table_1 = mk_entry(7'h33, 16'h0002, 8'h00);  // duplicate addr
        group_table_2 = mk_entry(7'h33, 16'h0004, 8'h00);  // duplicate addr
        addr_val = 7'h33;
        @(posedge clk);
        #1;
        check("group_match == 1 with duplicate addresses", group_match == 1'b1);
        check("group_idx == 0 (first wins)", group_idx == 3'd0);
        check("group_targets == 0x0001 (first entry)", group_targets == 16'h0001);

        // T13: First-wins priority when middle slot is empty but later slot matches
        test_num = 13;
        $display("--- T13: First-wins with sparse table ---");
        group_count = 7'd5;
        group_table_0 = mk_entry(7'h11, 16'h0001, 8'h00);
        group_table_1 = mk_entry(7'h22, 16'h0002, 8'h00);
        group_table_2 = mk_entry(7'h33, 16'h0004, 8'h00);
        group_table_3 = mk_entry(7'h11, 16'h0008, 8'h00);  // dup
        group_table_4 = mk_entry(7'h22, 16'h0010, 8'h00);  // dup
        addr_val = 7'h22;
        @(posedge clk);
        #1;
        check("first-wins picks slot 1 for addr 0x22", group_idx == 3'd1 && group_targets == 16'h0002);
        addr_val = 7'h11;
        @(posedge clk);
        #1;
        check("first-wins picks slot 0 for addr 0x11", group_idx == 3'd0 && group_targets == 16'h0001);

        // T14: GETRTGL with no groups (count=0)
        test_num = 14;
        $display("--- T14: GETRTGL with no groups ---");
        pulse_setrtgl;  // reset GETRTGL index to 0
        group_count = 7'd0;
        clear_tables;
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("GETRTGL response valid", ccc_response_valid == 1'b1);
        check("GETRTGL response byte == 0 (empty table)", ccc_response_byte == 8'h00);

        // T15: GETRTGL with single group
        test_num = 15;
        $display("--- T15: GETRTGL single group ---");
        pulse_setrtgl;  // reset GETRTGL index to 0
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h10, 16'hABCD, 8'h42);
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("GETRTGL returns reserved byte (0x42)", ccc_response_byte == 8'h42);
        check("GETRTGL response valid", ccc_response_valid == 1'b1);

        // T16: GETRTGL with all 8 groups — sequential reads
        test_num = 16;
        $display("--- T16: GETRTGL with all 8 groups ---");
        pulse_setrtgl;  // reset GETRTGL index to 0
        group_count = 7'd8;
        group_table_0 = mk_entry(7'h01, 16'h0001, 8'h11);
        group_table_1 = mk_entry(7'h02, 16'h0002, 8'h22);
        group_table_2 = mk_entry(7'h03, 16'h0004, 8'h33);
        group_table_3 = mk_entry(7'h04, 16'h0008, 8'h44);
        group_table_4 = mk_entry(7'h05, 16'h0010, 8'h55);
        group_table_5 = mk_entry(7'h06, 16'h0020, 8'h66);
        group_table_6 = mk_entry(7'h07, 16'h0040, 8'h77);
        group_table_7 = mk_entry(7'h08, 16'h0080, 8'h88);
        begin : getrtgl_loop
            integer i;
            logic [7:0] exp;
            logic [7:0] got;
            integer ok;
            ok = 1;
            for (i = 0; i < 8; i = i + 1) begin
                exp = 8'h11 * (i + 1);  // 0x11, 0x22, 0x33, ..., 0x88
                pulse_getrtgl;
                @(posedge clk);
                got = ccc_response_byte;
                if (got !== exp) begin
                    ok = 0;
                    $display("    GETRTGL idx %0d: got 0x%02x, exp 0x%02x", i, got, exp);
                end
            end
            repeat (3) @(posedge clk);  // settle
            check("GETRTGL returns all 8 reserved bytes in order", ok == 1);
        end

        // T17: GETRTGL counter wraps around modulo 8
        test_num = 17;
        $display("--- T17: GETRTGL index wraps around ---");
        pulse_setrtgl;  // reset GETRTGL index to 0
        // Read 8 entries to fill the index, then 9th should wrap to slot 0
        begin : t17_loop
            integer i;
            for (i = 0; i < 8; i = i + 1) begin
                pulse_getrtgl;
                @(posedge clk);
            end
        end
        // 9th read should wrap to slot 0
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("GETRTGL wraps to slot 0", ccc_response_byte == 8'h11);

        // T18: Match output updates combinationally with addr_val
        test_num = 18;
        $display("--- T18: Match updates combinationally ---");
        group_count = 7'd2;
        group_table_0 = mk_entry(7'h2A, 16'h00FF, 8'h00);
        group_table_1 = mk_entry(7'h3B, 16'hFF00, 8'h00);
        addr_val = 7'h2A;
        #1;  // small delay for combinational settle
        repeat (3) @(posedge clk);  // settle
        check("match AA combinationally", group_match == 1'b1 && group_idx == 3'd0);
        addr_val = 7'h3B;
        #1;
        repeat (3) @(posedge clk);  // settle
        check("match BB combinationally", group_match == 1'b1 && group_idx == 3'd1);
        addr_val = 7'h4C;
        #1;
        repeat (3) @(posedge clk);  // settle
        check("no match CC combinationally", group_match == 1'b0);

        // T19: SETRTGL CCC pulse (acknowledge only — table is in registers)
        test_num = 19;
        $display("--- T19: SETRTGL CCC pulse ---");
        @(negedge clk);
        ccc_setrtgl = 1'b1;
        @(negedge clk);
        ccc_setrtgl = 1'b0;
        @(posedge clk);
        #1;
        check("SETRTRL pulse accepted (no fault)", 1'b1);

        // T20: All 16 targets in one group
        test_num = 20;
        $display("--- T20: All 16 targets in one group ---");
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h20, 16'hFFFF, 8'h00);
        addr_val = 7'h20;
        @(posedge clk);
        #1;
        check("all 16 targets reported", group_targets == 16'hFFFF);

        // T21: group_count > 8 (clamped to 8 via loop limit)
        test_num = 21;
        $display("--- T21: group_count > 8 (overflow) ---");
        group_count = 7'd8;  // 7-bit max would be 127, but loop only goes to 8
        group_table_0 = mk_entry(7'h10, 16'h0001, 8'h00);
        addr_val = 7'h10;
        @(posedge clk);
        #1;
        check("match works with count=8 (effectively max)", group_match == 1'b1);

        // T22: Address just below broadcast (0x7D)
        test_num = 22;
        $display("--- T22: Group address 0x7D ---");
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h7D, 16'h00FF, 8'h00);
        addr_val = 7'h7D;
        @(posedge clk);
        #1;
        check("match on 0x7D", group_match == 1'b1);

        // T23: Reserved byte field preserved through GETRTGL
        test_num = 23;
        $display("--- T23: Reserved byte preserved ---");
        pulse_setrtgl;  // reset GETRTGL index to 0;
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h10, 16'h0000, 8'hAB);
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("reserved byte 0xAB returned", ccc_response_byte == 8'hAB);

        // T24: All-zero group entry (but valid)
        test_num = 24;
        $display("--- T24: All-zero entry ---");
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h00, 16'h0000, 8'h00);
        addr_val = 7'h00;
        @(posedge clk);
        #1;
        check("match on all-zero entry", group_match == 1'b1);
        check("group_targets == 0", group_targets == 16'h0000);

        // T25: GETRTGL without rst — index keeps advancing
        test_num = 25;
        $display("--- T25: GETRTGL index persists across calls ---");
        // Reset to known index
        @(negedge clk);
        rst_n = 1'b0;
        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);
        group_enable = 1'b1;
        group_count = 7'd2;
        group_table_0 = mk_entry(7'h01, 16'h0001, 8'hA0);
        group_table_1 = mk_entry(7'h02, 16'h0002, 8'hA1);
        // First GETRTGL — should return slot 0
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("first GETRTGL returns slot 0", ccc_response_byte == 8'hA0);
        // Second GETRTGL — should return slot 1
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("second GETRTGL returns slot 1", ccc_response_byte == 8'hA1);
        // Third GETRTGL — wraps back to slot 0
        pulse_getrtgl;
        @(posedge clk);
        #1;
        check("third GETRTGL wraps to slot 0", ccc_response_byte == 8'hA0);

        // T26: group_enable toggling
        test_num = 26;
        $display("--- T26: group_enable toggling ---");
        group_count = 7'd1;
        group_table_0 = mk_entry(7'h10, 16'h000F, 8'h00);
        addr_val = 7'h10;
        @(posedge clk);
        group_enable = 1'b1;
        @(posedge clk);
        #1;
        check("match with enable=1", group_match == 1'b1);
        @(negedge clk);
        group_enable = 1'b0;
        @(posedge clk);
        #1;
        check("no match with enable=0", group_match == 1'b0);
        @(negedge clk);
        group_enable = 1'b1;
        @(posedge clk);
        #1;
        check("match restored with enable=1", group_match == 1'b1);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
