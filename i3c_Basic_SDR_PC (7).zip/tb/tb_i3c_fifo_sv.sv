// =============================================================================
// tb_i3c_fifo_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_fifo (generic FIFO).
// 28 corner-case tests covering:
//   - empty→push→pop
//   - full→push (overflow)
//   - empty→pop (underflow)
//   - almost-full threshold
//   - almost-empty threshold
//   - wrap-around (write to full, read all, write again)
//   - data_count tracking
//   - flush
//   - simultaneous push+pop
//   - push then immediate pop
//   - reset during push
// =============================================================================

module tb_i3c_fifo_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic             wr_en = 1'b0;
    logic [31:0]      wr_data = 32'h0;
    logic             rd_en = 1'b0;
    logic [31:0]      rd_data;
    logic             empty;
    logic             full;
    logic             almost_full;
    logic             almost_empty;
    logic [4:0]       data_count;
    logic             overflow;
    logic             underflow;
    logic             flush = 1'b0;

    // DEPTH=16, AFULL_TH=14, AEMPTY_TH=1
    i3c_fifo #(
        .WIDTH     (32),
        .DEPTH     (16),
        .AFULL_TH  (14),
        .AEMPTY_TH (1),
        .REG_OUT   (1)
    ) u_dut (
        .clk          (clk),
        .rst_n        (rst_n),
        .wr_en        (wr_en),
        .wr_data      (wr_data),
        .rd_en        (rd_en),
        .rd_data      (rd_data),
        .empty        (empty),
        .full         (full),
        .almost_full  (almost_full),
        .almost_empty (almost_empty),
        .data_count   (data_count),
        .overflow     (overflow),
        .underflow    (underflow),
        .flush        (flush)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    task push;
        input [31:0] data;
        begin
            @(negedge clk);
            wr_en = 1'b1;
            wr_data = data;
            @(negedge clk);
            wr_en = 1'b0;
        end
    endtask

    task pop;
        begin
            @(negedge clk);
            rd_en = 1'b1;
            @(negedge clk);
            rd_en = 1'b0;
        end
    endtask

    task do_flush;
        begin
            @(negedge clk);
            flush = 1'b1;
            @(negedge clk);
            flush = 1'b0;
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_fifo_sv.vcd");
        $dumpvars(0, tb_i3c_fifo_sv);

        rst_n = 1'b0;
        wr_en = 1'b0;
        rd_en = 1'b0;
        flush = 1'b0;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C FIFO Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state
        test_num = 1;
        $display("--- T1: Reset state ---");
        check("empty == 1 after reset", empty == 1'b1);
        check("full == 0 after reset", full == 1'b0);
        check("data_count == 0 after reset", data_count == 5'd0);
        check("overflow == 0 after reset", overflow == 1'b0);
        check("underflow == 0 after reset", underflow == 1'b0);

        // T2: empty → pop (underflow)
        test_num = 2;
        $display("--- T2: Pop from empty (underflow) ---");
        pop;
        @(posedge clk);
        check("underflow == 1 after pop from empty", underflow == 1'b1);
        check("empty still == 1", empty == 1'b1);

        // T3: Push one item, check not empty
        test_num = 3;
        $display("--- T3: Push one item ---");
        push(32'hDEADBEEF);
        @(posedge clk);
        check("empty == 0 after push", empty == 1'b0);
        check("data_count == 1", data_count == 5'd1);

        // T4: Pop the item, check value
        test_num = 4;
        $display("--- T4: Pop item ---");
        pop;
        @(posedge clk);
        @(posedge clk);  // REG_OUT adds latency
        check("rd_data == 0xDEADBEEF", rd_data == 32'hDEADBEEF);
        check("empty == 1 after pop", empty == 1'b1);

        // T5: Push 16 items (fill to full)
        test_num = 5;
        $display("--- T5: Fill to full ---");
        begin : fill_loop
            integer i;
            for (i = 0; i < 16; i = i + 1) begin
                push(32'h1000_0000 + i);
            end
        end
        @(posedge clk);
        check("full == 1 after 16 pushes", full == 1'b1);
        check("data_count == 16", data_count == 5'd16);

        // T6: Push when full (overflow)
        test_num = 6;
        $display("--- T6: Push when full (overflow) ---");
        push(32'hFFFF_FFFF);
        @(posedge clk);
        check("overflow == 1 after push when full", overflow == 1'b1);
        check("data_count still == 16", data_count == 5'd16);

        // T7: Almost-full threshold (14)
        test_num = 7;
        $display("--- T7: Almost-full threshold ---");
        // Pop 2 to bring count to 14
        pop;
        pop;
        @(posedge clk);
        check("almost_full == 1 at count=14", almost_full == 1'b1);
        check("full == 0 at count=14", full == 1'b0);

        // T8: Almost-empty threshold (1)
        test_num = 8;
        $display("--- T8: Almost-empty threshold ---");
        // Pop down to 1 item
        begin : drain_loop
            integer i;
            for (i = 0; i < 13; i = i + 1) pop;
        end
        @(posedge clk);
        check("almost_empty == 1 at count<=1", almost_empty == 1'b1);
        check("empty == 0 (1 item left)", empty == 1'b0);

        // T9: Pop last item, almost_empty stays true, then empty
        test_num = 9;
        $display("--- T9: Pop last item ---");
        pop;
        @(posedge clk);
        check("empty == 1 after last pop", empty == 1'b1);
        check("almost_empty == 1 (count=0 <= 1)", almost_empty == 1'b1);

        // T10: Wrap-around (write to full, read all, write again)
        test_num = 10;
        $display("--- T10: Wrap-around ---");
        do_flush;
        @(posedge clk);
        // Fill
        begin : wrap_fill
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hA000_0000 + i);
        end
        @(posedge clk);
        check("full after first fill", full == 1'b1);
        // Drain
        begin : wrap_drain
            integer i;
            for (i = 0; i < 16; i = i + 1) pop;
        end
        @(posedge clk);
        check("empty after drain", empty == 1'b1);
        // Fill again
        begin : wrap_refill
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hB000_0000 + i);
        end
        @(posedge clk);
        check("full after second fill (wrap)", full == 1'b1);
        check("data_count == 16", data_count == 5'd16);

        // T11: Data integrity after wrap-around
        test_num = 11;
        $display("--- T11: Data integrity after wrap ---");
        pop;
        @(posedge clk);
        @(posedge clk);
        check("rd_data == 0xB0000000 (first written)", rd_data == 32'hB000_0000);

        // T12: data_count tracking
        test_num = 12;
        $display("--- T12: data_count tracking ---");
        do_flush;
        @(posedge clk);
        check("count == 0 after flush", data_count == 5'd0);
        push(32'h1);
        @(posedge clk);
        check("count == 1 after 1 push", data_count == 5'd1);
        push(32'h2);
        push(32'h3);
        @(posedge clk);
        check("count == 3 after 3 pushes", data_count == 5'd3);
        pop;
        @(posedge clk);
        check("count == 2 after 1 pop", data_count == 5'd2);

        // T13: Flush clears FIFO
        test_num = 13;
        $display("--- T13: Flush ---");
        // Fill with some items
        push(32'h11);
        push(32'h22);
        push(32'h33);
        @(posedge clk);
        check("count == 5 before flush", data_count == 5'd5);
        do_flush;
        @(posedge clk);
        check("count == 0 after flush", data_count == 5'd0);
        check("empty == 1 after flush", empty == 1'b1);

        // T14: Flush does NOT clear sticky overflow
        test_num = 14;
        $display("--- T14: Flush keeps sticky overflow ---");
        // First fill to full and overflow
        begin : t14_fill
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hF000_0000 + i);
        end
        @(posedge clk);
        push(32'hBAD);
        @(posedge clk);
        check("overflow set", overflow == 1'b1);
        do_flush;
        @(posedge clk);
        check("overflow still set after flush (sticky)", overflow == 1'b1);
        check("empty == 1 after flush", empty == 1'b1);

        // T15: Reset clears sticky flags
        test_num = 15;
        $display("--- T15: Reset clears sticky ---");
        @(negedge clk);
        rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("overflow cleared by reset", overflow == 1'b0);
        check("underflow cleared by reset", underflow == 1'b0);
        check("empty after reset", empty == 1'b1);

        // T16: Simultaneous push + pop (same cycle)
        test_num = 16;
        $display("--- T16: Simultaneous push + pop ---");
        // Pre-fill with 2 items
        push(32'hAAAA);
        push(32'hBBBB);
        @(posedge clk);
        check("count == 2 before simultaneous", data_count == 5'd2);
        // Simultaneous push + pop
        @(negedge clk);
        wr_en = 1'b1;
        wr_data = 32'hCCCC;
        rd_en = 1'b1;
        @(negedge clk);
        wr_en = 1'b0;
        rd_en = 1'b0;
        @(posedge clk);
        check("count stays at 2 after simultaneous push+pop", data_count == 5'd2);

        // T17: Push then immediate pop (back-to-back)
        test_num = 17;
        $display("--- T17: Push then immediate pop ---");
        do_flush;
        @(posedge clk);
        push(32'h1234);
        @(posedge clk);
        pop;
        @(posedge clk);
        @(posedge clk);  // REG_OUT latency
        check("rd_data == 0x1234", rd_data == 32'h1234);

        // T18: Reset during push
        test_num = 18;
        $display("--- T18: Reset during push ---");
        push(32'h5678);
        @(negedge clk);
        wr_en = 1'b1;
        wr_data = 32'h9ABC;
        rst_n = 1'b0;  // assert reset mid-push
        @(negedge clk);
        wr_en = 1'b0;
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("empty == 1 after reset during push", empty == 1'b1);
        check("data_count == 0", data_count == 5'd0);

        // T19: Reset during pop
        test_num = 19;
        $display("--- T19: Reset during pop ---");
        push(32'h1111);
        push(32'h2222);
        @(posedge clk);
        @(negedge clk);
        rd_en = 1'b1;
        rst_n = 1'b0;
        @(negedge clk);
        rd_en = 1'b0;
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        check("FIFO empty after reset during pop", empty == 1'b1);

        // T20: Push all unique values, pop and verify order
        test_num = 20;
        $display("--- T20: Push/pop order verification ---");
        do_flush;
        @(posedge clk);
        begin : order_loop
            integer i;
            integer ok;
            ok = 1;
            // Push 4 values
            for (i = 0; i < 4; i = i + 1) push(32'hD000_0000 + i);
            @(posedge clk);
            // Pop and check
            for (i = 0; i < 4; i = i + 1) begin
                pop;
                @(posedge clk);
                @(posedge clk);  // REG_OUT latency
                if (rd_data !== 32'hD000_0000 + i) begin
                    ok = 0;
                    $display("    pop %0d: got 0x%08x, exp 0x%08x", i, rd_data, 32'hD000_0000 + i);
                end
            end
            check("FIFO order preserved (FIFO)", ok == 1);
        end

        // T21: Underflow sticky flag
        test_num = 21;
        $display("--- T21: Underflow sticky ---");
        do_flush;
        @(posedge clk);
        pop;  // empty pop
        @(posedge clk);
        check("underflow set", underflow == 1'b1);
        // Push and pop validly
        push(32'h1);
        @(posedge clk);
        pop;
        @(posedge clk);
        check("underflow still set (sticky)", underflow == 1'b1);

        // T22: Multiple overflows
        test_num = 22;
        $display("--- T22: Multiple overflows ---");
        @(negedge clk);
        rst_n = 1'b0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);
        begin : fill2
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hA + i);
        end
        @(posedge clk);
        push(32'hBAD1);
        @(posedge clk);
        push(32'hBAD2);
        @(posedge clk);
        push(32'hBAD3);
        @(posedge clk);
        check("overflow set after multiple overflow pushes", overflow == 1'b1);
        check("count still == 16", data_count == 5'd16);

        // T23: Almost-full threshold boundary
        test_num = 23;
        $display("--- T23: Almost-full boundary ---");
        // Pop 2 items to bring count to 14
        pop;
        @(posedge clk);
        pop;
        @(posedge clk);
        check("almost_full == 1 at count=14", almost_full == 1'b1);
        pop;
        @(posedge clk);
        check("almost_full == 0 at count=13", almost_full == 1'b0);

        // T24: Almost-empty threshold boundary
        test_num = 24;
        $display("--- T24: Almost-empty boundary ---");
        // Drain to 0
        begin : drain2
            integer i;
            for (i = 0; i < 13; i = i + 1) pop;
        end
        @(posedge clk);
        check("empty == 1 (count=0)", empty == 1'b1);
        check("almost_empty == 1 (count<=1)", almost_empty == 1'b1);
        push(32'h1);
        @(posedge clk);
        check("almost_empty == 1 at count=1", almost_empty == 1'b1);
        push(32'h2);
        @(posedge clk);
        check("almost_empty == 0 at count=2", almost_empty == 1'b0);

        // T25: Full then flush then fill (rapid)
        test_num = 25;
        $display("--- T25: Full-flush-fill rapid ---");
        do_flush;
        @(posedge clk);
        begin : t25_loop
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hC000_0000 + i);
        end
        @(posedge clk);
        check("full after rapid fill", full == 1'b1);
        do_flush;
        @(posedge clk);
        check("empty after flush", empty == 1'b1);
        begin : t25_refill
            integer i;
            for (i = 0; i < 16; i = i + 1) push(32'hD000_0000 + i);
        end
        @(posedge clk);
        check("full after rapid refill", full == 1'b1);

        // T26: Multiple push without pop (stress fill)
        test_num = 26;
        $display("--- T26: Stress fill ---");
        do_flush;
        @(posedge clk);
        begin : t26_loop
            integer i;
            for (i = 0; i < 100; i = i + 1) begin
                if (!full) push(32'hE000_0000 + i);
            end
        end
        @(posedge clk);
        check("FIFO full after stress fill", full == 1'b1);
        check("count == 16", data_count == 5'd16);

        // T27: Continuous pop until empty (stress drain)
        test_num = 27;
        $display("--- T27: Stress drain ---");
        begin : t27_loop
            integer i;
            for (i = 0; i < 100; i = i + 1) begin
                if (!empty) pop;
            end
        end
        @(posedge clk);
        check("FIFO empty after stress drain", empty == 1'b1);
        check("count == 0", data_count == 5'd0);

        // T28: Push + pop simultaneously when empty (count stays at 0)
        test_num = 28;
        $display("--- T28: Simultaneous push+pop when empty ---");
        do_flush;
        @(posedge clk);
        @(negedge clk);
        wr_en = 1'b1;
        wr_data = 32'hFEED;
        rd_en = 1'b1;
        @(negedge clk);
        wr_en = 1'b0;
        rd_en = 1'b0;
        @(posedge clk);
        // Pop on empty -> underflow, but push succeeds
        check("underflow set (pop on empty)", underflow == 1'b1);
        check("count == 0 or 1 (push canceled by underflow?)", data_count <= 5'd1);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
