// =============================================================================
// tb_i3c_wake_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_wake_detector.
// 22 corner-case tests covering:
//   - START wake, SCL edge wake
//   - both wake sources simultaneously
//   - wake during sleep, wake during active
//   - wake clear via W1C
//   - wake priority (START > SCL)
//   - wake with very short SCL pulse
//   - wake with very long SCL low
//   - wake during reset
// =============================================================================

module tb_i3c_wake_sv;

    logic        clk_aon = 1'b0;
    logic        rst_aon_n = 1'b0;
    always #50000 clk_aon = ~clk_aon;  // slow 32 kHz-style clock (50ns half)

    logic        sda_raw = 1'b1;
    logic        scl_raw = 1'b1;
    logic        wake_en = 1'b0;
    logic        wake_start_en = 1'b0;
    logic        wake_scl_en = 1'b0;
    logic        wake_irq;
    logic        wake_src_start;
    logic        wake_src_scl;
    logic        wake_clear = 1'b0;

    i3c_wake_detector u_dut (
        .clk_aon        (clk_aon),
        .rst_aon_n      (rst_aon_n),
        .sda_raw        (sda_raw),
        .scl_raw        (scl_raw),
        .wake_en        (wake_en),
        .wake_start_en  (wake_start_en),
        .wake_scl_en    (wake_scl_en),
        .wake_irq       (wake_irq),
        .wake_src_start (wake_src_start),
        .wake_src_scl   (wake_src_scl),
        .wake_clear     (wake_clear)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Generate a START condition (SDA falling while SCL high)
    task gen_start;
        begin
            @(negedge clk_aon);
            sda_raw = 1'b1;
            scl_raw = 1'b1;
            @(negedge clk_aon);
            @(negedge clk_aon);
            sda_raw = 1'b0;  // SDA falls while SCL high
            @(negedge clk_aon);
            @(negedge clk_aon);
            sda_raw = 1'b1;  // back to idle
        end
    endtask

    // Generate SCL toggle (rising/falling edges)
    task gen_scl_toggle;
        input integer n;
        integer i;
        begin
            @(negedge clk_aon);
            scl_raw = 1'b1;
            for (i = 0; i < n; i = i + 1) begin
                @(negedge clk_aon);
                scl_raw = 1'b0;
                @(negedge clk_aon);
                scl_raw = 1'b1;
            end
        end
    endtask

    task do_clear;
        begin
            @(negedge clk_aon);
            wake_clear = 1'b1;
            @(negedge clk_aon);
            wake_clear = 1'b0;
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i3c_wake_sv.vcd");
        $dumpvars(0, tb_i3c_wake_sv);

        rst_aon_n = 1'b0;
        sda_raw = 1'b1;
        scl_raw = 1'b1;
        wake_en = 1'b0;
        wake_start_en = 1'b0;
        wake_scl_en = 1'b0;
        wake_clear = 1'b0;
        repeat (5) @(posedge clk_aon);
        @(negedge clk_aon);
        rst_aon_n = 1'b1;
        repeat (5) @(posedge clk_aon);

        $display("");
        $display("============================================================");
        $display("I3C Wake Detector Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state
        test_num = 1;
        $display("--- T1: Reset state ---");
        repeat (3) @(posedge clk_aon);  // settle
        check("wake_irq == 0 after reset", wake_irq == 1'b0);
        check("wake_src_start == 0 after reset", wake_src_start == 1'b0);
        check("wake_src_scl == 0 after reset", wake_src_scl == 1'b0);

        // T2: wake_en=0 — no wake on START
        test_num = 2;
        $display("--- T2: wake_en=0 (START ignored) ---");
        wake_en = 1'b0;
        wake_start_en = 1'b1;
        gen_start;
        repeat (10) @(posedge clk_aon);
        #1;
        check("wake_irq == 0 when wake_en=0", wake_irq == 1'b0);

        // T3: START wake detected
        test_num = 3;
        $display("--- T3: START wake ---");
        wake_en = 1'b1;
        wake_start_en = 1'b1;
        wake_scl_en = 1'b0;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 1 after START", wake_irq == 1'b1);
        check("wake_src_start == 1", wake_src_start == 1'b1);
        check("wake_src_scl == 0", wake_src_scl == 1'b0);
        do_clear;

        // T4: SCL edge wake detected (rising edge)
        test_num = 4;
        $display("--- T4: SCL edge wake (rising) ---");
        wake_start_en = 1'b0;
        wake_scl_en = 1'b1;
        gen_scl_toggle(1);
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 1 after SCL edge", wake_irq == 1'b1);
        check("wake_src_scl == 1", wake_src_scl == 1'b1);
        check("wake_src_start == 0", wake_src_start == 1'b0);
        do_clear;

        // T5: SCL falling edge also triggers wake
        test_num = 5;
        $display("--- T5: SCL falling edge wake ---");
        do_clear;
        repeat (5) @(posedge clk_aon);
        @(negedge clk_aon);
        scl_raw = 1'b1;
        repeat (3) @(negedge clk_aon);
        scl_raw = 1'b0;  // falling edge
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 1 after SCL falling edge", wake_irq == 1'b1);
        do_clear;
        scl_raw = 1'b1;
        repeat (3) @(posedge clk_aon);

        // T6: wake_start_en=0 — START ignored
        test_num = 6;
        $display("--- T6: wake_start_en=0 ---");
        do_clear;
        wake_en = 1'b1;
        wake_start_en = 1'b0;
        wake_scl_en = 1'b0;
        repeat (3) @(posedge clk_aon);
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 0 with start_en=0", wake_irq == 1'b0);

        // T7: wake_scl_en=0 — SCL edge ignored
        test_num = 7;
        $display("--- T7: wake_scl_en=0 ---");
        do_clear;
        wake_scl_en = 1'b0;
        repeat (3) @(posedge clk_aon);
        gen_scl_toggle(2);
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 0 with scl_en=0", wake_irq == 1'b0);

        // T8: Both START and SCL enabled — START wins priority
        test_num = 8;
        $display("--- T8: START priority over SCL ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b1;
        gen_start;  // this also creates an SCL-related activity? No - SCL stays high
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 1", wake_irq == 1'b1);
        check("wake_src_start == 1 (priority)", wake_src_start == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T9: Both wake sources simultaneously (START + SCL)
        test_num = 9;
        $display("--- T9: Simultaneous START + SCL ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b1;
        @(negedge clk_aon);
        sda_raw = 1'b1;
        scl_raw = 1'b1;
        @(negedge clk_aon);
        @(negedge clk_aon);
        // SDA falls AND SCL falls simultaneously
        sda_raw = 1'b0;
        scl_raw = 1'b0;
        @(negedge clk_aon);
        @(negedge clk_aon);
        sda_raw = 1'b1;
        scl_raw = 1'b1;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake_irq == 1 (simultaneous)", wake_irq == 1'b1);
        // One of them should be set
        check("at least one source set", wake_src_start == 1'b1 || wake_src_scl == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T10: Wake during sleep (no clocks, but clk_aon is always on)
        test_num = 10;
        $display("--- T10: Wake during sleep ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b0;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake fires during sleep", wake_irq == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T11: Wake during active (already woken, fires again)
        test_num = 11;
        $display("--- T11: Wake during active ---");
        wake_start_en = 1'b1;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("first wake fires", wake_irq == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("second wake fires after clear", wake_irq == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T12: Very short SCL pulse (1 cycle low)
        test_num = 12;
        $display("--- T12: Very short SCL pulse ---");
        wake_scl_en = 1'b1;
        wake_start_en = 1'b0;
        @(negedge clk_aon);
        scl_raw = 1'b1;
        repeat (2) @(negedge clk_aon);
        scl_raw = 1'b0;
        @(negedge clk_aon);
        scl_raw = 1'b1;  // quick low pulse
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake fires on short SCL pulse", wake_irq == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T13: Very long SCL low
        test_num = 13;
        $display("--- T13: Very long SCL low ---");
        @(negedge clk_aon);
        scl_raw = 1'b0;
        repeat (50) @(posedge clk_aon);
        // Wake fires on the falling edge (already triggered)
        check("wake fires on long SCL low", wake_irq == 1'b1);
        do_clear;
        scl_raw = 1'b1;
        repeat (5) @(posedge clk_aon);

        // T14: Wake during reset
        test_num = 14;
        $display("--- T14: Wake during reset ---");
        @(negedge clk_aon);
        rst_aon_n = 1'b0;
        wake_start_en = 1'b1;
        gen_start;
        repeat (5) @(posedge clk_aon);
        rst_aon_n = 1'b1;
        repeat (5) @(posedge clk_aon);
        #1;
        check("wake_irq == 0 after reset during wake attempt", wake_irq == 1'b0);

        // T15: Multiple SCL toggles in succession
        test_num = 15;
        $display("--- T15: Multiple SCL toggles ---");
        wake_scl_en = 1'b1;
        wake_start_en = 1'b0;
        gen_scl_toggle(5);
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake fires on multiple SCL toggles", wake_irq == 1'b1);
        do_clear;
        repeat (5) @(posedge clk_aon);

        // T16: wake_clear pulse clears all status
        test_num = 16;
        $display("--- T16: wake_clear clears status ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b1;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake set before clear", wake_irq == 1'b1);
        do_clear;
        repeat (3) @(posedge clk_aon);
        #1;
        check("wake_irq cleared", wake_irq == 1'b0);
        check("wake_src_start cleared", wake_src_start == 1'b0);
        check("wake_src_scl cleared", wake_src_scl == 1'b0);

        // T17: Sticky wake (stays set until cleared)
        test_num = 17;
        $display("--- T17: Sticky wake ---");
        wake_start_en = 1'b1;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake set", wake_irq == 1'b1);
        repeat (20) @(posedge clk_aon);
        #1;
        check("wake still set (sticky)", wake_irq == 1'b1);
        do_clear;
        repeat (3) @(posedge clk_aon);
        #1;
        check("wake cleared", wake_irq == 1'b0);

        // T18: SDA low but SCL low — not a START (no wake)
        test_num = 18;
        $display("--- T18: SDA falls while SCL low ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b0;
        @(negedge clk_aon);
        sda_raw = 1'b1;
        scl_raw = 1'b0;  // SCL low
        repeat (2) @(negedge clk_aon);
        sda_raw = 1'b0;  // SDA falls but SCL low
        repeat (8) @(posedge clk_aon);
        #1;
        check("no wake when SDA falls with SCL low", wake_irq == 1'b0);
        sda_raw = 1'b1;
        scl_raw = 1'b1;
        repeat (3) @(posedge clk_aon);

        // T19: SDA rising edge while SCL high — not a START
        test_num = 19;
        $display("--- T19: SDA rises (STOP, not START) ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b0;
        // Drive SDA low while SCL is low (no START), then raise SCL, then
        // raise SDA (STOP). Verify no wake fires.
        @(negedge clk_aon);
        scl_raw = 1'b0;  // SCL low first
        sda_raw = 1'b0;  // SDA low while SCL low (no START)
        @(negedge clk_aon);
        scl_raw = 1'b1;  // SCL rises while SDA low
        repeat (3) @(negedge clk_aon);
        sda_raw = 1'b1;  // SDA rises while SCL high (STOP)
        repeat (8) @(posedge clk_aon);
        #1;
        check("no wake on SDA rising edge (STOP)", wake_irq == 1'b0);

        // T20: Multiple STARTs in rapid succession
        test_num = 20;
        $display("--- T20: Rapid START pulses ---");
        wake_start_en = 1'b1;
        gen_start;
        repeat (5) @(posedge clk_aon);
        gen_start;
        repeat (5) @(posedge clk_aon);
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("wake fires on rapid STARTs", wake_irq == 1'b1);
        do_clear;
        repeat (3) @(posedge clk_aon);

        // T21: Wake with both enables disabled (sub-enable test)
        test_num = 21;
        $display("--- T21: wake_en=1 but both sub-enables=0 ---");
        wake_en = 1'b1;
        wake_start_en = 1'b0;
        wake_scl_en = 1'b0;
        gen_start;
        repeat (8) @(posedge clk_aon);
        #1;
        check("no wake with both sub-enables off", wake_irq == 1'b0);
        gen_scl_toggle(2);
        repeat (8) @(posedge clk_aon);
        #1;
        check("still no wake with both sub-enables off", wake_irq == 1'b0);

        // T22: wake_clear while new wake event fires (set priority)
        test_num = 22;
        $display("--- T22: Set priority over clear ---");
        wake_start_en = 1'b1;
        wake_scl_en = 1'b1;
        // Pre-set a wake
        gen_start;
        repeat (5) @(posedge clk_aon);
        // Apply clear
        @(negedge clk_aon);
        wake_clear = 1'b1;
        @(negedge clk_aon);
        wake_clear = 1'b0;
        repeat (3) @(posedge clk_aon);
        #1;
        check("wake cleared by W1C", wake_irq == 1'b0);
        // Generate new wake and clear in same cycle
        @(negedge clk_aon);
        sda_raw = 1'b1;
        scl_raw = 1'b1;
        @(negedge clk_aon);
        @(negedge clk_aon);
        sda_raw = 1'b0;  // START condition
        wake_clear = 1'b1;  // clear same cycle
        @(negedge clk_aon);
        sda_raw = 1'b1;
        wake_clear = 1'b0;
        repeat (8) @(posedge clk_aon);
        // Per RTL, set has priority over clear
        check("set priority over clear (wake fires)", wake_irq == 1'b1 || wake_src_start == 1'b1);
        do_clear;

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
