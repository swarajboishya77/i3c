// =============================================================================
// i3c_sva_properties.sv
// -----------------------------------------------------------------------------
// SystemVerilog Assertions (SVA) for the I3C controller.
// Written as runtime-checkable always blocks (iverilog-compatible) that are
// also synthesizable as SVA assertions in formal tools.
//
// To convert to formal SVA: replace each `always @(posedge clk)` block with
// `property` + `assert property`. The logic is identical.
// =============================================================================

`ifndef I3C_SVA_PROPERTIES_SV
`define I3C_SVA_PROPERTIES_SV

module i3c_sva_properties (
    input  logic        clk,
    input  logic        rst_n,

    // FIFO interface
    input  logic        cmd_fifo_push,
    input  logic        cmd_fifo_full,
    input  logic        cmd_fifo_empty,
    input  logic        wr_fifo_push,
    input  logic        wr_fifo_full,
    input  logic        rd_fifo_pop,
    input  logic        rd_fifo_empty,
    input  logic        resp_fifo_push,
    input  logic        resp_fifo_pop,
    input  logic        resp_fifo_empty,
    input  logic [31:0] resp_fifo_pop_data,

    // FSM state
    input  logic [4:0]  ctrl_state,
    input  logic        controller_idle,
    input  logic        controller_busy,

    // Response word fields
    input  logic [7:0]  resp_code_r,
    input  logic        resp_nack_r,
    input  logic        resp_timeout_r,

    // Bus signals
    input  logic        sda,
    input  logic        scl,

    // T-bit parity (from byte_serdes_i3c)
    input  logic [7:0]  byte_tx_latched_q,
    input  logic        parity_calc,
    input  logic        t_bit_sampled_r
);

    // =========================================================================
    // P1: FIFO protocol — never push when full
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && cmd_fifo_push && cmd_fifo_full)
            $error("SVA FAIL: CMD FIFO push asserted while full");
        if (rst_n && wr_fifo_push && wr_fifo_full)
            $error("SVA FAIL: WR FIFO push asserted while full");
    end

    // =========================================================================
    // P2: FIFO protocol — never pop when empty
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && rd_fifo_pop && rd_fifo_empty)
            $error("SVA FAIL: RD FIFO pop asserted while empty");
        if (rst_n && resp_fifo_pop && resp_fifo_empty)
            $error("SVA FAIL: RESP FIFO pop asserted while empty");
    end

    // =========================================================================
    // P3: Response word format — NACK bit at [17], TIMEOUT at [18], code at [7:0]
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && resp_fifo_push) begin
            if (resp_fifo_pop_data[17] !== resp_nack_r)
                $error("SVA FAIL: RESP NACK bit mismatch");
            if (resp_fifo_pop_data[18] !== resp_timeout_r)
                $error("SVA FAIL: RESP TIMEOUT bit mismatch");
            if (resp_fifo_pop_data[7:0] !== resp_code_r)
                $error("SVA FAIL: RESP code field mismatch");
        end
    end

    // =========================================================================
    // P4: T-bit parity correctness (ODD parity per MIPI spec §4.3.2.3.3)
    // T-bit = ~(^byte[7:0]) = XOR(byte, 1) = odd parity
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && (parity_calc !== ~(^byte_tx_latched_q)))
            $error("SVA FAIL: T-bit parity calc mismatch");
    end

    // =========================================================================
    // P5: FSM state — controller_idle and controller_busy are mutually exclusive
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && controller_idle && controller_busy)
            $error("SVA FAIL: controller_idle and controller_busy both asserted");
    end

    // =========================================================================
    // P6: SCL/SDA — never both driven low simultaneously by controller
    //     (would indicate bus contention) — requires oe signals, skipped
    // =========================================================================

    // =========================================================================
    // P9: resp_code_r must be a valid enum value (not X) when resp_fifo_push
    // =========================================================================
    always @(posedge clk) begin
        if (rst_n && resp_fifo_push) begin
            if (!(resp_code_r == 8'h00 ||  // SUCCESS
                  resp_code_r == 8'h01 ||  // NACK_ADDR
                  resp_code_r == 8'h02 ||  // NACK_DATA
                  resp_code_r == 8'h04 ||  // TIMEOUT
                  resp_code_r == 8'h06 ||  // FIFO_UNDERFLOW
                  resp_code_r == 8'h07 ||  // FIFO_OVERFLOW
                  resp_code_r == 8'h08 ||  // INVALID_CMD
                  resp_code_r == 8'h09))   // BUSY
                $error("SVA FAIL: resp_code_r invalid value 0x%02x", resp_code_r);
        end
    end

    // =========================================================================
    // P10: resp_xfer_len_r must not exceed 255 (8-bit field)
    //     (checked via resp_fifo_pop_data[15:8] — already truncated)
    // =========================================================================

endmodule

`endif // I3C_SVA_PROPERTIES_SV
