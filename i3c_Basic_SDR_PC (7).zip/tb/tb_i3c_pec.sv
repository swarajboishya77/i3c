// =============================================================================
// tb_i3c_pec.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i3c_pec (PEC CRC-8 generator/checker).
// Polynomial: 0x07 (CRC-8/SMBus). Same polynomial used by MIPI I3C PEC.
// 28 corner-case tests covering:
//   - Reset values and reset behavior
//   - Zero-byte PEC
//   - All-FF PEC
//   - Alternating-bit patterns
//   - Max-length (255 bytes) accumulation
//   - PEC verify with 1-bit error
//   - PEC verify with all-bits-wrong
//   - Multi-byte sequences with known CRC
//   - PEC append then verify roundtrip
//   - PEC disable mid-stream
//   - Boundary value tests
// =============================================================================

module tb_i3c_pec;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;  // 5 ns clock

    logic        pec_en = 1'b0;
    logic        pec_reset = 1'b0;
    logic        byte_valid = 1'b0;
    logic [7:0]  byte_in = 8'h00;
    logic [7:0]  crc_out;
    logic        pec_byte_rx = 1'b0;
    logic [7:0]  pec_rx_value = 8'h00;
    logic        pec_error;
    logic        pec_append = 1'b0;
    logic        pec_tx_valid;
    logic [7:0]  pec_tx_value;

    i3c_pec u_dut (
        .clk          (clk),
        .rst_n        (rst_n),
        .pec_en       (pec_en),
        .pec_reset    (pec_reset),
        .byte_valid   (byte_valid),
        .byte_in      (byte_in),
        .crc_out      (crc_out),
        .pec_byte_rx  (pec_byte_rx),
        .pec_rx_value (pec_rx_value),
        .pec_error    (pec_error),
        .pec_append   (pec_append),
        .pec_tx_valid (pec_tx_valid),
        .pec_tx_value (pec_tx_value)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;
    logic [7:0] t22_crc1;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // Reference CRC-8/SMBus model (polynomial 0x07)
    function automatic logic [7:0] crc8_ref(input logic [7:0] crc_in, input logic [7:0] data);
        logic [7:0] crc;
        logic [3:0] i;
        begin
            crc = crc_in ^ data;
            for (i = 4'd0; i < 4'd8; i++) begin
                if (crc[7])
                    crc = (crc << 1) ^ 8'h07;
                else
                    crc = (crc << 1);
            end
            return crc;
        end
    endfunction

    // Feed one byte into the PEC engine
    task feed_byte;
        input [7:0] data;
        begin
            @(negedge clk);
            byte_valid = 1'b1;
            byte_in    = data;
            @(negedge clk);
            byte_valid = 1'b0;
        end
    endtask

    // Pulse pec_reset
    task do_reset_crc;
        begin
            @(negedge clk);
            pec_reset = 1'b1;
            @(negedge clk);
            pec_reset = 1'b0;
        end
    endtask

    // Pulse pec_append (one cycle)
    task do_append;
        begin
            @(negedge clk);
            pec_append = 1'b1;
            @(negedge clk);
            pec_append = 1'b0;
            @(posedge clk);
        end
    endtask

    // Send PEC byte for checking (with given value)
    task send_pec_rx;
        input [7:0] val;
        begin
            @(negedge clk);
            pec_byte_rx  = 1'b1;
            pec_rx_value = val;
            @(negedge clk);
            pec_byte_rx  = 1'b0;
            @(posedge clk);
        end
    endtask

    // Helper: feed 4 bytes and return reference CRC
    function automatic logic [7:0] crc_seq(input logic [7:0] seed,
                                            input logic [7:0] b0,
                                            input logic [7:0] b1,
                                            input logic [7:0] b2,
                                            input logic [7:0] b3);
        logic [7:0] c;
        c = seed;
        c = crc8_ref(c, b0);
        c = crc8_ref(c, b1);
        c = crc8_ref(c, b2);
        c = crc8_ref(c, b3);
        return c;
    endfunction

    initial begin
        $dumpfile("/tmp/tb_i3c_pec.vcd");
        $dumpvars(0, tb_i3c_pec);

        rst_n = 1'b0;
        pec_en = 1'b0;
        pec_reset = 1'b0;
        byte_valid = 1'b0;
        byte_in = 8'h00;
        pec_byte_rx = 1'b0;
        pec_rx_value = 8'h00;
        pec_append = 1'b0;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I3C PEC (CRC-8) Comprehensive Testbench");
        $display("============================================================");

        // T1: CRC resets to 0 after reset
        test_num = 1;
        $display("--- T1: CRC resets to 0 after reset ---");
        pec_en = 1'b0;
        repeat (2) @(posedge clk);
        check("crc_out == 0x00 after reset", crc_out == 8'h00);

        // T2: Single byte 0x00 -> CRC
        test_num = 2;
        $display("--- T2: Single byte 0x00 ---");
        pec_en = 1'b1;
        do_reset_crc;
        feed_byte(8'h00);
        @(posedge clk);
        check("crc(0x00) matches reference", crc_out == crc8_ref(8'h00, 8'h00));

        // T3: Single byte 0xAA
        test_num = 3;
        $display("--- T3: Single byte 0xAA ---");
        do_reset_crc;
        feed_byte(8'hAA);
        @(posedge clk);
        check("crc(0xAA) matches reference", crc_out == crc8_ref(8'h00, 8'hAA));

        // T4: Multi-byte sequence (3 bytes)
        test_num = 4;
        $display("--- T4: Multi-byte 0x01,0x02,0x03 ---");
        do_reset_crc;
        feed_byte(8'h01);
        @(posedge clk);
        check("crc after 0x01", crc_out == crc8_ref(8'h00, 8'h01));
        feed_byte(8'h02);
        @(posedge clk);
        check("crc after 0x01,0x02", crc_out == crc8_ref(crc8_ref(8'h00, 8'h01), 8'h02));
        feed_byte(8'h03);
        @(posedge clk);
        check("crc after 0x01,0x02,0x03 matches reference",
              crc_out == crc8_ref(crc8_ref(crc8_ref(8'h00, 8'h01), 8'h02), 8'h03));

        // T5: PEC append produces correct PEC byte
        test_num = 5;
        $display("--- T5: PEC append ---");
        do_reset_crc;
        feed_byte(8'h55);
        feed_byte(8'hAA);
        @(posedge clk);
        do_append;
        check("pec_tx_valid asserted", pec_tx_valid == 1'b1);
        check("pec_tx_value == crc_out",
              pec_tx_value == crc8_ref(crc8_ref(8'h00, 8'h55), 8'hAA));

        // T6: PEC check PASS
        test_num = 6;
        $display("--- T6: PEC check PASS ---");
        do_reset_crc;
        feed_byte(8'h10);
        feed_byte(8'h20);
        @(posedge clk);
        send_pec_rx(crc8_ref(crc8_ref(8'h00, 8'h10), 8'h20));
        check("pec_error == 0 (matching PEC)", pec_error == 1'b0);

        // T7: PEC check FAIL
        test_num = 7;
        $display("--- T7: PEC check FAIL ---");
        do_reset_crc;
        feed_byte(8'h10);
        feed_byte(8'h20);
        @(posedge clk);
        send_pec_rx(crc8_ref(crc8_ref(8'h00, 8'h10), 8'h20) ^ 8'hFF);
        check("pec_error == 1 (mismatched PEC)", pec_error == 1'b1);

        // T8: All 256 single-byte CRC values match reference model
        test_num = 8;
        $display("--- T8: All 256 single-byte CRC values ---");
        begin : all_256_loop
            logic [3:0] i;
            logic [7:0] exp_crc;
            integer all_match;
            all_match = 1;
            for (i = 0; i < 256; i = i + 1) begin
                do_reset_crc;
                feed_byte(i[7:0]);
                @(posedge clk);
                exp_crc = crc8_ref(8'h00, i[7:0]);
                if (crc_out != exp_crc) begin
                    all_match = 0;
                    $display("    MISMATCH at byte 0x%02x: got 0x%02x, exp 0x%02x",
                             i, crc_out, exp_crc);
                end
            end
            repeat (2) @(posedge clk);  // settle
            check("all 256 single-byte CRCs match reference", all_match == 1);
        end

        // T9: pec_en=0: CRC not updated (bypass)
        test_num = 9;
        $display("--- T9: pec_en=0 bypass ---");
        pec_en = 1'b0;
        do_reset_crc;
        feed_byte(8'hFF);
        @(posedge clk);
        check("crc unchanged when pec_en=0", crc_out == 8'h00);

        // T10: pec_reset pulse clears CRC to 0
        test_num = 10;
        $display("--- T10: pec_reset clears CRC ---");
        pec_en = 1'b1;
        do_reset_crc;
        feed_byte(8'h12);
        feed_byte(8'h34);
        @(posedge clk);
        check("crc non-zero before reset", crc_out != 8'h00);
        do_reset_crc;
        @(posedge clk);
        check("crc cleared after pec_reset", crc_out == 8'h00);

        // ----- NEW CORNER CASES BELOW -----

        // T11: Zero-byte PEC (no bytes fed, append immediately)
        test_num = 11;
        $display("--- T11: Zero-byte PEC (CRC of empty payload) ---");
        pec_en = 1'b1;
        do_reset_crc;
        @(posedge clk);
        check("crc_out == 0 after zero bytes", crc_out == 8'h00);
        do_append;
        check("zero-byte PEC append valid", pec_tx_valid == 1'b1);
        repeat (2) @(posedge clk);  // settle
        check("zero-byte PEC value == 0x00", pec_tx_value == 8'h00);

        // T12: All-FF PEC (CRC of single 0xFF byte)
        test_num = 12;
        $display("--- T12: All-FF PEC (single 0xFF byte) ---");
        do_reset_crc;
        feed_byte(8'hFF);
        @(posedge clk);
        check("crc(0xFF) matches reference", crc_out == crc8_ref(8'h00, 8'hFF));

        // T13: Alternating bits pattern 0xAA,0x55,0xAA,0x55
        test_num = 13;
        $display("--- T13: Alternating bits 0xAA/0x55/0xAA/0x55 ---");
        do_reset_crc;
        feed_byte(8'hAA);
        feed_byte(8'h55);
        feed_byte(8'hAA);
        feed_byte(8'h55);
        @(posedge clk);
        check("alternating-bits CRC matches reference",
              crc_out == crc_seq(8'h00, 8'hAA, 8'h55, 8'hAA, 8'h55));

        // T14: Max-length 255-byte sequence accumulation
        test_num = 14;
        $display("--- T14: Max-length 255-byte sequence ---");
        begin : max_len_loop
            logic [3:0] i;
            logic [7:0] exp;
            exp = 8'h00;
            do_reset_crc;
            for (i = 0; i < 255; i = i + 1) begin
                feed_byte(i[7:0]);
                exp = crc8_ref(exp, i[7:0]);
            end
            @(posedge clk);
            check("255-byte CRC matches reference", crc_out == exp);
        end

        // T15: PEC verify with 1-bit error (toggle LSB of expected PEC)
        test_num = 15;
        $display("--- T15: PEC verify with 1-bit error ---");
        do_reset_crc;
        feed_byte(8'h42);
        feed_byte(8'h84);
        @(posedge clk);
        begin : t15_blk
            logic [7:0] expected_pec;
            expected_pec = crc8_ref(crc8_ref(8'h00, 8'h42), 8'h84);
            send_pec_rx(expected_pec ^ 8'h01);  // 1-bit error
            repeat (2) @(posedge clk);  // settle
            check("pec_error set on 1-bit error", pec_error == 1'b1);
        end

        // T16: PEC verify with all-bits-wrong (XOR with 0xFF)
        test_num = 16;
        $display("--- T16: PEC verify with all-bits-wrong ---");
        do_reset_crc;
        feed_byte(8'h99);
        feed_byte(8'h88);
        @(posedge clk);
        begin : t16_blk
            logic [7:0] expected_pec;
            expected_pec = crc8_ref(crc8_ref(8'h00, 8'h99), 8'h88);
            send_pec_rx(expected_pec ^ 8'hFF);
            repeat (2) @(posedge clk);  // settle
            check("pec_error set on all-bits-wrong", pec_error == 1'b1);
        end

        // T17: PEC append then verify roundtrip (no error)
        test_num = 17;
        $display("--- T17: PEC append then verify (roundtrip) ---");
        do_reset_crc;
        feed_byte(8'h30);
        feed_byte(8'h40);
        feed_byte(8'h50);
        @(posedge clk);
        do_append;
        check("append produces valid byte", pec_tx_valid == 1'b1);
        begin : t17_blk
            logic [7:0] computed_pec;
            computed_pec = pec_tx_value;
            // Receiver re-feeds the same bytes then verifies
            do_reset_crc;
            feed_byte(8'h30);
            feed_byte(8'h40);
            feed_byte(8'h50);
            @(posedge clk);
            send_pec_rx(computed_pec);
            check("roundtrip verify passes", pec_error == 1'b0);
        end

        // T18: PEC disable mid-stream (toggle pec_en after some bytes)
        test_num = 18;
        $display("--- T18: PEC disable mid-stream ---");
        do_reset_crc;
        pec_en = 1'b1;
        feed_byte(8'h11);
        @(posedge clk);
        begin : t18_blk
            logic [7:0] crc_after_1;
            crc_after_1 = crc_out;
            pec_en = 1'b0;          // disable mid-stream
            feed_byte(8'h22);
            feed_byte(8'h33);
            @(posedge clk);
            check("crc frozen after pec_en=0 mid-stream", crc_out == crc_after_1);
            pec_en = 1'b1;          // re-enable
            feed_byte(8'h44);
            @(posedge clk);
            check("crc continues correctly after re-enable",
                  crc_out == crc8_ref(crc8_ref(8'h00, 8'h11), 8'h44));
        end

        // T19: PEC append without any preceding byte (zero-byte append)
        test_num = 19;
        $display("--- T19: PEC append after only pec_reset ---");
        do_reset_crc;
        @(posedge clk);
        do_append;
        check("append valid after pec_reset", pec_tx_valid == 1'b1);
        check("append value == 0x00", pec_tx_value == 8'h00);

        // T20: pec_byte_rx without pec_en (should not set error)
        test_num = 20;
        $display("--- T20: PEC RX check disabled (pec_en=0) ---");
        pec_en = 1'b0;
        do_reset_crc;
        send_pec_rx(8'hFF);  // wrong value, but should be ignored
        repeat (2) @(posedge clk);  // settle
        check("pec_error stays 0 when pec_en=0", pec_error == 1'b0);
        pec_en = 1'b1;

        // T21: pec_append without pec_en (should not produce valid TX)
        test_num = 21;
        $display("--- T21: PEC append disabled (pec_en=0) ---");
        pec_en = 1'b0;
        do_reset_crc;
        do_append;
        repeat (2) @(posedge clk);  // settle
        check("pec_tx_valid stays 0 when pec_en=0", pec_tx_valid == 1'b0);
        pec_en = 1'b1;

        // T22: Consecutive pec_reset pulses (idempotent)
        test_num = 22;
        $display("--- T22: Consecutive pec_reset pulses ---");
        do_reset_crc;
        feed_byte(8'h77);
        @(posedge clk);
        check("crc non-zero before double reset", crc_out != 8'h00);
        do_reset_crc;
        t22_crc1 = crc_out;
        do_reset_crc;
        @(posedge clk);
        check("second pec_reset keeps CRC at 0", crc_out == t22_crc1 && crc_out == 8'h00);

        // T23: Known CRC value (CRC of "123456789" = 0xF4 per SMBus spec)
        // SMBus PEC of "123456789" ASCII = 0xF4
        test_num = 23;
        $display("--- T23: Known CRC of '123456789' (SMBus 0xF4) ---");
        do_reset_crc;
        feed_byte(8'h31);  // '1'
        feed_byte(8'h32);  // '2'
        feed_byte(8'h33);  // '3'
        feed_byte(8'h34);  // '4'
        feed_byte(8'h35);  // '5'
        feed_byte(8'h36);  // '6'
        feed_byte(8'h37);  // '7'
        feed_byte(8'h38);  // '8'
        feed_byte(8'h39);  // '9'
        @(posedge clk);
        check("CRC of '123456789' == 0xF4", crc_out == 8'hF4);

        // T24: byte_valid without pec_en (no effect)
        test_num = 24;
        $display("--- T24: byte_valid ignored when pec_en=0 ---");
        pec_en = 1'b0;
        do_reset_crc;
        feed_byte(8'hEE);
        feed_byte(8'hDD);
        @(posedge clk);
        check("crc stays 0 when pec_en=0 with valid bytes", crc_out == 8'h00);
        pec_en = 1'b1;

        // T25: pec_byte_rx while byte_valid also asserted (PEC RX takes priority)
        test_num = 25;
        $display("--- T25: pec_byte_rx and byte_valid simultaneously ---");
        do_reset_crc;
        feed_byte(8'h01);
        @(posedge clk);
        begin : t25_blk
            logic [7:0] crc_before;
            crc_before = crc_out;
            @(negedge clk);
            pec_byte_rx = 1'b1;
            pec_rx_value = crc_before;
            byte_valid = 1'b1;
            byte_in = 8'h02;
            @(negedge clk);
            pec_byte_rx = 1'b0;
            byte_valid = 1'b0;
            @(posedge clk);
            check("CRC unchanged when both rx/valid asserted", crc_out == crc_before);
            check("pec_error == 0 with matching PEC", pec_error == 1'b0);
        end

        // T26: pec_append while byte_valid asserted (append takes priority)
        test_num = 26;
        $display("--- T26: pec_append and byte_valid simultaneously ---");
        do_reset_crc;
        feed_byte(8'hCC);
        @(posedge clk);
        begin : t26_blk
            logic [7:0] crc_before;
            crc_before = crc_out;
            @(negedge clk);
            pec_append = 1'b1;
            byte_valid = 1'b1;
            byte_in = 8'hBB;
            @(negedge clk);
            pec_append = 1'b0;
            byte_valid = 1'b0;
            @(posedge clk);
            check("CRC unchanged when append+valid asserted", crc_out == crc_before);
            check("pec_tx_valid asserted", pec_tx_valid == 1'b1);
        end

        // T27: 256-byte max length sequence (one more than 255)
        test_num = 27;
        $display("--- T27: 256-byte sequence (max+1) ---");
        begin : t27_loop
            logic [3:0] i;
            logic [7:0] exp;
            exp = 8'h00;
            do_reset_crc;
            for (i = 0; i < 256; i = i + 1) begin
                feed_byte(i[7:0]);
                exp = crc8_ref(exp, i[7:0]);
            end
            @(posedge clk);
            check("256-byte CRC matches reference", crc_out == exp);
        end

        // T28: Multiple append pulses (each latches current CRC)
        test_num = 28;
        $display("--- T28: Multiple append pulses ---");
        do_reset_crc;
        feed_byte(8'hAA);
        @(posedge clk);
        do_append;
        begin : t28_blk
            logic [7:0] pec1;
            pec1 = pec_tx_value;
            feed_byte(8'hBB);
            @(posedge clk);
            do_append;
            check("second append produces different value", pec_tx_value != pec1);
            check("second append matches updated CRC",
                  pec_tx_value == crc8_ref(crc8_ref(8'h00, 8'hAA), 8'hBB));
        end

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
