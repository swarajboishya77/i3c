// =============================================================================
// tb_i2c_prescaler_sv.sv
// -----------------------------------------------------------------------------
// Comprehensive standalone testbench for i2c_prescaler.
// 22 corner-case tests covering:
//   - prescaler=0 (default Fm+)
//   - prescaler=1 (minimum)
//   - prescaler=125 (Fm)
//   - prescaler=499 (Std)
//   - prescaler=262143 (max cap)
//   - prescaler=262142 (just under cap)
//   - 50% duty cycle verification
//   - active flag
// =============================================================================

module tb_i2c_prescaler_sv;

    logic        clk = 1'b0;
    logic        rst_n = 1'b0;
    always #5000 clk = ~clk;

    logic [19:0] speed_prescaler = 20'd0;
    logic [17:0] i2c_scl_high_time;
    logic [17:0] i2c_scl_low_time;
    logic        prescaler_active;

    i2c_prescaler u_dut (
        .clk                (clk),
        .rst_n              (rst_n),
        .speed_prescaler    (speed_prescaler),
        .i2c_scl_high_time  (i2c_scl_high_time),
        .i2c_scl_low_time   (i2c_scl_low_time),
        .prescaler_active   (prescaler_active)
    );

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num   = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    initial begin
        $dumpfile("/tmp/tb_i2c_prescaler_sv.vcd");
        $dumpvars(0, tb_i2c_prescaler_sv);

        rst_n = 1'b0;
        speed_prescaler = 20'd0;
        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        $display("");
        $display("============================================================");
        $display("I2C Prescaler Comprehensive Testbench");
        $display("============================================================");

        // T1: Reset state — prescaler=0 -> default Fm+ (50 cycles)
        test_num = 1;
        $display("--- T1: prescaler=0 (default Fm+) ---");
        speed_prescaler = 20'd0;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 50 (default)", i2c_scl_high_time == 18'd50);
        check("i2c_scl_low_time == 50 (default)", i2c_scl_low_time == 18'd50);
        check("prescaler_active == 0 (not programmed)", prescaler_active == 1'b0);

        // T2: prescaler=1 (minimum)
        test_num = 2;
        $display("--- T2: prescaler=1 (minimum) ---");
        speed_prescaler = 20'd1;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 1", i2c_scl_high_time == 18'd1);
        check("i2c_scl_low_time == 1", i2c_scl_low_time == 18'd1);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T3: prescaler=50 (Fm+ speed)
        test_num = 3;
        $display("--- T3: prescaler=50 (Fm+) ---");
        speed_prescaler = 20'd50;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 50", i2c_scl_high_time == 18'd50);
        check("i2c_scl_low_time == 50", i2c_scl_low_time == 18'd50);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T4: prescaler=125 (Fm speed)
        test_num = 4;
        $display("--- T4: prescaler=125 (Fm 400kHz) ---");
        speed_prescaler = 20'd125;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 125", i2c_scl_high_time == 18'd125);
        check("i2c_scl_low_time == 125", i2c_scl_low_time == 18'd125);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T5: prescaler=499 (Std speed)
        test_num = 5;
        $display("--- T5: prescaler=499 (Std 100kHz) ---");
        speed_prescaler = 20'd499;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 499", i2c_scl_high_time == 18'd499);
        check("i2c_scl_low_time == 499", i2c_scl_low_time == 18'd499);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T6: prescaler=262143 (max cap = 18'h3FFFF)
        test_num = 6;
        $display("--- T6: prescaler=262143 (max cap) ---");
        speed_prescaler = 20'd262143;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 0x3FFFF (capped)", i2c_scl_high_time == 18'h3FFFF);
        check("i2c_scl_low_time == 0x3FFFF (capped)", i2c_scl_low_time == 18'h3FFFF);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T7: prescaler=262142 (just under cap)
        test_num = 7;
        $display("--- T7: prescaler=262142 (just under cap) ---");
        speed_prescaler = 20'd262142;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 262142 (not capped)", i2c_scl_high_time == 18'd262142);
        check("i2c_scl_low_time == 262142 (not capped)", i2c_scl_low_time == 18'd262142);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T8: prescaler=262144 (just over cap)
        test_num = 8;
        $display("--- T8: prescaler=262144 (just over cap) ---");
        speed_prescaler = 20'd262144;
        @(posedge clk);
        #1;
        check("i2c_scl_high_time == 0x3FFFF (capped)", i2c_scl_high_time == 18'h3FFFF);
        check("i2c_scl_low_time == 0x3FFFF (capped)", i2c_scl_low_time == 18'h3FFFF);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T9: 50% duty cycle (high == low for all values)
        test_num = 9;
        $display("--- T9: 50%% duty cycle ---");
        begin : t9_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 1; i < 100; i = i + 1) begin
                speed_prescaler = i;
                @(posedge clk);
                #1;
                if (i2c_scl_high_time !== i2c_scl_low_time) ok = 0;
            end
            check("50% duty cycle (high==low) for all values", ok == 1);
        end

        // T10: Active flag transitions correctly
        test_num = 10;
        $display("--- T10: Active flag ---");
        speed_prescaler = 20'd0;
        @(posedge clk);
        #1;
        check("active == 0 when prescaler=0", prescaler_active == 1'b0);
        speed_prescaler = 20'd1;
        @(posedge clk);
        #1;
        check("active == 1 when prescaler=1", prescaler_active == 1'b1);
        speed_prescaler = 20'd0;
        @(posedge clk);
        #1;
        check("active == 0 when prescaler back to 0", prescaler_active == 1'b0);

        // T11: Large prescaler values (1000, 5000, 10000)
        test_num = 11;
        $display("--- T11: Large prescaler values ---");
        speed_prescaler = 20'd1000;
        @(posedge clk);
        #1;
        check("prescaler=1000 -> high=1000", i2c_scl_high_time == 18'd1000);
        speed_prescaler = 20'd5000;
        @(posedge clk);
        #1;
        check("prescaler=5000 -> high=5000", i2c_scl_high_time == 18'd5000);
        speed_prescaler = 20'd10000;
        @(posedge clk);
        #1;
        check("prescaler=10000 -> high=10000", i2c_scl_high_time == 18'd10000);

        // T12: Boundary between 18-bit and beyond
        test_num = 12;
        $display("--- T12: 18-bit boundary ---");
        speed_prescaler = 20'd262143;  // 18'h3FFFF
        @(posedge clk);
        #1;
        check("262143 not capped", i2c_scl_high_time == 18'd262143);
        speed_prescaler = 20'd262144;  // over 18-bit
        @(posedge clk);
        #1;
        check("262144 capped", i2c_scl_high_time == 18'h3FFFF);

        // T13: Combinational output (changes immediately)
        test_num = 13;
        $display("--- T13: Combinational output ---");
        speed_prescaler = 20'd42;
        #1;  // no clk edge needed
        check("output updates combinationally", i2c_scl_high_time == 18'd42);
        speed_prescaler = 20'd99;
        #1;
        check("output updates again combinationally", i2c_scl_high_time == 18'd99);

        // T14: Reset doesn't change combinational output
        test_num = 14;
        $display("--- T14: Reset doesn't affect combinational output ---");
        speed_prescaler = 20'd77;
        @(negedge clk);
        rst_n = 1'b0;
        #1;
        check("output still 77 during reset", i2c_scl_high_time == 18'd77);
        @(negedge clk);
        rst_n = 1'b1;
        repeat (3) @(posedge clk);

        // T15: Maximum 20-bit value (1048575)
        test_num = 15;
        $display("--- T15: Maximum 20-bit value ---");
        speed_prescaler = 20'hFFFFF;  // 1048575
        @(posedge clk);
        #1;
        check("max 20-bit value capped", i2c_scl_high_time == 18'h3FFFF);
        check("prescaler_active == 1", prescaler_active == 1'b1);

        // T16: prescaler value 2
        test_num = 16;
        $display("--- T16: prescaler=2 ---");
        speed_prescaler = 20'd2;
        @(posedge clk);
        #1;
        check("prescaler=2 -> high=2", i2c_scl_high_time == 18'd2);
        check("prescaler=2 -> low=2", i2c_scl_low_time == 18'd2);

        // T17: prescaler value 100 (typical)
        test_num = 17;
        $display("--- T17: prescaler=100 ---");
        speed_prescaler = 20'd100;
        @(posedge clk);
        #1;
        check("prescaler=100 -> high=100", i2c_scl_high_time == 18'd100);

        // T18: Switching prescaler values rapidly
        test_num = 18;
        $display("--- T18: Rapid prescaler switching ---");
        begin : t18_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 1; i < 50; i = i + 1) begin
                speed_prescaler = i;
                #1;
                if (i2c_scl_high_time !== i[17:0]) ok = 0;
                if (i2c_scl_low_time !== i[17:0]) ok = 0;
            end
            check("rapid switching produces correct values", ok == 1);
        end

        // T19: Prescaler = 19'd0 + 1 bit pattern
        test_num = 19;
        $display("--- T19: Prescaler power-of-2 values ---");
        speed_prescaler = 20'd2;
        @(posedge clk);
        #1;
        check("prescaler=2", i2c_scl_high_time == 18'd2);
        speed_prescaler = 20'd4;
        @(posedge clk);
        #1;
        check("prescaler=4", i2c_scl_high_time == 18'd4);
        speed_prescaler = 20'd8;
        @(posedge clk);
        #1;
        check("prescaler=8", i2c_scl_high_time == 18'd8);
        speed_prescaler = 20'd16;
        @(posedge clk);
        #1;
        check("prescaler=16", i2c_scl_high_time == 18'd16);
        speed_prescaler = 20'd32;
        @(posedge clk);
        #1;
        check("prescaler=32", i2c_scl_high_time == 18'd32);
        speed_prescaler = 20'd64;
        @(posedge clk);
        #1;
        check("prescaler=64", i2c_scl_high_time == 18'd64);
        speed_prescaler = 20'd128;
        @(posedge clk);
        #1;
        check("prescaler=128", i2c_scl_high_time == 18'd128);
        speed_prescaler = 20'd256;
        @(posedge clk);
        #1;
        check("prescaler=256", i2c_scl_high_time == 18'd256);

        // T20: prescaler=1000 (Fm-ish slow)
        test_num = 20;
        $display("--- T20: prescaler=1000 ---");
        speed_prescaler = 20'd1000;
        @(posedge clk);
        #1;
        check("prescaler=1000", i2c_scl_high_time == 18'd1000);

        // T21: Toggle between 0 and a value repeatedly
        test_num = 21;
        $display("--- T21: Toggle 0 and 100 ---");
        begin : t21_loop
            integer i;
            integer ok;
            ok = 1;
            for (i = 0; i < 10; i = i + 1) begin
                speed_prescaler = (i[0]) ? 20'd100 : 20'd0;
                #1;
                if (i[0]) begin
                    if (i2c_scl_high_time !== 18'd100) ok = 0;
                    if (prescaler_active !== 1'b1) ok = 0;
                end else begin
                    if (i2c_scl_high_time !== 18'd50) ok = 0;
                    if (prescaler_active !== 1'b0) ok = 0;
                end
            end
            check("toggle between 0 and 100 works", ok == 1);
        end

        // T22: Verify default value exactly 50 (Fm+)
        test_num = 22;
        $display("--- T22: Default value exactly 50 ---");
        speed_prescaler = 20'd0;
        @(posedge clk);
        #1;
        check("default high == 50 (not 0 or other)", i2c_scl_high_time == 18'd50);
        check("default low == 50 (not 0 or other)", i2c_scl_low_time == 18'd50);

        // Summary
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;
        $display("TIMEOUT - test did not complete in time");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        $display("OVERALL: FAIL");
        $finish;
    end

endmodule
