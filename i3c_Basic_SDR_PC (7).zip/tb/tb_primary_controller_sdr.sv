// =============================================================================
// tb_i3c_primary_controller_sdr.sv
// -----------------------------------------------------------------------------
// Basic smoke testbench for the I3C Controller IP.
//
// Goals:
//   - Reset the IP
//   - Verify AXI4-Lite reads of VERSION and PID0
//   - Program timing registers
//   - Push a NOP command (no actual bus activity)
//   - Verify no X propagation
//
// This is NOT a full protocol-verification testbench. It is a smoke test
// to ensure the modules instantiate and interconnect correctly. A full
// verification environment would use UVM with a virtual I3C target BFM.
// =============================================================================

module tb_i3c_primary_controller_sdr;

  // -------------------------------------------------------------------------
  // DUT parameters
  // -------------------------------------------------------------------------
  localparam int unsigned CLK_FREQ_HZ = 100_000_000;
  localparam int unsigned SCL_FREQ_HZ = 12_500_000;

  // -------------------------------------------------------------------------
  // Signals
  // -------------------------------------------------------------------------
  logic        clk = 1'b0;
  logic        rst_n = 1'b0;
  wire         sda, scl;          // bidirectional I3C pads (multi-driver net)
  logic        sda_pullup_en, scl_pullup_en;
  logic        controller_busy, controller_idle;

  // AXI4-Lite
  logic        awvalid = 1'b0, awready;
  logic [31:0] awaddr = 32'h0;
  logic        wvalid  = 1'b0, wready;
  logic [31:0] wdata   = 32'h0;
  logic [3:0]  wstrb   = 4'hF;
  logic        bvalid, bready = 1'b0;
  logic [1:0]  bresp;
  logic        arvalid = 1'b0, arready;
  logic [31:0] araddr  = 32'h0;
  logic        rvalid,  rready = 1'b0;
  logic [31:0] rdata;
  logic [1:0]  rresp;

  // FIFO interface stubs (host-side inputs tied off; outputs left unconnected)
  logic        cmd_fifo_push = 1'b0;
  logic [31:0] cmd_fifo_push_data = 32'h0;
  logic        cmd_fifo_full, cmd_fifo_empty;
  logic        wr_fifo_push = 1'b0;
  logic [31:0] wr_fifo_push_data = 32'h0;
  logic        wr_fifo_full, wr_fifo_empty;
  logic [31:0] rd_fifo_pop_data;
  logic        rd_fifo_pop = 1'b0;
  logic        rd_fifo_full, rd_fifo_empty;
  logic [31:0] resp_fifo_pop_data;
  logic        resp_fifo_pop = 1'b0;
  logic        resp_fifo_full, resp_fifo_empty;

  // Always-on + wake + power + target + IRQ signals (stubs)
  logic        wake_irq, wake_src_start, wake_src_scl;
  logic        pd_core_off, pd_core_sw_en, pd_core_iso_en, pd_core_rst, wake_to_host;
  logic        target_addressed, target_busy, target_rx_done;
  logic [7:0]  target_rx_byte;
  logic        target_tx_req, target_ibi_req, target_nack_sent;
  logic        i2c_irq, i3c_irq;

  // -------------------------------------------------------------------------
  // DUT instantiation
  // -------------------------------------------------------------------------
  i3c_primary_controller_sdr #(
    .AXI_CLK_FREQ_HZ(CLK_FREQ_HZ),
    .SCL_CLK_FREQ_HZ(SCL_FREQ_HZ),
    .CTRL_PID        (48'h0000_AAAA_BBBB),
    .CTRL_BCR        (8'h00),
    .CTRL_DCR        (8'h00),
    .INST_PULLUP     (1'b0)
  ) dut (
    .s_axi_aclk     (clk),
    .s_axi_aresetn  (rst_n),
    .s_axi_awvalid  (awvalid),
    .s_axi_awready  (awready),
    .s_axi_awaddr   (awaddr),
        .s_axi_awprot(3'b000),
    .s_axi_wvalid   (wvalid),
    .s_axi_wready   (wready),
    .s_axi_wdata    (wdata),
    .s_axi_wstrb    (wstrb),
    .s_axi_bvalid   (bvalid),
    .s_axi_bready   (bready),
    .s_axi_bresp    (bresp),
    .s_axi_arvalid  (arvalid),
    .s_axi_arready  (arready),
    .s_axi_araddr   (araddr),
        .s_axi_arprot(3'b000),
    .s_axi_rvalid   (rvalid),
    .s_axi_rready   (rready),
    .s_axi_rdata    (rdata),
    .s_axi_rresp    (rresp),
    .sda            (sda),
    .scl            (scl),
    .sda_pullup_en  (sda_pullup_en),
    .scl_pullup_en  (scl_pullup_en),
    // Always-on domain
    .clk_aon        (clk),            // Use same clock for sim (no separate AON clk)
    .rst_aon_n      (rst_n),
    // Wake detector
    .wake_irq       (wake_irq),
    .wake_src_start (wake_src_start),
    .wake_src_scl   (wake_src_scl),
    // Power domain
    .pd_core_req    (1'b0),
    .pd_core_off    (pd_core_off),
    .pd_core_ack    (1'b0),
    .pd_core_sw_en  (pd_core_sw_en),
    .pd_core_iso_en (pd_core_iso_en),
    .pd_core_rst    (pd_core_rst),
    .wake_to_host   (wake_to_host),
    // Target engine
    .target_addressed (target_addressed),
    .target_busy      (target_busy),
    .target_rx_done   (target_rx_done),
    .target_rx_byte   (target_rx_byte),
    .target_tx_req    (target_tx_req),
    .target_tx_byte   (8'h00),
    .target_tx_valid  (1'b0),
    .target_ibi_req   (target_ibi_req),
    .target_nack_sent (target_nack_sent),
    // Mode select + IRQ
    .i2c_irq          (i2c_irq),
    .i3c_irq          (i3c_irq),
    // Status
    .controller_busy  (controller_busy),
    .controller_idle  (controller_idle),
    // FIFO Host-Side Interface (stubs — no commands/data pushed in smoke test)
    .cmd_fifo_push       (cmd_fifo_push),
    .cmd_fifo_push_data  (cmd_fifo_push_data),
    .cmd_fifo_full       (cmd_fifo_full),
    .cmd_fifo_empty      (cmd_fifo_empty),
    .wr_fifo_push        (wr_fifo_push),
    .wr_fifo_push_data   (wr_fifo_push_data),
    .wr_fifo_full        (wr_fifo_full),
    .wr_fifo_empty       (wr_fifo_empty),
    .rd_fifo_pop_data    (rd_fifo_pop_data),
    .rd_fifo_pop         (rd_fifo_pop),
    .rd_fifo_full        (rd_fifo_full),
    .rd_fifo_empty       (rd_fifo_empty),
    .resp_fifo_pop_data  (resp_fifo_pop_data),
    .resp_fifo_pop       (resp_fifo_pop),
    .resp_fifo_full      (resp_fifo_full),
    .resp_fifo_empty     (resp_fifo_empty)
  );

  // -------------------------------------------------------------------------
  // Pull-ups on the bus (weak)
  // -------------------------------------------------------------------------
  pullup(sda);
  pullup(scl);

  // -------------------------------------------------------------------------
  // Clock
  // -------------------------------------------------------------------------
  always #5000 clk = ~clk;  // 5000 ps = 5 ns (100 MHz)

  // -------------------------------------------------------------------------
  // AXI4-Lite driver tasks (with proper handshake — no hang)
  // -------------------------------------------------------------------------
  task axi_write(input [31:0] addr, input [31:0] data);
    integer timeout;
    begin
      @(negedge clk);
      awvalid = 1'b1; awaddr = addr;
      wvalid  = 1'b1; wdata  = data; wstrb = 4'hF;
      bready  = 1'b1;
      // Wait for both AW and W handshakes
      timeout = 0;
      while (!(awready && wready) && timeout < 100) begin
        @(posedge clk);
        timeout = timeout + 1;
      end
      @(negedge clk);
      awvalid = 1'b0; wvalid = 1'b0;
      // Wait for BVALID (write response)
      timeout = 0;
      while (!bvalid && timeout < 100) begin
        @(posedge clk);
        timeout = timeout + 1;
      end
      @(negedge clk);
      bready = 1'b0;
    end
  endtask

  task axi_read(input [31:0] addr, output [31:0] data);
    integer timeout;
    begin
      // Assert ARVALID at negedge
      @(negedge clk);
      arvalid = 1'b1; araddr = addr;
      rready  = 1'b1;
      // Wait for ARREADY handshake (at posedge)
      timeout = 0;
      while (!(arready && arvalid) && timeout < 100) begin
        @(posedge clk);
        timeout = timeout + 1;
      end
      // arready was high — slave latched addr, will return data next cycle
      // Deassert ARVALID
      @(negedge clk);
      arvalid = 1'b0;
      // Now wait for RVALID (slave enters RD_DATA state next posedge)
      timeout = 0;
      while (!rvalid && timeout < 100) begin
        @(posedge clk);
        timeout = timeout + 1;
      end
      // rvalid is high — but rdata may not be stable until negedge
      // Sample at negedge to be safe (rdata is stable throughout RD_DATA)
      @(negedge clk);
      data = rdata;
      rready = 1'b0;
    end
  endtask

  // -------------------------------------------------------------------------
  // Test sequence
  // -------------------------------------------------------------------------
  logic [31:0] read_val;
  integer errors = 0;
  integer pass_count = 0;

  task check(input [255:0] name, input condition);
    begin
      if (condition) begin
        pass_count = pass_count + 1;
        $display("[PASS] %0s", name);
      end else begin
        errors = errors + 1;
        $display("[FAIL] %0s", name);
      end
    end
  endtask

  initial begin
    // Init
    awvalid=0; awaddr=0; wvalid=0; wdata=0; wstrb=4'hF;
    bready=0; arvalid=0; araddr=0; rready=0;

    // Reset
    rst_n = 1'b0;
    #100000;
    rst_n = 1'b1;
    @(posedge clk);
    repeat(5) @(posedge clk);  // Let reset propagate

    $display("");
    $display("============================================================");
    $display("I3C Primary Controller SDR — Smoke Test");
    $display("============================================================");

    // Read VERSION
    axi_read(32'h00, read_val);
    $display("[TB] VERSION = 0x%08X (expected 0x0001_0002)", read_val);
    check("VERSION register = 0x0001_0002", read_val == 32'h0001_0002);

    // Read PID0 (at 0x90)
    axi_read(32'h90, read_val);
    $display("[TB] PID0 = 0x%08X (expected 0xAAAA_BBBB)", read_val);
    check("PID0 register = 0xAAAA_BBBB (CTRL_PID[31:0])", read_val == 32'hAAAA_BBBB);

    // Program SCL_HIGH_TIME_CFG (at 0x50). Minimum is 4 cycles (32ns Fm+).
    // Write 5 (in-spec) and verify readback.
    axi_write(32'h50, 32'd5);
    axi_read(32'h50, read_val);
    check("SCL_HIGH_TIME write/read back = 5", read_val[17:0] == 18'd5);

    // Verify controller_idle is asserted after reset (no commands pending)
    check("controller_idle asserted after reset", controller_idle == 1'b1);

    // Verify CMD FIFO is empty after reset
    check("CMD FIFO empty after reset", cmd_fifo_empty == 1'b1);

    // Verify RESP FIFO is empty after reset
    check("RESP FIFO empty after reset", resp_fifo_empty == 1'b1);

    // Verify no X propagation on key outputs
    check("controller_busy is not X", controller_busy !== 1'bx);
    check("i3c_irq is not X", i3c_irq !== 1'bx);
    check("wake_irq is not X", wake_irq !== 1'bx);

    $display("");
    $display("============================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, errors);
    if (errors == 0) $display("OVERALL: PASS");
    else             $display("OVERALL: FAIL");
    $display("============================================================");
    $finish;
  end

  // -------------------------------------------------------------------------
  // Watchdog timeout — prevent infinite hang
  // -------------------------------------------------------------------------
  initial begin
    #2000000000;  // 100 µs timeout
    $display("");
    $display("============================================================");
    $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, errors + 1);
    $display("OVERALL: FAIL (watchdog timeout)");
    $display("============================================================");
    $finish;
  end

endmodule
