// =============================================================================
// tb_i3c_target_engine.sv
// -----------------------------------------------------------------------------
// Standalone I3C Target Engine testbench — simulates an external I3C master
// addressing our target engine. Tests target RX (write) and TX (read) paths.
//
// The target engine is clocked by external SCL. This TB acts as the external
// master: drives SCL and SDA, checks target's SDA responses.
//
// Tests:
//   T1. Address match + write 1 byte (target should ACK address)
//   T2. Address match + write 3 bytes (target should ACK each)
//   T3. Address NACK (wrong address, target should not ACK)
//   T4. Read 1 byte from target (target should drive data + check ACK)
//   T5. STOP detection (target should return to IDLE)
//
// Simulator: Icarus Verilog 12.0
// =============================================================================


module tb_i3c_target_engine;

    // -------------------------------------------------------------------------
    // System clock (clk_sys)
    // -------------------------------------------------------------------------
    logic clk_sys = 1'b0;
    logic rst_sys_n = 1'b0;
    always #5 clk_sys = ~clk_sys;   // 100 MHz

    // -------------------------------------------------------------------------
    // External bus signals (master drives SCL/SDA)
    // -------------------------------------------------------------------------
    logic scl_master;    // master drives SCL
    logic sda_master;    // master drives SDA (1=release, 0=pull low)
    wire  sda_bus;       // resolved SDA on the bus
    wire  scl_bus;       // resolved SCL (open-drain: master or target stretch)

    // Target SDA drive (forward declare — used in wire assigns below)
    logic        tgt_sda_o;
    logic        tgt_sda_oe;

    // BFM-BUG-07 FIX: Open-drain SCL — target can pull low for clock stretching
    wire scl_master_low = (scl_master == 1'b0);
    wire scl_tgt_low    = 1'b0;  // target doesn't drive SCL in this test
    pullup(scl_bus);
    assign scl_bus = (scl_master_low | scl_tgt_low) ? 1'b0 : 1'bz;

    // Open-drain SDA: master and target can both pull low
    // SDA = 0 if EITHER master or target drives low
    // SDA = 1 if BOTH release (pullup)
    wire sda_master_low = (sda_master == 1'b0);
    wire sda_tgt_low    = (tgt_sda_oe == 1'b1 && tgt_sda_o == 1'b0);
    pullup(sda_bus);
    assign sda_bus = (sda_master_low | sda_tgt_low) ? 1'b0 : 1'bz;

    // SCL filtered = SCL bus (no DNF in this test)
    wire scl_filt = scl_bus;
    wire sda_filt = sda_bus;

    // -------------------------------------------------------------------------
    // Target engine config
    // -------------------------------------------------------------------------
    localparam [6:0] TARGET_DYN_ADDR = 7'h08;

    logic        target_en = 1'b0;
    logic [6:0]  target_dyn_addr = TARGET_DYN_ADDR;
    logic        target_ibi_en = 1'b0;
    logic        reclaim_test_active = 1'b0;

    // -------------------------------------------------------------------------
    // Target engine status
    // -------------------------------------------------------------------------
    logic        target_addressed;
    logic        target_busy;
    logic        target_rx_done;
    logic [7:0]  target_rx_byte;
    logic        target_tx_req;
    logic [7:0]  target_tx_byte;
    logic        target_tx_valid = 1'b0;
    logic        target_ibi_req;
    logic        target_nack_sent;
    logic        role_return;
    logic [7:0]  ccc_getrtgl_byte = 8'h00;
    logic        ccc_getrtgl_valid = 1'b0;

    // SCL domain reset
    logic scl_filt_rst_n;

    // -------------------------------------------------------------------------
    // DUT
    // -------------------------------------------------------------------------
    i3c_target_engine u_target (
        .clk_sys            (clk_sys),
        .rst_sys_n          (rst_sys_n),
        .scl_filt           (scl_filt),
        .sda_filt           (sda_filt),
        .scl_filt_rst_n     (scl_filt_rst_n),
        .target_en          (target_en),
        .target_dyn_addr    (target_dyn_addr),
        .target_ibi_en      (target_ibi_en),
        .reclaim_test_active(reclaim_test_active),
        .target_addressed   (target_addressed),
        .target_busy        (target_busy),
        .target_rx_done     (target_rx_done),
        .target_rx_byte     (target_rx_byte),
        .target_tx_req      (target_tx_req),
        .target_tx_byte     (target_tx_byte),
        .target_tx_valid    (target_tx_valid),
        .target_ibi_req     (target_ibi_req),
        .tgt_sda_o          (tgt_sda_o),
        .tgt_sda_oe         (tgt_sda_oe),
        .target_nack_sent   (target_nack_sent),
        .role_return        (role_return),
        .ccc_getrtgl_byte   (ccc_getrtgl_byte),
        .ccc_getrtgl_valid  (ccc_getrtgl_valid)
    );

    // Debug: monitor FIFO push signals
    // SIM-21: Capture target_rx_byte immediately when target_rx_done fires
    // (the RX FIFO auto-pops every cycle, so data is only valid for 1 cycle)
    logic [7:0] captured_rx_byte;
    logic       captured_rx_valid = 1'b0;
    always @(posedge clk_sys) begin
        if (target_rx_done && !captured_rx_valid) begin
            captured_rx_byte  <= target_rx_byte;
            captured_rx_valid <= 1'b1;
        end
    end


    // -------------------------------------------------------------------------
    // Master I3C bus driving tasks
    // -------------------------------------------------------------------------
    // SCL period: 80ns (12.5 MHz I3C SDR)
    localparam SCL_HALF = 40;  // 40ns half period = 80ns full = 12.5 MHz

    // Generate START condition
    task gen_start;
        begin
            // SDA high, SCL high
            sda_master = 1'b1;
            scl_master = 1'b1;
            #SCL_HALF;
            // SDA falls while SCL high = START
            sda_master = 1'b0;
            #SCL_HALF;
            // SCL falls
            scl_master = 1'b0;
            #SCL_HALF;
        end
    endtask

    // Generate STOP condition
    task gen_stop;
        begin
            // SDA low, SCL low
            sda_master = 1'b0;
            scl_master = 1'b0;
            #SCL_HALF;
            // SCL rises
            scl_master = 1'b1;
            #SCL_HALF;
            // SDA rises while SCL high = STOP
            sda_master = 1'b1;
            #SCL_HALF;
        end
    endtask

    // Send one bit and clock SCL
    task send_bit;
        input bit_val;
        begin
            // Set SDA while SCL low
            sda_master = bit_val;
            #SCL_HALF;
            // SCL rises (target samples SDA)
            scl_master = 1'b1;
            #SCL_HALF;
            // SCL falls
            scl_master = 1'b0;
            #SCL_HALF;
        end
    endtask

    // Sample one bit (read SDA during SCL high)
    task sample_bit;
        output bit_val;
        begin
            // SCL low
            #SCL_HALF;
            // SCL rises
            scl_master = 1'b1;
            #10000; // small delay for target to settle
            // Sample SDA
            bit_val = sda_bus;
            #SCL_HALF;
            // SCL falls
            scl_master = 1'b0;
            #SCL_HALF;
        end
    endtask

    // Send a byte (8 bits MSB first) + 9th bit
    // BFM-BUG-04 FIX: For I3C, the controller drives T-bit (0=last, 1=more).
    // For address bytes, the controller releases SDA and the target drives ACK.
    task send_byte;
        input [7:0] data;
        output      ack;  // 0=ACK (target drove low), 1=NACK (target released)
        input       is_addr;  // BFM-BUG-04: 1=address byte (target ACKs), 0=data byte (controller drives T-bit)
        input       t_bit;    // BFM-BUG-04: T-bit value for data bytes (0=last, 1=more)
        integer i;
        begin
            // Send 8 data bits MSB first
            for (i = 7; i >= 0; i = i - 1) begin
                send_bit(data[i]);
            end
            // 9th bit
            if (is_addr) begin
                // Address byte: release SDA, let target drive ACK/NACK
                sda_master = 1'b1; // release
                #SCL_HALF;
                scl_master = 1'b1;
                #10000;
                ack = sda_bus; // 0=ACK, 1=NACK
                #SCL_HALF;
                scl_master = 1'b0;
                #SCL_HALF;
            end else begin
                // Data byte: controller drives T-bit (I3C protocol)
                sda_master = t_bit; // T=0 (last byte) or T=1 (more data)
                #SCL_HALF;
                scl_master = 1'b1;
                #SCL_HALF;
                scl_master = 1'b0;
                #SCL_HALF;
                sda_master = 1'b1; // release after T-bit
                ack = 1'b0; // no ACK for data bytes in I3C
            end
        end
    endtask

    // Read a byte (8 bits MSB first) from target + sample 9th bit (T-bit)
    // BFM-BUG-05 FIX: For I3C reads, the target drives the T-bit on the 9th bit.
    // The controller must release SDA and sample it (T=0=last, T=1=more).
    task recv_byte;
        output [7:0] data;
        input       nack;  // 1=NACK (last byte, controller drives T=0), 0=more (T=1)
        output      t_bit_sampled;  // BFM-BUG-05: sampled T-bit from target
        integer i;
        logic bit_val;
        begin
            data = 8'h00;
            // Release SDA for target to drive
            sda_master = 1'b1;
            // Read 8 bits MSB first
            for (i = 7; i >= 0; i = i - 1) begin
                sample_bit(bit_val);
                data[i] = bit_val;
            end
            // 9th bit: release SDA, let target drive T-bit
            sda_master = 1'b1; // release
            #SCL_HALF;
            scl_master = 1'b1;
            #10000;
            t_bit_sampled = sda_bus; // T=0 (last byte) or T=1 (more available)
            #SCL_HALF;
            scl_master = 1'b0;
            #SCL_HALF;
            // Release SDA
            sda_master = 1'b1;
        end
    endtask

    // -------------------------------------------------------------------------
    // Test result tracking
    // -------------------------------------------------------------------------
    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // -------------------------------------------------------------------------
    // Main test sequence
    // -------------------------------------------------------------------------
    logic addr_ack;
    logic [7:0] rx_data;

    initial begin
        $dumpfile("/tmp/tb_i3c_target_engine.vcd");
        $dumpvars(0, tb_i3c_target_engine);

        // Init bus
        scl_master = 1'b1;
        sda_master = 1'b1;
        scl_filt_rst_n = 1'b0;

        // Reset
        rst_sys_n = 1'b0;
        repeat (10) @(posedge clk_sys);
        rst_sys_n = 1'b1;
        scl_filt_rst_n = 1'b1;
        repeat (10) @(posedge clk_sys);

        $display("");
        $display("============================================================");
        $display("I3C Target Engine Testbench");
        $display("============================================================");
        $display("");

        // Enable target
        target_en = 1'b1;
        repeat (5) @(posedge clk_sys);

        // -----------------------------------------------------
        // T1: Address match + write 1 byte
        // -----------------------------------------------------
        test_num = 1;
        $display("--- T1: Write 1 byte to target addr 0x08 ---");
        gen_start;
        // Send address byte: 0x08 + W=0 = 0x10
        send_byte({TARGET_DYN_ADDR, 1'b0}, addr_ack, 1'b1, 1'b0);
        $display("  Address ACK=%b (expect 0=ACK)", addr_ack);
        check("target ACKs address", addr_ack == 1'b0);

        // Send data byte: 0x55
        send_byte(8'h55, addr_ack, 1'b0, 1'b1);
        $display("  Data ACK=%b", addr_ack);
        check("target ACKs data byte", addr_ack == 1'b0);

        gen_stop;
        repeat (10) @(posedge clk_sys);
        // Check RX byte (captured when target_rx_done fired)
        $display("  captured_rx_byte=0x%02x (expect 0x55)", captured_rx_byte);
        check("RX byte = 0x55", captured_rx_byte == 8'h55);
        captured_rx_valid = 1'b0;  // clear for next test

        // -----------------------------------------------------
        // T2: Write 3 bytes
        // -----------------------------------------------------
        test_num = 2;
        $display("");
        $display("--- T2: Write 3 bytes to target addr 0x08 ---");
        gen_start;
        send_byte({TARGET_DYN_ADDR, 1'b0}, addr_ack, 1'b1, 1'b0);
        check("target ACKs address (3B write)", addr_ack == 1'b0);

        send_byte(8'hAA, addr_ack, 1'b0, 1'b1);
        check("target ACKs data byte 1", addr_ack == 1'b0);
        send_byte(8'hBB, addr_ack, 1'b0, 1'b1);
        check("target ACKs data byte 2", addr_ack == 1'b0);
        send_byte(8'hCC, addr_ack, 1'b0, 1'b0);
        check("target ACKs data byte 3", addr_ack == 1'b0);

        gen_stop;
        repeat (5) @(posedge clk_sys);

        // -----------------------------------------------------
        // T3: Wrong address (target should NACK)
        // -----------------------------------------------------
        test_num = 3;
        $display("");
        $display("--- T3: Wrong address (0x7F) — target should NACK ---");
        gen_start;
        send_byte({7'h7F, 1'b0}, addr_ack, 1'b1, 1'b0);
        $display("  Address ACK=%b (expect 1=NACK)", addr_ack);
        check("target NACKs wrong address", addr_ack == 1'b1);
        gen_stop;
        repeat (5) @(posedge clk_sys);

        // -----------------------------------------------------
        // T4: Read 1 byte from target
        // -----------------------------------------------------
        test_num = 4;
        $display("");
        $display("--- T4: Read 1 byte from target addr 0x08 ---");
        // Provide TX data for target
        target_tx_byte = 8'h42;
        target_tx_valid = 1'b1;
        @(posedge clk_sys);
        target_tx_valid = 1'b0;

        gen_start;
        // Send address byte: 0x08 + R=1 = 0x11
        send_byte({TARGET_DYN_ADDR, 1'b1}, addr_ack, 1'b1, 1'b0);
        $display("  Address ACK=%b (expect 0=ACK)", addr_ack);
        check("target ACKs read address", addr_ack == 1'b0);

        // Read 1 byte from target (NACK = last byte)
        begin logic t_bit_s; recv_byte(rx_data, 1'b1, t_bit_s); end  // NACK = last byte
        $display("  RX data=0x%02x (expect 0x42)", rx_data);
        check("read data = 0x42", rx_data == 8'h42);

        gen_stop;
        repeat (5) @(posedge clk_sys);

        // -----------------------------------------------------
        // T5: STOP detection (target returns to IDLE)
        // -----------------------------------------------------
        test_num = 5;
        $display("");
        $display("--- T5: STOP detection ---");
        gen_start;
        send_byte({TARGET_DYN_ADDR, 1'b0}, addr_ack, 1'b1, 1'b0);
        gen_stop;
        repeat (5) @(posedge clk_sys);
        check("target returns to IDLE after STOP", u_target.tgt_state == u_target.TGT_IDLE);

        // -----------------------------------------------------
        // Summary
        // -----------------------------------------------------
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL — see failures above");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000; // 1 ms
        $display("TIMEOUT — test did not complete in 1 ms");
        $finish;
    end



endmodule
