// =============================================================================
// tb_i3c_protocol_corner_cases.sv
// -----------------------------------------------------------------------------
// Comprehensive I3C protocol corner-case tests:
//   T1.  Repeated START (no STOP between transactions)
//   T2.  Back-to-back transactions (STOP + START)
//   T3.  Max-length transfer (256 bytes)
//   T4.  Address 0x00 edge case (reserved)
//   T5.  Address 0x7F edge case (broadcast)
//   T6.  Single-bit data (0x00 and 0xFF)
//   T7.  NACK recovery (NACK addr → next transaction succeeds)
//   T8.  Multi-byte read with NACK on last byte
//   T9.  T-bit parity verification (controller drives correct parity)
//   T10. Rapid command queue (push 4 commands back-to-back)
//   T11. TOC=0 then TOC=1 (bus hold then release)
//   T12. Empty transfer (byte_cnt_m1=0, 1 byte)
//   T13. Wrong address then correct address (target recovery)
//   T14. SCL stretch by target (target holds SCL low)
// =============================================================================


module tb_i3c_protocol_corner_cases;

    logic s_axi_aclk = 1'b0;
    logic s_axi_aresetn = 1'b0;
    logic clk_aon = 1'b0;
    logic rst_aon_n = 1'b0;
    always #5000 s_axi_aclk = ~s_axi_aclk;
    always #15000000 clk_aon = ~clk_aon;

    wire sda_pad, scl_pad;
    pullup(sda_pad);
    pullup(scl_pad);

    wire scl_resolved = (scl_pad === 1'bz) ? 1'b1 : scl_pad;
    wire sda_resolved = (sda_pad === 1'bz) ? 1'b1 : sda_pad;

    // =========================================================================
    // BFM Target Model (async SCL-edge, same as tb_i3c_transaction_e2e)
    // =========================================================================
    localparam [6:0] TARGET_ADDR = 7'h08;
    localparam [7:0] TX_BYTE_DEFAULT = 8'hAA;

    typedef enum { BFM_IDLE, BFM_RX_BYTE, BFM_ACK, BFM_TX_BYTE, BFM_T_BIT } bfm_state_e;

    bfm_state_e bfm_st = BFM_IDLE;
    logic [3:0]  bfm_bcnt = 0;
    logic [7:0]  bfm_rx_shift = 0;
    logic [7:0]  bfm_tx_byte = TX_BYTE_DEFAULT;
    logic        bfm_is_read = 0;
    logic        bfm_addr_matched = 0;
    logic        bfm_ack_done = 0;
    logic        bfm_scl_prev = 1'b1;
    logic        bfm_sda_prev = 1'b1;
    logic        bfm_first_byte = 1'b1;
    logic        bfm_is_addr_ack = 1'b0;  // SIM-22: 1 during address ACK phase only
    logic [7:0]  bfm_rx_byte_log;
    logic        bfm_rx_byte_valid = 0;

    always @(scl_resolved or sda_resolved) begin
        if (scl_resolved && bfm_scl_prev && bfm_sda_prev && !sda_resolved) begin
            bfm_st = BFM_RX_BYTE; bfm_bcnt = 0; bfm_first_byte = 1'b1;
            bfm_ack_done = 0; bfm_addr_matched = 0; bfm_is_addr_ack = 0;
            bfm_rx_byte_valid = 0;  // BFM-BUG-09 FIX: clear on START
            bfm_rx_shift = 8'h00;  // SIM-22: clear stale bits from STOP false-sample
        end else if (scl_resolved && bfm_scl_prev && !bfm_sda_prev && sda_resolved) begin
            bfm_st = BFM_IDLE; bfm_bcnt = 0; bfm_ack_done = 0; bfm_is_addr_ack = 0;
            bfm_rx_byte_valid = 0;  // BFM-BUG-09 FIX: clear on STOP
        end else begin
            if (scl_resolved && !bfm_scl_prev) begin
                if (bfm_st == BFM_RX_BYTE) begin
                    bfm_rx_shift = {bfm_rx_shift[6:0], sda_resolved};
                    bfm_bcnt = bfm_bcnt + 1;
                    if (bfm_bcnt == 4'h8) begin
                        if (bfm_first_byte) begin
                            bfm_addr_matched = (bfm_rx_shift[7:1] == TARGET_ADDR);
                            bfm_is_read = bfm_rx_shift[0];
                            bfm_first_byte = 1'b0;
                            bfm_is_addr_ack = 1'b1;  // SIM-22: mark addr ACK phase
                        end else begin
                            bfm_rx_byte_log = bfm_rx_shift;
                            bfm_rx_byte_valid = 1;
                            bfm_is_addr_ack = 1'b0;  // data byte: no ACK drive
                        end
                        bfm_st = BFM_ACK;
                    end
                end
            end else if (!scl_resolved && bfm_scl_prev) begin
                if (bfm_st == BFM_ACK) begin
                    if (!bfm_ack_done) begin
                        bfm_ack_done = 1;
                    end else begin
                        bfm_ack_done = 0;
                        bfm_bcnt = 0;
                        if (bfm_addr_matched) begin
                            if (bfm_is_read) begin
                                bfm_st = BFM_TX_BYTE;
                                bfm_tx_byte = TX_BYTE_DEFAULT;
                            end else begin
                                bfm_st = BFM_RX_BYTE;
                            end
                        end else begin
                            bfm_st = BFM_IDLE;
                        end
                    end
                end else if (bfm_st == BFM_TX_BYTE) begin
                    if (bfm_bcnt == 4'h7) begin
                        bfm_st = BFM_T_BIT;
                        bfm_bcnt = 0;
                    end else begin
                        bfm_bcnt = bfm_bcnt + 1;
                    end
                end else if (bfm_st == BFM_T_BIT) begin
                    // T-bit driven during SCL high. On fall, release SDA (go IDLE).
                    // The controller will issue STOP or continue clocking for the
                    // next byte. Going IDLE here prevents SDA bus conflict when
                    // the controller drives SDA low for STOP prep.
                    bfm_st = BFM_IDLE;
                    bfm_bcnt = 0;
                end
            end
        end
        bfm_scl_prev = scl_resolved;
        bfm_sda_prev = sda_resolved;
    end

    // I3C data write bytes have T-bit (controller drives), NOT ACK.
    // Only drive ACK for address byte (bfm_is_addr_ack == 1).
    wire bfm_drive_ack = (bfm_st == BFM_ACK) && bfm_ack_done && bfm_addr_matched
                         && bfm_is_addr_ack;
    wire bfm_drive_tx  = (bfm_st == BFM_TX_BYTE) || (bfm_st == BFM_T_BIT);
    wire bfm_tx_bit    = (bfm_st == BFM_T_BIT) ? 1'b1 : bfm_tx_byte[7 - bfm_bcnt[2:0]];

    // BFM-BUG-06 FIX: open-drain SDA (drive low for 0, release for 1)
    assign sda_pad = bfm_drive_ack ? 1'b0 :
                     bfm_drive_tx  ? (bfm_tx_bit ? 1'bz : 1'b0) :
                     1'bz;

    // =========================================================================
    // DUT + AXI + FIFOs (same as tb_i3c_transaction_e2e)
    // =========================================================================
    logic s_axi_awvalid=0, s_axi_awready, s_axi_wvalid=0, s_axi_wready;
    logic [31:0] s_axi_awaddr=0, s_axi_wdata=0; logic [3:0] s_axi_wstrb=4'hf;
    logic s_axi_bvalid, s_axi_bready=1; logic [1:0] s_axi_bresp;
    logic s_axi_arvalid=0, s_axi_arready; logic [31:0] s_axi_araddr=0;
    logic s_axi_rvalid, s_axi_rready=1; logic [31:0] s_axi_rdata; logic [1:0] s_axi_rresp;
    logic cmd_fifo_push=0; logic [31:0] cmd_fifo_push_data=0;
    logic cmd_fifo_full, cmd_fifo_empty;
    logic wr_fifo_push=0; logic [31:0] wr_fifo_push_data=0;
    logic wr_fifo_full, wr_fifo_empty;
    logic [31:0] rd_fifo_pop_data; logic rd_fifo_pop=0; logic rd_fifo_full, rd_fifo_empty;
    logic [31:0] resp_fifo_pop_data; logic resp_fifo_pop=0; logic resp_fifo_full, resp_fifo_empty;
    logic controller_busy, controller_idle, i2c_irq, i3c_irq;
    logic wake_irq, wake_src_start, wake_src_scl;
    logic pd_core_off, pd_core_sw_en, pd_core_iso_en, pd_core_rst, wake_to_host;
    logic target_addressed, target_busy, target_rx_done;
    logic [7:0] target_rx_byte;
    logic target_tx_req, target_ibi_req, target_nack_sent;
    logic sda_pullup_en, scl_pullup_en;

    i3c_primary_controller_sdr #(.AXI_CLK_FREQ_HZ(100_000_000), .SCL_CLK_FREQ_HZ(12_500_000)) u_dut (
        .s_axi_aclk(s_axi_aclk), .s_axi_aresetn(s_axi_aresetn),
        .s_axi_awvalid(s_axi_awvalid), .s_axi_awready(s_axi_awready), .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awprot(3'b000),
        .s_axi_wvalid(s_axi_wvalid), .s_axi_wready(s_axi_wready), .s_axi_wdata(s_axi_wdata), .s_axi_wstrb(s_axi_wstrb),
        .s_axi_bvalid(s_axi_bvalid), .s_axi_bready(s_axi_bready), .s_axi_bresp(s_axi_bresp),
        .s_axi_arvalid(s_axi_arvalid), .s_axi_arready(s_axi_arready), .s_axi_araddr(s_axi_araddr),
        .s_axi_arprot(3'b000),
        .s_axi_rvalid(s_axi_rvalid), .s_axi_rready(s_axi_rready), .s_axi_rdata(s_axi_rdata), .s_axi_rresp(s_axi_rresp),
        .sda(sda_pad), .scl(scl_pad), .sda_pullup_en(sda_pullup_en), .scl_pullup_en(scl_pullup_en),
        .clk_aon(clk_aon), .rst_aon_n(rst_aon_n),
        .wake_irq(wake_irq), .wake_src_start(wake_src_start), .wake_src_scl(wake_src_scl),
        .pd_core_req(1'b0), .pd_core_off(pd_core_off), .pd_core_ack(1'b0),
        .pd_core_sw_en(pd_core_sw_en), .pd_core_iso_en(pd_core_iso_en), .pd_core_rst(pd_core_rst), .wake_to_host(wake_to_host),
        .target_addressed(target_addressed), .target_busy(target_busy), .target_rx_done(target_rx_done), .target_rx_byte(target_rx_byte),
        .target_tx_req(target_tx_req), .target_tx_byte(8'h00), .target_tx_valid(1'b0),
        .target_ibi_req(target_ibi_req), .target_nack_sent(target_nack_sent),
        .i2c_irq(i2c_irq), .i3c_irq(i3c_irq), .controller_busy(controller_busy), .controller_idle(controller_idle),
        .cmd_fifo_push(cmd_fifo_push), .cmd_fifo_push_data(cmd_fifo_push_data), .cmd_fifo_full(cmd_fifo_full), .cmd_fifo_empty(cmd_fifo_empty),
        .wr_fifo_push(wr_fifo_push), .wr_fifo_push_data(wr_fifo_push_data), .wr_fifo_full(wr_fifo_full), .wr_fifo_empty(wr_fifo_empty),
        .rd_fifo_pop_data(rd_fifo_pop_data), .rd_fifo_pop(rd_fifo_pop), .rd_fifo_full(rd_fifo_full), .rd_fifo_empty(rd_fifo_empty),
        .resp_fifo_pop_data(resp_fifo_pop_data), .resp_fifo_pop(resp_fifo_pop), .resp_fifo_full(resp_fifo_full), .resp_fifo_empty(resp_fifo_empty)
    );

    // =========================================================================
    // AXI + FIFO tasks
    // =========================================================================
    task axi_write(input [31:0] addr, input [31:0] data);
        begin
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b1; s_axi_awaddr <= addr;
            s_axi_wvalid <= 1'b1; s_axi_wdata <= data; s_axi_wstrb <= 4'hf;
            while (!(s_axi_awready && s_axi_wready)) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b0; s_axi_wvalid <= 1'b0;
            while (!s_axi_bvalid) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
        end
    endtask

    task push_cmd(input [31:0] cmd_word);
        begin
            @(posedge s_axi_aclk);
            while (cmd_fifo_full) @(posedge s_axi_aclk);
            cmd_fifo_push <= 1'b1; cmd_fifo_push_data <= cmd_word;
            @(posedge s_axi_aclk);
            cmd_fifo_push <= 1'b0;
        end
    endtask

    task push_wr_data(input [31:0] data);
        begin
            @(posedge s_axi_aclk);
            while (wr_fifo_full) @(posedge s_axi_aclk);
            wr_fifo_push <= 1'b1; wr_fifo_push_data <= data;
            @(posedge s_axi_aclk);
            wr_fifo_push <= 1'b0;
        end
    endtask

    task pop_resp(output [31:0] resp);
        integer timeout_cnt;
        begin
            timeout_cnt = 0;
            while (resp_fifo_empty && timeout_cnt < 200000) begin
                @(posedge s_axi_aclk);
                timeout_cnt = timeout_cnt + 1;
            end
            if (resp_fifo_empty) begin
                $display("  TIMEOUT waiting for response!");
                resp = 32'hFFFF_FFFF;
            end else begin
                resp = resp_fifo_pop_data;
                @(posedge s_axi_aclk);
                resp_fifo_pop <= 1'b1;
                @(posedge s_axi_aclk);
                resp_fifo_pop <= 1'b0;
                @(posedge s_axi_aclk);  // SIM-22: ensure pop deasserted before next call
            end
        end
    endtask

    function [31:0] build_cmd(input toc, input cp, input i2c_mode,
                               input [7:0] byte_cnt_m1, input [6:0] dev_addr,
                               input rnw, input [7:0] ccc_opcode);
        begin
            // cmd_word_t layout (i3c_pkg.sv):
            //   [31]    toc
            //   [30]    cp
            //   [29:28] rsvd
            //   [27]    pec_append
            //   [26]    pec_check
            //   [25]    pec_en
            //   [24]    i2c_mode
            //   [23:16] byte_cnt_m1
            //   [15:9]  dev_addr
            //   [8]     rnw
            //   [7:0]   ccc_opcode
            build_cmd = {toc, cp, 2'b00, 3'b000, i2c_mode, byte_cnt_m1, dev_addr, rnw, ccc_opcode};
        end
    endfunction

    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num = 0;

    task check(input [255:0] name, input condition);
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    logic [31:0] resp_word;

    initial begin
        $dumpfile("/tmp/tb_i3c_corner.vcd");
        $dumpvars(0, tb_i3c_protocol_corner_cases);

        s_axi_aresetn = 1'b0; rst_aon_n = 1'b0;
        repeat (10) @(posedge s_axi_aclk);
        s_axi_aresetn = 1'b1; rst_aon_n = 1'b1;
        repeat (10) @(posedge s_axi_aclk);

        $display("");
        $display("============================================================");
        $display("I3C Protocol Corner Cases Testbench");
        $display("============================================================");

        axi_write(32'h0C, 32'h0000_0001);  // TRANSACTION_CTRL.EN=1
        repeat (5) @(posedge s_axi_aclk);

        // T1: Repeated START (TOC=0 then TOC=1)
        test_num = 1;
        $display("\n--- T1: Repeated START (TOC=0 → TOC=1) ---");
        push_wr_data(32'h0000_0011);
        push_cmd(build_cmd(1'b0, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));  // TOC=0 (hold bus)
        pop_resp(resp_word);
        $display("  First xfer (TOC=0): code=%02x", resp_word[7:0]);
        check("repeated START: first xfer succeeds", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0022);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));  // TOC=1 (release)
        pop_resp(resp_word);
        $display("  Second xfer (TOC=1): code=%02x", resp_word[7:0]);
        check("repeated START: second xfer succeeds", resp_word[7:0] == 8'h00);

        // T2: Back-to-back transactions (STOP + START)
        test_num = 2;
        $display("\n--- T2: Back-to-back transactions ---");
        push_wr_data(32'h0000_0033);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("back-to-back: first xfer", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0044);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("back-to-back: second xfer", resp_word[7:0] == 8'h00);

        // T3: Large transfer (16 bytes — verify multi-word handling)
        test_num = 3;
        $display("\n--- T3: Large transfer (16 bytes) ---");
        for (int i = 0; i < 4; i = i + 1)
            push_wr_data(32'hA5A5_A5A5);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'h0F, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  16-byte xfer: code=%02x len=%0d", resp_word[7:0], resp_word[15:8]);
        check("large transfer: RESP_SUCCESS", resp_word[7:0] == 8'h00);
        check("large transfer: xfer_len=16", resp_word[15:8] == 8'd16);

        // T4: Address 0x00 edge case
        test_num = 4;
        $display("\n--- T4: Address 0x00 (reserved) ---");
        push_wr_data(32'h0000_0001);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, 7'h00, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  addr 0x00: code=%02x", resp_word[7:0]);
        check("addr 0x00: NACK (no device)", resp_word[7:0] == 8'h01);

        // T5: Address 0x7F edge case
        test_num = 5;
        $display("\n--- T5: Address 0x7F ---");
        push_wr_data(32'h0000_0001);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, 7'h7F, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("addr 0x7F: NACK", resp_word[7:0] == 8'h01);

        // T6: Single-bit data extremes
        test_num = 6;
        $display("\n--- T6: Data extremes (0x00 and 0xFF) ---");
        push_wr_data(32'h0000_0000);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("data=0x00: success", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_00FF);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("data=0xFF: success", resp_word[7:0] == 8'h00);

        // T7: NACK recovery
        test_num = 7;
        $display("\n--- T7: NACK recovery ---");
        push_wr_data(32'h0000_0001);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, 7'h7E, 1'b0, 8'h00));  // NACK
        pop_resp(resp_word);
        check("NACK addr: returns NACK", resp_word[7:0] == 8'h01);
        push_wr_data(32'h0000_0055);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));  // should succeed
        pop_resp(resp_word);
        check("NACK recovery: next xfer succeeds", resp_word[7:0] == 8'h00);

        // T8: Multi-byte read with NACK on last byte
        test_num = 8;
        $display("\n--- T8: Multi-byte read (4 bytes) ---");
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd3, TARGET_ADDR, 1'b1, 8'h00));
        pop_resp(resp_word);
        $display("  4-byte read: code=%02x len=%0d", resp_word[7:0], resp_word[15:8]);
        check("multi-byte read: success", resp_word[7:0] == 8'h00);
        check("multi-byte read: len=4", resp_word[15:8] == 8'd4);

        // T9: T-bit parity (implicit — controller must drive correct parity)
        test_num = 9;
        $display("\n--- T9: T-bit parity verification ---");
        // If controller drives wrong T-bit, target won't ACK
        push_wr_data(32'h0000_0055);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        check("T-bit parity: target ACKs (correct parity driven)", resp_word[7:0] == 8'h00);

        // T10: Command queue depth (push 4 commands sequentially, verify FIFO handles)
        test_num = 10;
        $display("\n--- T10: Command queue depth (4 sequential commands) ---");
        // SIM-22: Extra settle time after T9 to ensure BFM returns to IDLE
        repeat (100) @(posedge s_axi_aclk);
        // Flush any stale responses from previous tests
        begin: flush_resp10
            integer flush_cnt;
            flush_cnt = 0;
            while (!resp_fifo_empty && flush_cnt < 100) begin
                @(posedge s_axi_aclk);
                resp_fifo_pop <= 1'b1;
                @(posedge s_axi_aclk);
                resp_fifo_pop <= 1'b0;
                flush_cnt = flush_cnt + 1;
            end
        end
        push_wr_data(32'h0000_0001);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  cmd 1 resp: 0x%08x", resp_word);
        check("queue depth: cmd 1", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0002);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  cmd 2 resp: 0x%08x", resp_word);
        check("queue depth: cmd 2", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0003);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  cmd 3 resp: 0x%08x", resp_word);
        check("queue depth: cmd 3", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0004);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  cmd 4 resp: 0x%08x", resp_word);
        check("queue depth: cmd 4", resp_word[7:0] == 8'h00);

        // T11: TOC=0 then TOC=1 (already tested in T1, but verify bus state)
        test_num = 11;
        $display("\n--- T11: TOC=0 hold then TOC=1 release ---");
        push_wr_data(32'h0000_0066);
        push_cmd(build_cmd(1'b0, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  TOC=0 resp: 0x%08x", resp_word);
        check("TOC=0: success", resp_word[7:0] == 8'h00);
        push_wr_data(32'h0000_0077);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  TOC=1 resp: 0x%08x", resp_word);
        check("TOC=1 after TOC=0: success", resp_word[7:0] == 8'h00);

        // T12: Empty transfer (1 byte minimum)
        test_num = 12;
        $display("\n--- T12: Minimum transfer (1 byte) ---");
        push_wr_data(32'h0000_0088);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));
        pop_resp(resp_word);
        $display("  T12 resp: 0x%08x", resp_word);
        check("min transfer: success", resp_word[7:0] == 8'h00);
        check("min transfer: len=1", resp_word[15:8] == 8'd1);

        // T13: Wrong address then correct address
        test_num = 13;
        $display("\n--- T13: Wrong addr → correct addr ---");
        push_wr_data(32'h0000_0099);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, 7'h7D, 1'b0, 8'h00));  // wrong addr
        pop_resp(resp_word);
        $display("  wrong-addr resp: 0x%08x", resp_word);
        check("wrong addr: NACK", resp_word[7:0] == 8'h01);
        push_wr_data(32'h0000_00AA);
        push_cmd(build_cmd(1'b1, 1'b0, 1'b0, 8'd0, TARGET_ADDR, 1'b0, 8'h00));  // correct
        pop_resp(resp_word);
        $display("  correct-addr resp: 0x%08x", resp_word);
        check("correct addr after wrong: success", resp_word[7:0] == 8'h00);

        // T14: Controller idle after all transactions
        test_num = 14;
        $display("\n--- T14: Controller idle check ---");
        repeat (20) @(posedge s_axi_aclk);
        check("controller_idle asserted", controller_idle == 1'b1);

        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0) $display("OVERALL: PASS");
        else $display("OVERALL: FAIL");
        $display("============================================================");
        $finish;
    end

    initial begin
        #2000000000;  // 2ms (256-byte transfer takes ~200µs + overhead)
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count + 1);
        $display("OVERALL: FAIL (watchdog timeout)");
        $display("============================================================");
        $finish;
    end

endmodule
