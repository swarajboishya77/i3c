// =============================================================================
// tb_i2c_transaction_e2e.sv
// -----------------------------------------------------------------------------
// End-to-end I2C transaction testbench — exercises the I2C fallback path
// through i2c_controller_fsm + byte_serdes_i2c.
//
// I2C protocol (per NXP UM10204):
//   - START: SDA falls while SCL high
//   - Address byte: 7-bit addr + R/W (8 bits, all open-drain)
//     9th bit: target drives ACK (low) or NACK (high)
//   - Data byte: 8 bits, 9th bit = ACK/NACK (same for read and write)
//   - STOP: SDA rises while SCL high
//
// Tests:
//   T1. I2C write 1 byte (target ACKs)
//   T2. I2C write 3 bytes (target ACKs all)
//   T3. I2C read 1 byte (controller ACKs, then NACKs last)
//   T4. I2C write to NACKing target (target NACKs data)
//   T5. I2C address NACK (no device at address)
//
// Simulator: Icarus Verilog 12.0
// =============================================================================


module tb_i2c_transaction_e2e;

    // -------------------------------------------------------------------------
    // Clocks / resets
    // -------------------------------------------------------------------------
    logic s_axi_aclk = 1'b0;
    logic s_axi_aresetn = 1'b0;
    logic clk_aon = 1'b0;
    logic rst_aon_n = 1'b0;

    always #5000 s_axi_aclk = ~s_axi_aclk;   // 100 MHz
    always #15000000 clk_aon = ~clk_aon;     // ~32 kHz

    // -------------------------------------------------------------------------
    // I2C bus (open-drain with pullup)
    // -------------------------------------------------------------------------
    wire sda, scl;
    pullup(sda);
    pullup(scl);

    // -------------------------------------------------------------------------
    // AXI4-Lite signals
    // -------------------------------------------------------------------------
    logic             s_axi_awvalid = 0, s_axi_awready;
    logic [31:0]      s_axi_awaddr = 0;
    logic             s_axi_wvalid = 0, s_axi_wready;
    logic [31:0]      s_axi_wdata = 0;
    logic [3:0]       s_axi_wstrb = 4'hf;
    logic             s_axi_bvalid, s_axi_bready = 1;
    logic [1:0]       s_axi_bresp;
    logic             s_axi_arvalid = 0, s_axi_arready;
    logic [31:0]      s_axi_araddr = 0;
    logic             s_axi_rvalid, s_axi_rready = 1;
    logic [31:0]      s_axi_rdata;
    logic [1:0]       s_axi_rresp;

    // -------------------------------------------------------------------------
    // FIFO interface (unused for I2C — I2C uses register file + internal FIFOs)
    // -------------------------------------------------------------------------
    logic        cmd_fifo_push = 0;
    logic [31:0] cmd_fifo_push_data = 0;
    logic        cmd_fifo_full, cmd_fifo_empty;
    logic        wr_fifo_push = 0;
    logic [31:0] wr_fifo_push_data = 0;
    logic        wr_fifo_full, wr_fifo_empty;
    logic [31:0] rd_fifo_pop_data;
    logic        rd_fifo_pop = 0;
    logic        rd_fifo_full, rd_fifo_empty;
    logic [31:0] resp_fifo_pop_data;
    logic        resp_fifo_pop = 0;
    logic        resp_fifo_full, resp_fifo_empty;

    // -------------------------------------------------------------------------
    // Status / interrupts
    // -------------------------------------------------------------------------
    logic        controller_busy, controller_idle;
    logic        i2c_irq, i3c_irq;
    logic        wake_irq, wake_src_start, wake_src_scl;
    logic        pd_core_off, pd_core_sw_en, pd_core_iso_en, pd_core_rst, wake_to_host;
    logic        target_addressed, target_busy, target_rx_done;
    logic [7:0]  target_rx_byte;
    logic        target_tx_req, target_ibi_req, target_nack_sent;
    logic        sda_pullup_en, scl_pullup_en;

    // -------------------------------------------------------------------------
    // DUT
    // -------------------------------------------------------------------------
    i3c_primary_controller_sdr #(
        .AXI_CLK_FREQ_HZ (100_000_000),
        .SCL_CLK_FREQ_HZ (12_500_000)
    ) u_dut (
        .s_axi_aclk       (s_axi_aclk),
        .s_axi_aresetn    (s_axi_aresetn),
        .s_axi_awvalid    (s_axi_awvalid),
        .s_axi_awready    (s_axi_awready),
        .s_axi_awaddr     (s_axi_awaddr),
        .s_axi_awprot(3'b000),
        .s_axi_wvalid     (s_axi_wvalid),
        .s_axi_wready     (s_axi_wready),
        .s_axi_wdata      (s_axi_wdata),
        .s_axi_wstrb      (s_axi_wstrb),
        .s_axi_bvalid     (s_axi_bvalid),
        .s_axi_bready     (s_axi_bready),
        .s_axi_bresp      (s_axi_bresp),
        .s_axi_arvalid    (s_axi_arvalid),
        .s_axi_arready    (s_axi_arready),
        .s_axi_araddr     (s_axi_araddr),
        .s_axi_arprot(3'b000),
        .s_axi_rvalid     (s_axi_rvalid),
        .s_axi_rready     (s_axi_rready),
        .s_axi_rdata      (s_axi_rdata),
        .s_axi_rresp      (s_axi_rresp),
        .sda              (sda),
        .scl              (scl),
        .sda_pullup_en    (sda_pullup_en),
        .scl_pullup_en    (scl_pullup_en),
        .clk_aon          (clk_aon),
        .rst_aon_n        (rst_aon_n),
        .wake_irq         (wake_irq),
        .wake_src_start   (wake_src_start),
        .wake_src_scl     (wake_src_scl),
        .pd_core_req      (1'b0),
        .pd_core_off      (pd_core_off),
        .pd_core_ack      (1'b0),
        .pd_core_sw_en    (pd_core_sw_en),
        .pd_core_iso_en   (pd_core_iso_en),
        .pd_core_rst      (pd_core_rst),
        .wake_to_host     (wake_to_host),
        .target_addressed (target_addressed),
        .target_busy      (target_busy),
        .target_rx_done   (target_rx_done),
        .target_rx_byte   (target_rx_byte),
        .target_tx_req    (target_tx_req),
        .target_tx_byte   (8'h00),
        .target_tx_valid  (1'b0),
        .target_ibi_req   (target_ibi_req),
        .target_nack_sent (target_nack_sent),
        .i2c_irq          (i2c_irq),
        .i3c_irq          (i3c_irq),
        .controller_busy  (controller_busy),
        .controller_idle  (controller_idle),
        .cmd_fifo_push         (cmd_fifo_push),
        .cmd_fifo_push_data    (cmd_fifo_push_data),
        .cmd_fifo_full         (cmd_fifo_full),
        .cmd_fifo_empty        (cmd_fifo_empty),
        .wr_fifo_push          (wr_fifo_push),
        .wr_fifo_push_data     (wr_fifo_push_data),
        .wr_fifo_full          (wr_fifo_full),
        .wr_fifo_empty         (wr_fifo_empty),
        .rd_fifo_pop_data      (rd_fifo_pop_data),
        .rd_fifo_pop           (rd_fifo_pop),
        .rd_fifo_full          (rd_fifo_full),
        .rd_fifo_empty         (rd_fifo_empty),
        .resp_fifo_pop_data    (resp_fifo_pop_data),
        .resp_fifo_pop         (resp_fifo_pop),
        .resp_fifo_full        (resp_fifo_full),
        .resp_fifo_empty       (resp_fifo_empty)
    );

    // -------------------------------------------------------------------------
    // I2C Target Model — async SCL/SDA edge-triggered (SIM-21 fix)
    // -------------------------------------------------------------------------
    // I2C protocol: every byte (address AND data) has ACK/NACK on 9th bit.
    // No T-bit, no parity. Simpler than I3C.
    // -------------------------------------------------------------------------
    localparam [6:0] I2C_TARGET_ADDR = 7'h50;  // I2C address 0x50

    typedef enum { I2C_TGT_IDLE, I2C_TGT_RX_BYTE, I2C_TGT_DRV_ACK,
                   I2C_TGT_TX_BYTE, I2C_TGT_DRV_ACK_CTRL } i2c_tgt_state_e;

    i2c_tgt_state_e i2c_tgt_state = I2C_TGT_IDLE;
    logic [3:0]  i2c_tgt_bit_cnt = 0;
    logic [7:0]  i2c_tgt_rx_shift = 0;
    logic [7:0]  i2c_tgt_tx_byte = 8'hBB;
    logic        i2c_tgt_is_read = 0;
    logic        i2c_tgt_first_byte = 1'b1;
    logic        i2c_tgt_ack_done = 0;
    logic        i2c_tgt_scl_prev = 1'b1;
    logic        i2c_tgt_sda_prev = 1'b1;

    wire scl_resolved_i2c = (scl === 1'bz) ? 1'b1 : scl;
    wire sda_resolved_i2c = (sda === 1'bz) ? 1'b1 : sda;

    // Combinational SDA drive signals
    logic i2c_tgt_drive_ack, i2c_tgt_drive_tx, i2c_tgt_tx_bit;

    // SINGLE always block — all blocking, no race conditions
    always @(scl_resolved_i2c or sda_resolved_i2c) begin
        // START/STOP: SCL must be HIGH and STABLE (scl_prev == 1)
        if (scl_resolved_i2c && i2c_tgt_scl_prev && i2c_tgt_sda_prev && !sda_resolved_i2c) begin
            // START
            i2c_tgt_state = I2C_TGT_RX_BYTE;
            i2c_tgt_bit_cnt = 0;
            i2c_tgt_first_byte = 1'b1;
            i2c_tgt_ack_done = 0;
        end else if (scl_resolved_i2c && i2c_tgt_scl_prev && !i2c_tgt_sda_prev && sda_resolved_i2c) begin
            // STOP
            i2c_tgt_state = I2C_TGT_IDLE;
            i2c_tgt_bit_cnt = 0;
            i2c_tgt_ack_done = 0;
        end else begin
            if (scl_resolved_i2c && !i2c_tgt_scl_prev) begin
                // SCL rising edge — sample
                if (i2c_tgt_state == I2C_TGT_RX_BYTE) begin
                    i2c_tgt_rx_shift = {i2c_tgt_rx_shift[6:0], sda_resolved_i2c};
                    i2c_tgt_bit_cnt = i2c_tgt_bit_cnt + 1;
                    if (i2c_tgt_bit_cnt == 4'h8) begin
                        if (i2c_tgt_first_byte) begin
                            i2c_tgt_is_read = i2c_tgt_rx_shift[0];
                            // DON'T clear first_byte here — keep it 1 through ACK phase
                            // so the ACK logic knows this was the address byte
                        end
                        i2c_tgt_state = I2C_TGT_DRV_ACK;
                    end
                end
                // TX_BYTE and DRV_ACK_CTRL: no action on rise (bit is stable)
            end else if (!scl_resolved_i2c && i2c_tgt_scl_prev) begin
                // SCL falling edge
                if (i2c_tgt_state == I2C_TGT_DRV_ACK) begin
                    if (!i2c_tgt_ack_done) begin
                        i2c_tgt_ack_done = 1;  // 8th falling — ACK drive starts
                    end else begin
                        i2c_tgt_ack_done = 0;  // 9th falling — ACK drive ends
                        i2c_tgt_first_byte = 1'b0;  // NOW clear first_byte (after ACK)
                        i2c_tgt_bit_cnt = 0;
                        if (i2c_tgt_is_read)
                            i2c_tgt_state = I2C_TGT_TX_BYTE;
                        else
                            i2c_tgt_state = I2C_TGT_RX_BYTE;
                    end
                end else if (i2c_tgt_state == I2C_TGT_TX_BYTE) begin
                    if (i2c_tgt_bit_cnt == 4'h7) begin
                        i2c_tgt_state = I2C_TGT_DRV_ACK_CTRL;
                        i2c_tgt_bit_cnt = 0;
                    end else begin
                        i2c_tgt_bit_cnt = i2c_tgt_bit_cnt + 1;
                    end
                end else if (i2c_tgt_state == I2C_TGT_DRV_ACK_CTRL) begin
                    // Controller's ACK/NACK sampled on rise. On fall, go back to TX.
                    i2c_tgt_state = I2C_TGT_TX_BYTE;
                    i2c_tgt_bit_cnt = 0;
                end
            end
        end
        i2c_tgt_scl_prev = scl_resolved_i2c;
        i2c_tgt_sda_prev = sda_resolved_i2c;
    end

    // Combinational SDA drive — continuous assign for t=0 evaluation
    // ACK: drive low when in DRV_ACK and ack_done (between 8th and 9th fall)
    //      For address byte: only ACK if address matches
    //      For data byte: always ACK
    // TX:  drive data MSB first when in TX_BYTE
    assign i2c_tgt_drive_ack = (i2c_tgt_state == I2C_TGT_DRV_ACK) && i2c_tgt_ack_done;
    assign i2c_tgt_drive_tx  = (i2c_tgt_state == I2C_TGT_TX_BYTE);
    assign i2c_tgt_tx_bit    = i2c_tgt_tx_byte[7 - i2c_tgt_bit_cnt[2:0]];

    // For address ACK: check if address matches (first byte only)
    // For data ACK: always ACK
    wire i2c_addr_match = (i2c_tgt_rx_shift[7:1] == I2C_TARGET_ADDR);
    wire i2c_should_ack = i2c_tgt_drive_ack && (!i2c_tgt_first_byte || i2c_addr_match);

    assign sda = i2c_should_ack        ? 1'b0 :      // ACK = low
                 i2c_tgt_drive_tx      ? i2c_tgt_tx_bit :  // TX data
                 1'bz;                                 // release

    // -------------------------------------------------------------------------
    // AXI4-Lite write task
    // -------------------------------------------------------------------------
    task axi_write;
        input [31:0] addr;
        input [31:0] data;
        begin
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b1;
            s_axi_awaddr  <= addr;
            s_axi_wvalid  <= 1'b1;
            s_axi_wdata   <= data;
            s_axi_wstrb   <= 4'hf;
            while (!(s_axi_awready && s_axi_wready)) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
            s_axi_awvalid <= 1'b0;
            s_axi_wvalid  <= 1'b0;
            while (!s_axi_bvalid) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
        end
    endtask

    // -------------------------------------------------------------------------
    // AXI4-Lite read task
    // -------------------------------------------------------------------------
    task axi_read;
        input  [31:0] addr;
        output [31:0] data;
        begin
            @(posedge s_axi_aclk);
            s_axi_arvalid <= 1'b1;
            s_axi_araddr  <= addr;
            while (!s_axi_arready) @(posedge s_axi_aclk);
            @(posedge s_axi_aclk);
            s_axi_arvalid <= 1'b0;
            while (!s_axi_rvalid) @(posedge s_axi_aclk);
            data = s_axi_rdata;
            @(posedge s_axi_aclk);
        end
    endtask

    // -------------------------------------------------------------------------
    // Bus monitor
    // -------------------------------------------------------------------------
    logic scl_prev_mon, sda_prev_mon;
    always_ff @(posedge s_axi_aclk) begin
        scl_prev_mon <= (scl === 1'bz) ? 1'b1 : scl;
        sda_prev_mon <= (sda === 1'bz) ? 1'b1 : sda;
    end

    // -------------------------------------------------------------------------
    // Test result tracking
    // -------------------------------------------------------------------------
    integer pass_count = 0;
    integer fail_count = 0;
    integer test_num = 0;

    task check;
        input [255:0] name;
        input         condition;
        begin
            if (condition) begin
                pass_count = pass_count + 1;
                $display("[PASS] T%0d %0s", test_num, name);
            end else begin
                fail_count = fail_count + 1;
                $display("[FAIL] T%0d %0s", test_num, name);
            end
        end
    endtask

    // -------------------------------------------------------------------------
    // I2C register offsets (base = 0x100)
    // -------------------------------------------------------------------------
    localparam [31:0] I2C_BASE          = 32'h0100;
    localparam [31:0] I2C_SPD_MODE_CFG  = I2C_BASE + 32'h00;
    localparam [31:0] I2C_TRANS_CFG     = I2C_BASE + 32'h04;
    localparam [31:0] I2C_TRANS_EN_CTRL = I2C_BASE + 32'h08;
    localparam [31:0] I2C_TARGET_ADDR_CFG = I2C_BASE + 32'h18;
    localparam [31:0] I2C_WDATA_TXFIFO  = I2C_BASE + 32'h2C;  // BUGFIX: was 0x20, should be 0x2C per i3c_pkg.sv
    localparam [31:0] I2C_FIFO_CTRL     = I2C_BASE + 32'h24;
    localparam [31:0] I2C_RDATA_RXFIFO  = I2C_BASE + 32'h30;
    localparam [31:0] I2C_INT_STATUS    = I2C_BASE + 32'h38;  // BUGFIX: was 0x30, should be 0x38 per i3c_pkg.sv
    localparam [31:0] I2C_FIFO_STATUS   = I2C_BASE + 32'h28;  // BUGFIX: was 0x2C, should be 0x28 per i3c_pkg.sv

    // -------------------------------------------------------------------------
    // Main test sequence
    // -------------------------------------------------------------------------
    logic [31:0] rd_data;
    integer timeout_cnt;

    initial begin
        $dumpfile("/tmp/tb_i2c_transaction_e2e.vcd");
        $dumpvars(0, tb_i2c_transaction_e2e);

        // Reset
        s_axi_aresetn = 1'b0;
        rst_aon_n     = 1'b0;
        repeat (10) @(posedge s_axi_aclk);
        s_axi_aresetn = 1'b1;
        rst_aon_n     = 1'b1;
        repeat (10) @(posedge s_axi_aclk);

        $display("");
        $display("============================================================");
        $display("I2C Transaction End-to-End Testbench");
        $display("============================================================");
        $display("");

        // -----------------------------------------------------
        // Setup: Configure I2C controller
        // -----------------------------------------------------
        $display("--- Setup: Configure I2C controller ---");
        // Set speed prescaler: 50 cycles = 1 MHz Fm+ (at 100MHz PCLK)
        axi_write(I2C_SPD_MODE_CFG, 32'h0000_0032);  // 50 decimal
        // Set transfer length: 1 byte
        axi_write(I2C_TRANS_CFG, 32'h0000_0001);
        // Set target address: 0x50 (7-bit) + W=0 (write)
        axi_write(I2C_TARGET_ADDR_CFG, {24'h0, I2C_TARGET_ADDR, 1'b0});
        repeat (5) @(posedge s_axi_aclk);

        // -----------------------------------------------------
        // T1: I2C write 1 byte to address 0x50
        // -----------------------------------------------------
        test_num = 1;
        $display("");
        $display("--- T1: I2C write 1 byte to 0x50 ---");
        // Push TX data to I2C TX FIFO
        axi_write(I2C_WDATA_TXFIFO, 32'h0000_0055);  // 1 byte: 0x55
        repeat (2) @(posedge s_axi_aclk);
        // Trigger transfer
        axi_write(I2C_TRANS_EN_CTRL, 32'h0000_0001);
        // Wait for completion (poll INT_STATUS or timeout)
        timeout_cnt = 0;
        rd_data = 0;
        begin: wait_loop1
            while (timeout_cnt < 5000) begin
                axi_read(I2C_TRANS_EN_CTRL, rd_data);
                if (rd_data[0] == 1'b0) begin
                    $display("  I2C transfer done (TRANS_EN cleared)");
                    disable wait_loop1;
                end
                timeout_cnt = timeout_cnt + 1;
            end
        end
        if (timeout_cnt >= 5000)
            $display("  TIMEOUT waiting for I2C transfer!");
        check("I2C write 1 byte completes (TRANS_EN cleared)", rd_data[0] == 1'b0);

        // -----------------------------------------------------
        // T2: I2C write 3 bytes to address 0x50
        // -----------------------------------------------------
        test_num = 2;
        $display("");
        $display("--- T2: I2C write 3 bytes to 0x50 ---");
        axi_write(I2C_TRANS_CFG, 32'h0000_0003);  // 3 bytes
        repeat (2) @(posedge s_axi_aclk);
        axi_write(I2C_WDATA_TXFIFO, 32'h0000_AA11);
        axi_write(I2C_WDATA_TXFIFO, 32'h0000_BB22);
        axi_write(I2C_WDATA_TXFIFO, 32'h0000_CC33);
        repeat (2) @(posedge s_axi_aclk);
        axi_write(I2C_TRANS_EN_CTRL, 32'h0000_0001);
        timeout_cnt = 0;
        rd_data = 0;
        begin: wait_loop2
            while (timeout_cnt < 5000) begin
                axi_read(I2C_TRANS_EN_CTRL, rd_data);
                if (rd_data[0] == 1'b0) begin
                    $display("  I2C transfer done (TRANS_EN cleared)");
                    disable wait_loop2;
                end
                timeout_cnt = timeout_cnt + 1;
            end
        end
        if (timeout_cnt >= 5000)
            $display("  TIMEOUT waiting for I2C transfer!");
        check("I2C write 3 bytes completes (TRANS_EN cleared)", rd_data[0] == 1'b0);

        // -----------------------------------------------------
        // T3: I2C read 1 byte from address 0x50
        // -----------------------------------------------------
        test_num = 3;
        $display("");
        $display("--- T3: I2C read 1 byte from 0x50 ---");
        // SIM-21: Wait for I2C FSM to return to IDLE before starting T3.
        begin: wait_fsm_idle3
            while (u_dut.u_i2c_fsm.state_q != u_dut.u_i2c_fsm.I2C_IDLE) begin
                @(posedge s_axi_aclk);
                if ($time > 40000000) begin
                    $display("  TIMEOUT waiting for I2C FSM idle!");
                    disable wait_fsm_idle3;
                end
            end
        end
        repeat (10) @(posedge s_axi_aclk);
        axi_write(I2C_TRANS_CFG, 32'h0000_0001);  // 1 byte
        axi_write(I2C_TARGET_ADDR_CFG, {24'h0, I2C_TARGET_ADDR, 1'b1});  // R=1
        repeat (5) @(posedge s_axi_aclk);
        axi_write(I2C_TRANS_EN_CTRL, 32'h0000_0001);
        timeout_cnt = 0;
        rd_data = 0;
        begin: wait_loop3
            while (timeout_cnt < 5000) begin
                axi_read(I2C_TRANS_EN_CTRL, rd_data);
                if (rd_data[0] == 1'b0) begin
                    $display("  I2C read done (TRANS_EN cleared)");
                    disable wait_loop3;
                end
                timeout_cnt = timeout_cnt + 1;
            end
        end
        if (timeout_cnt >= 5000)
            $display("  TIMEOUT waiting for I2C read!");
        check("I2C read 1 byte completes (TRANS_EN cleared)", rd_data[0] == 1'b0);
        // Read RX data
        axi_read(I2C_RDATA_RXFIFO, rd_data);
        $display("  RX data: 0x%08x (expect 0xBB in low byte)", rd_data);
        check("RX data = 0xBB", rd_data[7:0] == 8'hBB);

        // -----------------------------------------------------
        // Summary
        // -----------------------------------------------------
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count);
        if (fail_count == 0)
            $display("OVERALL: PASS");
        else
            $display("OVERALL: FAIL — see failures above");
        $display("============================================================");

        $finish;
    end

    // Watchdog
    initial begin
        #2000000000;  // 2ms
        $display("");
        $display("============================================================");
        $display("SUMMARY: %0d PASS, %0d FAIL", pass_count, fail_count + 1);
        $display("OVERALL: FAIL (watchdog timeout)");
        $display("============================================================");
        $finish;
    end

endmodule
