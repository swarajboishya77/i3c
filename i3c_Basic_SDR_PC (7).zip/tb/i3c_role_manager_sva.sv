// =============================================================================
// i3c_role_manager_sva.sv
// -----------------------------------------------------------------------------
// SVA properties for i3c_role_manager.
// Written as runtime-checkable always blocks (iverilog-compatible) that are
// also synthesizable as SVA assertions in formal tools.
//
// To convert to formal SVA: replace each `always @(posedge clk)` block with
// `property` + `assert property`. The logic is identical.
// =============================================================================

`ifndef I3C_ROLE_MANAGER_SVA_SV
`define I3C_ROLE_MANAGER_SVA_SV

module i3c_role_manager_sva (
    input  logic        clk_sys,
    input  logic        rst_sys_n,
    input  logic [2:0]  state_q,
    input  logic [2:0]  state_d,
    input  logic        handoff_trigger,
    input  logic        getacccr_done,
    input  logic        getacccr_ack,
    input  logic        getacccr_addr_nack,
    input  logic        getacccr_data_nack,
    input  logic        role_return,
    input  logic        scl_falling,
    input  logic        sda_falling,
    input  logic        idle_timer_expired,
    input  logic        reclaim_en,
    input  logic        handoff_done_pulse,
    input  logic        handoff_failed_pulse,
    input  logic [1:0]  phy_mux_sel,
    input  logic        role_is_controller,
    input  logic        role_is_target,
    input  logic        reclaim_in_progress,
    input  logic        target_engine_en
);

    // State encodings
    localparam ROLE_ACTIVE_CONTROLLER = 3'd0;
    localparam ROLE_PREPARING_HANDOFF = 3'd1;
    localparam ROLE_MONITORING_NEW    = 3'd2;
    localparam ROLE_TESTING_NEW       = 3'd3;
    localparam ROLE_RECLAIMING        = 3'd4;
    localparam ROLE_TARGET            = 3'd5;
    localparam ROLE_HANDOFF_FAILED    = 3'd6;
    localparam ROLE_BOOTSTRAP         = 3'd7;

    logic [2:0] state_q_prev;

    always @(posedge clk_sys or negedge rst_sys_n) begin
        if (!rst_sys_n)
            state_q_prev <= ROLE_ACTIVE_CONTROLLER;
        else
            state_q_prev <= state_q;
    end

    // =========================================================================
    // P1: Reset always returns to ACTIVE_CONTROLLER
    // =========================================================================
    always @(posedge clk_sys) begin
        if (!rst_sys_n && state_q !== ROLE_ACTIVE_CONTROLLER)
            $error("SVA FAIL: Reset did not return to ACTIVE_CONTROLLER");
    end

    // =========================================================================
    // P2: handoff_trigger from ACTIVE → PREPARING_HANDOFF
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && state_q_prev == ROLE_ACTIVE_CONTROLLER && handoff_trigger
            && state_q != ROLE_PREPARING_HANDOFF)
            $error("SVA FAIL: handoff_trigger did not transition to PREPARING_HANDOFF");
    end

    // =========================================================================
    // P3: GETACCR ACK → MONITORING_NEW
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && state_q_prev == ROLE_PREPARING_HANDOFF
            && getacccr_done && getacccr_ack
            && state_q != ROLE_MONITORING_NEW)
            $error("SVA FAIL: GETACCR ACK did not transition to MONITORING_NEW");
    end

    // =========================================================================
    // P4: GETACCR NACK → HANDOFF_FAILED
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && state_q_prev == ROLE_PREPARING_HANDOFF && getacccr_done
            && (getacccr_addr_nack || getacccr_data_nack)
            && state_q != ROLE_HANDOFF_FAILED)
            $error("SVA FAIL: GETACCR NACK did not transition to HANDOFF_FAILED");
    end

    // =========================================================================
    // P5: phy_mux_sel = DPHY when role_is_controller
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && role_is_controller && phy_mux_sel != 2'd0)
            $error("SVA FAIL: phy_mux_sel != DPHY when role_is_controller");
    end

    // =========================================================================
    // P6: phy_mux_sel = TARGET when role_is_target
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && role_is_target && phy_mux_sel != 2'd1)
            $error("SVA FAIL: phy_mux_sel != TARGET when role_is_target");
    end

    // =========================================================================
    // P7: target_engine_en = 1 when role_is_target
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && role_is_target && !target_engine_en)
            $error("SVA FAIL: target_engine_en not asserted when role_is_target");
    end

    // =========================================================================
    // P8: role_is_controller and role_is_target are mutually exclusive
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && role_is_controller && role_is_target)
            $error("SVA FAIL: role_is_controller and role_is_target both asserted");
    end

    // =========================================================================
    // P9: reclaim_in_progress only in RECLAIMING state
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && reclaim_in_progress && state_q != ROLE_RECLAIMING)
            $error("SVA FAIL: reclaim_in_progress outside RECLAIMING state");
    end

    // =========================================================================
    // P10: Voluntary return from TARGET → ACTIVE
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && state_q_prev == ROLE_TARGET && role_return
            && state_q != ROLE_ACTIVE_CONTROLLER)
            $error("SVA FAIL: Voluntary return did not transition to ACTIVE_CONTROLLER");
    end

    // =========================================================================
    // P11: HANDOFF_FAILED is transient (1 cycle only)
    // =========================================================================
    always @(posedge clk_sys) begin
        if (rst_sys_n && state_q_prev == ROLE_HANDOFF_FAILED
            && state_q != ROLE_ACTIVE_CONTROLLER)
            $error("SVA FAIL: HANDOFF_FAILED did not transition to ACTIVE_CONTROLLER");
    end

endmodule

`endif // I3C_ROLE_MANAGER_SVA_SV
