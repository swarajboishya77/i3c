#!/bin/bash
# =============================================================================
# 2_vivado_elaborate.sh  —  STEP 2: ELABORATE
# -----------------------------------------------------------------------------
# Elaborates the top-level design with xelab (Vivado XSIM elaborator).
# Builds the simulation snapshot from the compiled work library.
#
# Usage:
#   bash 2_vivado_xelab_elaborate.sh                    # Default: i3c_primary_controller_sdr
#   bash 2_vivado_xelab_elaborate.sh <top_module>       # Custom top module
#
# Prerequisite: bash 1_vivado_xvlog_compile.sh must have been run first.
# Output: sim_top.sim snapshot in xsim.dir/
# Next:   bash 3_vivado_xsim_simulate.sh
# =============================================================================

# No set -e — we handle errors manually

# --- Auto-detect project root ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT=""
for dir in "$SCRIPT_DIR" "$SCRIPT_DIR/.." "$SCRIPT_DIR/../.." "$(pwd)" "$(pwd)/.."; do
    if [ -f "${dir}/rtl/include/i3c_pkg.sv" ]; then
        PROJECT_ROOT="$(cd "$dir" && pwd)"
        break
    fi
done
if [ -z "$PROJECT_ROOT" ]; then
    echo "ERROR: Cannot find rtl/include/i3c_pkg.sv"
    exit 1
fi
cd "$PROJECT_ROOT"

# --- Check that compile was done ---
if [ ! -d "xsim.dir" ]; then
    echo "ERROR: xsim.dir/ not found. Run Step 1 first:"
    echo "  bash 1_vivado_xvlog_compile.sh"
    exit 1
fi

TOP_MODULE="${1:-i3c_primary_controller_sdr}"
SNAPSHOT="sim_${TOP_MODULE}"

echo "================================================================"
echo "STEP 2: ELABORATE (xelab)"
echo "Project:  $PROJECT_ROOT"
echo "Top:      $TOP_MODULE"
echo "Snapshot: $SNAPSHOT"
echo "================================================================"

# --- Elaborate ---
echo ""
echo "--- Elaborating $TOP_MODULE ---"
xelab -L work -debug typical $TOP_MODULE -s $SNAPSHOT
ELAB_RC=$?

if [ $ELAB_RC -ne 0 ]; then
    echo ""
    echo "ERROR: Elaboration FAILED for $TOP_MODULE (exit code $ELAB_RC)"
    echo "The simulation snapshot was NOT created."
    echo "Please fix the errors above before running Step 3."
    exit 1
fi

echo ""
echo "================================================================"
echo "STEP 2 COMPLETE: Elaborate done."
echo "Output: xsim.dir/${SNAPSHOT} snapshot"
echo ""
echo "NEXT: bash 3_vivado_xsim_simulate.sh --batch"
echo "================================================================"
