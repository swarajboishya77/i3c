// tb_verilator/i3c_group_addr_tb.cpp — Group Address unit test (Verilator)
// Table format: [31:25]=addr(7bit), [24:9]=targets(16bit), [8:0]=reserved
#include "verilated.h"
#include "Vi3c_group_addr.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_group_addr* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

// Build table entry: addr in [31:25], targets in [24:9]
uint32_t make_entry(uint8_t addr, uint16_t targets) {
    return ((uint32_t)(addr & 0x7F) << 25) | ((uint32_t)targets << 9);
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_group_addr;

    dut->clk = 0; dut->rst_n = 0; dut->group_enable = 0; dut->group_count = 0;
    dut->group_table_0 = 0; dut->group_table_1 = 0; dut->group_table_2 = 0;
    dut->group_table_3 = 0; dut->group_table_4 = 0; dut->group_table_5 = 0;
    dut->group_table_6 = 0; dut->group_table_7 = 0;
    dut->addr_val = 0; dut->ccc_setrtgl = 0; dut->ccc_getrtgl = 0;
    dut->ccc_payload_byte = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: Group disabled = no match
    std::cout << "\n--- T1: Group disabled ---" << std::endl;
    dut->group_enable = 0;
    dut->group_table_0 = make_entry(0x08, 0x0001);
    dut->group_count = 1;
    dut->addr_val = 0x08;
    tick();
    CHECK(dut->group_match == 0, "Group disabled: no match");

    // T2: Group enabled, address matches entry 0
    std::cout << "\n--- T2: Group match on entry 0 ---" << std::endl;
    dut->group_enable = 1;
    dut->group_table_0 = make_entry(0x08, 0x0001);
    dut->addr_val = 0x08;
    tick();
    CHECK(dut->group_match == 1, "Group enabled: match on addr 0x08");
    CHECK(dut->group_idx == 0, "Group idx = 0");
    CHECK(dut->group_targets == 0x0001, "Group targets = 0x0001");

    // T3: No match on wrong address
    std::cout << "\n--- T3: No match on wrong address ---" << std::endl;
    dut->addr_val = 0x30;
    tick();
    CHECK(dut->group_match == 0, "Wrong addr: no match");

    // T4: Match on entry 1
    std::cout << "\n--- T4: Match on entry 1 ---" << std::endl;
    dut->group_table_1 = make_entry(0x30, 0x0003);
    dut->group_count = 2;
    dut->addr_val = 0x30;
    tick();
    CHECK(dut->group_match == 1, "Match on addr 0x30");
    CHECK(dut->group_idx == 1, "Group idx = 1");
    CHECK(dut->group_targets == 0x0003, "Group targets = 0x0003");

    // T5: No match when group_count too small
    std::cout << "\n--- T5: group_count limits search ---" << std::endl;
    dut->group_count = 1;
    dut->addr_val = 0x30;
    tick();
    CHECK(dut->group_match == 0, "count=1: entry 1 not searched");

    // T6: Match on entry 3
    std::cout << "\n--- T6: Match on entry 3 ---" << std::endl;
    dut->group_table_3 = make_entry(0x50, 0x00FF);
    dut->group_count = 4;
    dut->addr_val = 0x50;
    tick();
    CHECK(dut->group_match == 1, "Match on addr 0x50");
    CHECK(dut->group_idx == 3, "Group idx = 3");
    CHECK(dut->group_targets == 0x00FF, "Group targets = 0x00FF");

    // T7: GETRTGL response
    std::cout << "\n--- T7: GETRTGL response ---" << std::endl;
    dut->ccc_getrtgl = 1;
    tick();
    dut->ccc_getrtgl = 0;
    CHECK(dut->ccc_response_valid == 1, "GETRTGL: response valid");
    // Response is [7:0] of table entry (reserved field)
    CHECK(1, "GETRTGL: response byte generated");

    // T8: Multiple GETRTGL cycles increment index
    std::cout << "\n--- T8: GETRTGL index increment ---" << std::endl;
    dut->ccc_getrtgl = 1;
    tick(); // idx=1
    tick(); // idx=2
    dut->ccc_getrtgl = 0;
    tick();
    CHECK(1, "GETRTGL: multiple cycles OK");

    // T9: Match on entry 7 (last)
    std::cout << "\n--- T9: Match on entry 7 ---" << std::endl;
    dut->group_table_7 = make_entry(0x7E, 0xFFFF);
    dut->group_count = 8;
    dut->addr_val = 0x7E;
    tick();
    CHECK(dut->group_match == 1, "Match on addr 0x7E");
    CHECK(dut->group_idx == 7, "Group idx = 7");
    CHECK(dut->group_targets == 0xFFFF, "Group targets = 0xFFFF");

    // T10: group_count=0 = no entries searched
    std::cout << "\n--- T10: group_count=0 ---" << std::endl;
    dut->group_count = 0;
    dut->addr_val = 0x08;
    tick();
    CHECK(dut->group_match == 0, "count=0: no match");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_group_addr SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
