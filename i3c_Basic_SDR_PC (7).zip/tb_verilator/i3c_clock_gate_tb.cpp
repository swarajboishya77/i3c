// tb_verilator/i3c_clock_gate_tb.cpp — Clock Gate unit test (Verilator)
// NOTE: AUTO_GATE=0 by default, so auto_gate_en/activity have NO effect.
// Only manual_gate_en matters: manual_gate_en=1 → gated, =0 → not gated
#include "verilated.h"
#include "Vi3c_clock_gate.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_clock_gate* dut;

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_clock_gate;

    dut->clk_in = 0; dut->rst_n = 0;
    dut->manual_gate_en = 0; dut->auto_gate_en = 0; dut->activity = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    dut->rst_n = 1; dut->eval();

    // T1: manual_gate_en=0 → not gated (clock passes)
    std::cout << "\n--- T1: manual_gate_en=0 (not gated) ---" << std::endl;
    dut->manual_gate_en = 0;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 0, "manual_gate_en=0: gated=0 (clock on)");

    // T2: manual_gate_en=1 → gated (clock off)
    std::cout << "\n--- T2: manual_gate_en=1 (gated) ---" << std::endl;
    dut->manual_gate_en = 1;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 1, "manual_gate_en=1: gated=1 (clock off)");

    // T3: Toggle manual_gate_en
    std::cout << "\n--- T3: Toggle manual_gate_en ---" << std::endl;
    dut->manual_gate_en = 0;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 0, "Toggle off: gated=0");
    dut->manual_gate_en = 1;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 1, "Toggle on: gated=1");

    // T4: clk_out follows clk_in when not gated
    // Latch-based: must go through falling edge (clk_in=0) to capture enable,
    // then rising edge (clk_in=1) to see clk_out=1
    std::cout << "\n--- T4: clk_out follows clk_in ---" << std::endl;
    dut->manual_gate_en = 0;
    dut->clk_in = 0; dut->eval(); // falling edge: latch captures enable=1
    dut->clk_in = 1; dut->eval(); // rising edge: clk_out = 1 && latched=1
    CHECK(dut->clk_out == 1, "clk_in=1, not gated: clk_out=1");
    dut->clk_in = 0; dut->eval();
    CHECK(dut->clk_out == 0, "clk_in=0, not gated: clk_out=0");

    // T5: clk_out is 0 when gated (manual_gate_en=1)
    std::cout << "\n--- T5: clk_out=0 when gated ---" << std::endl;
    dut->manual_gate_en = 1;
    dut->clk_in = 0; dut->eval(); // falling edge: latch captures enable=0
    dut->clk_in = 1; dut->eval(); // rising edge: clk_out = 1 && latched=0 = 0
    CHECK(dut->clk_out == 0, "clk_in=1, gated: clk_out=0");
    dut->clk_in = 0; dut->eval();
    CHECK(dut->clk_out == 0, "clk_in=0, gated: clk_out=0");

    // T6: auto_gate_en has no effect when AUTO_GATE=0
    std::cout << "\n--- T6: auto_gate_en no effect (AUTO_GATE=0) ---" << std::endl;
    dut->manual_gate_en = 0; dut->auto_gate_en = 1; dut->activity = 0;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 0, "auto_gate_en=1, no activity: still not gated (AUTO_GATE=0)");

    // T7: activity has no effect when AUTO_GATE=0
    std::cout << "\n--- T7: activity no effect (AUTO_GATE=0) ---" << std::endl;
    dut->activity = 1;
    for (int i = 0; i < 4; i++) {
        dut->clk_in = !dut->clk_in; dut->eval(); main_time++;
    }
    CHECK(dut->gated == 0, "activity=1: still not gated (AUTO_GATE=0)");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_clock_gate SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
