// tb_verilator/i3c_pec_tb.cpp — PEC CRC-8 unit test (Verilator)
#include "verilated.h"
#include "Vi3c_pec.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_pec* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

void feed_byte(uint8_t b) {
    dut->byte_valid = 1;
    dut->byte_in = b;
    dut->pec_byte_rx = 0;
    dut->pec_append = 0;
    tick();
    dut->byte_valid = 0;
}

void reset_crc() {
    dut->pec_reset = 1;
    tick();
    dut->pec_reset = 0;
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_pec;

    // Init
    dut->clk = 0; dut->rst_n = 0; dut->pec_en = 0; dut->pec_reset = 0;
    dut->byte_valid = 0; dut->byte_in = 0; dut->pec_byte_rx = 0;
    dut->pec_rx_value = 0; dut->pec_append = 0;
    dut->eval();

    // Reset
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: CRC of empty transfer = 0x00
    std::cout << "\n--- T1: CRC of empty transfer ---" << std::endl;
    dut->pec_en = 1;
    reset_crc();
    CHECK(dut->crc_out == 0x00, "CRC empty = 0x00");

    // T2: CRC of 0x00
    std::cout << "\n--- T2: CRC of 0x00 ---" << std::endl;
    reset_crc();
    feed_byte(0x00);
    CHECK(dut->crc_out == 0x00, "CRC(0x00) = 0x00");

    // T3: CRC of 0x01
    std::cout << "\n--- T3: CRC of 0x01 ---" << std::endl;
    reset_crc();
    feed_byte(0x01);
    // CRC-8(0x01) with poly 0x07: 0x01 -> 8 shifts = 0x07
    CHECK(dut->crc_out == 0x07, "CRC(0x01) = 0x07");

    // T4: CRC of 0xFF
    std::cout << "\n--- T4: CRC of 0xFF ---" << std::endl;
    reset_crc();
    feed_byte(0xFF);
    CHECK(dut->crc_out != 0x00, "CRC(0xFF) != 0x00");

    // T5: Multi-byte CRC (0x5A, 0xA5)
    std::cout << "\n--- T5: Multi-byte CRC ---" << std::endl;
    reset_crc();
    feed_byte(0x5A);
    feed_byte(0xA5);
    CHECK(dut->crc_out != 0x00, "CRC({0x5A, 0xA5}) != 0x00");

    // T6: PEC append (TX path)
    std::cout << "\n--- T6: PEC append ---" << std::endl;
    reset_crc();
    feed_byte(0x42);
    dut->pec_append = 1;
    tick();
    dut->pec_append = 0;
    CHECK(dut->pec_tx_valid == 1, "PEC TX valid after append");
    // pec_tx_value should be CRC of 0x42
    // On the next cycle, pec_tx_valid should deassert (1-cycle pulse)
    tick();
    CHECK(dut->pec_tx_valid == 0, "PEC TX valid deasserts (1-cycle pulse)");

    // T7: PEC check (RX path) — correct PEC
    std::cout << "\n--- T7: PEC check (correct) ---" << std::endl;
    reset_crc();
    feed_byte(0x42);
    uint8_t computed_crc = dut->crc_out;
    dut->pec_byte_rx = 1;
    dut->pec_rx_value = computed_crc; // correct PEC
    tick();
    dut->pec_byte_rx = 0;
    CHECK(dut->pec_error == 0, "PEC check: no error (correct PEC)");

    // T8: PEC check (RX path) — incorrect PEC
    std::cout << "\n--- T8: PEC check (incorrect) ---" << std::endl;
    reset_crc();
    feed_byte(0x42);
    dut->pec_byte_rx = 1;
    dut->pec_rx_value = computed_crc ^ 0xFF; // wrong PEC
    tick();
    dut->pec_byte_rx = 0;
    CHECK(dut->pec_error == 1, "PEC check: error (wrong PEC)");

    // T9: PEC disabled (pec_en=0) — no accumulation
    std::cout << "\n--- T9: PEC disabled ---" << std::endl;
    reset_crc();
    dut->pec_en = 0;
    feed_byte(0x55);
    CHECK(dut->crc_out == 0x00, "PEC disabled: CRC stays 0x00");
    dut->pec_en = 1;

    // T10: PEC reset clears CRC
    std::cout << "\n--- T10: PEC reset ---" << std::endl;
    feed_byte(0xAA);
    CHECK(dut->crc_out != 0x00, "Before reset: CRC != 0");
    reset_crc();
    CHECK(dut->crc_out == 0x00, "After reset: CRC = 0x00");

    // T11: Multi-byte CRC accumulates correctly
    std::cout << "\n--- T11: Multi-byte accumulation ---" << std::endl;
    reset_crc();
    feed_byte(0x01);
    uint8_t crc_after_01 = dut->crc_out;
    feed_byte(0x02);
    uint8_t crc_after_01_02 = dut->crc_out;
    CHECK(crc_after_01_02 != crc_after_01, "CRC changes after second byte");

    dut->final();
    delete dut;

    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_pec SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
