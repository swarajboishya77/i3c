// tb_verilator/i3c_wake_detector_tb.cpp — Wake Detector unit test (Verilator)
#include "verilated.h"
#include "Vi3c_wake_detector.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_wake_detector* dut;

void tick() {
    dut->clk_aon = 0; dut->eval(); main_time++;
    dut->clk_aon = 1; dut->eval(); main_time++;
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_wake_detector;

    dut->clk_aon = 0; dut->rst_aon_n = 0;
    dut->sda_raw = 1; dut->scl_raw = 1;
    dut->wake_en = 0; dut->wake_start_en = 0; dut->wake_scl_en = 0;
    dut->wake_clear = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_aon_n = 1;
    tick();

    // T1: Wake disabled = no detection
    std::cout << "\n--- T1: Wake disabled ---" << std::endl;
    dut->wake_en = 0;
    dut->sda_raw = 1; dut->scl_raw = 1; tick();
    dut->sda_raw = 0; // SDA falling while SCL high
    tick(); tick();
    CHECK(dut->wake_irq == 0, "Wake disabled: no irq");

    // T2: Wake via START (SDA falling while SCL high)
    std::cout << "\n--- T2: Wake via START ---" << std::endl;
    dut->wake_en = 1; dut->wake_start_en = 1;
    dut->sda_raw = 1; dut->scl_raw = 1; tick(); tick();
    dut->sda_raw = 0; // SDA falls while SCL high = START
    tick(); tick(); tick();
    CHECK(dut->wake_irq == 1, "Wake via START: irq asserted");
    CHECK(dut->wake_src_start == 1, "Wake source = START");

    // T3: Wake clear
    std::cout << "\n--- T3: Wake clear ---" << std::endl;
    dut->wake_clear = 1;
    tick();
    dut->wake_clear = 0;
    tick();
    CHECK(dut->wake_irq == 0, "Wake clear: irq deasserted");

    // T4: Wake via SCL edge
    std::cout << "\n--- T4: Wake via SCL edge ---" << std::endl;
    dut->wake_scl_en = 1; dut->wake_start_en = 0;
    dut->scl_raw = 1; dut->sda_raw = 1; tick(); tick();
    dut->scl_raw = 0; // SCL falling edge
    tick(); tick(); tick();
    CHECK(dut->wake_irq == 1, "Wake via SCL: irq asserted");
    CHECK(dut->wake_src_scl == 1, "Wake source = SCL");

    // T5: Wake clear
    std::cout << "\n--- T5: Wake clear (SCL) ---" << std::endl;
    dut->wake_clear = 1; tick(); dut->wake_clear = 0; tick();
    CHECK(dut->wake_irq == 0, "Wake clear: irq deasserted");

    // T6: No wake when SDA falls but SCL is low (not a START)
    std::cout << "\n--- T6: SCL low = no START wake ---" << std::endl;
    dut->wake_start_en = 1; dut->wake_scl_en = 0;
    dut->scl_raw = 0; dut->sda_raw = 1; tick(); tick();
    dut->sda_raw = 0; tick(); tick(); tick();
    CHECK(dut->wake_irq == 0, "SCL low: no START wake");
    dut->scl_raw = 1;

    // T7: Both wake sources enabled
    std::cout << "\n--- T7: Both wake sources ---" << std::endl;
    dut->wake_clear = 1; tick(); dut->wake_clear = 0; tick();
    dut->wake_start_en = 1; dut->wake_scl_en = 1;
    dut->sda_raw = 1; dut->scl_raw = 1; tick(); tick();
    dut->sda_raw = 0; tick(); tick(); tick();
    CHECK(dut->wake_irq == 1, "Both enabled: wake detected");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_wake_detector SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
