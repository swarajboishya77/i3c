// tb_verilator/i3c_hotjoin_handler_tb.cpp — HotJoin Handler unit test (Verilator)
#include "verilated.h"
#include "Vi3c_hotjoin_handler.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_hotjoin_handler* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_hotjoin_handler;

    dut->clk = 0; dut->rst_n = 0; dut->hj_enable = 0; dut->hj_auto_daa = 0;
    dut->controller_idle = 1; dut->bus_idle = 1;
    dut->sda_i = 1; dut->scl_i = 1; dut->hj_clear = 0; dut->ibi_active = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: HJ disabled = no detection
    std::cout << "\n--- T1: HJ disabled ---" << std::endl;
    dut->hj_enable = 0;
    dut->sda_i = 1; dut->scl_i = 1; tick();
    dut->sda_i = 0; tick(); // SDA falling while SCL high
    tick(); tick();
    CHECK(dut->hj_pending == 0, "HJ disabled: no pending");

    // T2: HJ enabled, SDA falling while SCL high = detection
    std::cout << "\n--- T2: HJ detection ---" << std::endl;
    dut->hj_enable = 1;
    dut->sda_i = 1; dut->scl_i = 1; tick(); tick();
    dut->sda_i = 0; // SDA falls while SCL high = HotJoin
    tick(); tick(); tick();
    CHECK(dut->hj_pending == 1, "HJ enabled: pending after detection");
    CHECK(dut->hj_detected == 1, "HJ detected flag set");

    // T3: HJ clear
    std::cout << "\n--- T3: HJ clear ---" << std::endl;
    dut->hj_clear = 1;
    tick();
    dut->hj_clear = 0;
    tick();
    CHECK(dut->hj_pending == 0, "HJ clear: pending cleared");

    // T4: HJ with auto-DAA
    // After T3's clear, need extra cycles for FSM to settle back to IDLE
    std::cout << "\n--- T4: HJ auto-DAA trigger ---" << std::endl;
    dut->hj_auto_daa = 1;
    // Wait for FSM to be fully back in IDLE
    for (int i = 0; i < 5; i++) tick();
    // Generate HJ event: SDA high, SCL high, then SDA falls
    dut->scl_i = 1; dut->sda_i = 1;
    tick(); tick(); // sda_prev settles to 1
    dut->sda_i = 0; // SDA falls while SCL high = HotJoin
    // Wait for detection + trigger sequence
    int triggered = 0;
    for (int i = 0; i < 10; i++) {
        tick();
        if (dut->hj_trigger_daa) triggered = 1;
    }
    CHECK(triggered == 1, "HJ auto-DAA: trigger fired");

    // T5: HJ not detected when controller busy
    std::cout << "\n--- T5: HJ suppressed when controller busy ---" << std::endl;
    dut->hj_clear = 1; tick(); dut->hj_clear = 0;
    dut->controller_idle = 0; dut->bus_idle = 0;
    dut->sda_i = 1; tick(); tick();
    dut->sda_i = 0; tick(); tick(); tick();
    CHECK(dut->hj_pending == 0, "Controller busy: no HJ detection");
    dut->controller_idle = 1; dut->bus_idle = 1;

    // T6: HJ suppressed when IBI active
    std::cout << "\n--- T6: HJ suppressed during IBI ---" << std::endl;
    dut->hj_clear = 1; tick(); dut->hj_clear = 0;
    dut->ibi_active = 1;
    dut->sda_i = 1; tick(); tick();
    dut->sda_i = 0; tick(); tick(); tick();
    CHECK(dut->hj_pending == 0, "IBI active: no HJ detection");
    dut->ibi_active = 0;

    // T7: HJ not detected when SCL is low (not a valid START)
    std::cout << "\n--- T7: SCL low = no HJ ---" << std::endl;
    dut->hj_clear = 1; tick(); dut->hj_clear = 0;
    dut->sda_i = 1; dut->scl_i = 0; tick(); tick();
    dut->sda_i = 0; tick(); tick(); tick(); // SDA falls but SCL is low
    CHECK(dut->hj_pending == 0, "SCL low: no HJ detection");
    dut->scl_i = 1;

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_hotjoin_handler SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
