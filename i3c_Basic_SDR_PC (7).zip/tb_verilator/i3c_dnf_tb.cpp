// tb_verilator/i3c_dnf_tb.cpp — Digital Noise Filter unit test (Verilator)
#include "verilated.h"
#include "Vi3c_dnf.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_dnf* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

// Wait for filter to settle (extra cycles for safety)
void settle(int n) { for (int i = 0; i < n; i++) tick(); }

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_dnf;

    dut->clk = 0; dut->rst_n = 0; dut->dnf_threshold = 0; dut->dnf_enable = 0;
    dut->sda_raw = 1; dut->scl_raw = 1;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: DNF disabled = passthrough
    std::cout << "\n--- T1: DNF disabled (passthrough) ---" << std::endl;
    dut->dnf_enable = 0;
    dut->sda_raw = 0; tick();
    CHECK(dut->sda_filtered == 0, "DNF disabled: sda_filtered follows sda_raw=0");
    dut->sda_raw = 1; tick();
    CHECK(dut->sda_filtered == 1, "DNF disabled: sda_filtered follows sda_raw=1");

    // T2: DNF enabled, threshold=0 = bypass
    std::cout << "\n--- T2: DNF threshold=0 (bypass) ---" << std::endl;
    dut->dnf_enable = 1; dut->dnf_threshold = 0;
    dut->sda_raw = 0; tick();
    CHECK(dut->sda_filtered == 0, "Threshold=0: sda_filtered=0");
    dut->sda_raw = 1; tick();
    CHECK(dut->sda_filtered == 1, "Threshold=0: sda_filtered=1");

    // T3: DNF enabled, threshold=1 (2 samples must agree)
    std::cout << "\n--- T3: DNF threshold=1 ---" << std::endl;
    dut->dnf_enable = 1; dut->dnf_threshold = 1;
    dut->sda_raw = 1; settle(5);
    CHECK(dut->sda_filtered == 1, "Threshold=1: stable high → filtered=1");

    // Transition to low: need 2 stable samples
    dut->sda_raw = 0; tick(); tick(); tick(); // 3 cycles stable
    CHECK(dut->sda_filtered == 0, "Threshold=1: stable low → filtered=0");

    // Back to high
    dut->sda_raw = 1; tick(); tick(); tick();
    CHECK(dut->sda_filtered == 1, "Threshold=1: stable high → filtered=1");

    // T4: Glitch rejection (threshold=1) — filter has 1-cycle latency
    // A 1-cycle input glitch may cause a brief output transition, but the
    // output should recover to stable high after the glitch passes.
    std::cout << "\n--- T4: Glitch rejection (threshold=1) ---" << std::endl;
    dut->sda_raw = 0; tick(); // 1 cycle low (glitch)
    dut->sda_raw = 1; tick(); tick(); tick(); tick(); tick(); // back high, settle
    CHECK(dut->sda_filtered == 1, "Threshold=1: output recovers after glitch");

    // T5: DNF threshold=3 (4 samples must agree)
    std::cout << "\n--- T5: DNF threshold=3 ---" << std::endl;
    dut->dnf_enable = 1; dut->dnf_threshold = 3;
    dut->sda_raw = 1; settle(6);
    CHECK(dut->sda_filtered == 1, "Threshold=3: stable high → filtered=1");

    // Stable low: need 4+ samples
    dut->sda_raw = 0; settle(6);
    CHECK(dut->sda_filtered == 0, "Threshold=3: 6-cycle stable low → filtered=0");

    // T6: SCL filtering
    std::cout << "\n--- T6: SCL filtering ---" << std::endl;
    dut->dnf_threshold = 0; // bypass
    dut->scl_raw = 0; tick();
    CHECK(dut->scl_filtered == 0, "SCL bypass: filtered=0");
    dut->scl_raw = 1; tick();
    CHECK(dut->scl_filtered == 1, "SCL bypass: filtered=1");

    // T7: threshold=2 (3 samples)
    std::cout << "\n--- T7: DNF threshold=2 ---" << std::endl;
    dut->dnf_enable = 1; dut->dnf_threshold = 2;
    dut->sda_raw = 1; settle(5);
    CHECK(dut->sda_filtered == 1, "Threshold=2: stable high → filtered=1");
    dut->sda_raw = 0; settle(5);
    CHECK(dut->sda_filtered == 0, "Threshold=2: stable low → filtered=0");

    // T8: Toggle enable/disable
    std::cout << "\n--- T8: Enable/disable toggle ---" << std::endl;
    dut->dnf_enable = 0;
    dut->sda_raw = 1; tick();
    CHECK(dut->sda_filtered == 1, "Disabled: passthrough=1");
    dut->sda_raw = 0; tick();
    CHECK(dut->sda_filtered == 0, "Disabled: passthrough=0");

    // T9: Maximum threshold (15)
    std::cout << "\n--- T9: DNF threshold=15 (max) ---" << std::endl;
    dut->dnf_enable = 1; dut->dnf_threshold = 15;
    dut->sda_raw = 1; settle(20);
    CHECK(dut->sda_filtered == 1, "Threshold=15: stable high → filtered=1");
    dut->sda_raw = 0; settle(20);
    CHECK(dut->sda_filtered == 0, "Threshold=15: stable low → filtered=0");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_dnf SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
