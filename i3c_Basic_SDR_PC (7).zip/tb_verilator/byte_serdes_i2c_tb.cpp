// tb_verilator/byte_serdes_i2c_tb.cpp — I2C Byte SerDes unit test (Verilator)
// The serdes asserts cmd_bit_xfer and waits for phy_done on the SAME cycle.
// We must provide phy_done on a cycle where cmd_bit_xfer is high.
#include "verilated.h"
#include "Vbyte_serdes_i2c.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vbyte_serdes_i2c* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

// Wait until cmd_bit_xfer is high, then provide phy_done on the same cycle
void do_one_bit(uint8_t sda_val) {
    dut->phy_done = 0;
    dut->sda_sampled = sda_val;
    // Wait for cmd_bit_xfer (max 10 cycles for safety)
    for (int i = 0; i < 10; i++) {
        tick();
        if (dut->cmd_bit_xfer || dut->byte_done) break;
    }
    // Provide phy_done on the next cycle (while cmd_bit_xfer is still high)
    if (dut->cmd_bit_xfer) {
        dut->phy_done = 1;
        tick();
        dut->phy_done = 0;
    }
}

// Process a full byte: 8 data bits + 1 ACK/NACK bit
void do_full_byte(uint8_t sda_9th) {
    for (int bit = 0; bit < 8; bit++) {
        do_one_bit(1);
    }
    do_one_bit(sda_9th);
    // Wait for byte_done to be visible (may need a few extra cycles)
    for (int i = 0; i < 5; i++) {
        if (dut->byte_done) break;
        tick();
    }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vbyte_serdes_i2c;

    dut->clk = 0; dut->rst_n = 0;
    dut->req_send_byte = 0; dut->req_recv_byte = 0;
    dut->byte_tx = 0; dut->is_last_byte = 0;
    dut->phy_done = 0; dut->sda_sampled = 1;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: Idle
    std::cout << "\n--- T1: Idle ---" << std::endl;
    CHECK(dut->busy == 0, "SerDes not busy in idle");

    // T2: Send byte 0x55 (target ACKs)
    std::cout << "\n--- T2: Send byte 0x55 ---" << std::endl;
    dut->byte_tx = 0x55;
    dut->req_send_byte = 1;
    tick();
    dut->req_send_byte = 0;
    do_full_byte(0); // ACK
    CHECK(dut->byte_done == 1, "Send byte done");
    CHECK(dut->ack_received == 1, "ACK received");

    // T3: Send byte 0xFF (target NACKs)
    std::cout << "\n--- T3: Send byte 0xFF (NACK) ---" << std::endl;
    tick(); tick(); // settle between bytes
    dut->byte_tx = 0xFF;
    dut->req_send_byte = 1;
    tick();
    dut->req_send_byte = 0;
    do_full_byte(1); // NACK
    CHECK(dut->byte_done == 1, "Send byte done");
    CHECK(dut->ack_received == 0, "NACK received");

    // T4: Receive byte (controller ACKs)
    std::cout << "\n--- T4: Receive byte ---" << std::endl;
    tick(); tick();
    dut->req_recv_byte = 1;
    dut->is_last_byte = 0;
    tick();
    dut->req_recv_byte = 0;
    do_full_byte(0);
    CHECK(dut->byte_done == 1, "Receive byte done");

    // T5: Receive last byte (controller NACKs)
    std::cout << "\n--- T5: Receive last byte (NACK) ---" << std::endl;
    tick(); tick();
    dut->req_recv_byte = 1;
    dut->is_last_byte = 1;
    tick();
    dut->req_recv_byte = 0;
    do_full_byte(1);
    CHECK(dut->byte_done == 1, "Receive last byte done");

    // T6: Open-drain mode
    std::cout << "\n--- T6: Open-drain mode ---" << std::endl;
    CHECK(dut->mode_pushpull == 0, "I2C always open-drain");

    // T7: Send byte 0x00
    std::cout << "\n--- T7: Send byte 0x00 ---" << std::endl;
    tick(); tick();
    dut->byte_tx = 0x00;
    dut->req_send_byte = 1;
    tick();
    dut->req_send_byte = 0;
    do_full_byte(0);
    CHECK(dut->byte_done == 1, "Send 0x00 done");

    // T8: Multiple consecutive bytes
    std::cout << "\n--- T8: Multiple bytes ---" << std::endl;
    for (int i = 0; i < 3; i++) {
        tick(); tick();
        dut->byte_tx = 0x10 + i;
        dut->req_send_byte = 1;
        tick();
        dut->req_send_byte = 0;
        do_full_byte(0);
        CHECK(dut->byte_done == 1, "Consecutive byte done");
    }

    // T9: Check busy deasserts
    std::cout << "\n--- T9: Busy deasserts ---" << std::endl;
    tick(); tick();
    CHECK(dut->busy == 0, "Busy deasserts after done");

    // T10: Send + Receive interleaved
    std::cout << "\n--- T10: Interleaved ---" << std::endl;
    tick(); tick(); tick(); // extra settle
    dut->byte_tx = 0x33;
    dut->req_send_byte = 1; tick(); dut->req_send_byte = 0;
    do_full_byte(0);
    CHECK(dut->byte_done == 1, "Send before receive done");
    tick(); tick(); tick(); // extra settle
    dut->req_recv_byte = 1; tick(); dut->req_recv_byte = 0;
    do_full_byte(0);
    CHECK(dut->byte_done == 1, "Receive after send done");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "byte_serdes_i2c SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
