#!/bin/bash
# run_all_verilator.sh — Build and run all Verilator testbenches
export PATH=/home/z/my-project/tools/verilator/usr/bin:$PATH
RTL_DIR=/home/z/my-project/download/i3c_controller_rtl
cd "$RTL_DIR"

VFLAGS="--cc --exe --build -Wno-DECLFILENAME -Wno-UNUSED -Wno-WIDTH -Wno-UNDRIVEN -Wno-CASEINCOMPLETE -Wno-PINMISSING -Wno-IMPLICIT -Wno-LITENDIAN -Wno-IMPORTSTAR -Wno-PINCONNECTEMPTY -Wno-BLKSEQ -Wno-COMBDLY -Wno-SYNCASYNCNET -Wno-MULTIDRIVEN -Wno-UNOPT -Wno-WIDTHCONCAT -Wno-UNSIGNED -Wno-TIMESCALEMOD -Wno-fatal"

# Test definitions: "name|rtl_file(s)|top_module"
TESTS=(
    "i3c_pec|rtl/pec/i3c_pec.sv|i3c_pec"
    "i3c_dnf|rtl/dnf/i3c_dnf.sv|i3c_dnf"
    "i3c_clock_gate|rtl/clock/i3c_clock_gate.sv|i3c_clock_gate"
    "i3c_group_addr|rtl/group/i3c_group_addr.sv|i3c_group_addr"
    "i3c_hotjoin_handler|rtl/hj/i3c_hotjoin_handler.sv|i3c_hotjoin_handler"
    "i3c_wake_detector|rtl/wake/i3c_wake_detector.sv|i3c_wake_detector"
    "i2c_prescaler|rtl/controller/i2c_prescaler.sv|i2c_prescaler"
    "i3c_start_stop_gen|rtl/include/i3c_pkg.sv rtl/digital_phy/i3c_start_stop_gen.sv|i3c_start_stop_gen"
    "byte_serdes_i3c|rtl/pec/i3c_pec.sv rtl/controller/byte_serdes_i3c.sv|byte_serdes_i3c"
    "byte_serdes_i2c|rtl/controller/byte_serdes_i2c.sv|byte_serdes_i2c"
)

echo "============================================================"
echo "Verilator Testbench Suite — I3C Controller IP"
echo "Verilator 5.032 + g++ 14.2"
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo "============================================================"
echo ""

TOTAL_PASS=0
TOTAL_FAIL=0
ALL_PASS=1

for entry in "${TESTS[@]}"; do
    IFS='|' read -r name rtl_files top <<< "$entry"
    
    echo "--- Building $name ---"
    rm -rf obj_dir
    
    output=$(verilator $VFLAGS --top-module $top -y rtl +incdir+rtl/include \
             $rtl_files "tb_verilator/${name}_tb.cpp" 2>&1)
    
    if [ $? -ne 0 ]; then
        echo "  COMPILE FAILED for $name"
        echo "$output" | tail -5
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        ALL_PASS=0
        echo ""
        continue
    fi
    
    echo "  Compile: OK"
    result=$(obj_dir/V${top} 2>&1)
    summary=$(echo "$result" | grep "SUMMARY:")
    
    if [ -z "$summary" ]; then
        echo "  RUN FAILED for $name (no summary)"
        echo "$result" | tail -10
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        ALL_PASS=0
    else
        echo "  $summary"
        p=$(echo "$summary" | grep -oP '\d+(?= PASS)' || echo 0)
        f=$(echo "$summary" | grep -oP '\d+(?= FAIL)' || echo 0)
        TOTAL_PASS=$((TOTAL_PASS + p))
        TOTAL_FAIL=$((TOTAL_FAIL + f))
        [ "$f" -ne 0 ] && ALL_PASS=0
    fi
    echo ""
done

rm -rf obj_dir

echo "============================================================"
echo "VERILATOR TESTBENCH SUMMARY"
echo "============================================================"
echo "Total tests:        $((TOTAL_PASS + TOTAL_FAIL))"
echo "  PASS:             $TOTAL_PASS"
echo "  FAIL:             $TOTAL_FAIL"
echo ""

if [ "$ALL_PASS" -eq 1 ] && [ "$TOTAL_FAIL" -eq 0 ]; then
    echo "RESULT: ALL TESTS PASS ✓"
else
    echo "RESULT: FAILURES DETECTED"
fi
echo "============================================================"
