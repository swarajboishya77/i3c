// tb_verilator/i3c_start_stop_gen_tb.cpp — Start/Stop Generator unit test (Verilator)
#include "verilated.h"
#include "Vi3c_start_stop_gen.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi3c_start_stop_gen* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

// Wait for done with timeout
void wait_done(int max_cycles) {
    for (int i = 0; i < max_cycles; i++) {
        tick();
        if (dut->done) return;
    }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi3c_start_stop_gen;

    dut->clk = 0; dut->rst_n = 0;
    dut->cfg_tsu_start = 2; dut->cfg_thd_start = 2;
    dut->cfg_tsu_stop = 2; dut->cfg_bus_free_time = 4;
    dut->cmd_start = 0; dut->cmd_repeat_start = 0;
    dut->cmd_stop = 0; dut->cmd_release = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: Idle state — outputs high-Z
    std::cout << "\n--- T1: Idle state ---" << std::endl;
    CHECK(dut->busy == 0, "Not busy in idle");
    CHECK(dut->sda_oe == 0, "SDA oe=0 (high-Z) in idle");
    CHECK(dut->scl_oe == 0, "SCL oe=0 (high-Z) in idle");

    // T2: START condition
    std::cout << "\n--- T2: START condition ---" << std::endl;
    dut->cmd_start = 1;
    tick();
    dut->cmd_start = 0;
    CHECK(dut->busy == 1, "Busy after START command");
    wait_done(20);
    CHECK(dut->done == 1, "START done");
    // After START: SDA should be low, SCL should be low (or driven)
    tick();

    // T3: STOP condition
    std::cout << "\n--- T3: STOP condition ---" << std::endl;
    dut->cmd_stop = 1;
    tick();
    dut->cmd_stop = 0;
    CHECK(dut->busy == 1, "Busy after STOP command");
    wait_done(20);
    CHECK(dut->done == 1, "STOP done");

    // T4: Repeated START
    std::cout << "\n--- T4: Repeated START ---" << std::endl;
    dut->cmd_repeat_start = 1;
    tick();
    dut->cmd_repeat_start = 0;
    CHECK(dut->busy == 1, "Busy after Repeated START");
    wait_done(20);
    CHECK(dut->done == 1, "Repeated START done");

    // T5: Release bus
    std::cout << "\n--- T5: Release bus ---" << std::endl;
    dut->cmd_release = 1;
    tick();
    dut->cmd_release = 0;
    wait_done(10);
    CHECK(dut->done == 1, "Release done");
    tick();
    CHECK(dut->sda_oe == 0, "After release: SDA high-Z");
    CHECK(dut->scl_oe == 0, "After release: SCL high-Z");

    // T6: START with larger timing parameters
    std::cout << "\n--- T6: START with larger timing ---" << std::endl;
    dut->cfg_tsu_start = 10; dut->cfg_thd_start = 10;
    dut->cmd_start = 1;
    tick();
    dut->cmd_start = 0;
    CHECK(dut->busy == 1, "Busy with larger timing");
    wait_done(50);
    CHECK(dut->done == 1, "START done (larger timing)");

    // T7: STOP after START
    std::cout << "\n--- T7: STOP after START ---" << std::endl;
    dut->cfg_tsu_start = 2; dut->cfg_thd_start = 2; dut->cfg_tsu_stop = 2;
    dut->cmd_start = 1; tick(); dut->cmd_start = 0;
    wait_done(20);
    dut->cmd_stop = 1; tick(); dut->cmd_stop = 0;
    wait_done(20);
    CHECK(dut->done == 1, "STOP after START done");

    // T8: Multiple START-STOP cycles
    std::cout << "\n--- T8: Multiple START-STOP cycles ---" << std::endl;
    for (int i = 0; i < 3; i++) {
        dut->cmd_start = 1; tick(); dut->cmd_start = 0;
        wait_done(20);
        CHECK(dut->done == 1, "START in cycle");
        dut->cmd_stop = 1; tick(); dut->cmd_stop = 0;
        wait_done(20);
        CHECK(dut->done == 1, "STOP in cycle");
    }

    // T9: Bus free time enforced
    std::cout << "\n--- T9: Bus free time ---" << std::endl;
    dut->cfg_bus_free_time = 10;
    dut->cmd_stop = 1; tick(); dut->cmd_stop = 0;
    int cycles = 0;
    while (!dut->done && cycles < 50) {
        tick();
        cycles++;
    }
    CHECK(dut->done == 1, "STOP with bus_free_time done");
    CHECK(cycles > 5, "Bus free time took multiple cycles");

    // T10: No spurious done when idle
    std::cout << "\n--- T10: No spurious done ---" << std::endl;
    dut->cmd_start = 0; dut->cmd_stop = 0; dut->cmd_repeat_start = 0; dut->cmd_release = 0;
    for (int i = 0; i < 5; i++) tick();
    CHECK(dut->done == 0, "No spurious done in idle");

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i3c_start_stop_gen SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
