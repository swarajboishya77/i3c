// tb_verilator/i2c_prescaler_tb.cpp — I2C Prescaler unit test (Verilator)
#include "verilated.h"
#include "Vi2c_prescaler.h"
#include <iostream>
#include <cstdint>

vluint64_t main_time = 0;
double sc_time_stamp() { return main_time; }

static int pass_cnt = 0, fail_cnt = 0;
#define CHECK(cond, msg) do { \
    if (cond) { std::cout << "[PASS] " << msg << std::endl; pass_cnt++; } \
    else { std::cout << "[FAIL] " << msg << std::endl; fail_cnt++; } \
} while(0)

Vi2c_prescaler* dut;

void tick() {
    dut->clk = 0; dut->eval(); main_time++;
    dut->clk = 1; dut->eval(); main_time++;
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    dut = new Vi2c_prescaler;

    dut->clk = 0; dut->rst_n = 0; dut->speed_prescaler = 0;
    dut->eval();
    for (int i = 0; i < 5; i++) tick();
    dut->rst_n = 1;
    tick();

    // T1: Prescaler not programmed (0) = safe default
    std::cout << "\n--- T1: Prescaler=0 (default) ---" << std::endl;
    dut->speed_prescaler = 0;
    tick();
    CHECK(dut->prescaler_active == 0, "Prescaler=0: not active");
    CHECK(dut->i2c_scl_high_time > 0, "Default high time > 0");
    CHECK(dut->i2c_scl_low_time > 0, "Default low time > 0");

    // T2: Program prescaler for Fm+ (50 cycles at 100MHz = 1MHz)
    std::cout << "\n--- T2: Fm+ prescaler (50) ---" << std::endl;
    dut->speed_prescaler = 50;
    tick();
    CHECK(dut->prescaler_active == 1, "Prescaler=50: active");
    CHECK(dut->i2c_scl_high_time > 0, "High time > 0");
    CHECK(dut->i2c_scl_low_time > 0, "Low time > 0");

    // T3: Program different prescaler
    std::cout << "\n--- T3: Standard mode (500) ---" << std::endl;
    dut->speed_prescaler = 500;
    tick();
    CHECK(dut->prescaler_active == 1, "Prescaler=500: active");
    uint32_t high_500 = dut->i2c_scl_high_time;
    uint32_t low_500 = dut->i2c_scl_low_time;

    // T4: Higher prescaler = longer times
    std::cout << "\n--- T4: Slower speed (1000) ---" << std::endl;
    dut->speed_prescaler = 1000;
    tick();
    CHECK(dut->prescaler_active == 1, "Prescaler=1000: active");
    CHECK(dut->i2c_scl_high_time > high_500, "1000 > 500 high time");
    CHECK(dut->i2c_scl_low_time > low_500, "1000 > 500 low time");

    // T5: Back to 0 = default
    std::cout << "\n--- T5: Back to 0 ---" << std::endl;
    dut->speed_prescaler = 0;
    tick();
    CHECK(dut->prescaler_active == 0, "Back to 0: not active");

    // T6: Prescaler = 1 (minimum)
    std::cout << "\n--- T6: Minimum prescaler (1) ---" << std::endl;
    dut->speed_prescaler = 1;
    tick();
    CHECK(dut->prescaler_active == 1, "Prescaler=1: active");
    CHECK(dut->i2c_scl_high_time > 0, "Min high time > 0");

    // T7: High time + low time = full period
    std::cout << "\n--- T7: Period calculation ---" << std::endl;
    dut->speed_prescaler = 100;
    tick();
    uint32_t high = dut->i2c_scl_high_time;
    uint32_t low = dut->i2c_scl_low_time;
    CHECK(high + low > 0, "Period > 0");
    std::cout << "  high=" << high << " low=" << low << " period=" << (high+low) << std::endl;

    dut->final();
    delete dut;
    std::cout << "\n========================================" << std::endl;
    std::cout << "i2c_prescaler SUMMARY: " << pass_cnt << " PASS, " << fail_cnt << " FAIL" << std::endl;
    std::cout << "========================================" << std::endl;
    return fail_cnt > 0 ? 1 : 0;
}
