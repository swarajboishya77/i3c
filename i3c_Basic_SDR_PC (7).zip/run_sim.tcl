# XSIM TCL script — run simulation and show all output
run all
exit
